/* File generated on Tue Oct  2 00:23:47 EDT 2012
by getwhitespace <UnicodeData.txt */

#define SPACECASE16	SPACECASE8 \
case 0x1680:\
case 0x180e:\
case 0x2000:\
case 0x2001:\
case 0x2002:\
case 0x2003:\
case 0x2004:\
case 0x2005:\
case 0x2006:\
case 0x2007:\
case 0x2008:\
case 0x2009:\
case 0x200a:\
case 0x2028:\
case 0x2029:\
case 0x202f:\
case 0x205f:\
case 0x3000:\

