/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 01597aa76601a3155fa0829095713390e41c2a85 $
*/

#include "global.h"
#include "svalue.h"
#include "interpret.h"
#include "stralloc.h"
#include "version.h"

RCSID("$Id: 01597aa76601a3155fa0829095713390e41c2a85 $");

/*! @decl string version()
 *!
 *! Report the version of Pike. Does the same as
 *! @code
 *! sprintf("Pike v%d.%d release %d", __REAL_VERSION__,
 *!         __REAL_MINOR__, __REAL_BUILD__);
 *! @endcode
 *!
 *! @seealso
 *!   @[__VERSION__], @[__MINOR__], @[__BUILD__],
 *!   @[__REAL_VERSION__], @[__REAL_MINOR__], @[__REAL_BUILD__],
 */
void f_version(INT32 args)
{
  pop_n_elems(args);
  push_constant_text ("Pike v"
		      DEFINETOSTR (PIKE_MAJOR_VERSION)
		      "."
		      DEFINETOSTR (PIKE_MINOR_VERSION)
		      " release "
		      DEFINETOSTR (PIKE_BUILD_VERSION));
}
