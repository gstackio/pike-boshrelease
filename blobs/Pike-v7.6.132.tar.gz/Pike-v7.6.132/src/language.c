/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_ARROW = 258,
     TOK_CONSTANT = 259,
     TOK_FLOAT = 260,
     TOK_STRING = 261,
     TOK_NUMBER = 262,
     TOK_INC = 263,
     TOK_DEC = 264,
     TOK_RETURN = 265,
     TOK_EQ = 266,
     TOK_GE = 267,
     TOK_LE = 268,
     TOK_NE = 269,
     TOK_NOT = 270,
     TOK_LSH = 271,
     TOK_RSH = 272,
     TOK_LAND = 273,
     TOK_LOR = 274,
     TOK_SWITCH = 275,
     TOK_SSCANF = 276,
     TOK_CATCH = 277,
     TOK_FOREACH = 278,
     TOK_LEX_EOF = 279,
     TOK_ADD_EQ = 280,
     TOK_AND_EQ = 281,
     TOK_ARRAY_ID = 282,
     TOK_BREAK = 283,
     TOK_CASE = 284,
     TOK_CLASS = 285,
     TOK_COLON_COLON = 286,
     TOK_CONTINUE = 287,
     TOK_DEFAULT = 288,
     TOK_DIV_EQ = 289,
     TOK_DO = 290,
     TOK_DOT_DOT = 291,
     TOK_DOT_DOT_DOT = 292,
     TOK_ELSE = 293,
     TOK_ENUM = 294,
     TOK_EXTERN = 295,
     TOK_FLOAT_ID = 296,
     TOK_FOR = 297,
     TOK_FUNCTION_ID = 298,
     TOK_GAUGE = 299,
     TOK_GLOBAL = 300,
     TOK_IDENTIFIER = 301,
     TOK_IF = 302,
     TOK_IMPORT = 303,
     TOK_INHERIT = 304,
     TOK_INLINE = 305,
     TOK_LOCAL_ID = 306,
     TOK_FINAL_ID = 307,
     TOK_INT_ID = 308,
     TOK_LAMBDA = 309,
     TOK_MULTISET_ID = 310,
     TOK_MULTISET_END = 311,
     TOK_MULTISET_START = 312,
     TOK_LSH_EQ = 313,
     TOK_MAPPING_ID = 314,
     TOK_MIXED_ID = 315,
     TOK_MOD_EQ = 316,
     TOK_MULT_EQ = 317,
     TOK_NO_MASK = 318,
     TOK_OBJECT_ID = 319,
     TOK_OR_EQ = 320,
     TOK_PRIVATE = 321,
     TOK_PROGRAM_ID = 322,
     TOK_PROTECTED = 323,
     TOK_PREDEF = 324,
     TOK_PUBLIC = 325,
     TOK_RSH_EQ = 326,
     TOK_STATIC = 327,
     TOK_STRING_ID = 328,
     TOK_SUB_EQ = 329,
     TOK_TYPEDEF = 330,
     TOK_TYPEOF = 331,
     TOK_VARIANT = 332,
     TOK_VOID_ID = 333,
     TOK_WHILE = 334,
     TOK_XOR_EQ = 335,
     TOK_OPTIONAL = 336
   };
#endif
/* Tokens.  */
#define TOK_ARROW 258
#define TOK_CONSTANT 259
#define TOK_FLOAT 260
#define TOK_STRING 261
#define TOK_NUMBER 262
#define TOK_INC 263
#define TOK_DEC 264
#define TOK_RETURN 265
#define TOK_EQ 266
#define TOK_GE 267
#define TOK_LE 268
#define TOK_NE 269
#define TOK_NOT 270
#define TOK_LSH 271
#define TOK_RSH 272
#define TOK_LAND 273
#define TOK_LOR 274
#define TOK_SWITCH 275
#define TOK_SSCANF 276
#define TOK_CATCH 277
#define TOK_FOREACH 278
#define TOK_LEX_EOF 279
#define TOK_ADD_EQ 280
#define TOK_AND_EQ 281
#define TOK_ARRAY_ID 282
#define TOK_BREAK 283
#define TOK_CASE 284
#define TOK_CLASS 285
#define TOK_COLON_COLON 286
#define TOK_CONTINUE 287
#define TOK_DEFAULT 288
#define TOK_DIV_EQ 289
#define TOK_DO 290
#define TOK_DOT_DOT 291
#define TOK_DOT_DOT_DOT 292
#define TOK_ELSE 293
#define TOK_ENUM 294
#define TOK_EXTERN 295
#define TOK_FLOAT_ID 296
#define TOK_FOR 297
#define TOK_FUNCTION_ID 298
#define TOK_GAUGE 299
#define TOK_GLOBAL 300
#define TOK_IDENTIFIER 301
#define TOK_IF 302
#define TOK_IMPORT 303
#define TOK_INHERIT 304
#define TOK_INLINE 305
#define TOK_LOCAL_ID 306
#define TOK_FINAL_ID 307
#define TOK_INT_ID 308
#define TOK_LAMBDA 309
#define TOK_MULTISET_ID 310
#define TOK_MULTISET_END 311
#define TOK_MULTISET_START 312
#define TOK_LSH_EQ 313
#define TOK_MAPPING_ID 314
#define TOK_MIXED_ID 315
#define TOK_MOD_EQ 316
#define TOK_MULT_EQ 317
#define TOK_NO_MASK 318
#define TOK_OBJECT_ID 319
#define TOK_OR_EQ 320
#define TOK_PRIVATE 321
#define TOK_PROGRAM_ID 322
#define TOK_PROTECTED 323
#define TOK_PREDEF 324
#define TOK_PUBLIC 325
#define TOK_RSH_EQ 326
#define TOK_STATIC 327
#define TOK_STRING_ID 328
#define TOK_SUB_EQ 329
#define TOK_TYPEDEF 330
#define TOK_TYPEOF 331
#define TOK_VARIANT 332
#define TOK_VOID_ID 333
#define TOK_WHILE 334
#define TOK_XOR_EQ 335
#define TOK_OPTIONAL 336




/* Copy the first part of user declarations.  */
#line 112 "language.yacc"

/* This is the grammar definition of Pike. */

#include "global.h"
RCSID("$Id: 1e95e178f1ae9c517e3def0b1a0e1b25cdfb7569 $");
#ifdef HAVE_MEMORY_H
#include <memory.h>
#endif

#include "interpret.h"
#include "array.h"
#include "object.h"
#include "stralloc.h"
#include "las.h"
#include "interpret.h"
#include "program.h"
#include "pike_types.h"
#include "constants.h"
#include "pike_macros.h"
#include "pike_error.h"
#include "docode.h"
#include "machine.h"
#include "main.h"
#include "opcodes.h"
#include "operators.h"
#include "bignum.h"

#define YYMAXDEPTH	1000

#ifdef PIKE_DEBUG
#ifndef YYDEBUG
/* May also be defined by machine.h */
#define YYDEBUG 1
#endif /* YYDEBUG */
#endif

/* Get verbose parse error reporting. */
#define YYERROR_VERBOSE	1

/* #define LAMBDA_DEBUG	1 */

int add_local_name(struct pike_string *, struct pike_type *, node *);
int low_add_local_name(struct compiler_frame *,
		       struct pike_string *, struct pike_type *, node *);
static node *lexical_islocal(struct pike_string *);
static void safe_inc_enum(void);
static int call_handle_import(struct pike_string *s);

static int inherit_depth;
static struct program_state *inherit_state = NULL;

/*
 * Kludge for Bison not using prototypes.
 */
#ifndef __GNUC__
#ifndef __cplusplus
static void __yy_memcpy(char *to, const char *from,
			unsigned int count);
#endif /* !__cplusplus */
#endif /* !__GNUC__ */



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 176 "language.yacc"
{
  int number;
  FLOAT_TYPE fnum;
  struct node_s *n;
  char *str;
  void *ptr;
}
/* Line 193 of yacc.c.  */
#line 329 "y.tab.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */
#line 184 "language.yacc"

/* Needs to be included after YYSTYPE is defined. */
#define INCLUDED_FROM_LANGUAGE_YACC
#include "lex.h"
#line 190 "language.yacc"

/* Include <stdio.h> our selves, so that we can do our magic
 * without being disturbed... */
#include <stdio.h>
int yylex(YYSTYPE *yylval);
/* Bison is stupid, and tries to optimize for space... */
#ifdef YYBISON
#define short int
#endif /* YYBISON */



/* Line 216 of yacc.c.  */
#line 358 "y.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef /* short */ int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned /* short */ int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef /* short */ int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   8557

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  106
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  191
/* YYNRULES -- Number of rules.  */
#define YYNRULES  620
/* YYNRULES -- Number of states.  */
#define YYNSTATES  923

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   336

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    92,    86,     2,
      99,   100,    91,    89,    98,    90,   105,    93,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    96,    95,
      88,    82,    87,    83,   104,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   101,     2,   102,    85,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   103,    84,    97,    94,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     8,    11,    14,    15,    17,    21,
      24,    27,    30,    31,    33,    35,    37,    38,    41,    47,
      53,    59,    65,    70,    75,    80,    84,    88,    92,    96,
     100,   104,   108,   112,   114,   118,   123,   128,   133,   138,
     140,   142,   144,   146,   148,   150,   152,   153,   155,   156,
     158,   160,   162,   164,   165,   166,   167,   178,   185,   186,
     196,   201,   203,   205,   207,   209,   211,   213,   216,   219,
     222,   223,   229,   231,   233,   234,   236,   238,   239,   243,
     247,   249,   252,   254,   258,   262,   264,   266,   268,   270,
     272,   274,   276,   278,   280,   282,   284,   286,   288,   290,
     292,   294,   296,   298,   300,   302,   304,   306,   308,   310,
     312,   314,   316,   318,   320,   322,   324,   326,   328,   330,
     332,   334,   336,   338,   340,   342,   344,   346,   348,   350,
     352,   354,   356,   358,   360,   362,   364,   366,   368,   370,
     372,   374,   376,   378,   380,   382,   384,   386,   388,   390,
     391,   394,   397,   398,   402,   406,   408,   411,   413,   415,
     418,   420,   423,   425,   427,   429,   431,   435,   437,   441,
     443,   445,   447,   449,   451,   453,   455,   458,   461,   464,
     467,   470,   473,   476,   478,   479,   481,   484,   485,   487,
     490,   492,   494,   495,   501,   502,   503,   508,   509,   510,
     519,   520,   522,   525,   527,   528,   533,   537,   538,   539,
     540,   541,   550,   551,   553,   557,   560,   563,   564,   570,
     575,   580,   585,   588,   591,   596,   601,   606,   611,   613,
     615,   619,   623,   624,   625,   626,   633,   635,   637,   639,
     641,   643,   645,   646,   651,   653,   654,   659,   663,   667,
     671,   673,   677,   681,   685,   689,   693,   694,   697,   700,
     702,   704,   706,   708,   710,   712,   715,   718,   721,   724,
     727,   729,   731,   733,   735,   737,   739,   741,   743,   745,
     747,   748,   753,   755,   756,   759,   762,   764,   767,   768,
     769,   770,   778,   783,   784,   790,   794,   795,   802,   807,
     813,   818,   820,   824,   828,   830,   833,   834,   835,   840,
     844,   846,   848,   849,   857,   859,   861,   862,   865,   866,
     869,   871,   875,   876,   884,   890,   891,   892,   902,   904,
     906,   908,   909,   912,   914,   916,   918,   920,   922,   923,
     925,   928,   933,   934,   935,   945,   954,   960,   965,   967,
     969,   970,   971,   984,   985,   986,   995,   996,   998,   999,
    1000,  1009,  1013,  1019,  1024,  1026,  1028,  1030,  1032,  1035,
    1039,  1040,  1042,  1044,  1045,  1047,  1049,  1051,  1053,  1056,
    1059,  1062,  1065,  1067,  1071,  1073,  1076,  1078,  1082,  1086,
    1090,  1096,  1100,  1104,  1108,  1114,  1119,  1121,  1127,  1129,
    1131,  1133,  1135,  1137,  1139,  1141,  1143,  1145,  1147,  1148,
    1150,  1151,  1154,  1156,  1160,  1161,  1164,  1166,  1170,  1174,
    1178,  1182,  1184,  1188,  1192,  1196,  1200,  1204,  1208,  1212,
    1216,  1220,  1224,  1228,  1232,  1236,  1240,  1244,  1248,  1252,
    1256,  1260,  1264,  1268,  1272,  1276,  1280,  1284,  1288,  1292,
    1296,  1300,  1304,  1308,  1312,  1316,  1320,  1324,  1328,  1330,
    1333,  1336,  1339,  1342,  1345,  1348,  1351,  1353,  1356,  1359,
    1361,  1362,  1370,  1372,  1374,  1376,  1378,  1380,  1382,  1384,
    1386,  1388,  1390,  1392,  1397,  1402,  1407,  1412,  1417,  1422,
    1427,  1434,  1439,  1444,  1449,  1454,  1459,  1463,  1469,  1475,
    1480,  1485,  1489,  1493,  1497,  1501,  1506,  1511,  1516,  1521,
    1526,  1531,  1536,  1538,  1542,  1546,  1548,  1552,  1555,  1559,
    1563,  1567,  1570,  1573,  1577,  1581,  1583,  1587,  1591,  1594,
    1597,  1600,  1603,  1606,  1607,  1609,  1611,  1612,  1614,  1616,
    1619,  1624,  1629,  1634,  1639,  1644,  1648,  1652,  1656,  1660,
    1664,  1666,  1668,  1669,  1673,  1681,  1689,  1697,  1705,  1713,
    1719,  1725,  1731,  1737,  1742,  1747,  1752,  1757,  1759,  1763,
    1766,  1768,  1771,  1772,  1776,  1778,  1781,  1783,  1785,  1787,
    1789,  1791,  1793,  1795,  1797,  1799,  1801,  1803,  1805,  1807,
    1809,  1811,  1813,  1815,  1817,  1819,  1821,  1823,  1825,  1827,
    1829,  1831,  1833,  1835,  1837,  1839,  1841,  1843,  1845,  1847,
    1849,  1851,  1853,  1855,  1857,  1859,  1861,  1863,  1865,  1867,
    1869
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     107,     0,    -1,   108,    -1,   108,    24,    -1,   108,   129,
      -1,   108,    95,    -1,    -1,   294,    -1,   109,    89,   294,
      -1,    96,    46,    -1,    96,   295,    -1,    96,     1,    -1,
      -1,   109,    -1,   280,    -1,   111,    -1,    -1,   114,   111,
      -1,   145,    49,   113,   110,    95,    -1,   145,    49,   113,
       1,    95,    -1,   145,    49,   113,     1,    24,    -1,   145,
      49,   113,     1,    97,    -1,   145,    49,     1,    95,    -1,
     145,    49,     1,    24,    -1,   145,    49,     1,    97,    -1,
      48,   280,    95,    -1,    48,   294,    95,    -1,    48,     1,
      95,    -1,    48,     1,    24,    -1,    48,     1,    97,    -1,
      46,    82,   236,    -1,   295,    82,   236,    -1,     1,    82,
     236,    -1,   117,    -1,   118,    98,   117,    -1,   145,     4,
     118,    95,    -1,   145,     4,     1,    95,    -1,   145,     4,
       1,    24,    -1,   145,     4,     1,    97,    -1,   185,    -1,
      95,    -1,    24,    -1,     1,    -1,   154,    -1,    99,    -1,
     100,    -1,    -1,    97,    -1,    -1,    97,    -1,    24,    -1,
     101,    -1,   102,    -1,    -1,    -1,    -1,   145,   121,   147,
      46,   128,    99,   137,   123,   130,   120,    -1,   145,   121,
     147,    46,   128,     1,    -1,    -1,   145,   121,   147,   295,
     131,    99,   137,   100,   120,    -1,   145,   121,   179,    95,
      -1,   115,    -1,   116,    -1,   119,    -1,   221,    -1,   227,
      -1,   229,    -1,     1,    24,    -1,     1,    95,    -1,     1,
      97,    -1,    -1,   145,   103,   132,   108,   125,    -1,    37,
      -1,    36,    -1,    -1,    46,    -1,   295,    -1,    -1,   153,
     133,   134,    -1,    99,   137,   123,    -1,   267,    -1,   138,
     267,    -1,   135,    -1,   138,    98,   135,    -1,   138,    96,
     135,    -1,    63,    -1,    52,    -1,    72,    -1,    40,    -1,
      81,    -1,    66,    -1,    51,    -1,    70,    -1,    68,    -1,
      50,    -1,    77,    -1,    63,    -1,    52,    -1,    72,    -1,
      40,    -1,    66,    -1,    51,    -1,    70,    -1,    68,    -1,
      50,    -1,    81,    -1,    77,    -1,    78,    -1,    60,    -1,
      27,    -1,    59,    -1,    55,    -1,    64,    -1,    43,    -1,
      67,    -1,    73,    -1,    41,    -1,    53,    -1,    39,    -1,
      75,    -1,    47,    -1,    35,    -1,    42,    -1,    79,    -1,
      38,    -1,    23,    -1,    22,    -1,    44,    -1,    30,    -1,
      28,    -1,    29,    -1,     4,    -1,    32,    -1,    33,    -1,
      48,    -1,    49,    -1,    54,    -1,    69,    -1,    10,    -1,
      21,    -1,    20,    -1,    76,    -1,    45,    -1,   140,    -1,
     141,    -1,   142,    -1,    46,    -1,   143,    -1,   146,    -1,
      -1,   139,   146,    -1,   147,    91,    -1,    -1,   122,   152,
     100,    -1,   126,   152,   102,    -1,   157,    -1,   150,    91,
      -1,   152,    -1,   161,    -1,   152,    91,    -1,   158,    -1,
     153,    91,    -1,   157,    -1,   157,    -1,   158,    -1,   161,
      -1,   157,    84,   159,    -1,   159,    -1,   158,    84,   159,
      -1,   160,    -1,   160,    -1,   161,    -1,    41,    -1,    78,
      -1,    60,    -1,    73,    -1,    53,   165,    -1,    59,   175,
      -1,    43,   168,    -1,    64,   166,    -1,    67,   166,    -1,
      27,   174,    -1,    55,   174,    -1,   280,    -1,    -1,     7,
      -1,    90,     7,    -1,    -1,     7,    -1,    90,     7,    -1,
      36,    -1,    37,    -1,    -1,    99,   163,   164,   162,   100,
      -1,    -1,    -1,   167,    99,   112,   100,    -1,    -1,    -1,
      99,   169,   171,   133,    96,   170,   153,   100,    -1,    -1,
     267,    -1,   172,   267,    -1,   153,    -1,    -1,   172,    98,
     173,   153,    -1,    99,   153,   100,    -1,    -1,    -1,    -1,
      -1,    99,   176,   153,    96,   177,   153,   178,   100,    -1,
      -1,   180,    -1,   179,    98,   180,    -1,   147,    46,    -1,
     147,   295,    -1,    -1,   147,    46,    82,   181,   264,    -1,
     147,    46,    82,     1,    -1,   147,    46,    82,    24,    -1,
     147,   295,    82,   264,    -1,   147,    46,    -1,   147,   295,
      -1,   147,    46,    82,   264,    -1,   147,   295,    82,   264,
      -1,   147,    46,    82,     1,    -1,   147,    46,    82,    24,
      -1,    46,    -1,   295,    -1,    46,    82,   236,    -1,   295,
      82,   236,    -1,    -1,    -1,    -1,   103,   186,   184,   187,
     197,   188,    -1,    97,    -1,    24,    -1,   185,    -1,     1,
      -1,    24,    -1,   182,    -1,    -1,   190,    98,   191,   182,
      -1,   183,    -1,    -1,   192,    98,   193,   182,    -1,    46,
      82,   236,    -1,   295,    82,   236,    -1,     1,    82,   236,
      -1,   194,    -1,   195,    98,   194,    -1,     4,   195,    95,
      -1,     4,     1,    95,    -1,     4,     1,    24,    -1,     4,
       1,    97,    -1,    -1,   197,   200,    -1,   258,   276,    -1,
     198,    -1,   116,    -1,   230,    -1,   256,    -1,   196,    -1,
     185,    -1,   204,   243,    -1,   206,   243,    -1,     1,    95,
      -1,     1,    24,    -1,     1,    97,    -1,    95,    -1,   199,
      -1,   247,    -1,   242,    -1,   244,    -1,   239,    -1,   251,
      -1,   254,    -1,   205,    -1,   201,    -1,    -1,    46,   202,
      96,   200,    -1,    46,    -1,    -1,    28,   203,    -1,    33,
      96,    -1,    33,    -1,    32,   203,    -1,    -1,    -1,    -1,
      54,   184,   207,   209,   136,   210,   189,    -1,    54,   184,
     207,     1,    -1,    -1,    46,   207,   136,   212,   189,    -1,
      46,   207,     1,    -1,    -1,   147,    46,   207,   136,   214,
     189,    -1,   147,    46,   207,     1,    -1,   145,   121,   147,
     133,    46,    -1,   145,   121,   147,   295,    -1,   215,    -1,
     216,    98,   215,    -1,   216,    96,   215,    -1,   267,    -1,
     216,   267,    -1,    -1,    -1,    99,   218,   217,   123,    -1,
     103,   108,   188,    -1,     1,    -1,    24,    -1,    -1,   145,
      30,   184,   134,   222,   219,   220,    -1,    46,    -1,   295,
      -1,    -1,    82,   236,    -1,    -1,   223,   224,    -1,   225,
      -1,   226,    98,   225,    -1,    -1,   145,    39,   228,   134,
     103,   226,   188,    -1,   145,    75,   150,   223,    95,    -1,
      -1,    -1,    47,   231,   184,   232,    99,   260,   233,   200,
     234,    -1,   100,    -1,    97,    -1,    24,    -1,    -1,    38,
     200,    -1,   291,    -1,     1,    -1,   264,    -1,    24,    -1,
       1,    -1,    -1,   235,    -1,    98,   235,    -1,    95,   237,
      95,   237,    -1,    -1,    -1,    23,   240,   184,   241,    99,
     264,   238,   233,   200,    -1,    35,   184,   200,    79,    99,
     260,   233,   243,    -1,    35,   184,   200,    79,    24,    -1,
      35,   184,   200,    24,    -1,    95,    -1,    24,    -1,    -1,
      -1,    42,   245,   184,   246,    99,   257,   243,   250,   243,
     257,   233,   200,    -1,    -1,    -1,    79,   248,   184,   249,
      99,   260,   233,   200,    -1,    -1,   260,    -1,    -1,    -1,
      20,   252,   184,   253,    99,   260,   233,   200,    -1,    29,
     260,   255,    -1,    29,   260,   164,   259,   255,    -1,    29,
     164,   260,   255,    -1,    96,    -1,    95,    -1,    97,    -1,
      24,    -1,    10,   243,    -1,    10,   260,   243,    -1,    -1,
     260,    -1,   261,    -1,    -1,   260,    -1,   261,    -1,     1,
      -1,   262,    -1,   155,   190,    -1,   156,   192,    -1,   156,
     211,    -1,   155,   213,    -1,   264,    -1,   262,    98,   264,
      -1,   264,    -1,   104,   264,    -1,   265,    -1,   278,    82,
     264,    -1,   278,    82,     1,    -1,   296,    82,   264,    -1,
     126,   292,   102,    82,   264,    -1,   278,   266,   264,    -1,
     278,   266,     1,    -1,   296,   266,   264,    -1,   126,   292,
     102,   266,   264,    -1,   126,   292,   102,     1,    -1,   273,
      -1,   273,    83,   265,    96,   265,    -1,    26,    -1,    65,
      -1,    80,    -1,    58,    -1,    71,    -1,    25,    -1,    74,
      -1,    62,    -1,    61,    -1,    34,    -1,    -1,    98,    -1,
      -1,   269,   267,    -1,   263,    -1,   269,    98,   263,    -1,
      -1,   271,   267,    -1,   272,    -1,   271,    98,   272,    -1,
     271,    98,     1,    -1,   264,   255,   264,    -1,   264,   255,
       1,    -1,   274,    -1,   273,    19,   273,    -1,   273,    18,
     273,    -1,   273,    84,   273,    -1,   273,    85,   273,    -1,
     273,    86,   273,    -1,   273,    11,   273,    -1,   273,    14,
     273,    -1,   273,    87,   273,    -1,   273,    12,   273,    -1,
     273,    88,   273,    -1,   273,    13,   273,    -1,   273,    16,
     273,    -1,   273,    17,   273,    -1,   273,    89,   273,    -1,
     273,    90,   273,    -1,   273,    91,   273,    -1,   273,    92,
     273,    -1,   273,    93,   273,    -1,   273,    19,     1,    -1,
     273,    18,     1,    -1,   273,    84,     1,    -1,   273,    85,
       1,    -1,   273,    86,     1,    -1,   273,    11,     1,    -1,
     273,    14,     1,    -1,   273,    87,     1,    -1,   273,    12,
       1,    -1,   273,    88,     1,    -1,   273,    13,     1,    -1,
     273,    16,     1,    -1,   273,    17,     1,    -1,   273,    89,
       1,    -1,   273,    90,     1,    -1,   273,    91,     1,    -1,
     273,    92,     1,    -1,   273,    93,     1,    -1,   275,    -1,
     148,   274,    -1,   149,   274,    -1,     8,   278,    -1,     9,
     278,    -1,    15,   274,    -1,    94,   274,    -1,    90,   274,
      -1,   278,    -1,   278,     8,    -1,   278,     9,    -1,    95,
      -1,    -1,   103,   184,   128,   277,   197,   188,   243,    -1,
     294,    -1,     7,    -1,     5,    -1,   288,    -1,   285,    -1,
     286,    -1,   290,    -1,   208,    -1,   221,    -1,   227,    -1,
     279,    -1,   278,   122,   268,   100,    -1,   278,   122,     1,
     100,    -1,   278,   122,     1,    24,    -1,   278,   122,     1,
      95,    -1,   278,   122,     1,    97,    -1,   278,   126,    91,
     102,    -1,   278,   126,   264,   102,    -1,   278,   126,   283,
     164,   284,   102,    -1,   278,   126,     1,   102,    -1,   278,
     126,     1,    24,    -1,   278,   126,     1,    95,    -1,   278,
     126,     1,    97,    -1,   278,   126,     1,   100,    -1,   122,
     262,   100,    -1,   122,   103,   268,   124,   100,    -1,   122,
     126,   270,   127,   100,    -1,    57,   184,   268,    56,    -1,
      57,   184,   268,   100,    -1,   122,     1,   100,    -1,   122,
       1,    24,    -1,   122,     1,    95,    -1,   122,     1,    97,
      -1,    57,   184,     1,    56,    -1,    57,   184,     1,   100,
      -1,    57,   184,     1,    24,    -1,    57,   184,     1,    95,
      -1,    57,   184,     1,    97,    -1,   278,     3,   184,   144,
      -1,   278,     3,   184,     1,    -1,   280,    -1,    51,    31,
      46,    -1,    51,    31,   295,    -1,   282,    -1,   280,   105,
      46,    -1,   105,    46,    -1,    45,   105,    46,    -1,   280,
     105,   295,    -1,   280,   105,     1,    -1,    46,    31,    -1,
      45,    31,    -1,   281,    46,    31,    -1,   281,   295,    31,
      -1,    46,    -1,    69,    31,    46,    -1,    69,    31,   295,
      -1,   281,    46,    -1,   281,   295,    -1,   281,     1,    -1,
      31,    46,    -1,    31,   295,    -1,    -1,   261,    -1,    24,
      -1,    -1,   261,    -1,    24,    -1,    44,   287,    -1,    76,
      99,   264,   100,    -1,    76,    99,     1,   100,    -1,    76,
      99,     1,    97,    -1,    76,    99,     1,    24,    -1,    76,
      99,     1,    95,    -1,    99,   261,   100,    -1,    99,     1,
     100,    -1,    99,     1,    24,    -1,    99,     1,    97,    -1,
      99,     1,    95,    -1,   185,    -1,     1,    -1,    -1,    22,
     289,   287,    -1,    21,    99,   264,    98,   264,   293,   100,
      -1,    21,    99,   264,    98,   264,     1,   100,    -1,    21,
      99,   264,    98,   264,     1,    24,    -1,    21,    99,   264,
      98,   264,     1,    97,    -1,    21,    99,   264,    98,   264,
       1,    95,    -1,    21,    99,   264,     1,   100,    -1,    21,
      99,   264,     1,    24,    -1,    21,    99,   264,     1,    97,
      -1,    21,    99,   264,     1,    95,    -1,    21,    99,     1,
     100,    -1,    21,    99,     1,    24,    -1,    21,    99,     1,
      97,    -1,    21,    99,     1,    95,    -1,   278,    -1,   126,
     292,   102,    -1,   151,    46,    -1,   296,    -1,   291,   293,
      -1,    -1,    98,   291,   293,    -1,     6,    -1,   294,     6,
      -1,   296,    -1,    27,    -1,    30,    -1,    39,    -1,    41,
      -1,    43,    -1,    53,    -1,    59,    -1,    60,    -1,    55,
      -1,    64,    -1,    67,    -1,    73,    -1,    75,    -1,    78,
      -1,    50,    -1,    51,    -1,    63,    -1,    69,    -1,    66,
      -1,    68,    -1,    70,    -1,    81,    -1,    77,    -1,    72,
      -1,    40,    -1,    52,    -1,    35,    -1,    38,    -1,    10,
      -1,    48,    -1,    49,    -1,    22,    -1,    44,    -1,    54,
      -1,    21,    -1,    20,    -1,    76,    -1,    28,    -1,    29,
      -1,    32,    -1,    33,    -1,    42,    -1,    23,    -1,    47,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   355,   355,   356,   360,   361,   362,   365,   366,   379,
     380,   381,   382,   388,   405,   422,   434,   434,   444,   459,
     465,   472,   478,   479,   484,   487,   494,   502,   503,   508,
     511,   555,   556,   559,   560,   563,   564,   565,   570,   573,
     578,   579,   580,   584,   597,   604,   610,   617,   619,   624,
     625,   631,   638,   640,   646,   664,   662,   918,   925,   924,
     932,   933,   934,   935,   936,   937,   938,   939,   945,   951,
     959,   957,   970,   971,   976,   979,   980,   981,   984,  1009,
    1016,  1017,  1020,  1021,  1022,  1030,  1031,  1032,  1033,  1034,
    1035,  1036,  1037,  1038,  1039,  1040,  1044,  1045,  1046,  1047,
    1048,  1049,  1050,  1051,  1052,  1053,  1054,  1058,  1059,  1060,
    1061,  1062,  1063,  1064,  1065,  1066,  1067,  1068,  1069,  1070,
    1074,  1075,  1076,  1077,  1078,  1079,  1080,  1081,  1082,  1083,
    1084,  1085,  1086,  1087,  1088,  1089,  1090,  1091,  1092,  1093,
    1094,  1095,  1096,  1099,  1099,  1099,  1101,  1102,  1110,  1116,
    1117,  1120,  1121,  1124,  1134,  1144,  1145,  1154,  1154,  1156,
    1163,  1166,  1173,  1176,  1189,  1202,  1215,  1216,  1219,  1220,
    1223,  1223,  1226,  1227,  1228,  1229,  1230,  1231,  1232,  1233,
    1234,  1235,  1236,  1239,  1313,  1316,  1317,  1330,  1333,  1334,
    1346,  1347,  1354,  1357,  1398,  1399,  1399,  1440,  1444,  1439,
    1471,  1484,  1485,  1488,  1490,  1489,  1495,  1496,  1500,  1503,
    1506,  1499,  1511,  1520,  1521,  1524,  1538,  1540,  1539,  1564,
    1568,  1573,  1580,  1595,  1596,  1611,  1616,  1622,  1631,  1642,
    1643,  1654,  1658,  1665,  1670,  1664,  1690,  1691,  1698,  1699,
    1700,  1704,  1705,  1705,  1709,  1710,  1710,  1715,  1752,  1753,
    1756,  1757,  1760,  1761,  1762,  1767,  1771,  1772,  1778,  1789,
    1790,  1791,  1792,  1793,  1794,  1795,  1796,  1797,  1798,  1805,
    1812,  1815,  1819,  1820,  1821,  1822,  1823,  1824,  1825,  1826,
    1830,  1829,  1846,  1847,  1850,  1851,  1852,  1858,  1861,  1867,
    1875,  1866,  1959,  1969,  1968,  2091,  2099,  2098,  2229,  2237,
    2269,  2272,  2273,  2274,  2281,  2282,  2286,  2291,  2292,  2403,
    2404,  2405,  2412,  2411,  2513,  2514,  2518,  2521,  2558,  2559,
    2580,  2581,  2585,  2584,  2611,  2632,  2636,  2631,  2655,  2656,
    2657,  2664,  2665,  2668,  2669,  2672,  2673,  2674,  2678,  2679,
    2682,  2683,  2688,  2692,  2687,  2716,  2724,  2731,  2740,  2741,
    2749,  2753,  2748,  2773,  2777,  2772,  2793,  2794,  2798,  2802,
    2797,  2817,  2821,  2825,  2831,  2832,  2836,  2840,  2847,  2859,
    2865,  2866,  2869,  2871,  2872,  2875,  2876,  2879,  2880,  2881,
    2882,  2883,  2887,  2888,  2894,  2895,  2897,  2898,  2899,  2900,
    2901,  2907,  2908,  2909,  2910,  2916,  2921,  2922,  2925,  2926,
    2927,  2928,  2929,  2930,  2931,  2932,  2933,  2934,  2937,  2937,
    2939,  2940,  2944,  2945,  2948,  2949,  2952,  2953,  2962,  2965,
    2969,  2972,  2973,  2974,  2975,  2976,  2977,  2978,  2979,  2980,
    2981,  2982,  2983,  2984,  2985,  2986,  2987,  2988,  2989,  2990,
    2991,  2992,  2993,  2994,  2995,  2996,  2997,  2998,  2999,  3000,
    3001,  3002,  3003,  3004,  3005,  3006,  3007,  3008,  3011,  3012,
    3017,  3022,  3023,  3024,  3025,  3026,  3029,  3030,  3031,  3053,
    3055,  3054,  3137,  3138,  3139,  3140,  3141,  3142,  3143,  3144,
    3145,  3146,  3147,  3148,  3154,  3160,  3167,  3173,  3179,  3185,
    3191,  3198,  3204,  3210,  3212,  3214,  3216,  3223,  3229,  3238,
    3244,  3251,  3252,  3257,  3258,  3259,  3260,  3264,  3269,  3270,
    3271,  3277,  3280,  3281,  3346,  3352,  3353,  3362,  3378,  3385,
    3386,  3389,  3426,  3433,  3462,  3465,  3491,  3506,  3510,  3560,
    3561,  3562,  3603,  3609,  3610,  3611,  3614,  3615,  3616,  3619,
    3634,  3657,  3658,  3659,  3664,  3667,  3668,  3669,  3674,  3675,
    3676,  3677,  3681,  3680,  3691,  3695,  3702,  3710,  3717,  3724,
    3730,  3737,  3743,  3749,  3750,  3755,  3756,  3759,  3760,  3762,
    3771,  3774,  3777,  3778,  3781,  3782,  3800,  3801,  3803,  3805,
    3807,  3809,  3811,  3813,  3815,  3817,  3819,  3821,  3823,  3825,
    3827,  3832,  3834,  3836,  3838,  3840,  3842,  3844,  3846,  3848,
    3850,  3852,  3854,  3856,  3858,  3860,  3862,  3864,  3866,  3868,
    3870,  3872,  3874,  3876,  3878,  3880,  3882,  3884,  3886,  3888,
    3890
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_ARROW", "TOK_CONSTANT", "TOK_FLOAT",
  "TOK_STRING", "TOK_NUMBER", "TOK_INC", "TOK_DEC", "TOK_RETURN", "TOK_EQ",
  "TOK_GE", "TOK_LE", "TOK_NE", "TOK_NOT", "TOK_LSH", "TOK_RSH",
  "TOK_LAND", "TOK_LOR", "TOK_SWITCH", "TOK_SSCANF", "TOK_CATCH",
  "TOK_FOREACH", "TOK_LEX_EOF", "TOK_ADD_EQ", "TOK_AND_EQ", "TOK_ARRAY_ID",
  "TOK_BREAK", "TOK_CASE", "TOK_CLASS", "TOK_COLON_COLON", "TOK_CONTINUE",
  "TOK_DEFAULT", "TOK_DIV_EQ", "TOK_DO", "TOK_DOT_DOT", "TOK_DOT_DOT_DOT",
  "TOK_ELSE", "TOK_ENUM", "TOK_EXTERN", "TOK_FLOAT_ID", "TOK_FOR",
  "TOK_FUNCTION_ID", "TOK_GAUGE", "TOK_GLOBAL", "TOK_IDENTIFIER", "TOK_IF",
  "TOK_IMPORT", "TOK_INHERIT", "TOK_INLINE", "TOK_LOCAL_ID",
  "TOK_FINAL_ID", "TOK_INT_ID", "TOK_LAMBDA", "TOK_MULTISET_ID",
  "TOK_MULTISET_END", "TOK_MULTISET_START", "TOK_LSH_EQ", "TOK_MAPPING_ID",
  "TOK_MIXED_ID", "TOK_MOD_EQ", "TOK_MULT_EQ", "TOK_NO_MASK",
  "TOK_OBJECT_ID", "TOK_OR_EQ", "TOK_PRIVATE", "TOK_PROGRAM_ID",
  "TOK_PROTECTED", "TOK_PREDEF", "TOK_PUBLIC", "TOK_RSH_EQ", "TOK_STATIC",
  "TOK_STRING_ID", "TOK_SUB_EQ", "TOK_TYPEDEF", "TOK_TYPEOF",
  "TOK_VARIANT", "TOK_VOID_ID", "TOK_WHILE", "TOK_XOR_EQ", "TOK_OPTIONAL",
  "'='", "'?'", "'|'", "'^'", "'&'", "'>'", "'<'", "'+'", "'-'", "'*'",
  "'%'", "'/'", "'~'", "';'", "':'", "'}'", "','", "'('", "')'", "'['",
  "']'", "'{'", "'@'", "'.'", "$accept", "all", "program",
  "string_constant", "optional_rename_inherit", "low_program_ref",
  "program_ref", "inherit_ref", "@1", "inheritance", "import",
  "constant_name", "constant_list", "constant", "block_or_semi",
  "type_or_error", "open_paren_with_line_info", "close_paren_or_missing",
  "close_brace_or_missing", "close_brace_or_eof",
  "open_bracket_with_line_info", "close_bracket_or_missing",
  "push_compiler_frame0", "def", "@2", "@3", "@4", "optional_dot_dot_dot",
  "optional_identifier", "new_arg_name", "func_args", "arguments",
  "arguments2", "modifier", "magic_identifiers1", "magic_identifiers2",
  "magic_identifiers3", "magic_identifiers", "magic_identifier",
  "modifiers", "modifier_list", "optional_stars", "cast", "soft_cast",
  "full_type", "type6", "type", "type7", "simple_type", "simple_type2",
  "simple_identifier_type", "type4", "type2", "type8", "basic_type",
  "identifier_type", "number_or_maxint", "number_or_minint",
  "expected_dot_dot", "opt_int_range", "opt_object_type", "@5",
  "opt_function_type", "@6", "@7", "function_type_list",
  "function_type_list2", "@8", "opt_array_type", "opt_mapping_type", "@9",
  "@10", "@11", "name_list", "new_name", "@12", "new_local_name",
  "new_local_name2", "line_number_info", "block", "@13", "@14",
  "end_block", "failsafe_block", "local_name_list", "@15",
  "local_name_list2", "@16", "local_constant_name", "local_constant_list",
  "local_constant", "statements", "statement_with_semicolon",
  "normal_label_statement", "statement", "labeled_statement", "@17",
  "optional_label", "break", "default", "continue", "push_compiler_frame1",
  "lambda", "@18", "@19", "local_function", "@20", "local_function2",
  "@21", "create_arg", "create_arguments2", "create_arguments",
  "push_compiler_frame01", "optional_create_arguments", "failsafe_program",
  "class", "@22", "simple_identifier", "enum_value", "enum_def",
  "enum_list", "enum", "@23", "typedef", "cond", "@24", "@25", "end_cond",
  "optional_else_part", "safe_lvalue", "safe_expr0",
  "foreach_optional_lvalue", "foreach_lvalues", "foreach", "@26", "@27",
  "do", "expected_semicolon", "for", "@28", "@29", "while", "@30", "@31",
  "for_expr", "switch", "@32", "@33", "case", "expected_colon", "return",
  "unused", "unused2", "optional_comma_expr", "safe_comma_expr",
  "comma_expr", "comma_expr2", "expr00", "expr0", "expr01", "assign",
  "optional_comma", "expr_list", "expr_list2", "m_expr_list",
  "m_expr_list2", "assoc_pair", "expr1", "expr2", "expr3",
  "optional_block", "@34", "expr4", "idents2", "idents",
  "inherit_specifier", "low_idents", "comma_expr_or_zero",
  "comma_expr_or_maxint", "gauge", "typeof", "catch_arg", "catch", "@35",
  "sscanf", "lvalue", "low_lvalue_list", "lvalue_list", "string",
  "bad_identifier", "bad_expr_ident", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,    61,    63,   124,    94,    38,    62,    60,    43,
      45,    42,    37,    47,   126,    59,    58,   125,    44,    40,
      41,    91,    93,   123,    64,    46
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   106,   107,   107,   108,   108,   108,   109,   109,   110,
     110,   110,   110,   111,   111,   112,   114,   113,   115,   115,
     115,   115,   115,   115,   115,   116,   116,   116,   116,   116,
     117,   117,   117,   118,   118,   119,   119,   119,   119,   120,
     120,   120,   120,   121,   122,   123,   123,   124,   124,   125,
     125,   126,   127,   127,   128,   130,   129,   129,   131,   129,
     129,   129,   129,   129,   129,   129,   129,   129,   129,   129,
     132,   129,   133,   133,   133,   134,   134,   134,   135,   136,
     137,   137,   138,   138,   138,   139,   139,   139,   139,   139,
     139,   139,   139,   139,   139,   139,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     142,   142,   142,   142,   142,   142,   142,   142,   142,   142,
     142,   142,   142,   142,   142,   142,   142,   142,   142,   142,
     142,   142,   142,   143,   143,   143,   144,   144,   145,   146,
     146,   147,   147,   148,   149,   150,   150,   151,   151,   152,
     152,   153,   153,   154,   155,   156,   157,   157,   158,   158,
     159,   159,   160,   160,   160,   160,   160,   160,   160,   160,
     160,   160,   160,   161,   162,   162,   162,   163,   163,   163,
     164,   164,   165,   165,   166,   167,   166,   169,   170,   168,
     168,   171,   171,   172,   173,   172,   174,   174,   176,   177,
     178,   175,   175,   179,   179,   180,   180,   181,   180,   180,
     180,   180,   182,   182,   182,   182,   182,   182,   183,   183,
     183,   183,   184,   186,   187,   185,   188,   188,   189,   189,
     189,   190,   191,   190,   192,   193,   192,   194,   194,   194,
     195,   195,   196,   196,   196,   196,   197,   197,   198,   199,
     199,   199,   199,   199,   199,   199,   199,   199,   199,   199,
     199,   200,   200,   200,   200,   200,   200,   200,   200,   200,
     202,   201,   203,   203,   204,   205,   205,   206,   207,   209,
     210,   208,   208,   212,   211,   211,   214,   213,   213,   215,
     215,   216,   216,   216,   217,   217,   218,   219,   219,   220,
     220,   220,   222,   221,   223,   223,   224,   224,   225,   225,
     226,   226,   228,   227,   229,   231,   232,   230,   233,   233,
     233,   234,   234,   235,   235,   236,   236,   236,   237,   237,
     238,   238,   240,   241,   239,   242,   242,   242,   243,   243,
     245,   246,   244,   248,   249,   247,   250,   250,   252,   253,
     251,   254,   254,   254,   255,   255,   255,   255,   256,   256,
     257,   257,   258,   259,   259,   260,   260,   261,   261,   261,
     261,   261,   262,   262,   263,   263,   264,   264,   264,   264,
     264,   264,   264,   264,   264,   264,   265,   265,   266,   266,
     266,   266,   266,   266,   266,   266,   266,   266,   267,   267,
     268,   268,   269,   269,   270,   270,   271,   271,   271,   272,
     272,   273,   273,   273,   273,   273,   273,   273,   273,   273,
     273,   273,   273,   273,   273,   273,   273,   273,   273,   273,
     273,   273,   273,   273,   273,   273,   273,   273,   273,   273,
     273,   273,   273,   273,   273,   273,   273,   273,   274,   274,
     274,   274,   274,   274,   274,   274,   275,   275,   275,   276,
     277,   276,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   279,   279,   279,   280,   280,   280,   280,   280,
     280,   281,   281,   281,   281,   282,   282,   282,   282,   282,
     282,   282,   282,   283,   283,   283,   284,   284,   284,   285,
     286,   286,   286,   286,   286,   287,   287,   287,   287,   287,
     287,   287,   289,   288,   290,   290,   290,   290,   290,   290,
     290,   290,   290,   290,   290,   290,   290,   291,   291,   291,
     291,   292,   293,   293,   294,   294,   295,   295,   295,   295,
     295,   295,   295,   295,   295,   295,   295,   295,   295,   295,
     295,   296,   296,   296,   296,   296,   296,   296,   296,   296,
     296,   296,   296,   296,   296,   296,   296,   296,   296,   296,
     296,   296,   296,   296,   296,   296,   296,   296,   296,   296,
     296
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     2,     2,     0,     1,     3,     2,
       2,     2,     0,     1,     1,     1,     0,     2,     5,     5,
       5,     5,     4,     4,     4,     3,     3,     3,     3,     3,
       3,     3,     3,     1,     3,     4,     4,     4,     4,     1,
       1,     1,     1,     1,     1,     1,     0,     1,     0,     1,
       1,     1,     1,     0,     0,     0,    10,     6,     0,     9,
       4,     1,     1,     1,     1,     1,     1,     2,     2,     2,
       0,     5,     1,     1,     0,     1,     1,     0,     3,     3,
       1,     2,     1,     3,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     0,
       2,     2,     0,     3,     3,     1,     2,     1,     1,     2,
       1,     2,     1,     1,     1,     1,     3,     1,     3,     1,
       1,     1,     1,     1,     1,     1,     2,     2,     2,     2,
       2,     2,     2,     1,     0,     1,     2,     0,     1,     2,
       1,     1,     0,     5,     0,     0,     4,     0,     0,     8,
       0,     1,     2,     1,     0,     4,     3,     0,     0,     0,
       0,     8,     0,     1,     3,     2,     2,     0,     5,     4,
       4,     4,     2,     2,     4,     4,     4,     4,     1,     1,
       3,     3,     0,     0,     0,     6,     1,     1,     1,     1,
       1,     1,     0,     4,     1,     0,     4,     3,     3,     3,
       1,     3,     3,     3,     3,     3,     0,     2,     2,     1,
       1,     1,     1,     1,     1,     2,     2,     2,     2,     2,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       0,     4,     1,     0,     2,     2,     1,     2,     0,     0,
       0,     7,     4,     0,     5,     3,     0,     6,     4,     5,
       4,     1,     3,     3,     1,     2,     0,     0,     4,     3,
       1,     1,     0,     7,     1,     1,     0,     2,     0,     2,
       1,     3,     0,     7,     5,     0,     0,     9,     1,     1,
       1,     0,     2,     1,     1,     1,     1,     1,     0,     1,
       2,     4,     0,     0,     9,     8,     5,     4,     1,     1,
       0,     0,    12,     0,     0,     8,     0,     1,     0,     0,
       8,     3,     5,     4,     1,     1,     1,     1,     2,     3,
       0,     1,     1,     0,     1,     1,     1,     1,     2,     2,
       2,     2,     1,     3,     1,     2,     1,     3,     3,     3,
       5,     3,     3,     3,     5,     4,     1,     5,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     0,     1,
       0,     2,     1,     3,     0,     2,     1,     3,     3,     3,
       3,     1,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     1,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     2,     1,
       0,     7,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     4,     4,     4,     4,     4,     4,     4,
       6,     4,     4,     4,     4,     4,     3,     5,     5,     4,
       4,     3,     3,     3,     3,     4,     4,     4,     4,     4,
       4,     4,     1,     3,     3,     1,     3,     2,     3,     3,
       3,     2,     2,     3,     3,     1,     3,     3,     2,     2,
       2,     2,     2,     0,     1,     1,     0,     1,     1,     2,
       4,     4,     4,     4,     4,     3,     3,     3,     3,     3,
       1,     1,     0,     3,     7,     7,     7,     7,     7,     5,
       5,     5,     5,     4,     4,     4,     4,     1,     3,     2,
       1,     2,     0,     3,     1,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       6,     0,     0,     1,     0,     3,    88,     0,    94,    91,
      86,    85,    90,    93,    92,    87,    95,    89,     5,    61,
      62,    63,     4,   149,     0,   148,    64,    65,    66,    67,
      68,    69,     0,   574,     0,     0,   525,     0,     0,     0,
       0,   515,     0,   150,     0,   207,   232,   322,   172,   200,
       0,   192,   207,   212,   174,   194,   194,   175,     0,   173,
      70,   152,    43,   163,   167,   170,   171,   183,    28,    27,
      29,   605,   612,   611,   608,   619,   577,   614,   615,   578,
     616,   617,   603,   604,   579,   601,   580,   618,   581,   609,
     531,   620,   606,   607,   591,   592,   602,   582,   610,   585,
     583,   584,   593,   586,   595,   587,   596,   594,   597,   600,
     588,   589,   613,   599,   590,   598,   532,   576,   522,     0,
     521,     0,   517,    25,     0,   530,   528,   529,   575,    26,
       0,     0,    33,     0,     0,     0,   181,    77,    77,   197,
     178,     0,     0,     0,   187,   176,   182,   208,   177,   179,
       0,   180,     0,   155,     6,     0,     0,   213,     0,   518,
     526,   527,   520,   516,   519,   523,   524,    37,     0,    36,
      38,     0,    35,     0,     0,     0,   162,    75,   312,    76,
       0,   408,    23,    22,    24,     0,     0,     0,    13,    17,
      14,     7,   188,     0,     0,     0,     0,   314,   156,     0,
     315,     0,    54,   151,   216,    60,   152,   166,   337,   474,
     473,   149,   149,   149,   611,   608,   336,   601,     0,   591,
     592,   602,   610,   232,   593,   595,   596,   594,   597,   600,
     613,   599,   598,   149,   149,    44,    51,     0,   149,     0,
     149,   149,   479,   480,   481,    32,   335,   386,   396,   421,
     458,   466,   482,   512,   476,   477,   475,   478,   472,     0,
      30,     0,    34,    31,   161,   206,   307,   318,   409,   203,
      74,   408,   201,    20,    19,    21,    11,     9,    10,    18,
       0,   189,   190,   191,   184,     0,    15,     0,   324,    50,
      49,    71,     0,     0,   149,     0,     0,   214,     0,   552,
       0,    91,   232,     0,     0,   461,   462,     0,   463,   466,
       0,     0,   551,     0,   233,   550,   539,     0,   288,     0,
       0,   465,   464,     0,   149,   149,     0,   160,   169,     0,
     382,   149,     0,   157,   158,   567,   183,   572,     0,   570,
     459,   460,     0,     0,     0,     0,     0,     0,     0,     0,
     149,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   232,   467,   468,   403,   398,   407,   401,   406,   405,
     399,   402,   404,   400,     0,     0,     0,     0,   149,   149,
     306,     0,   316,   320,     0,    73,    72,     0,   204,   202,
       8,   185,     0,     0,   209,   196,   219,   220,   149,    57,
     408,   221,   408,   215,   216,     0,     0,     0,   553,     0,
     152,     0,   164,   165,     0,   377,   232,   513,   514,     0,
       0,   149,   412,   384,     0,   408,     0,     0,   502,   503,
     504,   501,    48,   149,     0,    53,   408,   416,   466,   570,
     159,   153,     0,   149,   496,   157,     0,   569,   154,   149,
     571,     0,   445,   427,   448,   430,   450,   432,   446,   428,
     451,   433,   452,   434,   441,   423,   440,   422,     0,   442,
     424,   443,   425,   444,   426,   447,   429,   449,   431,   453,
     435,   454,   436,   455,   437,   456,   438,   457,   439,     0,
     388,   387,     0,     0,     0,   535,     0,   534,   382,     0,
     392,   391,   389,   393,   149,   310,   311,     6,   313,     0,
     319,   237,   236,   318,   323,   198,     0,   186,   193,     0,
     218,    82,    46,   408,    74,    80,     0,   564,   566,   565,
     563,     0,   149,   547,   549,   548,   546,     0,   241,   378,
     381,   228,   244,   379,   380,   229,   545,   234,   292,     0,
     507,   505,   508,   509,   506,   385,   499,   500,   409,   411,
     543,   544,   542,   541,   540,    47,     0,     0,   367,   365,
     364,   366,     0,    52,     0,     0,   415,   168,   383,   568,
     572,   395,   149,   149,   149,   511,   131,   138,   140,   139,
     126,   125,   109,   129,   130,   128,   132,   133,   121,   124,
     118,    99,   116,   122,   113,   127,   142,   146,   120,   134,
     135,   104,   101,    97,   117,   136,   111,   110,   108,    96,
     112,   100,   114,   103,   137,   102,    98,   115,   119,   141,
     106,   107,   123,   105,   143,   144,   145,   147,   510,   485,
     486,   487,   484,   483,   492,   493,   494,   495,   491,   488,
     489,   149,     0,   301,   408,    46,   304,     0,   317,   321,
       0,   205,   210,    45,    55,     0,   409,    81,    77,     0,
     560,   562,   561,   559,     0,   222,   223,   242,     0,     0,
     245,     0,   256,   408,   290,   413,   497,     0,   420,   419,
     498,   418,   417,   573,   390,   394,   397,   538,   537,     0,
     152,   149,   149,   305,   308,   309,     0,     0,     0,    84,
      83,    78,    42,    41,    40,    59,    39,     0,     0,     0,
       0,   149,   152,   230,   295,   293,   152,   231,     0,    46,
       0,   490,    74,   303,   302,   199,   211,    56,   556,   558,
     557,   555,   554,   226,   227,   224,   298,   296,   225,     0,
     243,     0,   246,     0,     0,     0,   612,   619,   614,     0,
     616,   286,   232,   618,   525,   620,     0,   353,   270,   260,
     264,   235,   263,   259,   271,   257,   279,     0,   278,     0,
     261,   275,   273,   274,   272,   276,   277,   262,     0,   372,
      79,   239,   240,   238,   291,     0,   300,     0,   222,   294,
     268,   267,   269,     0,     0,   250,     0,     0,   376,   349,
     348,   368,     0,   375,   232,   232,   282,   284,     0,     0,
     287,   285,     0,   232,     0,   232,   232,   265,   266,   469,
     232,   258,   299,   297,   254,     0,   253,   255,     0,   252,
       0,     0,   369,   359,   343,     0,     0,   361,     0,   351,
       0,   326,   354,    54,   249,   247,     0,   251,   248,     0,
       0,   363,     0,   374,   347,     0,     0,   281,     0,     0,
     470,     0,   149,   362,   346,     0,     0,     0,     0,   256,
       0,     0,     0,     0,   371,     0,     0,     0,   330,   329,
     328,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     360,   334,   339,     0,   333,   340,     0,   345,     0,   357,
     331,   355,   471,     0,   344,     0,     0,   327,   341,     0,
     332,     0,   352
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,   188,   187,   189,   287,   142,   143,    19,
     769,   132,   133,    21,   715,    61,   237,   664,   566,   291,
     238,   574,   293,    22,   708,   295,   154,   387,   178,   521,
     684,   522,   523,    23,   634,   635,   636,   637,   638,   239,
      25,   749,   240,   241,   152,   332,   445,   524,    62,   410,
     411,   176,   412,    64,   328,   413,   393,   194,   284,   145,
     149,   150,   140,   181,   660,   270,   271,   516,   136,   148,
     195,   519,   707,   156,   157,   398,   538,   542,   318,   770,
     416,   682,   514,   794,   539,   722,   543,   726,   805,   806,
     772,   728,   773,   774,   775,   776,   824,   817,   777,   778,
     779,   419,   242,   549,   730,   544,   751,   540,   797,   653,
     654,   655,   504,   381,   508,   243,   266,   382,   510,   383,
     384,   244,   138,    28,   780,   825,   868,   891,   917,   902,
     245,   903,   894,   781,   815,   860,   782,   811,   783,   823,
     866,   784,   826,   869,   908,   785,   814,   859,   786,   572,
     787,   883,   788,   862,   884,   813,   415,   422,   330,   247,
     377,   525,   424,   425,   435,   436,   437,   248,   249,   250,
     831,   879,   251,   252,   253,    40,    41,   499,   699,   254,
     255,   316,   256,   311,   257,   337,   338,   450,   258,   179,
     259
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -734
static const yytype_int16 yypact[] =
{
    -734,    88,   930,  -734,   108,  -734,  -734,   270,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  7806,  5818,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,   405,  -734,  7899,    82,    31,   195,    49,   129,
    7359,  -734,    44,  -734,  7423,   148,  -734,  -734,  -734,   159,
     299,   164,   148,   174,  -734,   192,   192,  -734,  7839,  -734,
    -734,  -734,  -734,   220,  -734,  -734,  -734,   215,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,   343,
    -734,  7963,  -734,  -734,  7487,  -734,   302,   377,  -734,  -734,
     201,   348,  -734,   227,   362,  7839,  -734,  8027,  8027,  -734,
    -734,   471,    74,   177,    32,  -734,  -734,  -734,  -734,  -734,
     326,  -734,  6891,   220,  -734,  6963,   272,  -734,  7839,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  2806,  -734,
    -734,  2806,  -734,  7551,  2806,   -14,   220,  -734,  -734,  -734,
     320,  7795,  -734,  -734,  -734,   480,  7615,   355,   365,  -734,
     215,   452,  -734,   460,    64,  7839,   177,  -734,  -734,   364,
    -734,  3693,   186,  -734,    -8,  -734,  -734,  -734,  -734,  -734,
    -734,  6596,  6596,  6515,   366,    35,  -734,   786,   732,  6477,
     699,  8263,    54,  -734,  8271,  8306,  8340,   195,  8374,  8408,
     369,  8442,  8476,  6515,  6515,  -734,  -734,  1955,  6125,   250,
    6515,  6515,  -734,  -734,  -734,  -734,  -734,  -734,  5644,  -734,
    -734,  6673,  -734,   215,  -734,  -734,  -734,  -734,   452,  3986,
    -734,   388,  -734,  -734,  -734,  -734,   372,  8091,  -734,   392,
     391,   381,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
     482,  -734,  -734,  -734,    45,   -13,  -734,   399,  -734,  -734,
    -734,  -734,  2907,    72,  6414,   393,  7035,  -734,   366,  -734,
      83,   472,  -734,   369,  3008,   101,   101,  8322,  -734,   140,
    3210,    83,  -734,  2056,  -734,  -734,  -734,  8155,  -734,  2502,
    3311,  -734,  -734,   197,  6212,  5938,   286,   407,  -734,   132,
    -734,  6125,   462,   -26,  -734,   101,  5682,   412,   409,  -734,
    -734,  -734,  3832,  3933,  4034,  4135,  4236,  4337,  4438,  4539,
    6515,  4640,  4741,  4842,  4943,  5044,  5145,  5246,  5347,  5448,
    5549,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  3412,  2603,  1348,  3513,  6414,  6414,
    -734,    42,   434,  -734,   205,  -734,  -734,   421,   230,  -734,
     452,  -734,   511,   442,  -734,  -734,  -734,  -734,  6414,  -734,
    7795,  -734,  7795,   476,   477,   -26,   237,    98,  -734,   303,
    -734,  8219,   407,  -734,   453,   465,  -734,  -734,  -734,    81,
     316,  6414,  -734,  -734,    14,   466,   312,   467,  -734,  -734,
    -734,  -734,   474,  6125,   390,   470,   475,  -734,  6626,  3986,
    -734,  -734,  7839,  6414,  -734,   483,   478,  -734,  -734,  6125,
    -734,  7239,  -734,   435,  -734,   458,  -734,   458,  -734,   435,
    -734,   651,  -734,   651,  -734,  6729,  -734,  6698,   487,  -734,
     927,  -734,  6706,  -734,  6745,  -734,   458,  -734,   458,  -734,
     385,  -734,   385,  -734,  -734,  -734,  -734,  -734,  -734,  7295,
    -734,  -734,   341,   479,   297,  -734,   494,  -734,   515,    64,
    -734,  -734,  -734,  -734,  5762,  -734,  -734,  -734,  -734,  2806,
    -734,  -734,  -734,  8091,  -734,  -734,  7839,  -734,  -734,  7839,
    -734,  -734,   489,   181,   305,  -734,   518,  -734,  -734,  -734,
    -734,   436,  6414,  -734,  -734,  -734,  -734,  7107,  -734,   522,
    -734,    62,  -734,   524,  -734,   496,  -734,  -734,  -734,   525,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  6313,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,   523,   531,  -734,  -734,
    -734,  -734,  3614,  -734,   526,  2704,  -734,  -734,  -734,  -734,
     412,  -734,  6414,  6414,  6515,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  6039,  7839,  -734,   292,   489,  -734,  3754,  -734,  -734,
    7839,   392,   392,  -734,  -734,  7839,  7839,  -734,  8027,    70,
    -734,  -734,  -734,  -734,    33,   110,   545,  -734,  2806,    86,
    -734,  2806,  -734,  7795,  -734,  -734,  -734,  5854,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,   535,
    -734,  7806,   852,  -734,  -734,  -734,   287,   538,    70,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,   437,   539,  3109,
      96,  6414,  -734,  -734,  -734,  -734,  -734,  -734,  1247,   489,
      56,  -734,  6819,  -734,  -734,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  7179,
    -734,    56,  -734,   495,  7679,  1021,   542,   547,   216,  1145,
     216,  3885,  4087,   550,   160,   552,  5607,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,   233,  -734,   233,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,   278,  -734,
    -734,  -734,  -734,  -734,  -734,   608,  -734,    56,   574,  -734,
    -734,  -734,  -734,   448,   575,  -734,   323,   580,  -734,  -734,
    -734,  -734,   233,  -734,  -734,  -734,  -734,  -734,  2157,   533,
    -734,  -734,  1450,  -734,   567,  -734,  -734,  -734,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  2806,  -734,  -734,  2806,  -734,
    7743,  2806,  -734,  -734,  -734,   390,  1551,  -734,    29,  -734,
    1450,  -734,  -734,  -734,  -734,  -734,   582,  -734,  -734,   568,
     569,  -734,   390,  -734,  -734,    30,   576,  -734,   578,   579,
    -734,  2157,  6414,  -734,  -734,  2157,  1753,  2157,  2157,  -734,
     190,   324,   190,   233,  -734,   190,   190,  1247,  -734,  -734,
    -734,  1450,  2329,  2415,   190,   233,  1854,  1450,  1450,   233,
    -734,  -734,  -734,   586,  -734,  -734,  1450,  -734,   233,  -734,
     644,  -734,  -734,  2243,  -734,  1652,  1450,  -734,  -734,   190,
    -734,  1450,  -734
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -734,  -734,  -131,  -734,  -734,   488,  -734,  -734,  -734,  -734,
       3,   510,  -734,  -734,   -22,    36,  -179,  -454,  -734,  -734,
     256,  -734,  -163,  -734,  -734,  -734,  -734,  -489,  -128,  -226,
    -451,  -373,  -734,  -734,  -734,  -734,  -734,  -734,  -734,     9,
     670,   -39,  -734,  -734,  -734,  -734,  -200,  -114,  -734,  -734,
    -734,   -17,  -222,  -134,   285,   -18,  -734,  -734,  -481,  -734,
     640,  -734,  -734,  -734,  -734,  -734,  -734,  -734,   645,  -734,
    -734,  -734,  -734,  -734,   493,  -734,  -624,  -734,   -42,  -154,
    -734,  -734,  -632,  -682,  -734,  -734,  -734,  -734,  -138,  -734,
    -734,  -176,  -734,  -734,  -377,  -734,  -734,   -56,  -734,  -734,
    -734,  -511,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -268,
    -734,  -734,  -734,  -734,  -734,    12,  -734,   554,  -734,   194,
    -734,    17,  -734,  -734,  -734,  -734,  -734,  -300,  -734,  -185,
    -143,  -197,  -734,  -734,  -734,  -734,  -734,  -733,  -734,  -734,
    -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -734,  -531,
    -734,  -196,  -734,  -734,  -699,  -266,  -188,   166,  -126,  -324,
    -232,  -113,  -263,  -734,  -734,  -734,   150,   785,   439,  -734,
    -734,  -734,     4,  -734,    -7,  -734,  -734,  -734,  -734,  -734,
    -734,   415,  -734,  -734,  -734,  -429,  -273,  -462,    -6,   -31,
     -32
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -618
static const yytype_int16 yytable[] =
{
      39,    42,   117,   116,   137,    20,    66,    63,   117,   127,
     180,    24,   117,   134,    26,   327,   327,    67,   651,    27,
     580,   175,   155,   201,   207,   705,   468,   379,   260,   526,
     679,   263,   304,   304,   717,   668,  -552,   326,   333,   192,
      66,   153,   246,   505,   827,   246,   828,   414,   246,   329,
     128,    67,   391,   864,   874,  -232,   812,   791,   446,   304,
     819,   432,   120,  -288,   315,   440,   506,   269,   272,   799,
     556,   712,   375,   399,   294,   185,   448,   264,   264,   842,
     792,   285,   548,   394,   312,   327,   265,   724,     3,   117,
     161,   -58,   117,   164,   713,   122,   771,   746,   750,   531,
     282,   283,   752,   327,   361,   117,   117,   405,   865,   327,
     497,  -288,   493,   118,   557,   833,   329,    66,   693,   845,
     117,   200,   193,   117,   204,   333,   375,   375,    67,   875,
     375,   449,    29,  -572,  -552,   392,   190,   191,  -552,   129,
      66,   117,   134,   361,   678,   507,   315,   863,   362,   363,
     896,    67,   304,  -232,   117,   278,   375,   315,   389,   314,
     567,  -288,   907,    66,   720,   714,   912,   296,   401,   -12,
     186,   400,   880,   314,    67,   915,   882,    66,   885,   886,
    -289,   319,   313,    33,   407,   683,   314,   119,    67,   190,
     191,   120,   719,   423,   427,   683,   532,   909,   423,   434,
     235,   704,   236,    30,    20,    31,   339,   379,    34,  -288,
      24,   327,   718,    26,   888,   305,   306,   309,    27,   583,
     334,   428,    35,    36,   123,   167,   121,   327,   725,   511,
     443,   336,   444,   333,   124,   117,   200,   309,   309,   235,
    -283,   236,   335,   795,   309,   309,    37,   135,   491,   423,
     498,   501,   502,   503,   304,   899,  -280,   809,   139,   375,
     696,   527,   816,   144,   117,   404,  -409,  -409,   292,   747,
     304,    32,   520,   147,   390,   790,    33,   665,   818,   666,
      46,  -215,    38,   168,  -215,   117,   418,   889,   847,    47,
     890,  -195,   429,   439,   430,   555,   169,   431,   170,   339,
     141,    34,   512,   513,   158,   -16,   336,   334,   577,    65,
     729,  -283,   559,   334,   861,    35,    36,   578,   336,   489,
     124,   644,   172,   576,   336,   173,  -409,   533,   810,   438,
     -16,   873,   528,   165,   529,   335,   560,   530,   846,    37,
     550,   385,   386,    65,   -16,   -16,   309,   309,   309,   309,
     309,   309,   309,   309,   309,   309,   309,   309,   309,   309,
     309,   309,   309,   309,   309,   639,   658,   205,   -16,   336,
     206,   537,   551,   829,   547,    38,   657,   440,   264,   117,
     545,   830,    66,   246,    66,   698,   441,   735,   701,   159,
     702,   656,   645,    67,   646,    67,   264,   647,   534,   648,
     535,   339,   661,   536,   -16,   662,   674,   561,   166,   562,
     667,   552,   563,   553,   568,   334,   554,   339,   839,   892,
      65,   840,   893,   267,    66,   196,   336,   385,   386,    68,
     171,   334,   423,   733,   734,    67,   640,   335,   641,   709,
     710,   642,   336,    65,   174,   848,   689,   343,   344,   434,
     279,   346,   347,   335,   280,   583,   694,   695,   128,   288,
     670,   738,   789,   904,   904,   310,    65,   281,   320,   307,
     168,   380,   834,   867,   346,   347,   358,   359,   360,   388,
      65,   117,   200,   264,   904,   569,   570,   571,    33,   307,
     307,   442,   402,   325,   331,   182,   307,   307,    66,   395,
      69,    66,    70,   317,   273,   117,   676,   376,   447,    67,
     449,   451,    67,   652,   900,   716,   509,   515,   517,   800,
     910,   911,   354,   355,   356,   357,   358,   359,   360,   914,
     835,   671,   739,   672,   740,   723,   673,   741,   727,   920,
     711,   703,   518,   836,   922,   837,   706,   356,   357,   358,
     359,   360,   246,   546,   716,   246,   789,   568,   292,   294,
     325,   376,   376,   443,   558,   376,   183,   564,   184,   282,
     283,   565,   573,   575,   440,   274,   793,   275,   681,   643,
     579,   433,   895,   584,   789,   897,   898,   331,   309,   663,
     801,   376,   802,   745,   906,   748,   649,   793,   307,   307,
     307,   307,   307,   307,   307,   307,   307,   307,   307,   307,
     307,   307,   307,   307,   307,   307,   307,   650,   669,   921,
     677,   789,   680,   686,   683,   789,   690,   721,   569,   570,
     571,   789,   789,   687,    66,    63,   117,   731,   736,   742,
     789,  -358,    66,   793,   336,    67,  -342,    66,    66,  -350,
     789,  -325,   308,    67,   832,   789,   719,   838,    67,    67,
      20,   732,   841,   850,   835,    66,    24,   871,   872,    26,
     327,   327,   321,   322,    27,   876,    67,   877,   878,   340,
     341,   913,   916,   262,   286,    65,   737,    65,   700,   331,
     870,   327,   854,    43,   376,   855,   151,   146,   858,   297,
     117,   796,   857,   887,   820,   331,   199,   659,   905,   246,
     652,   652,   246,   304,   304,   246,   918,   117,   676,   919,
     822,   336,   117,   807,   685,   692,   408,    65,     0,   -91,
     317,     0,     0,   312,   304,     0,     0,     0,   -91,   -91,
     356,   357,   358,   359,   360,     0,   881,     0,   336,   -91,
     -91,   -91,   336,     0,     0,     0,  -609,  -609,  -609,    39,
      42,     0,   -91,     0,     0,   -91,  -609,   -91,     0,   -91,
       0,   -91,   843,   844,     0,     0,   -91,     0,     0,     0,
     -91,   849,     0,   851,   852,     0,     0,     0,   853,     0,
    -609,     0,     0,  -609,  -609,     0,     0,  -609,     0,     0,
       0,    65,     0,  -609,    65,     0,  -609,     0,   117,   807,
       0,   336,  -609,     0,  -609,   336,   -88,     0,     0,     0,
       0,     0,     0,     0,     0,   -88,   -88,  -609,     0,  -609,
    -609,   313,  -609,     0,  -609,   314,   -88,   -88,   -88,   336,
     307,     0,     0,   336,     0,     0,     0,     0,     0,   -88,
       0,     0,   -88,  -409,   -88,     0,   -88,     0,   -88,     0,
     339,   339,     0,   -88,   336,     0,     0,   -88,   336,   336,
     336,   336,     0,     0,   334,   334,  -409,     0,     0,     0,
     336,   339,     0,     0,   336,   336,   336,     0,     0,   336,
     336,   336,     6,     0,     0,   334,   335,   335,     0,   336,
       0,     0,     8,     9,    10,     0,   336,     0,   336,   336,
       0,     0,     0,     0,   336,    11,     0,   335,    12,     0,
      13,     0,    14,     0,    15,     0,     0,     0,     0,    16,
      -2,     4,     0,    17,  -149,     0,     0,    65,   342,   343,
     344,   345,     0,   346,   347,    65,     0,     0,     0,     0,
      65,    65,  -409,     0,     5,  -409,     0,  -149,     0,     0,
    -149,  -149,     0,     0,     0,     0,     0,     0,    65,  -149,
       6,  -149,     0,  -149,     0,  -149,  -149,     0,     7,  -149,
       8,     9,    10,  -149,     0,  -149,     0,     0,     0,  -149,
    -149,     0,     0,    11,  -149,     0,    12,  -149,    13,  -149,
      14,     0,    15,  -149,     0,  -149,     0,    16,  -149,     0,
       0,    17,   352,   353,   354,   355,   356,   357,   358,   359,
     360,     0,   808,     0,     0,    18,   209,    33,   210,   211,
     212,    71,     0,  -149,     0,  -149,   213,     0,     0,     0,
       0,    72,   214,   215,    75,   809,  -605,  -605,    45,    77,
      78,  -149,    34,    80,    81,  -605,    82,     0,     0,    83,
    -149,   217,    48,    87,    49,   218,    35,    36,    91,    92,
      93,   219,   220,   221,    51,   222,    52,     0,   223,  -605,
      53,    54,  -605,  -605,   224,    55,  -605,   225,    56,   226,
     227,   228,  -605,   229,    57,  -605,     0,   230,   231,    59,
       0,  -605,   232,  -605,     0,     0,     0,     0,     0,     0,
       0,   233,     0,     0,     0,   234,   810,     0,     0,     0,
     235,     0,   236,     0,     0,     0,    38,   453,   455,   457,
     459,   461,   463,   465,   467,     0,   470,   472,   474,   476,
     478,   480,   482,   484,   486,   488,   808,     0,   331,   331,
     209,    33,   210,   211,   212,    71,     0,     0,     0,     0,
     213,     0,     0,     0,     0,    72,   214,   215,    75,   331,
    -615,  -615,    45,    77,    78,  -149,    34,    80,    81,  -615,
      82,   282,   283,    83,  -149,   217,    48,    87,    49,   218,
      35,    36,    91,    92,    93,   219,   220,   221,    51,   222,
      52,     0,   223,  -615,    53,    54,  -615,  -615,   224,    55,
    -615,   225,    56,   226,   227,   228,  -615,   229,    57,  -615,
       0,   230,   231,    59,     0,  -615,   232,  -615,     0,     0,
       0,     0,     0,     0,     0,   233,     0,     0,     0,   234,
       0,     0,     0,     0,   235,     0,   236,     0,   753,     0,
      38,   754,   209,    33,   210,   211,   212,   755,     0,     0,
       0,     0,   213,     0,     0,     0,     0,   756,   214,   215,
     757,   511,     0,     0,    45,   758,   759,  -149,    34,   760,
     761,     0,   762,     0,     0,    83,  -149,   217,    48,   763,
      49,   218,    35,   764,   765,   766,    93,   219,   220,   221,
      51,   222,    52,     0,   223,     0,    53,    54,     0,     0,
     224,    55,     0,   225,    56,   226,   227,   228,     0,   229,
      57,     0,     0,   230,   231,    59,   767,     0,   232,     0,
       0,     0,     0,     0,     0,     0,     0,   233,     0,     0,
       0,   234,   768,     0,   512,     0,   235,     0,   236,   494,
     314,     0,    38,   209,    33,   210,   211,   212,    71,     0,
       0,     0,     0,   213,     0,     0,     0,     0,    72,   214,
     215,    75,   495,     0,     0,    45,    77,    78,  -149,    34,
      80,    81,     0,    82,  -533,  -533,    83,  -149,   217,    48,
      87,    49,   218,    35,    36,    91,    92,    93,   219,   220,
     221,    51,   222,    52,     0,   223,     0,    53,    54,     0,
       0,   224,    55,     0,   225,    56,   226,   227,   228,     0,
     229,    57,     0,     0,   230,   231,    59,     0,     0,   232,
       0,     0,     0,     0,     0,     0,     0,     0,   233,   496,
       0,     0,   234,     0,     0,     0,     0,   235,     0,   236,
       0,   753,     0,    38,   754,   209,    33,   210,   211,   212,
     755,     0,     0,     0,     0,   213,     0,     0,     0,     0,
     756,   214,   215,   757,     0,     0,     0,    45,   758,   759,
    -149,    34,   760,   761,     0,   762,     0,     0,    83,  -149,
     217,    48,   763,    49,   218,    35,   764,   765,   766,    93,
     219,   220,   221,    51,   222,    52,     0,   223,     0,    53,
      54,     0,     0,   224,    55,     0,   225,    56,   226,   227,
     228,     0,   229,    57,     0,     0,   230,   231,    59,   767,
       0,   232,     0,     0,     0,     0,     0,     0,     0,     0,
     233,     0,     0,     0,   234,   768,     0,     0,     0,   235,
       0,   236,   808,   314,     0,    38,   209,    33,   210,   211,
     212,    71,     0,     0,     0,     0,   213,     0,     0,     0,
       0,    72,   214,   215,    75,  -373,     0,     0,    45,    77,
      78,  -149,    34,    80,    81,     0,    82,     0,     0,    83,
    -149,   217,    48,    87,    49,   218,    35,    36,    91,    92,
      93,   219,   220,   221,    51,   222,    52,     0,   223,     0,
      53,    54,     0,     0,   224,    55,     0,   225,    56,   226,
     227,   228,     0,   229,    57,     0,     0,   230,   231,    59,
       0,     0,   232,     0,     0,     0,     0,     0,     0,     0,
       0,   233,     0,     0,     0,   234,  -373,  -373,  -373,     0,
     235,     0,   236,   808,     0,     0,    38,   209,    33,   210,
     211,   212,    71,     0,     0,     0,     0,   213,     0,     0,
       0,     0,    72,   214,   215,    75,  -370,     0,     0,    45,
      77,    78,  -149,    34,    80,    81,     0,    82,     0,     0,
      83,  -149,   217,    48,    87,    49,   218,    35,    36,    91,
      92,    93,   219,   220,   221,    51,   222,    52,     0,   223,
       0,    53,    54,     0,     0,   224,    55,     0,   225,    56,
     226,   227,   228,     0,   229,    57,     0,     0,   230,   231,
      59,     0,     0,   232,     0,     0,     0,     0,     0,     0,
       0,     0,   233,     0,     0,     0,   234,     0,     0,  -370,
       0,   235,  -370,   236,   808,     0,     0,    38,   209,    33,
     210,   211,   212,    71,     0,     0,     0,     0,   213,     0,
       0,     0,     0,    72,   214,   215,    75,  -370,     0,     0,
      45,    77,    78,  -149,    34,    80,    81,     0,    82,     0,
       0,    83,  -149,   217,    48,    87,    49,   218,    35,    36,
      91,    92,    93,   219,   220,   221,    51,   222,    52,     0,
     223,     0,    53,    54,     0,     0,   224,    55,     0,   225,
      56,   226,   227,   228,     0,   229,    57,     0,     0,   230,
     231,    59,     0,     0,   232,     0,     0,     0,     0,     0,
       0,     0,     0,   233,     0,     0,     0,   234,  -370,     0,
       0,     0,   235,     0,   236,   808,     0,     0,    38,   209,
      33,   210,   211,   212,    71,     0,     0,     0,     0,   213,
       0,     0,     0,     0,    72,   214,   215,    75,  -356,     0,
       0,    45,    77,    78,  -149,    34,    80,    81,     0,    82,
       0,     0,    83,  -149,   217,    48,    87,    49,   218,    35,
      36,    91,    92,    93,   219,   220,   221,    51,   222,    52,
       0,   223,     0,    53,    54,     0,     0,   224,    55,     0,
     225,    56,   226,   227,   228,     0,   229,    57,     0,     0,
     230,   231,    59,     0,     0,   232,     0,     0,     0,     0,
       0,     0,     0,     0,   233,     0,     0,     0,   234,  -356,
       0,     0,     0,   235,     0,   236,   323,     0,     0,    38,
     209,    33,   210,   211,   212,    71,     0,     0,     0,     0,
     213,     0,     0,     0,     0,    72,   214,   215,    75,     0,
       0,     0,    45,    77,    78,  -149,    34,    80,    81,     0,
      82,     0,     0,    83,  -149,   217,    48,    87,    49,   218,
      35,    36,    91,    92,    93,   219,   220,   221,    51,   222,
      52,     0,   223,     0,    53,    54,     0,     0,   224,    55,
       0,   225,    56,   226,   227,   228,     0,   229,    57,     0,
       0,   230,   231,    59,     0,     0,   232,     0,     0,     0,
       0,     0,     0,     0,     0,   233,     0,     0,     0,   234,
       0,     0,     0,     0,   235,     0,   236,   409,   324,     0,
      38,   209,    33,   210,   211,   212,    71,     0,     0,     0,
       0,   213,     0,     0,     0,     0,    72,   214,   215,    75,
       0,     0,     0,    45,    77,    78,  -149,    34,    80,    81,
       0,    82,     0,     0,    83,  -149,   217,    48,    87,    49,
     218,    35,    36,    91,    92,    93,   219,   220,   221,    51,
     222,    52,     0,   223,     0,    53,    54,     0,     0,   224,
      55,     0,   225,    56,   226,   227,   228,     0,   229,    57,
       0,     0,   230,   231,    59,     0,     0,   232,     0,     0,
       0,     0,     0,     0,     0,     0,   233,     0,     0,     0,
     234,     0,     0,     0,     0,   235,     0,   236,   808,     0,
       0,    38,   209,    33,   210,   211,   212,    71,     0,     0,
       0,     0,   213,     0,     0,     0,     0,    72,   214,   215,
      75,     0,     0,     0,    45,    77,    78,  -149,    34,    80,
      81,     0,    82,     0,     0,    83,  -149,   217,    48,    87,
      49,   218,    35,    36,    91,    92,    93,   219,   220,   221,
      51,   222,    52,     0,   223,     0,    53,    54,     0,     0,
     224,    55,     0,   225,    56,   226,   227,   228,     0,   229,
      57,     0,     0,   230,   231,    59,     0,     0,   232,     0,
       0,     0,     0,     0,   901,     0,     0,   233,   209,    33,
     210,   234,     0,    71,     0,     0,   235,     0,   236,     0,
       0,     0,    38,    72,   214,   215,    75,  -338,     0,     0,
      45,    77,    78,  -149,    34,    80,    81,     0,    82,     0,
       0,    83,  -149,   217,    48,    87,    49,   218,    35,    36,
      91,    92,    93,   219,   220,   221,    51,   222,    52,     0,
     223,     0,    53,    54,     0,     0,   224,    55,     0,   225,
      56,   226,   227,   228,     0,   229,    57,     0,     0,   230,
     231,    59,     0,     0,   232,     0,     0,     0,     0,     0,
     901,     0,     0,     0,   209,    33,   210,     0,     0,    71,
    -338,     0,   235,  -338,   236,     0,     0,     0,    38,    72,
     214,   215,    75,     0,     0,     0,    45,    77,    78,  -149,
      34,    80,    81,     0,    82,     0,     0,    83,  -149,   217,
      48,    87,    49,   218,    35,    36,    91,    92,    93,   219,
     220,   221,    51,   222,    52,     0,   223,     0,    53,    54,
       0,     0,   224,    55,     0,   225,    56,   226,   227,   228,
       0,   229,    57,     0,     0,   230,   231,    59,     0,     0,
     232,     0,     0,     0,     0,     0,   901,     0,     0,     0,
     209,    33,   210,     0,  -338,    71,     0,     0,   235,     0,
     236,     0,     0,     0,    38,    72,   214,   215,    75,     0,
       0,     0,    45,    77,    78,  -149,    34,    80,    81,     0,
      82,     0,     0,    83,  -149,   217,    48,    87,    49,   218,
      35,    36,    91,    92,    93,   219,   220,   221,    51,   222,
      52,     0,   223,     0,    53,    54,     0,     0,   224,    55,
       0,   225,    56,   226,   227,   228,     0,   229,    57,     0,
       0,   230,   231,    59,     0,     0,   232,     0,     0,     0,
       0,     0,     0,   420,     0,     0,     0,   209,    33,   210,
     211,   212,    71,     0,   235,     0,   236,   213,     0,     0,
      38,     0,    72,   214,   215,    75,     0,     0,     0,     0,
      77,    78,  -149,    34,    80,    81,     0,    82,     0,     0,
      83,  -149,   217,     0,    87,     0,   218,    35,    36,    91,
      92,    93,   219,   220,   221,     0,   222,     0,  -410,   223,
       0,     0,     0,     0,     0,   224,     0,     0,   225,     0,
     226,   227,   228,     0,   229,     0,     0,     0,   230,   231,
       0,     0,     0,   232,     0,     0,     0,     0,     0,     0,
       0,     0,   233,     0,     0,     0,   234,     0,     0,     0,
       0,   235,  -410,   236,   492,     0,   421,    38,   209,    33,
     210,   211,   212,    71,     0,     0,     0,     0,   213,     0,
       0,     0,     0,    72,   214,   215,    75,     0,     0,     0,
       0,    77,    78,  -149,    34,    80,    81,     0,    82,     0,
       0,    83,  -149,   217,     0,    87,     0,   218,    35,    36,
      91,    92,    93,   219,   220,   221,     0,   222,     0,     0,
     223,     0,     0,     0,     0,     0,   224,     0,     0,   225,
       0,   226,   227,   228,     0,   229,     0,     0,     0,   230,
     231,     0,     0,     0,   232,     0,     0,     0,     0,     0,
       0,     0,     0,   233,     0,     0,     0,   234,     0,     0,
       0,     0,   235,  -410,   236,   691,     0,   421,    38,   209,
      33,   210,   211,   212,    71,     0,     0,     0,     0,   213,
       0,     0,     0,     0,    72,   214,   215,    75,     0,     0,
       0,     0,    77,    78,  -149,    34,    80,    81,     0,    82,
       0,     0,    83,  -149,   217,     0,    87,     0,   218,    35,
      36,    91,    92,    93,   219,   220,   221,     0,   222,     0,
       0,   223,     0,     0,     0,     0,     0,   224,     0,     0,
     225,     0,   226,   227,   228,     0,   229,     0,     0,     0,
     230,   231,     0,     0,     0,   232,     0,     0,     0,     0,
       0,     0,     0,     0,   233,     0,     0,     0,   234,     0,
       0,     0,     0,   235,  -409,   236,  -409,   208,     0,    38,
       0,   209,    33,   210,   211,   212,    71,     0,     0,     0,
       0,   213,     0,     0,     0,     0,    72,   214,   215,    75,
     216,     0,     0,     0,    77,    78,  -149,    34,    80,    81,
       0,    82,     0,     0,    83,  -149,   217,     0,    87,     0,
     218,    35,    36,    91,    92,    93,   219,   220,   221,     0,
     222,     0,     0,   223,     0,     0,     0,     0,     0,   224,
       0,     0,   225,     0,   226,   227,   228,     0,   229,     0,
       0,     0,   230,   231,     0,     0,     0,   232,     0,     0,
       0,     0,     0,     0,     0,     0,   233,     0,     0,     0,
     234,     0,     0,     0,     0,   235,     0,   236,   396,     0,
       0,    38,  -217,  -217,  -217,  -217,  -217,  -217,     0,     0,
       0,     0,  -217,     0,     0,     0,     0,  -217,  -217,  -217,
    -217,   397,     0,     0,     0,  -217,  -217,  -217,  -217,  -217,
    -217,     0,  -217,     0,     0,  -217,  -217,  -217,     0,  -217,
       0,  -217,  -217,  -217,  -217,  -217,  -217,  -217,  -217,  -217,
       0,  -217,     0,     0,  -217,     0,     0,     0,     0,     0,
    -217,     0,     0,  -217,     0,  -217,  -217,  -217,     0,  -217,
       0,     0,     0,  -217,  -217,     0,     0,     0,  -217,     0,
       0,     0,     0,     0,     0,     0,     0,  -217,     0,     0,
       0,  -217,     0,     0,     0,     0,  -217,     0,  -217,   323,
       0,     0,  -217,   209,    33,   210,   211,   212,    71,     0,
       0,     0,     0,   213,     0,     0,     0,     0,    72,   214,
     215,    75,     0,     0,     0,     0,    77,    78,  -149,    34,
      80,    81,     0,    82,     0,     0,    83,  -149,   217,     0,
      87,     0,   218,    35,    36,    91,    92,    93,   219,   220,
     221,     0,   222,     0,     0,   223,     0,     0,     0,     0,
       0,   224,     0,     0,   225,     0,   226,   227,   228,     0,
     229,     0,     0,     0,   230,   231,     0,     0,     0,   232,
       0,     0,     0,     0,     0,     0,     0,     0,   233,     0,
       0,     0,   234,     0,     0,     0,     0,   235,     0,   236,
     743,   324,     0,    38,   209,    33,   210,   211,   212,    71,
       0,     0,     0,     0,   213,     0,     0,     0,     0,    72,
     214,   215,    75,   744,     0,     0,     0,    77,    78,  -149,
      34,    80,    81,     0,    82,     0,     0,    83,  -149,   217,
       0,    87,     0,   218,    35,    36,    91,    92,    93,   219,
     220,   221,     0,   222,     0,     0,   223,     0,     0,     0,
       0,     0,   224,     0,     0,   225,     0,   226,   227,   228,
       0,   229,     0,     0,     0,   230,   231,     0,     0,     0,
     232,     0,     0,     0,     0,     0,     0,     0,     0,   233,
       0,     0,     0,   234,     0,     0,     0,     0,   235,     0,
     236,   406,     0,     0,    38,   209,    33,   210,   211,   212,
      71,     0,     0,     0,     0,   213,     0,     0,     0,     0,
      72,   214,   215,    75,     0,     0,     0,     0,    77,    78,
    -149,    34,    80,    81,     0,    82,     0,     0,    83,  -149,
     217,     0,    87,     0,   218,    35,    36,    91,    92,    93,
     219,   220,   221,     0,   222,     0,     0,   223,     0,     0,
       0,     0,     0,   224,     0,     0,   225,     0,   226,   227,
     228,     0,   229,     0,     0,     0,   230,   231,     0,     0,
       0,   232,     0,     0,     0,     0,     0,     0,     0,     0,
     233,     0,     0,     0,   234,     0,     0,     0,     0,   235,
       0,   236,   426,     0,     0,    38,   209,    33,   210,   211,
     212,    71,     0,     0,     0,     0,   213,     0,     0,     0,
       0,    72,   214,   215,    75,     0,     0,     0,     0,    77,
      78,  -149,    34,    80,    81,     0,    82,     0,     0,    83,
    -149,   217,     0,    87,     0,   218,    35,    36,    91,    92,
      93,   219,   220,   221,     0,   222,     0,     0,   223,     0,
       0,     0,     0,     0,   224,     0,     0,   225,     0,   226,
     227,   228,     0,   229,     0,     0,     0,   230,   231,     0,
       0,     0,   232,     0,     0,     0,     0,     0,     0,     0,
       0,   233,     0,     0,     0,   234,     0,     0,     0,     0,
     235,     0,   236,   490,     0,     0,    38,   209,    33,   210,
     211,   212,    71,     0,     0,     0,     0,   213,     0,     0,
       0,     0,    72,   214,   215,    75,     0,     0,     0,     0,
      77,    78,  -149,    34,    80,    81,     0,    82,     0,     0,
      83,  -149,   217,     0,    87,     0,   218,    35,    36,    91,
      92,    93,   219,   220,   221,     0,   222,     0,     0,   223,
       0,     0,     0,     0,     0,   224,     0,     0,   225,     0,
     226,   227,   228,     0,   229,     0,     0,     0,   230,   231,
       0,     0,     0,   232,     0,     0,     0,     0,     0,     0,
       0,     0,   233,     0,     0,     0,   234,     0,     0,     0,
       0,   235,     0,   236,   500,     0,     0,    38,   209,    33,
     210,   211,   212,    71,     0,     0,     0,     0,   213,     0,
       0,     0,     0,    72,   214,   215,    75,     0,     0,     0,
       0,    77,    78,  -149,    34,    80,    81,     0,    82,     0,
       0,    83,  -149,   217,     0,    87,     0,   218,    35,    36,
      91,    92,    93,   219,   220,   221,     0,   222,     0,     0,
     223,     0,     0,     0,     0,     0,   224,     0,     0,   225,
       0,   226,   227,   228,     0,   229,     0,     0,     0,   230,
     231,     0,     0,     0,   232,     0,     0,     0,     0,     0,
       0,     0,     0,   233,     0,     0,     0,   234,     0,     0,
       0,     0,   235,     0,   236,   688,     0,     0,    38,   209,
      33,   210,   211,   212,    71,     0,     0,     0,     0,   213,
       0,     0,     0,     0,    72,   214,   215,    75,     0,     0,
       0,     0,    77,    78,  -149,    34,    80,    81,     0,    82,
       0,     0,    83,  -149,   217,     0,    87,     0,   218,    35,
      36,    91,    92,    93,   219,   220,   221,     0,   222,     0,
       0,   223,     0,     0,     0,     0,     0,   224,     0,     0,
     225,     0,   226,   227,   228,     0,   229,     0,     0,     0,
     230,   231,     0,     0,     4,   232,     0,  -149,     0,     0,
       0,     0,     0,     0,   233,     0,     0,     0,   234,     0,
       0,     0,     0,   235,     0,   236,     0,   289,     0,    38,
    -149,     0,     0,  -149,  -149,     0,     0,     0,     0,     0,
       0,     0,  -149,     6,  -149,     0,  -149,     0,  -149,  -149,
       0,     7,  -149,     8,     9,    10,  -149,     0,  -149,     0,
       0,     0,  -149,  -149,     0,     4,    11,  -149,  -149,    12,
    -149,    13,  -149,    14,     0,    15,  -149,     0,  -149,     0,
      16,  -149,     0,     0,    17,     0,     0,     0,   511,     0,
       0,  -149,     0,     0,  -149,  -149,     0,     0,    18,     0,
     290,     0,     0,  -149,     6,  -149,  -149,  -149,  -149,  -149,
    -149,     0,     7,  -149,     8,     9,    10,  -149,     0,  -149,
       0,     0,     0,  -149,  -149,     0,     0,    11,  -149,     0,
      12,  -149,    13,  -149,    14,     0,    15,  -149,     0,  -149,
       0,    16,  -149,   452,     0,    17,     0,   209,    33,   210,
     211,   212,     0,     0,     0,     0,     0,   213,     0,    18,
       0,   512,     0,   298,   299,     0,     0,  -149,     0,  -149,
       0,     0,  -149,    34,     0,     0,     0,     0,     0,     0,
       0,  -149,     6,     0,     0,     0,   300,    35,    36,     0,
       0,     0,     8,   301,    10,     0,   302,     0,     0,   223,
       0,     0,     0,     0,     0,    11,     0,     0,    12,     0,
      13,    37,    14,     0,    15,     0,     0,     0,   303,    16,
    -617,  -617,     0,    17,     0,     0,     0,     0,     0,  -617,
       0,     0,   233,     0,     0,     0,   234,     0,     0,     0,
       0,   235,     0,   236,   454,     0,     0,    38,   209,    33,
     210,   211,   212,  -617,     0,     0,  -617,  -617,   213,     0,
    -617,     0,     0,     0,   298,   299,  -617,     0,     0,  -617,
       0,     0,     0,  -149,    34,  -617,     0,  -617,     0,     0,
       0,     0,  -149,     6,     0,     0,     0,   300,    35,    36,
       0,   821,     0,     8,   301,    10,     0,   302,     0,     0,
     223,     0,     0,     0,     0,     0,    11,     0,     0,    12,
       0,    13,    37,    14,     0,    15,     0,     0,     0,   303,
      16,   364,   365,     0,    17,     0,     0,     0,     0,     0,
     366,     0,     0,   233,     0,     0,     0,   234,     0,     0,
       0,     0,   235,     0,   236,   456,     0,     0,    38,   209,
      33,   210,   211,   212,   367,     0,     0,   368,   369,   213,
       0,   370,     0,     0,     0,   298,   299,   371,     0,     0,
     372,     0,     0,     0,  -149,    34,   373,     0,   378,     0,
       0,     0,     0,  -149,     6,     0,     0,     0,   300,    35,
      36,     0,     0,     0,     8,   301,    10,     0,   302,     0,
       0,   223,     0,     0,     0,     0,     0,    11,     0,     0,
      12,     0,    13,    37,    14,     0,    15,     0,     0,     0,
     303,    16,  -603,  -603,     0,    17,     0,     0,     0,     0,
       0,  -603,     0,     0,   233,     0,     0,     0,   234,     0,
       0,     0,     0,   235,     0,   236,   458,     0,     0,    38,
     209,    33,   210,   211,   212,  -603,     0,     0,  -603,  -603,
     213,     0,  -603,     0,     0,     0,   298,   299,  -603,     0,
       0,  -603,     0,     0,     0,  -149,    34,  -603,     0,  -603,
       0,     0,     0,     0,  -149,     6,     0,     0,     0,   300,
      35,    36,     0,     0,     0,     8,   301,    10,     0,   302,
       0,     0,   223,     0,     0,     0,     0,     0,    11,     0,
       0,    12,     0,    13,    37,    14,     0,    15,     0,     0,
       0,   303,    16,     0,     0,     0,    17,     0,     0,     0,
       0,     0,     0,     0,     0,   233,     0,     0,     0,   234,
       0,     0,     0,     0,   235,     0,   236,   460,     0,     0,
      38,   209,    33,   210,   211,   212,     0,     0,     0,     0,
       0,   213,     0,     0,     0,     0,     0,   298,   299,     0,
       0,     0,     0,     0,     0,     0,  -149,    34,     0,     0,
       0,     0,     0,     0,     0,  -149,     6,     0,     0,     0,
     300,    35,    36,     0,     0,     0,     8,   301,    10,     0,
     302,     0,     0,   223,     0,     0,     0,     0,     0,    11,
       0,     0,    12,     0,    13,    37,    14,     0,    15,     0,
       0,     0,   303,    16,     0,     0,     0,    17,     0,     0,
       0,     0,     0,     0,     0,     0,   233,     0,     0,     0,
     234,     0,     0,     0,     0,   235,     0,   236,   462,     0,
       0,    38,   209,    33,   210,   211,   212,     0,     0,     0,
       0,     0,   213,     0,     0,     0,     0,     0,   298,   299,
       0,     0,     0,     0,     0,     0,     0,  -149,    34,     0,
       0,     0,     0,     0,     0,     0,  -149,     6,     0,     0,
       0,   300,    35,    36,     0,     0,     0,     8,   301,    10,
       0,   302,     0,     0,   223,     0,     0,     0,     0,     0,
      11,     0,     0,    12,     0,    13,    37,    14,     0,    15,
       0,     0,     0,   303,    16,     0,     0,     0,    17,     0,
       0,     0,     0,     0,     0,     0,     0,   233,     0,     0,
       0,   234,     0,     0,     0,     0,   235,     0,   236,   464,
       0,     0,    38,   209,    33,   210,   211,   212,     0,     0,
       0,     0,     0,   213,     0,     0,     0,     0,     0,   298,
     299,     0,     0,     0,     0,     0,     0,     0,  -149,    34,
       0,     0,     0,     0,     0,     0,     0,  -149,     6,     0,
       0,     0,   300,    35,    36,     0,     0,     0,     8,   301,
      10,     0,   302,     0,     0,   223,     0,     0,     0,     0,
       0,    11,     0,     0,    12,     0,    13,    37,    14,     0,
      15,     0,     0,     0,   303,    16,     0,     0,     0,    17,
       0,     0,     0,     0,     0,     0,     0,     0,   233,     0,
       0,     0,   234,     0,     0,     0,     0,   235,     0,   236,
     466,     0,     0,    38,   209,    33,   210,   211,   212,     0,
       0,     0,     0,     0,   213,     0,     0,     0,     0,     0,
     298,   299,     0,     0,     0,     0,     0,     0,     0,  -149,
      34,     0,     0,     0,     0,     0,     0,     0,  -149,     6,
       0,     0,     0,   300,    35,    36,     0,     0,     0,     8,
     301,    10,     0,   302,     0,     0,   223,     0,     0,     0,
       0,     0,    11,     0,     0,    12,     0,    13,    37,    14,
       0,    15,     0,     0,     0,   303,    16,     0,     0,     0,
      17,     0,     0,     0,     0,     0,     0,     0,     0,   233,
       0,     0,     0,   234,     0,     0,     0,     0,   235,     0,
     236,   469,     0,     0,    38,   209,    33,   210,   211,   212,
       0,     0,     0,     0,     0,   213,     0,     0,     0,     0,
       0,   298,   299,     0,     0,     0,     0,     0,     0,     0,
    -149,    34,     0,     0,     0,     0,     0,     0,     0,  -149,
       6,     0,     0,     0,   300,    35,    36,     0,     0,     0,
       8,   301,    10,     0,   302,     0,     0,   223,     0,     0,
       0,     0,     0,    11,     0,     0,    12,     0,    13,    37,
      14,     0,    15,     0,     0,     0,   303,    16,     0,     0,
       0,    17,     0,     0,     0,     0,     0,     0,     0,     0,
     233,     0,     0,     0,   234,     0,     0,     0,     0,   235,
       0,   236,   471,     0,     0,    38,   209,    33,   210,   211,
     212,     0,     0,     0,     0,     0,   213,     0,     0,     0,
       0,     0,   298,   299,     0,     0,     0,     0,     0,     0,
       0,  -149,    34,     0,     0,     0,     0,     0,     0,     0,
    -149,     6,     0,     0,     0,   300,    35,    36,     0,     0,
       0,     8,   301,    10,     0,   302,     0,     0,   223,     0,
       0,     0,     0,     0,    11,     0,     0,    12,     0,    13,
      37,    14,     0,    15,     0,     0,     0,   303,    16,     0,
       0,     0,    17,     0,     0,     0,     0,     0,     0,     0,
       0,   233,     0,     0,     0,   234,     0,     0,     0,     0,
     235,     0,   236,   473,     0,     0,    38,   209,    33,   210,
     211,   212,     0,     0,     0,     0,     0,   213,     0,     0,
       0,     0,     0,   298,   299,     0,     0,     0,     0,     0,
       0,     0,  -149,    34,     0,     0,     0,     0,     0,     0,
       0,  -149,     6,     0,     0,     0,   300,    35,    36,     0,
       0,     0,     8,   301,    10,     0,   302,     0,     0,   223,
       0,     0,     0,     0,     0,    11,     0,     0,    12,     0,
      13,    37,    14,     0,    15,     0,     0,     0,   303,    16,
       0,     0,     0,    17,     0,     0,     0,     0,     0,     0,
       0,     0,   233,     0,     0,     0,   234,     0,     0,     0,
       0,   235,     0,   236,   475,     0,     0,    38,   209,    33,
     210,   211,   212,     0,     0,     0,     0,     0,   213,     0,
       0,     0,     0,     0,   298,   299,     0,     0,     0,     0,
       0,     0,     0,  -149,    34,     0,     0,     0,     0,     0,
       0,     0,  -149,     6,     0,     0,     0,   300,    35,    36,
       0,     0,     0,     8,   301,    10,     0,   302,     0,     0,
     223,     0,     0,     0,     0,     0,    11,     0,     0,    12,
       0,    13,    37,    14,     0,    15,     0,     0,     0,   303,
      16,     0,     0,     0,    17,     0,     0,     0,     0,     0,
       0,     0,     0,   233,     0,     0,     0,   234,     0,     0,
       0,     0,   235,     0,   236,   477,     0,     0,    38,   209,
      33,   210,   211,   212,     0,     0,     0,     0,     0,   213,
       0,     0,     0,     0,     0,   298,   299,     0,     0,     0,
       0,     0,     0,     0,  -149,    34,     0,     0,     0,     0,
       0,     0,     0,  -149,     6,     0,     0,     0,   300,    35,
      36,     0,     0,     0,     8,   301,    10,     0,   302,     0,
       0,   223,     0,     0,     0,     0,     0,    11,     0,     0,
      12,     0,    13,    37,    14,     0,    15,     0,     0,     0,
     303,    16,     0,     0,     0,    17,     0,     0,     0,     0,
       0,     0,     0,     0,   233,     0,     0,     0,   234,     0,
       0,     0,     0,   235,     0,   236,   479,     0,     0,    38,
     209,    33,   210,   211,   212,     0,     0,     0,     0,     0,
     213,     0,     0,     0,     0,     0,   298,   299,     0,     0,
       0,     0,     0,     0,     0,  -149,    34,     0,     0,     0,
       0,     0,     0,     0,  -149,     6,     0,     0,     0,   300,
      35,    36,     0,     0,     0,     8,   301,    10,     0,   302,
       0,     0,   223,     0,     0,     0,     0,     0,    11,     0,
       0,    12,     0,    13,    37,    14,     0,    15,     0,     0,
       0,   303,    16,     0,     0,     0,    17,     0,     0,     0,
       0,     0,     0,     0,     0,   233,     0,     0,     0,   234,
       0,     0,     0,     0,   235,     0,   236,   481,     0,     0,
      38,   209,    33,   210,   211,   212,     0,     0,     0,     0,
       0,   213,     0,     0,     0,     0,     0,   298,   299,     0,
       0,     0,     0,     0,     0,     0,  -149,    34,     0,     0,
       0,     0,     0,     0,     0,  -149,     6,     0,     0,     0,
     300,    35,    36,     0,     0,     0,     8,   301,    10,     0,
     302,     0,     0,   223,     0,     0,     0,     0,     0,    11,
       0,     0,    12,     0,    13,    37,    14,     0,    15,     0,
       0,     0,   303,    16,     0,     0,     0,    17,     0,     0,
       0,     0,     0,     0,     0,     0,   233,     0,     0,     0,
     234,     0,     0,     0,     0,   235,     0,   236,   483,     0,
       0,    38,   209,    33,   210,   211,   212,     0,     0,     0,
       0,     0,   213,     0,     0,     0,     0,     0,   298,   299,
       0,     0,     0,     0,     0,     0,     0,  -149,    34,     0,
       0,     0,     0,     0,     0,     0,  -149,     6,     0,     0,
       0,   300,    35,    36,     0,     0,     0,     8,   301,    10,
       0,   302,     0,     0,   223,     0,     0,     0,     0,     0,
      11,     0,     0,    12,     0,    13,    37,    14,     0,    15,
       0,     0,     0,   303,    16,     0,     0,     0,    17,     0,
       0,     0,     0,     0,     0,     0,     0,   233,     0,     0,
       0,   234,     0,     0,     0,     0,   235,     0,   236,   485,
       0,     0,    38,   209,    33,   210,   211,   212,     0,     0,
       0,     0,     0,   213,     0,     0,     0,     0,     0,   298,
     299,     0,     0,     0,     0,     0,     0,     0,  -149,    34,
       0,     0,     0,     0,     0,     0,     0,  -149,     6,     0,
       0,     0,   300,    35,    36,     0,     0,     0,     8,   301,
      10,     0,   302,     0,     0,   223,     0,     0,     0,     0,
       0,    11,     0,     0,    12,     0,    13,    37,    14,     0,
      15,     0,     0,     0,   303,    16,     0,     0,     0,    17,
       0,     0,     0,     0,     0,     0,     0,     0,   233,     0,
       0,     0,   234,     0,     0,     0,     0,   235,     0,   236,
     487,     0,     0,    38,   209,    33,   210,   211,   212,     0,
       0,     0,     0,     0,   213,     0,     0,     0,     0,     0,
     298,   299,     0,     0,     0,     0,     0,     0,     0,  -149,
      34,     0,     0,     0,     0,     0,     0,     0,  -149,     6,
       0,     0,     0,   300,    35,    36,     0,     0,     0,     8,
     301,    10,     0,   302,     0,     0,   223,     0,    32,     0,
       0,     0,    11,    33,     0,    12,     0,    13,    37,    14,
       0,    15,     0,     0,     0,   303,    16,     0,     0,     0,
      17,     0,  -606,  -606,     0,     0,     0,     0,    34,   233,
       0,  -606,     0,   234,     0,     0,     0,     0,   235,     0,
     236,     0,    35,    36,    38,   342,   343,   344,   345,     0,
     346,   347,   348,   349,     0,  -606,     0,     0,  -606,  -606,
       0,     0,  -606,     0,     0,     0,    37,     0,  -606,     0,
       0,  -606,     0,     0,     0,  -512,     0,  -606,     0,  -606,
    -512,  -512,     0,  -512,  -512,  -512,  -512,     0,  -512,  -512,
    -512,  -512,     0,     0,     0,     0,  -512,  -512,  -512,     0,
       0,     0,    38,     0,     0,     0,  -512,     0,  -512,  -512,
       0,     0,     0,     0,     0,     0,     0,   350,   351,   352,
     353,   354,   355,   356,   357,   358,   359,   360,     0,     0,
    -512,     0,     0,  -512,  -512,     0,     0,  -512,     0,     0,
       0,     0,     0,  -512,     0,     0,  -512,     0,     0,     0,
       0,     0,  -512,  -408,  -512,  -512,  -512,  -512,  -512,  -512,
    -512,  -512,  -512,  -512,  -512,  -512,     0,  -512,  -512,  -512,
    -512,  -512,  -512,  -512,  -512,  -512,  -408,   124,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     6,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     8,     9,    10,     0,     0,     0,     0,     0,
       0,     0,    44,     0,     0,    11,     0,     0,    12,     0,
      13,     0,    14,     0,    15,     0,     0,     0,     0,    16,
       0,     0,     0,    17,     0,    45,     0,     0,    46,    34,
       0,     0,     0,     0,     0,   581,     0,    47,     0,    48,
     268,    49,  -408,    35,    36,  -408,     0,    50,     0,     0,
       0,    51,     0,    52,     0,     0,     0,    53,    54,   364,
     365,     0,    55,     0,     0,    56,     0,    37,   366,     0,
       0,    57,     0,    58,     0,     0,    59,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   367,     0,     0,   368,   369,     0,     0,   370,
       0,    60,     0,    38,     0,   371,     0,     0,   372,     0,
       0,     0,     0,     0,   373,     0,   582,     0,     0,     0,
       0,     0,     0,   209,    33,   210,   211,   212,    71,     0,
       0,     0,  -568,   213,     0,     0,  -568,     0,    72,   214,
     215,    75,     0,     0,     0,    45,    77,    78,     0,    34,
      80,    81,     0,    82,     0,     0,    83,     0,   217,    48,
      87,    49,   218,    35,    36,    91,    92,    93,   219,   220,
     221,    51,   222,    52,     0,   223,     0,    53,    54,     0,
       0,   224,    55,     0,   225,    56,   226,   227,   228,     0,
     229,    57,     0,     0,   230,   231,    59,     0,     0,   232,
       0,     0,     0,     0,     0,     0,     0,     0,   233,     0,
       0,     0,   234,     0,     0,     0,     0,   235,  -414,   236,
    -414,     0,     0,    38,   209,    33,   210,   211,   212,    71,
       0,     0,     0,     0,   213,     0,     0,     0,     0,    72,
     214,   215,    75,   697,     0,     0,    45,    77,    78,     0,
      34,    80,    81,     0,    82,     0,     0,    83,     0,   217,
      48,    87,    49,   218,    35,    36,    91,    92,    93,   219,
     220,   221,    51,   222,    52,     0,   223,     0,    53,    54,
       0,     0,   224,    55,     0,   225,    56,   226,   227,   228,
       0,   229,    57,     0,     0,   230,   231,    59,     0,     0,
     232,     0,     0,     0,     0,     0,     0,     0,     0,   233,
     209,    33,   210,   234,     0,    71,     0,     0,   235,     0,
     236,  -536,     0,     0,    38,    72,   214,   215,    75,     0,
       0,     0,    45,    77,    78,     0,    34,    80,    81,     0,
      82,     0,     0,    83,     0,   217,    48,    87,    49,   218,
      35,    36,    91,    92,    93,   219,   220,   221,    51,   222,
      52,     0,   223,     0,    53,    54,     0,     0,   224,    55,
       0,   225,    56,   226,   227,   228,     0,   229,    57,     0,
       0,   230,   231,    59,     0,     0,   232,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   209,    33,   210,
     211,   212,    71,     0,   235,     0,   236,   213,     0,     0,
      38,     0,    72,   214,   215,    75,     0,     0,     0,     0,
      77,    78,     0,    34,    80,    81,     0,    82,     0,     0,
      83,     0,   217,     0,    87,     0,   218,    35,    36,    91,
      92,    93,   219,   220,   221,     0,   222,     0,     0,   223,
       0,     0,     0,     0,     0,   224,     0,     0,   225,     0,
     226,   227,   228,     0,   229,     0,     0,     0,   230,   231,
       0,     0,     0,   232,     0,     0,     0,     0,     0,     0,
       0,     0,   233,     0,     0,     0,   234,     0,     0,  -410,
       0,   235,  -410,   236,     0,     0,   421,    38,   209,    33,
     210,   211,   212,    71,     0,     0,     0,     0,   213,     0,
       0,     0,     0,    72,   214,   215,    75,     0,     0,     0,
       0,    77,    78,  -149,    34,    80,    81,     0,    82,     0,
       0,    83,  -149,   217,     0,    87,     0,   218,    35,    36,
      91,    92,    93,   219,   220,   221,     0,   222,     0,     0,
     223,     0,     0,     0,     0,     0,   224,     0,     0,   225,
       0,   226,   227,   228,     0,   229,     0,     0,     0,   230,
     231,     0,     0,     0,   232,     0,     0,     0,     0,     0,
       0,     0,     0,   233,     0,     0,     0,   234,     0,     0,
       0,     0,   235,     0,   236,     0,     0,   421,    38,   209,
      33,   210,   211,   212,    71,     0,     0,     0,     0,   213,
       0,     0,     0,     0,    72,   214,   215,    75,     0,     0,
       0,     0,    77,    78,     0,    34,    80,    81,     0,    82,
       0,     0,    83,     0,   217,     0,    87,     0,   218,    35,
      36,    91,    92,    93,   219,   220,   221,     0,   222,     0,
       0,   223,     0,     0,     0,     0,     0,   224,     0,     0,
     225,     0,   226,   227,   228,     0,   229,     0,     0,     0,
     230,   231,     0,     0,     0,   232,     0,     0,     0,     0,
       0,     0,     0,     0,   233,     0,     0,   -94,   234,     0,
       0,     0,     0,   235,     0,   236,   -94,   -94,     0,    38,
     209,    33,   210,   211,   212,     0,     0,   -94,   -94,   -94,
     213,     0,     0,     0,     0,     0,   298,   299,     0,     0,
     -94,     0,     0,   -94,     0,   -94,    34,   -94,     0,   -94,
       0,     0,     0,     0,   -94,     6,     0,     0,   -94,   300,
      35,    36,     0,     0,     0,     8,   301,    10,     0,   302,
       0,     0,   223,     0,     0,     0,     0,     0,    11,     0,
       0,    12,     0,    13,    37,    14,     0,    15,     0,     0,
       0,   303,    16,     0,     0,     0,    17,     0,     0,     0,
       0,   209,    33,   210,     0,   233,     0,     0,     0,   234,
       0,     0,     0,     0,   235,     0,   236,   298,   299,     0,
      38,     0,     0,     0,     0,     0,     0,    34,     0,   361,
       0,     0,     0,     0,   362,   363,     6,     0,     0,     0,
     300,    35,    36,     0,     0,     0,     8,   301,    10,     0,
     302,   364,   365,   223,     0,     0,     0,     0,     0,    11,
     366,     0,    12,     0,    13,    37,    14,     0,    15,     0,
       0,     0,   303,    16,     0,     0,   361,    17,     0,     0,
       0,   362,   363,     0,   367,     0,     0,   368,   369,     0,
       0,   370,     0,     0,     0,   235,     0,   371,   364,   365,
     372,    38,     0,     0,     0,     0,   373,   366,   374,   342,
     343,   344,   345,     0,   346,   347,   348,   342,   343,   344,
     345,     0,   346,   347,  -567,   235,     0,   236,  -567,     0,
       0,   367,     0,     0,   368,   369,     0,     0,   370,     0,
     342,   343,   344,   345,   371,   346,   347,   372,     0,     0,
       0,     0,     0,   373,     0,   374,   342,   343,   344,   345,
       0,   346,   347,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   235,     0,   236,     0,     0,     0,     0,     0,
       0,     0,   351,   352,   353,   354,   355,   356,   357,   358,
     359,   360,   353,   354,   355,   356,   357,   358,   359,   360,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   351,   352,   353,   354,   355,   356,   357,
     358,   359,   360,     0,     0,     0,     0,     0,     0,    71,
       0,     0,   354,   355,   356,   357,   358,   359,   360,    72,
      73,    74,    75,     0,     0,     0,    76,    77,    78,    79,
       0,    80,    81,     0,    82,   385,   386,    83,    84,    85,
      86,    87,    88,    89,     0,     0,    91,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,   100,   101,
       0,     0,   102,   103,     0,   104,   105,   106,   107,   108,
       0,   109,   110,     0,   111,   112,   113,   114,     0,     0,
     115,    71,     0,     0,     0,     0,     0,     0,     0,     0,
     203,    72,    73,    74,    75,     0,     0,     0,    76,    77,
      78,    79,     0,    80,    81,     0,    82,     0,     0,    83,
      84,    85,    86,    87,    88,    89,     0,   197,    91,    92,
      93,    94,    95,    96,    97,    98,    99,     0,     0,     0,
     100,   101,     0,     0,   102,   103,     0,   104,   105,   106,
     107,   108,     0,   109,   110,     0,   111,   112,   113,   114,
       0,     0,   115,    71,     0,     0,     0,     0,     0,     0,
       0,     0,   198,    72,    73,    74,    75,     0,     0,     0,
      76,    77,    78,    79,     0,    80,    81,     0,    82,     0,
       0,    83,    84,    85,    86,    87,    88,    89,     0,   202,
      91,    92,    93,    94,    95,    96,    97,    98,    99,     0,
       0,     0,   100,   101,     0,     0,   102,   103,     0,   104,
     105,   106,   107,   108,     0,   109,   110,     0,   111,   112,
     113,   114,     0,     0,   115,    71,     0,     0,     0,     0,
       0,     0,     0,     0,   203,    72,    73,    74,    75,     0,
       0,     0,    76,    77,    78,    79,     0,    80,    81,     0,
      82,     0,     0,    83,    84,    85,    86,    87,    88,    89,
       0,   403,    91,    92,    93,    94,    95,    96,    97,    98,
      99,     0,     0,     0,   100,   101,     0,     0,   102,   103,
       0,   104,   105,   106,   107,   108,     0,   109,   110,     0,
     111,   112,   113,   114,     0,     0,   115,    71,     0,     0,
       0,     0,     0,     0,     0,     0,   203,    72,    73,    74,
      75,     0,     0,     0,    76,    77,    78,    79,     0,    80,
      81,     0,    82,     0,     0,    83,    84,    85,    86,    87,
      88,    89,     0,   675,    91,    92,    93,    94,    95,    96,
      97,    98,    99,     0,     0,     0,   100,   101,     0,     0,
     102,   103,     0,   104,   105,   106,   107,   108,     0,   109,
     110,     0,   111,   112,   113,   114,     0,     0,   115,    71,
       0,     0,     0,     0,     0,     0,     0,     0,   203,    72,
      73,    74,    75,     0,     0,     0,    76,    77,    78,    79,
       0,    80,    81,     0,    82,     0,     0,    83,    84,    85,
      86,    87,    88,    89,     0,   798,    91,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,   100,   101,
     581,     0,   102,   103,     0,   104,   105,   106,   107,   108,
       0,   109,   110,     0,   111,   112,   113,   114,     0,     0,
     115,     0,     0,     0,   364,   365,     0,     0,     0,     0,
     203,     0,     0,   366,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   585,   367,     0,   586,
     368,   369,     0,     0,   370,   587,     0,     0,     0,     0,
     371,     0,     0,   372,     0,   588,   589,   590,   591,   373,
       0,   582,   592,   593,   594,   595,     0,   596,   597,     0,
     598,     0,     0,   599,   600,   601,   602,   603,   604,   605,
     606,   607,   608,   609,   610,   611,   612,   613,   614,   615,
     616,     0,     0,     0,   617,   618,     0,     0,   619,   620,
     125,   621,   622,   623,   624,   625,     0,   626,   627,    71,
     628,   629,   630,   631,   632,     0,   633,     0,     0,    72,
      73,    74,    75,     0,     0,     0,    76,    77,    78,    79,
       0,    80,    81,     0,    82,     0,     0,    83,    84,    85,
      86,    87,    88,    89,     0,   126,    91,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,   100,   101,
       0,     0,   102,   103,   130,   104,   105,   106,   107,   108,
       0,   109,   110,    71,   111,   112,   113,   114,     0,     0,
     115,     0,     0,    72,    73,    74,    75,     0,     0,     0,
      76,    77,    78,    79,     0,    80,    81,     0,    82,     0,
       0,    83,    84,    85,    86,    87,    88,    89,     0,   131,
      91,    92,    93,    94,    95,    96,    97,    98,    99,     0,
       0,     0,   100,   101,     0,     0,   102,   103,   162,   104,
     105,   106,   107,   108,     0,   109,   110,    71,   111,   112,
     113,   114,     0,     0,   115,     0,     0,    72,    73,    74,
      75,     0,     0,     0,    76,    77,    78,    79,     0,    80,
      81,     0,    82,     0,     0,    83,    84,    85,    86,    87,
      88,    89,     0,   163,    91,    92,    93,    94,    95,    96,
      97,    98,    99,     0,     0,     0,   100,   101,     0,     0,
     102,   103,   261,   104,   105,   106,   107,   108,     0,   109,
     110,    71,   111,   112,   113,   114,     0,     0,   115,     0,
       0,    72,    73,    74,    75,     0,     0,     0,    76,    77,
      78,    79,     0,    80,    81,     0,    82,     0,     0,    83,
      84,    85,    86,    87,    88,    89,     0,   131,    91,    92,
      93,    94,    95,    96,    97,    98,    99,     0,     0,     0,
     100,   101,     0,     0,   102,   103,   276,   104,   105,   106,
     107,   108,     0,   109,   110,    71,   111,   112,   113,   114,
       0,     0,   115,     0,     0,    72,    73,    74,    75,     0,
       0,     0,    76,    77,    78,    79,     0,    80,    81,     0,
      82,     0,     0,    83,    84,    85,    86,    87,    88,    89,
       0,   277,    91,    92,    93,    94,    95,    96,    97,    98,
      99,     0,     0,     0,   100,   101,     0,     0,   102,   103,
     803,   104,   105,   106,   107,   108,     0,   109,   110,    71,
     111,   112,   113,   114,     0,     0,   115,     0,     0,    72,
      73,    74,    75,     0,     0,     0,    76,    77,    78,    79,
       0,    80,    81,     0,    82,     0,     0,    83,    84,    85,
      86,    87,    88,    89,     0,   804,    91,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,   100,   101,
       0,     0,   102,   103,   856,   104,   105,   106,   107,   108,
       0,   109,   110,    71,   111,   112,   113,   114,     0,     0,
     115,     0,     0,    72,    73,    74,    75,     0,     0,     0,
      76,    77,    78,    79,     0,    80,    81,     0,    82,     0,
       0,    83,    84,    85,    86,    87,    88,    89,     0,   804,
      91,    92,    93,    94,    95,    96,    97,    98,    99,     0,
       0,     0,   100,   101,     0,     0,   102,   103,     0,   104,
     105,   106,   107,   108,     0,   109,   110,     0,   111,   112,
     113,   114,    45,     0,   115,     0,    34,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    48,     0,    49,     0,
      35,    36,     0,     0,     0,     0,     6,     0,    51,     0,
      52,     0,     0,     0,    53,    54,     8,     9,    10,    55,
       0,     0,    56,     0,    37,     0,    45,     0,    57,    11,
      34,     0,    12,    59,    13,     0,    14,     0,    15,     0,
      48,     0,    49,    16,    35,    36,     0,    17,     0,     0,
       0,     0,    51,   268,    52,     0,     0,     0,    53,    54,
      38,     0,     0,    55,     0,     0,    56,     0,    37,    71,
       0,     0,    57,     0,     0,     0,     0,    59,     0,    72,
      73,    74,    75,     0,     0,     0,    76,    77,    78,    79,
       0,    80,    81,     0,    82,     0,     0,    83,    84,    85,
      86,    87,    88,    89,    38,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,   100,   101,
       0,     0,   102,   103,     0,   104,   105,   106,   107,   108,
       0,   109,   110,    71,   111,   112,   113,   114,     0,     0,
     115,     0,     0,    72,    73,    74,    75,     0,     0,     0,
      76,    77,    78,    79,     0,    80,    81,     0,    82,     0,
       0,    83,    84,    85,    86,    87,    88,    89,     0,   160,
      91,    92,    93,    94,    95,    96,    97,    98,    99,     0,
       0,     0,   100,   101,     0,     0,   102,   103,     0,   104,
     105,   106,   107,   108,     0,   109,   110,    71,   111,   112,
     113,   114,     0,     0,   115,     0,     0,    72,    73,    74,
      75,     0,     0,     0,    76,    77,    78,    79,     0,    80,
      81,     0,    82,     0,     0,    83,    84,    85,    86,    87,
      88,    89,     0,   177,    91,    92,    93,    94,    95,    96,
      97,    98,    99,     0,     0,     0,   100,   101,     0,     0,
     102,   103,     0,   104,   105,   106,   107,   108,     0,   109,
     110,    71,   111,   112,   113,   114,     0,     0,   115,     0,
       0,    72,    73,    74,    75,     0,     0,     0,    76,    77,
      78,    79,     0,    80,    81,     0,    82,     0,     0,    83,
      84,    85,    86,    87,    88,    89,     0,   197,    91,    92,
      93,    94,    95,    96,    97,    98,    99,     0,     0,     0,
     100,   101,     0,     0,   102,   103,     0,   104,   105,   106,
     107,   108,     0,   109,   110,    71,   111,   112,   113,   114,
       0,     0,   115,     0,     0,    72,    73,    74,    75,     0,
       0,     0,    76,    77,    78,    79,     0,    80,    81,     0,
      82,     0,     0,    83,    84,    85,    86,    87,    88,    89,
       0,   417,    91,    92,    93,    94,    95,    96,    97,    98,
      99,     0,     0,     0,   100,   101,     0,     0,   102,   103,
       0,   104,   105,   106,   107,   108,     0,   109,   110,    71,
     111,   112,   113,   114,     0,     0,   115,     0,     0,    72,
      73,    74,    75,     0,     0,     0,    76,    77,    78,    79,
       0,    80,    81,     0,    82,     0,     0,    83,    84,    85,
      86,    87,    88,    89,     0,   541,    91,    92,    93,    94,
      95,    96,    97,    98,    99,     0,     0,     0,   100,   101,
       0,     0,   102,   103,     0,   104,   105,   106,   107,   108,
       0,   109,   110,   -86,   111,   112,   113,   114,     0,     0,
     115,   -85,   -86,   -86,     0,     0,     0,     0,     0,     0,
     -85,   -85,     0,   -86,   -86,   -86,     0,     0,     0,     0,
       0,   -85,   -85,   -85,     0,     0,   -86,     0,     0,   -86,
       0,   -86,     0,   -86,   -85,   -86,   -90,   -85,     0,   -85,
     -86,   -85,     0,   -85,   -86,   -90,   -90,     0,   -85,    45,
       0,     0,   -85,     0,     0,     0,   -90,   -90,   -90,     0,
       0,     0,     0,    48,     0,    49,     0,     0,     0,   -90,
     -93,     0,   -90,     0,   -90,    51,   -90,    52,   -90,   -93,
     -93,    53,    54,   -90,     0,     0,    55,   -90,     0,    56,
     -93,   -93,   -93,     0,     0,    57,     0,     0,     0,     0,
      59,     0,     0,   -93,   -92,     0,   -93,     0,   -93,     0,
     -93,     0,   -93,   -92,   -92,     0,     0,   -93,     0,     0,
       0,   -93,     0,     0,   -92,   -92,   -92,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   -92,   -87,     0,
     -92,     0,   -92,     0,   -92,     0,   -92,   -87,   -87,     0,
       0,   -92,     0,     0,     0,   -92,     0,     0,   -87,   -87,
     -87,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   -87,   -95,     0,   -87,     0,   -87,     0,   -87,     0,
     -87,   -95,   -95,     0,     0,   -87,     0,     0,     0,   -87,
       0,     0,   -95,   -95,   -95,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   -95,   -89,     0,   -95,     0,
     -95,     0,   -95,     0,   -95,   -89,   -89,     0,     0,   -95,
       0,     0,     0,   -95,     0,     0,   -89,   -89,   -89,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   -89,
       0,     0,   -89,     0,   -89,     0,   -89,     0,   -89,     0,
       0,     0,     0,   -89,     0,     0,     0,   -89
};

static const yytype_int16 yycheck[] =
{
       7,     7,    34,    34,    46,     2,    24,    24,    40,    40,
     138,     2,    44,    44,     2,   237,   238,    24,   499,     2,
     449,   135,    61,   154,   158,   657,   350,   259,   171,   402,
     541,   174,   211,   212,     1,   524,     1,   237,   238,     7,
      58,    58,   168,     1,   777,   171,   779,   313,   174,   237,
       6,    58,     7,    24,    24,     1,   755,     1,   331,   238,
     759,   324,    31,     1,   218,    91,    24,   181,   181,   751,
      56,     1,   251,     1,    82,     1,   102,    91,    91,   812,
      24,   195,     1,    96,     1,   307,   100,     1,     0,   121,
     121,    99,   124,   124,    24,    46,   728,     1,   722,     1,
      36,    37,   726,   325,     3,   137,   138,   307,    79,   331,
     376,     1,   375,    31,   100,   797,   304,   135,   580,   818,
     152,   152,    90,   155,   155,   325,   305,   306,   135,    99,
     309,    98,    24,   100,    99,    90,   143,   143,   103,    95,
     158,   173,   173,     3,    82,   103,   300,   846,     8,     9,
     883,   158,   331,    99,   186,   186,   335,   311,   271,   103,
     433,    99,   895,   181,   675,    95,   899,   206,   294,    95,
      96,    99,   871,   103,   181,   908,   875,   195,   877,   878,
      99,   223,    99,     6,   310,    99,   103,   105,   195,   196,
     196,    31,    82,   319,   320,    99,    98,   896,   324,   325,
      99,   655,   101,    95,   201,    97,   238,   439,    31,    99,
     201,   433,   674,   201,    24,   211,   212,   213,   201,   451,
     238,    24,    45,    46,    95,    24,    31,   449,   679,    24,
      98,   238,   100,   433,   105,   267,   267,   233,   234,    99,
      24,   101,   238,   732,   240,   241,    69,    99,   374,   375,
     376,   377,   378,   379,   433,   887,    96,    24,    99,   438,
     584,    24,    46,    99,   296,   296,    36,    37,    82,   720,
     449,     1,   398,    99,   280,   729,     6,    96,   759,    98,
      30,    95,   105,    82,    98,   317,   317,    97,   819,    39,
     100,    99,    95,   325,    97,   421,    95,   100,    97,   331,
       1,    31,    97,    98,    84,     6,   313,   325,   442,    24,
     683,    95,   425,   331,   845,    45,    46,   443,   325,   361,
     105,    24,    95,   436,   331,    98,    96,    24,    95,   325,
      31,   862,    95,    31,    97,   331,    24,   100,   819,    69,
      24,    36,    37,    58,    45,    46,   342,   343,   344,   345,
     346,   347,   348,   349,   350,   351,   352,   353,   354,   355,
     356,   357,   358,   359,   360,    24,   509,    95,    69,   376,
      98,   410,    56,    95,   416,   105,   507,    91,    91,   411,
     411,   103,   400,   509,   402,   651,   100,   100,    96,    46,
      98,   504,    95,   400,    97,   402,    91,   100,    95,   102,
      97,   433,   516,   100,   105,   519,   532,    95,    31,    97,
     523,    95,   100,    97,    24,   433,   100,   449,    95,    95,
     135,    98,    98,   103,   442,    99,   433,    36,    37,    24,
      82,   449,   558,   701,   702,   442,    95,   433,    97,   665,
     666,   100,   449,   158,    82,   822,   572,    12,    13,   575,
      95,    16,    17,   449,    89,   687,   582,   583,     6,    95,
      24,    24,   728,   892,   893,    99,   181,     7,    99,   213,
      82,    99,    24,   850,    16,    17,    91,    92,    93,    98,
     195,   513,   513,    91,   913,    95,    96,    97,     6,   233,
     234,    84,    99,   237,   238,    24,   240,   241,   516,   100,
      95,   519,    97,    31,    24,   537,   537,   251,    46,   516,
      98,   102,   519,   504,   891,   669,    82,    96,     7,    24,
     897,   898,    87,    88,    89,    90,    91,    92,    93,   906,
      82,    95,    95,    97,    97,   678,   100,   100,   681,   916,
     668,   654,   100,    95,   921,    97,   660,    89,    90,    91,
      92,    93,   678,   100,   708,   681,   822,    24,    82,    82,
     304,   305,   306,    98,    98,   309,    95,   100,    97,    36,
      37,    97,   102,    98,    91,    95,   730,    97,    82,   100,
     102,   325,   882,    96,   850,   885,   886,   331,   584,   100,
      95,   335,    97,   719,   894,   721,   102,   751,   342,   343,
     344,   345,   346,   347,   348,   349,   350,   351,   352,   353,
     354,   355,   356,   357,   358,   359,   360,   102,   100,   919,
      98,   887,    98,   100,    99,   891,   100,    82,    95,    96,
      97,   897,   898,   102,   652,   652,   668,   102,   100,   100,
     906,    99,   660,   797,   651,   652,    99,   665,   666,    99,
     916,    99,   213,   660,    46,   921,    82,    82,   665,   666,
     657,   700,    82,    96,    82,   683,   657,    99,    99,   657,
     892,   893,   233,   234,   657,    99,   683,    99,    99,   240,
     241,    95,    38,   173,   196,   400,   708,   402,   652,   433,
     853,   913,   835,    23,   438,   838,    56,    52,   841,   206,
     732,   732,   840,   879,   760,   449,   152,   513,   893,   835,
     701,   702,   838,   892,   893,   841,   913,   749,   749,   915,
     762,   728,   754,   754,   558,   575,   311,   442,    -1,    30,
      31,    -1,    -1,     1,   913,    -1,    -1,    -1,    39,    40,
      89,    90,    91,    92,    93,    -1,   872,    -1,   755,    50,
      51,    52,   759,    -1,    -1,    -1,    24,    25,    26,   766,
     766,    -1,    63,    -1,    -1,    66,    34,    68,    -1,    70,
      -1,    72,   814,   815,    -1,    -1,    77,    -1,    -1,    -1,
      81,   823,    -1,   825,   826,    -1,    -1,    -1,   830,    -1,
      58,    -1,    -1,    61,    62,    -1,    -1,    65,    -1,    -1,
      -1,   516,    -1,    71,   519,    -1,    74,    -1,   840,   840,
      -1,   818,    80,    -1,    82,   822,    30,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    39,    40,    95,    -1,    97,
      98,    99,   100,    -1,   102,   103,    50,    51,    52,   846,
     584,    -1,    -1,   850,    -1,    -1,    -1,    -1,    -1,    63,
      -1,    -1,    66,     1,    68,    -1,    70,    -1,    72,    -1,
     892,   893,    -1,    77,   871,    -1,    -1,    81,   875,   876,
     877,   878,    -1,    -1,   892,   893,    24,    -1,    -1,    -1,
     887,   913,    -1,    -1,   891,   892,   893,    -1,    -1,   896,
     897,   898,    40,    -1,    -1,   913,   892,   893,    -1,   906,
      -1,    -1,    50,    51,    52,    -1,   913,    -1,   915,   916,
      -1,    -1,    -1,    -1,   921,    63,    -1,   913,    66,    -1,
      68,    -1,    70,    -1,    72,    -1,    -1,    -1,    -1,    77,
       0,     1,    -1,    81,     4,    -1,    -1,   652,    11,    12,
      13,    14,    -1,    16,    17,   660,    -1,    -1,    -1,    -1,
     665,   666,   100,    -1,    24,   103,    -1,    27,    -1,    -1,
      30,    31,    -1,    -1,    -1,    -1,    -1,    -1,   683,    39,
      40,    41,    -1,    43,    -1,    45,    46,    -1,    48,    49,
      50,    51,    52,    53,    -1,    55,    -1,    -1,    -1,    59,
      60,    -1,    -1,    63,    64,    -1,    66,    67,    68,    69,
      70,    -1,    72,    73,    -1,    75,    -1,    77,    78,    -1,
      -1,    81,    85,    86,    87,    88,    89,    90,    91,    92,
      93,    -1,     1,    -1,    -1,    95,     5,     6,     7,     8,
       9,    10,    -1,   103,    -1,   105,    15,    -1,    -1,    -1,
      -1,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    -1,    76,    77,    78,
      -1,    80,    81,    82,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    90,    -1,    -1,    -1,    94,    95,    -1,    -1,    -1,
      99,    -1,   101,    -1,    -1,    -1,   105,   342,   343,   344,
     345,   346,   347,   348,   349,    -1,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,     1,    -1,   892,   893,
       5,     6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,
      15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,   913,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      -1,    76,    77,    78,    -1,    80,    81,    82,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,
      -1,    -1,    -1,    -1,    99,    -1,   101,    -1,     1,    -1,
     105,     4,     5,     6,     7,     8,     9,    10,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,
      23,    24,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    -1,    35,    -1,    -1,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    -1,    57,    -1,    59,    60,    -1,    -1,
      63,    64,    -1,    66,    67,    68,    69,    70,    -1,    72,
      73,    -1,    -1,    76,    77,    78,    79,    -1,    81,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,
      -1,    94,    95,    -1,    97,    -1,    99,    -1,   101,     1,
     103,    -1,   105,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,
      22,    23,    24,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    -1,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    -1,    57,    -1,    59,    60,    -1,
      -1,    63,    64,    -1,    66,    67,    68,    69,    70,    -1,
      72,    73,    -1,    -1,    76,    77,    78,    -1,    -1,    81,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    91,
      -1,    -1,    94,    -1,    -1,    -1,    -1,    99,    -1,   101,
      -1,     1,    -1,   105,     4,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    -1,    -1,    -1,    27,    28,    29,
      30,    31,    32,    33,    -1,    35,    -1,    -1,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    -1,    57,    -1,    59,
      60,    -1,    -1,    63,    64,    -1,    66,    67,    68,    69,
      70,    -1,    72,    73,    -1,    -1,    76,    77,    78,    79,
      -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      90,    -1,    -1,    -1,    94,    95,    -1,    -1,    -1,    99,
      -1,   101,     1,   103,    -1,   105,     5,     6,     7,     8,
       9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,
      -1,    20,    21,    22,    23,    24,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    -1,    35,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    57,    -1,
      59,    60,    -1,    -1,    63,    64,    -1,    66,    67,    68,
      69,    70,    -1,    72,    73,    -1,    -1,    76,    77,    78,
      -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    90,    -1,    -1,    -1,    94,    95,    96,    97,    -1,
      99,    -1,   101,     1,    -1,    -1,   105,     5,     6,     7,
       8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,
      -1,    -1,    20,    21,    22,    23,    24,    -1,    -1,    27,
      28,    29,    30,    31,    32,    33,    -1,    35,    -1,    -1,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    -1,    57,
      -1,    59,    60,    -1,    -1,    63,    64,    -1,    66,    67,
      68,    69,    70,    -1,    72,    73,    -1,    -1,    76,    77,
      78,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    97,
      -1,    99,   100,   101,     1,    -1,    -1,   105,     5,     6,
       7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    20,    21,    22,    23,    24,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    -1,
      57,    -1,    59,    60,    -1,    -1,    63,    64,    -1,    66,
      67,    68,    69,    70,    -1,    72,    73,    -1,    -1,    76,
      77,    78,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    95,    -1,
      -1,    -1,    99,    -1,   101,     1,    -1,    -1,   105,     5,
       6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,
      -1,    -1,    -1,    -1,    20,    21,    22,    23,    24,    -1,
      -1,    27,    28,    29,    30,    31,    32,    33,    -1,    35,
      -1,    -1,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      -1,    57,    -1,    59,    60,    -1,    -1,    63,    64,    -1,
      66,    67,    68,    69,    70,    -1,    72,    73,    -1,    -1,
      76,    77,    78,    -1,    -1,    81,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    95,
      -1,    -1,    -1,    99,    -1,   101,     1,    -1,    -1,   105,
       5,     6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,
      15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    -1,
      35,    -1,    -1,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    57,    -1,    59,    60,    -1,    -1,    63,    64,
      -1,    66,    67,    68,    69,    70,    -1,    72,    73,    -1,
      -1,    76,    77,    78,    -1,    -1,    81,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,
      -1,    -1,    -1,    -1,    99,    -1,   101,     1,   103,    -1,
     105,     5,     6,     7,     8,     9,    10,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,
      -1,    -1,    -1,    27,    28,    29,    30,    31,    32,    33,
      -1,    35,    -1,    -1,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    -1,    57,    -1,    59,    60,    -1,    -1,    63,
      64,    -1,    66,    67,    68,    69,    70,    -1,    72,    73,
      -1,    -1,    76,    77,    78,    -1,    -1,    81,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,
      94,    -1,    -1,    -1,    -1,    99,    -1,   101,     1,    -1,
      -1,   105,     5,     6,     7,     8,     9,    10,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,
      23,    -1,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    -1,    35,    -1,    -1,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    -1,    57,    -1,    59,    60,    -1,    -1,
      63,    64,    -1,    66,    67,    68,    69,    70,    -1,    72,
      73,    -1,    -1,    76,    77,    78,    -1,    -1,    81,    -1,
      -1,    -1,    -1,    -1,     1,    -1,    -1,    90,     5,     6,
       7,    94,    -1,    10,    -1,    -1,    99,    -1,   101,    -1,
      -1,    -1,   105,    20,    21,    22,    23,    24,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    -1,
      57,    -1,    59,    60,    -1,    -1,    63,    64,    -1,    66,
      67,    68,    69,    70,    -1,    72,    73,    -1,    -1,    76,
      77,    78,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,
       1,    -1,    -1,    -1,     5,     6,     7,    -1,    -1,    10,
      97,    -1,    99,   100,   101,    -1,    -1,    -1,   105,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    -1,    35,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    57,    -1,    59,    60,
      -1,    -1,    63,    64,    -1,    66,    67,    68,    69,    70,
      -1,    72,    73,    -1,    -1,    76,    77,    78,    -1,    -1,
      81,    -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    -1,
       5,     6,     7,    -1,    95,    10,    -1,    -1,    99,    -1,
     101,    -1,    -1,    -1,   105,    20,    21,    22,    23,    -1,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    -1,
      35,    -1,    -1,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    57,    -1,    59,    60,    -1,    -1,    63,    64,
      -1,    66,    67,    68,    69,    70,    -1,    72,    73,    -1,
      -1,    76,    77,    78,    -1,    -1,    81,    -1,    -1,    -1,
      -1,    -1,    -1,     1,    -1,    -1,    -1,     5,     6,     7,
       8,     9,    10,    -1,    99,    -1,   101,    15,    -1,    -1,
     105,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    -1,
      28,    29,    30,    31,    32,    33,    -1,    35,    -1,    -1,
      38,    39,    40,    -1,    42,    -1,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    -1,    54,    -1,    56,    57,
      -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,    -1,
      68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,    77,
      -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    -1,
      -1,    99,   100,   101,     1,    -1,   104,   105,     5,     6,
       7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,
      -1,    28,    29,    30,    31,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    -1,    42,    -1,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    -1,    54,    -1,    -1,
      57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,
      -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,
      77,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,
      -1,    -1,    99,   100,   101,     1,    -1,   104,   105,     5,
       6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,
      -1,    -1,    -1,    -1,    20,    21,    22,    23,    -1,    -1,
      -1,    -1,    28,    29,    30,    31,    32,    33,    -1,    35,
      -1,    -1,    38,    39,    40,    -1,    42,    -1,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    -1,    54,    -1,
      -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,
      66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,
      76,    77,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,
      -1,    -1,    -1,    99,   100,   101,   102,     1,    -1,   105,
      -1,     5,     6,     7,     8,     9,    10,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,
      24,    -1,    -1,    -1,    28,    29,    30,    31,    32,    33,
      -1,    35,    -1,    -1,    38,    39,    40,    -1,    42,    -1,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    -1,
      54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    63,
      -1,    -1,    66,    -1,    68,    69,    70,    -1,    72,    -1,
      -1,    -1,    76,    77,    -1,    -1,    -1,    81,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,
      94,    -1,    -1,    -1,    -1,    99,    -1,   101,     1,    -1,
      -1,   105,     5,     6,     7,     8,     9,    10,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,
      23,    24,    -1,    -1,    -1,    28,    29,    30,    31,    32,
      33,    -1,    35,    -1,    -1,    38,    39,    40,    -1,    42,
      -1,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      -1,    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,
      63,    -1,    -1,    66,    -1,    68,    69,    70,    -1,    72,
      -1,    -1,    -1,    76,    77,    -1,    -1,    -1,    81,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,
      -1,    94,    -1,    -1,    -1,    -1,    99,    -1,   101,     1,
      -1,    -1,   105,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    -1,    28,    29,    30,    31,
      32,    33,    -1,    35,    -1,    -1,    38,    39,    40,    -1,
      42,    -1,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    -1,    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,
      -1,    63,    -1,    -1,    66,    -1,    68,    69,    70,    -1,
      72,    -1,    -1,    -1,    76,    77,    -1,    -1,    -1,    81,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,
      -1,    -1,    94,    -1,    -1,    -1,    -1,    99,    -1,   101,
       1,   103,    -1,   105,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    24,    -1,    -1,    -1,    28,    29,    30,
      31,    32,    33,    -1,    35,    -1,    -1,    38,    39,    40,
      -1,    42,    -1,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    -1,    54,    -1,    -1,    57,    -1,    -1,    -1,
      -1,    -1,    63,    -1,    -1,    66,    -1,    68,    69,    70,
      -1,    72,    -1,    -1,    -1,    76,    77,    -1,    -1,    -1,
      81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,
      -1,    -1,    -1,    94,    -1,    -1,    -1,    -1,    99,    -1,
     101,     1,    -1,    -1,   105,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    -1,    -1,    -1,    -1,    28,    29,
      30,    31,    32,    33,    -1,    35,    -1,    -1,    38,    39,
      40,    -1,    42,    -1,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    -1,    54,    -1,    -1,    57,    -1,    -1,
      -1,    -1,    -1,    63,    -1,    -1,    66,    -1,    68,    69,
      70,    -1,    72,    -1,    -1,    -1,    76,    77,    -1,    -1,
      -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      90,    -1,    -1,    -1,    94,    -1,    -1,    -1,    -1,    99,
      -1,   101,     1,    -1,    -1,   105,     5,     6,     7,     8,
       9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,
      -1,    20,    21,    22,    23,    -1,    -1,    -1,    -1,    28,
      29,    30,    31,    32,    33,    -1,    35,    -1,    -1,    38,
      39,    40,    -1,    42,    -1,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    -1,    54,    -1,    -1,    57,    -1,
      -1,    -1,    -1,    -1,    63,    -1,    -1,    66,    -1,    68,
      69,    70,    -1,    72,    -1,    -1,    -1,    76,    77,    -1,
      -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    -1,    -1,
      99,    -1,   101,     1,    -1,    -1,   105,     5,     6,     7,
       8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,
      -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    -1,
      28,    29,    30,    31,    32,    33,    -1,    35,    -1,    -1,
      38,    39,    40,    -1,    42,    -1,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    -1,    54,    -1,    -1,    57,
      -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,    -1,
      68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,    77,
      -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    -1,
      -1,    99,    -1,   101,     1,    -1,    -1,   105,     5,     6,
       7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,
      -1,    28,    29,    30,    31,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    -1,    42,    -1,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    -1,    54,    -1,    -1,
      57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,
      -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,
      77,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,
      -1,    -1,    99,    -1,   101,     1,    -1,    -1,   105,     5,
       6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,
      -1,    -1,    -1,    -1,    20,    21,    22,    23,    -1,    -1,
      -1,    -1,    28,    29,    30,    31,    32,    33,    -1,    35,
      -1,    -1,    38,    39,    40,    -1,    42,    -1,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    -1,    54,    -1,
      -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,
      66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,
      76,    77,    -1,    -1,     1,    81,    -1,     4,    -1,    -1,
      -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,
      -1,    -1,    -1,    99,    -1,   101,    -1,    24,    -1,   105,
      27,    -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    39,    40,    41,    -1,    43,    -1,    45,    46,
      -1,    48,    49,    50,    51,    52,    53,    -1,    55,    -1,
      -1,    -1,    59,    60,    -1,     1,    63,    64,     4,    66,
      67,    68,    69,    70,    -1,    72,    73,    -1,    75,    -1,
      77,    78,    -1,    -1,    81,    -1,    -1,    -1,    24,    -1,
      -1,    27,    -1,    -1,    30,    31,    -1,    -1,    95,    -1,
      97,    -1,    -1,    39,    40,    41,   103,    43,   105,    45,
      46,    -1,    48,    49,    50,    51,    52,    53,    -1,    55,
      -1,    -1,    -1,    59,    60,    -1,    -1,    63,    64,    -1,
      66,    67,    68,    69,    70,    -1,    72,    73,    -1,    75,
      -1,    77,    78,     1,    -1,    81,    -1,     5,     6,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,    15,    -1,    95,
      -1,    97,    -1,    21,    22,    -1,    -1,   103,    -1,   105,
      -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    39,    40,    -1,    -1,    -1,    44,    45,    46,    -1,
      -1,    -1,    50,    51,    52,    -1,    54,    -1,    -1,    57,
      -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,    -1,
      68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,    77,
      25,    26,    -1,    81,    -1,    -1,    -1,    -1,    -1,    34,
      -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    -1,
      -1,    99,    -1,   101,     1,    -1,    -1,   105,     5,     6,
       7,     8,     9,    58,    -1,    -1,    61,    62,    15,    -1,
      65,    -1,    -1,    -1,    21,    22,    71,    -1,    -1,    74,
      -1,    -1,    -1,    30,    31,    80,    -1,    82,    -1,    -1,
      -1,    -1,    39,    40,    -1,    -1,    -1,    44,    45,    46,
      -1,    96,    -1,    50,    51,    52,    -1,    54,    -1,    -1,
      57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,
      -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,
      77,    25,    26,    -1,    81,    -1,    -1,    -1,    -1,    -1,
      34,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,
      -1,    -1,    99,    -1,   101,     1,    -1,    -1,   105,     5,
       6,     7,     8,     9,    58,    -1,    -1,    61,    62,    15,
      -1,    65,    -1,    -1,    -1,    21,    22,    71,    -1,    -1,
      74,    -1,    -1,    -1,    30,    31,    80,    -1,    82,    -1,
      -1,    -1,    -1,    39,    40,    -1,    -1,    -1,    44,    45,
      46,    -1,    -1,    -1,    50,    51,    52,    -1,    54,    -1,
      -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,
      66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,
      76,    77,    25,    26,    -1,    81,    -1,    -1,    -1,    -1,
      -1,    34,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,
      -1,    -1,    -1,    99,    -1,   101,     1,    -1,    -1,   105,
       5,     6,     7,     8,     9,    58,    -1,    -1,    61,    62,
      15,    -1,    65,    -1,    -1,    -1,    21,    22,    71,    -1,
      -1,    74,    -1,    -1,    -1,    30,    31,    80,    -1,    82,
      -1,    -1,    -1,    -1,    39,    40,    -1,    -1,    -1,    44,
      45,    46,    -1,    -1,    -1,    50,    51,    52,    -1,    54,
      -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,
      -1,    66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,
      -1,    76,    77,    -1,    -1,    -1,    81,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,
      -1,    -1,    -1,    -1,    99,    -1,   101,     1,    -1,    -1,
     105,     5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    -1,    21,    22,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    30,    31,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    39,    40,    -1,    -1,    -1,
      44,    45,    46,    -1,    -1,    -1,    50,    51,    52,    -1,
      54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    63,
      -1,    -1,    66,    -1,    68,    69,    70,    -1,    72,    -1,
      -1,    -1,    76,    77,    -1,    -1,    -1,    81,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,
      94,    -1,    -1,    -1,    -1,    99,    -1,   101,     1,    -1,
      -1,   105,     5,     6,     7,     8,     9,    -1,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,    21,    22,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,    31,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    -1,    -1,
      -1,    44,    45,    46,    -1,    -1,    -1,    50,    51,    52,
      -1,    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,
      63,    -1,    -1,    66,    -1,    68,    69,    70,    -1,    72,
      -1,    -1,    -1,    76,    77,    -1,    -1,    -1,    81,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,
      -1,    94,    -1,    -1,    -1,    -1,    99,    -1,   101,     1,
      -1,    -1,   105,     5,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,    21,
      22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,    31,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    -1,
      -1,    -1,    44,    45,    46,    -1,    -1,    -1,    50,    51,
      52,    -1,    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,
      -1,    63,    -1,    -1,    66,    -1,    68,    69,    70,    -1,
      72,    -1,    -1,    -1,    76,    77,    -1,    -1,    -1,    81,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,
      -1,    -1,    94,    -1,    -1,    -1,    -1,    99,    -1,   101,
       1,    -1,    -1,   105,     5,     6,     7,     8,     9,    -1,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,
      21,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,
      31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,
      -1,    -1,    -1,    44,    45,    46,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,    -1,    57,    -1,    -1,    -1,
      -1,    -1,    63,    -1,    -1,    66,    -1,    68,    69,    70,
      -1,    72,    -1,    -1,    -1,    76,    77,    -1,    -1,    -1,
      81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,
      -1,    -1,    -1,    94,    -1,    -1,    -1,    -1,    99,    -1,
     101,     1,    -1,    -1,   105,     5,     6,     7,     8,     9,
      -1,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      -1,    21,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      30,    31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,
      40,    -1,    -1,    -1,    44,    45,    46,    -1,    -1,    -1,
      50,    51,    52,    -1,    54,    -1,    -1,    57,    -1,    -1,
      -1,    -1,    -1,    63,    -1,    -1,    66,    -1,    68,    69,
      70,    -1,    72,    -1,    -1,    -1,    76,    77,    -1,    -1,
      -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      90,    -1,    -1,    -1,    94,    -1,    -1,    -1,    -1,    99,
      -1,   101,     1,    -1,    -1,   105,     5,     6,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,
      -1,    -1,    21,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    30,    31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      39,    40,    -1,    -1,    -1,    44,    45,    46,    -1,    -1,
      -1,    50,    51,    52,    -1,    54,    -1,    -1,    57,    -1,
      -1,    -1,    -1,    -1,    63,    -1,    -1,    66,    -1,    68,
      69,    70,    -1,    72,    -1,    -1,    -1,    76,    77,    -1,
      -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    -1,    -1,
      99,    -1,   101,     1,    -1,    -1,   105,     5,     6,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,    15,    -1,    -1,
      -1,    -1,    -1,    21,    22,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    39,    40,    -1,    -1,    -1,    44,    45,    46,    -1,
      -1,    -1,    50,    51,    52,    -1,    54,    -1,    -1,    57,
      -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,    -1,
      68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,    77,
      -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    -1,
      -1,    99,    -1,   101,     1,    -1,    -1,   105,     5,     6,
       7,     8,     9,    -1,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    -1,    21,    22,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    30,    31,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    39,    40,    -1,    -1,    -1,    44,    45,    46,
      -1,    -1,    -1,    50,    51,    52,    -1,    54,    -1,    -1,
      57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,
      -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,
      77,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,
      -1,    -1,    99,    -1,   101,     1,    -1,    -1,   105,     5,
       6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,    15,
      -1,    -1,    -1,    -1,    -1,    21,    22,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    30,    31,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    39,    40,    -1,    -1,    -1,    44,    45,
      46,    -1,    -1,    -1,    50,    51,    52,    -1,    54,    -1,
      -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,
      66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,
      76,    77,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,
      -1,    -1,    -1,    99,    -1,   101,     1,    -1,    -1,   105,
       5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,
      15,    -1,    -1,    -1,    -1,    -1,    21,    22,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    30,    31,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    39,    40,    -1,    -1,    -1,    44,
      45,    46,    -1,    -1,    -1,    50,    51,    52,    -1,    54,
      -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,
      -1,    66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,
      -1,    76,    77,    -1,    -1,    -1,    81,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    94,
      -1,    -1,    -1,    -1,    99,    -1,   101,     1,    -1,    -1,
     105,     5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    -1,    21,    22,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    30,    31,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    39,    40,    -1,    -1,    -1,
      44,    45,    46,    -1,    -1,    -1,    50,    51,    52,    -1,
      54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    63,
      -1,    -1,    66,    -1,    68,    69,    70,    -1,    72,    -1,
      -1,    -1,    76,    77,    -1,    -1,    -1,    81,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,
      94,    -1,    -1,    -1,    -1,    99,    -1,   101,     1,    -1,
      -1,   105,     5,     6,     7,     8,     9,    -1,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,    21,    22,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,    31,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    -1,    -1,
      -1,    44,    45,    46,    -1,    -1,    -1,    50,    51,    52,
      -1,    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,
      63,    -1,    -1,    66,    -1,    68,    69,    70,    -1,    72,
      -1,    -1,    -1,    76,    77,    -1,    -1,    -1,    81,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,    -1,
      -1,    94,    -1,    -1,    -1,    -1,    99,    -1,   101,     1,
      -1,    -1,   105,     5,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,    21,
      22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,    31,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,    -1,
      -1,    -1,    44,    45,    46,    -1,    -1,    -1,    50,    51,
      52,    -1,    54,    -1,    -1,    57,    -1,    -1,    -1,    -1,
      -1,    63,    -1,    -1,    66,    -1,    68,    69,    70,    -1,
      72,    -1,    -1,    -1,    76,    77,    -1,    -1,    -1,    81,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,
      -1,    -1,    94,    -1,    -1,    -1,    -1,    99,    -1,   101,
       1,    -1,    -1,   105,     5,     6,     7,     8,     9,    -1,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    -1,
      21,    22,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    30,
      31,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    39,    40,
      -1,    -1,    -1,    44,    45,    46,    -1,    -1,    -1,    50,
      51,    52,    -1,    54,    -1,    -1,    57,    -1,     1,    -1,
      -1,    -1,    63,     6,    -1,    66,    -1,    68,    69,    70,
      -1,    72,    -1,    -1,    -1,    76,    77,    -1,    -1,    -1,
      81,    -1,    25,    26,    -1,    -1,    -1,    -1,    31,    90,
      -1,    34,    -1,    94,    -1,    -1,    -1,    -1,    99,    -1,
     101,    -1,    45,    46,   105,    11,    12,    13,    14,    -1,
      16,    17,    18,    19,    -1,    58,    -1,    -1,    61,    62,
      -1,    -1,    65,    -1,    -1,    -1,    69,    -1,    71,    -1,
      -1,    74,    -1,    -1,    -1,     3,    -1,    80,    -1,    82,
       8,     9,    -1,    11,    12,    13,    14,    -1,    16,    17,
      18,    19,    -1,    -1,    -1,    -1,    24,    25,    26,    -1,
      -1,    -1,   105,    -1,    -1,    -1,    34,    -1,    36,    37,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    -1,    -1,
      58,    -1,    -1,    61,    62,    -1,    -1,    65,    -1,    -1,
      -1,    -1,    -1,    71,    -1,    -1,    74,    -1,    -1,    -1,
      -1,    -1,    80,     1,    82,    83,    84,    85,    86,    87,
      88,    89,    90,    91,    92,    93,    -1,    95,    96,    97,
      98,    99,   100,   101,   102,   103,    24,   105,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    40,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    50,    51,    52,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     4,    -1,    -1,    63,    -1,    -1,    66,    -1,
      68,    -1,    70,    -1,    72,    -1,    -1,    -1,    -1,    77,
      -1,    -1,    -1,    81,    -1,    27,    -1,    -1,    30,    31,
      -1,    -1,    -1,    -1,    -1,     1,    -1,    39,    -1,    41,
      98,    43,   100,    45,    46,   103,    -1,    49,    -1,    -1,
      -1,    53,    -1,    55,    -1,    -1,    -1,    59,    60,    25,
      26,    -1,    64,    -1,    -1,    67,    -1,    69,    34,    -1,
      -1,    73,    -1,    75,    -1,    -1,    78,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    58,    -1,    -1,    61,    62,    -1,    -1,    65,
      -1,   103,    -1,   105,    -1,    71,    -1,    -1,    74,    -1,
      -1,    -1,    -1,    -1,    80,    -1,    82,    -1,    -1,    -1,
      -1,    -1,    -1,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    98,    15,    -1,    -1,   102,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    27,    28,    29,    -1,    31,
      32,    33,    -1,    35,    -1,    -1,    38,    -1,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    -1,    57,    -1,    59,    60,    -1,
      -1,    63,    64,    -1,    66,    67,    68,    69,    70,    -1,
      72,    73,    -1,    -1,    76,    77,    78,    -1,    -1,    81,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,    -1,
      -1,    -1,    94,    -1,    -1,    -1,    -1,    99,   100,   101,
     102,    -1,    -1,   105,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    24,    -1,    -1,    27,    28,    29,    -1,
      31,    32,    33,    -1,    35,    -1,    -1,    38,    -1,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    57,    -1,    59,    60,
      -1,    -1,    63,    64,    -1,    66,    67,    68,    69,    70,
      -1,    72,    73,    -1,    -1,    76,    77,    78,    -1,    -1,
      81,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    90,
       5,     6,     7,    94,    -1,    10,    -1,    -1,    99,    -1,
     101,   102,    -1,    -1,   105,    20,    21,    22,    23,    -1,
      -1,    -1,    27,    28,    29,    -1,    31,    32,    33,    -1,
      35,    -1,    -1,    38,    -1,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    57,    -1,    59,    60,    -1,    -1,    63,    64,
      -1,    66,    67,    68,    69,    70,    -1,    72,    73,    -1,
      -1,    76,    77,    78,    -1,    -1,    81,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     5,     6,     7,
       8,     9,    10,    -1,    99,    -1,   101,    15,    -1,    -1,
     105,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    -1,
      28,    29,    -1,    31,    32,    33,    -1,    35,    -1,    -1,
      38,    -1,    40,    -1,    42,    -1,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    -1,    54,    -1,    -1,    57,
      -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,    -1,
      68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,    77,
      -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,    97,
      -1,    99,   100,   101,    -1,    -1,   104,   105,     5,     6,
       7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,
      -1,    28,    29,    30,    31,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    -1,    42,    -1,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    -1,    54,    -1,    -1,
      57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,    66,
      -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,    76,
      77,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    90,    -1,    -1,    -1,    94,    -1,    -1,
      -1,    -1,    99,    -1,   101,    -1,    -1,   104,   105,     5,
       6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,
      -1,    -1,    -1,    -1,    20,    21,    22,    23,    -1,    -1,
      -1,    -1,    28,    29,    -1,    31,    32,    33,    -1,    35,
      -1,    -1,    38,    -1,    40,    -1,    42,    -1,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    -1,    54,    -1,
      -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,    -1,
      66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,    -1,
      76,    77,    -1,    -1,    -1,    81,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    90,    -1,    -1,    30,    94,    -1,
      -1,    -1,    -1,    99,    -1,   101,    39,    40,    -1,   105,
       5,     6,     7,     8,     9,    -1,    -1,    50,    51,    52,
      15,    -1,    -1,    -1,    -1,    -1,    21,    22,    -1,    -1,
      63,    -1,    -1,    66,    -1,    68,    31,    70,    -1,    72,
      -1,    -1,    -1,    -1,    77,    40,    -1,    -1,    81,    44,
      45,    46,    -1,    -1,    -1,    50,    51,    52,    -1,    54,
      -1,    -1,    57,    -1,    -1,    -1,    -1,    -1,    63,    -1,
      -1,    66,    -1,    68,    69,    70,    -1,    72,    -1,    -1,
      -1,    76,    77,    -1,    -1,    -1,    81,    -1,    -1,    -1,
      -1,     5,     6,     7,    -1,    90,    -1,    -1,    -1,    94,
      -1,    -1,    -1,    -1,    99,    -1,   101,    21,    22,    -1,
     105,    -1,    -1,    -1,    -1,    -1,    -1,    31,    -1,     3,
      -1,    -1,    -1,    -1,     8,     9,    40,    -1,    -1,    -1,
      44,    45,    46,    -1,    -1,    -1,    50,    51,    52,    -1,
      54,    25,    26,    57,    -1,    -1,    -1,    -1,    -1,    63,
      34,    -1,    66,    -1,    68,    69,    70,    -1,    72,    -1,
      -1,    -1,    76,    77,    -1,    -1,     3,    81,    -1,    -1,
      -1,     8,     9,    -1,    58,    -1,    -1,    61,    62,    -1,
      -1,    65,    -1,    -1,    -1,    99,    -1,    71,    25,    26,
      74,   105,    -1,    -1,    -1,    -1,    80,    34,    82,    11,
      12,    13,    14,    -1,    16,    17,    18,    11,    12,    13,
      14,    -1,    16,    17,    98,    99,    -1,   101,   102,    -1,
      -1,    58,    -1,    -1,    61,    62,    -1,    -1,    65,    -1,
      11,    12,    13,    14,    71,    16,    17,    74,    -1,    -1,
      -1,    -1,    -1,    80,    -1,    82,    11,    12,    13,    14,
      -1,    16,    17,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    99,    -1,   101,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    84,    85,    86,    87,    88,    89,    90,    91,
      92,    93,    86,    87,    88,    89,    90,    91,    92,    93,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    84,    85,    86,    87,    88,    89,    90,
      91,    92,    93,    -1,    -1,    -1,    -1,    -1,    -1,    10,
      -1,    -1,    87,    88,    89,    90,    91,    92,    93,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      -1,    32,    33,    -1,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    -1,    -1,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    59,    60,
      -1,    -1,    63,    64,    -1,    66,    67,    68,    69,    70,
      -1,    72,    73,    -1,    75,    76,    77,    78,    -1,    -1,
      81,    10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      91,    20,    21,    22,    23,    -1,    -1,    -1,    27,    28,
      29,    30,    -1,    32,    33,    -1,    35,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    -1,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    -1,    -1,
      59,    60,    -1,    -1,    63,    64,    -1,    66,    67,    68,
      69,    70,    -1,    72,    73,    -1,    75,    76,    77,    78,
      -1,    -1,    81,    10,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    91,    20,    21,    22,    23,    -1,    -1,    -1,
      27,    28,    29,    30,    -1,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    41,    42,    43,    44,    -1,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    -1,
      -1,    -1,    59,    60,    -1,    -1,    63,    64,    -1,    66,
      67,    68,    69,    70,    -1,    72,    73,    -1,    75,    76,
      77,    78,    -1,    -1,    81,    10,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    91,    20,    21,    22,    23,    -1,
      -1,    -1,    27,    28,    29,    30,    -1,    32,    33,    -1,
      35,    -1,    -1,    38,    39,    40,    41,    42,    43,    44,
      -1,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    -1,    -1,    59,    60,    -1,    -1,    63,    64,
      -1,    66,    67,    68,    69,    70,    -1,    72,    73,    -1,
      75,    76,    77,    78,    -1,    -1,    81,    10,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    91,    20,    21,    22,
      23,    -1,    -1,    -1,    27,    28,    29,    30,    -1,    32,
      33,    -1,    35,    -1,    -1,    38,    39,    40,    41,    42,
      43,    44,    -1,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    -1,    -1,    -1,    59,    60,    -1,    -1,
      63,    64,    -1,    66,    67,    68,    69,    70,    -1,    72,
      73,    -1,    75,    76,    77,    78,    -1,    -1,    81,    10,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    91,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      -1,    32,    33,    -1,    35,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,    -1,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    59,    60,
       1,    -1,    63,    64,    -1,    66,    67,    68,    69,    70,
      -1,    72,    73,    -1,    75,    76,    77,    78,    -1,    -1,
      81,    -1,    -1,    -1,    25,    26,    -1,    -1,    -1,    -1,
      91,    -1,    -1,    34,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     1,    58,    -1,     4,
      61,    62,    -1,    -1,    65,    10,    -1,    -1,    -1,    -1,
      71,    -1,    -1,    74,    -1,    20,    21,    22,    23,    80,
      -1,    82,    27,    28,    29,    30,    -1,    32,    33,    -1,
      35,    -1,    -1,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    -1,    -1,    59,    60,    -1,    -1,    63,    64,
       1,    66,    67,    68,    69,    70,    -1,    72,    73,    10,
      75,    76,    77,    78,    79,    -1,    81,    -1,    -1,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      -1,    32,    33,    -1,    35,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,    -1,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    59,    60,
      -1,    -1,    63,    64,     1,    66,    67,    68,    69,    70,
      -1,    72,    73,    10,    75,    76,    77,    78,    -1,    -1,
      81,    -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,
      27,    28,    29,    30,    -1,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    41,    42,    43,    44,    -1,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    -1,
      -1,    -1,    59,    60,    -1,    -1,    63,    64,     1,    66,
      67,    68,    69,    70,    -1,    72,    73,    10,    75,    76,
      77,    78,    -1,    -1,    81,    -1,    -1,    20,    21,    22,
      23,    -1,    -1,    -1,    27,    28,    29,    30,    -1,    32,
      33,    -1,    35,    -1,    -1,    38,    39,    40,    41,    42,
      43,    44,    -1,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    -1,    -1,    -1,    59,    60,    -1,    -1,
      63,    64,     1,    66,    67,    68,    69,    70,    -1,    72,
      73,    10,    75,    76,    77,    78,    -1,    -1,    81,    -1,
      -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,    28,
      29,    30,    -1,    32,    33,    -1,    35,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    -1,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    -1,    -1,
      59,    60,    -1,    -1,    63,    64,     1,    66,    67,    68,
      69,    70,    -1,    72,    73,    10,    75,    76,    77,    78,
      -1,    -1,    81,    -1,    -1,    20,    21,    22,    23,    -1,
      -1,    -1,    27,    28,    29,    30,    -1,    32,    33,    -1,
      35,    -1,    -1,    38,    39,    40,    41,    42,    43,    44,
      -1,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    -1,    -1,    59,    60,    -1,    -1,    63,    64,
       1,    66,    67,    68,    69,    70,    -1,    72,    73,    10,
      75,    76,    77,    78,    -1,    -1,    81,    -1,    -1,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      -1,    32,    33,    -1,    35,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,    -1,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    59,    60,
      -1,    -1,    63,    64,     1,    66,    67,    68,    69,    70,
      -1,    72,    73,    10,    75,    76,    77,    78,    -1,    -1,
      81,    -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,
      27,    28,    29,    30,    -1,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    41,    42,    43,    44,    -1,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    -1,
      -1,    -1,    59,    60,    -1,    -1,    63,    64,    -1,    66,
      67,    68,    69,    70,    -1,    72,    73,    -1,    75,    76,
      77,    78,    27,    -1,    81,    -1,    31,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    41,    -1,    43,    -1,
      45,    46,    -1,    -1,    -1,    -1,    40,    -1,    53,    -1,
      55,    -1,    -1,    -1,    59,    60,    50,    51,    52,    64,
      -1,    -1,    67,    -1,    69,    -1,    27,    -1,    73,    63,
      31,    -1,    66,    78,    68,    -1,    70,    -1,    72,    -1,
      41,    -1,    43,    77,    45,    46,    -1,    81,    -1,    -1,
      -1,    -1,    53,    98,    55,    -1,    -1,    -1,    59,    60,
     105,    -1,    -1,    64,    -1,    -1,    67,    -1,    69,    10,
      -1,    -1,    73,    -1,    -1,    -1,    -1,    78,    -1,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      -1,    32,    33,    -1,    35,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,   105,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    59,    60,
      -1,    -1,    63,    64,    -1,    66,    67,    68,    69,    70,
      -1,    72,    73,    10,    75,    76,    77,    78,    -1,    -1,
      81,    -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,
      27,    28,    29,    30,    -1,    32,    33,    -1,    35,    -1,
      -1,    38,    39,    40,    41,    42,    43,    44,    -1,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    -1,
      -1,    -1,    59,    60,    -1,    -1,    63,    64,    -1,    66,
      67,    68,    69,    70,    -1,    72,    73,    10,    75,    76,
      77,    78,    -1,    -1,    81,    -1,    -1,    20,    21,    22,
      23,    -1,    -1,    -1,    27,    28,    29,    30,    -1,    32,
      33,    -1,    35,    -1,    -1,    38,    39,    40,    41,    42,
      43,    44,    -1,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    -1,    -1,    -1,    59,    60,    -1,    -1,
      63,    64,    -1,    66,    67,    68,    69,    70,    -1,    72,
      73,    10,    75,    76,    77,    78,    -1,    -1,    81,    -1,
      -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,    28,
      29,    30,    -1,    32,    33,    -1,    35,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    -1,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    -1,    -1,
      59,    60,    -1,    -1,    63,    64,    -1,    66,    67,    68,
      69,    70,    -1,    72,    73,    10,    75,    76,    77,    78,
      -1,    -1,    81,    -1,    -1,    20,    21,    22,    23,    -1,
      -1,    -1,    27,    28,    29,    30,    -1,    32,    33,    -1,
      35,    -1,    -1,    38,    39,    40,    41,    42,    43,    44,
      -1,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    -1,    -1,    59,    60,    -1,    -1,    63,    64,
      -1,    66,    67,    68,    69,    70,    -1,    72,    73,    10,
      75,    76,    77,    78,    -1,    -1,    81,    -1,    -1,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      -1,    32,    33,    -1,    35,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,    -1,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    -1,    59,    60,
      -1,    -1,    63,    64,    -1,    66,    67,    68,    69,    70,
      -1,    72,    73,    30,    75,    76,    77,    78,    -1,    -1,
      81,    30,    39,    40,    -1,    -1,    -1,    -1,    -1,    -1,
      39,    40,    -1,    50,    51,    52,    -1,    -1,    -1,    -1,
      -1,    50,    51,    52,    -1,    -1,    63,    -1,    -1,    66,
      -1,    68,    -1,    70,    63,    72,    30,    66,    -1,    68,
      77,    70,    -1,    72,    81,    39,    40,    -1,    77,    27,
      -1,    -1,    81,    -1,    -1,    -1,    50,    51,    52,    -1,
      -1,    -1,    -1,    41,    -1,    43,    -1,    -1,    -1,    63,
      30,    -1,    66,    -1,    68,    53,    70,    55,    72,    39,
      40,    59,    60,    77,    -1,    -1,    64,    81,    -1,    67,
      50,    51,    52,    -1,    -1,    73,    -1,    -1,    -1,    -1,
      78,    -1,    -1,    63,    30,    -1,    66,    -1,    68,    -1,
      70,    -1,    72,    39,    40,    -1,    -1,    77,    -1,    -1,
      -1,    81,    -1,    -1,    50,    51,    52,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,    30,    -1,
      66,    -1,    68,    -1,    70,    -1,    72,    39,    40,    -1,
      -1,    77,    -1,    -1,    -1,    81,    -1,    -1,    50,    51,
      52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    63,    30,    -1,    66,    -1,    68,    -1,    70,    -1,
      72,    39,    40,    -1,    -1,    77,    -1,    -1,    -1,    81,
      -1,    -1,    50,    51,    52,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    63,    30,    -1,    66,    -1,
      68,    -1,    70,    -1,    72,    39,    40,    -1,    -1,    77,
      -1,    -1,    -1,    81,    -1,    -1,    50,    51,    52,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63,
      -1,    -1,    66,    -1,    68,    -1,    70,    -1,    72,    -1,
      -1,    -1,    -1,    77,    -1,    -1,    -1,    81
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,   107,   108,     0,     1,    24,    40,    48,    50,    51,
      52,    63,    66,    68,    70,    72,    77,    81,    95,   115,
     116,   119,   129,   139,   145,   146,   221,   227,   229,    24,
      95,    97,     1,     6,    31,    45,    46,    69,   105,   280,
     281,   282,   294,   146,     4,    27,    30,    39,    41,    43,
      49,    53,    55,    59,    60,    64,    67,    73,    75,    78,
     103,   121,   154,   157,   159,   160,   161,   280,    24,    95,
      97,    10,    20,    21,    22,    23,    27,    28,    29,    30,
      32,    33,    35,    38,    39,    40,    41,    42,    43,    44,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      59,    60,    63,    64,    66,    67,    68,    69,    70,    72,
      73,    75,    76,    77,    78,    81,   295,   296,    31,   105,
      31,    31,    46,    95,   105,     1,    46,   295,     6,    95,
       1,    46,   117,   118,   295,    99,   174,   184,   228,    99,
     168,     1,   113,   114,    99,   165,   174,    99,   175,   166,
     167,   166,   150,   157,   132,   147,   179,   180,    84,    46,
      46,   295,     1,    46,   295,    31,    31,    24,    82,    95,
      97,    82,    95,    98,    82,   153,   157,    46,   134,   295,
     134,   169,    24,    95,    97,     1,    96,   110,   109,   111,
     280,   294,     7,    90,   163,   176,    99,    46,    91,   223,
     295,   108,    46,    91,   295,    95,    98,   159,     1,     5,
       7,     8,     9,    15,    21,    22,    24,    40,    44,    50,
      51,    52,    54,    57,    63,    66,    68,    69,    70,    72,
      76,    77,    81,    90,    94,    99,   101,   122,   126,   145,
     148,   149,   208,   221,   227,   236,   264,   265,   273,   274,
     275,   278,   279,   280,   285,   286,   288,   290,   294,   296,
     236,     1,   117,   236,    91,   100,   222,   103,    98,   153,
     171,   172,   267,    24,    95,    97,     1,    46,   295,    95,
      89,     7,    36,    37,   164,   153,   111,   112,    95,    24,
      97,   125,    82,   128,    82,   131,   147,   180,    21,    22,
      44,    51,    54,    76,   122,   278,   278,   126,   274,   278,
      99,   289,     1,    99,   103,   185,   287,    31,   184,   184,
      99,   274,   274,     1,   103,   126,   152,   158,   160,   262,
     264,   126,   151,   152,   161,   278,   280,   291,   292,   296,
     274,   274,    11,    12,    13,    14,    16,    17,    18,    19,
      83,    84,    85,    86,    87,    88,    89,    90,    91,    92,
      93,     3,     8,     9,    25,    26,    34,    58,    61,    62,
      65,    71,    74,    80,    82,   122,   126,   266,    82,   266,
      99,   219,   223,   225,   226,    36,    37,   133,    98,   267,
     294,     7,    90,   162,    96,   100,     1,    24,   181,     1,
      99,   264,    99,    46,   295,   152,     1,   264,   287,     1,
     155,   156,   158,   161,   261,   262,   186,    46,   295,   207,
       1,   104,   263,   264,   268,   269,     1,   264,    24,    95,
      97,   100,   268,   126,   264,   270,   271,   272,   278,   296,
      91,   100,    84,    98,   100,   152,   292,    46,   102,    98,
     293,   102,     1,   273,     1,   273,     1,   273,     1,   273,
       1,   273,     1,   273,     1,   273,     1,   273,   265,     1,
     273,     1,   273,     1,   273,     1,   273,     1,   273,     1,
     273,     1,   273,     1,   273,     1,   273,     1,   273,   184,
       1,   264,     1,   268,     1,    24,    91,   261,   264,   283,
       1,   264,   264,   264,   218,     1,    24,   103,   220,    82,
     224,    24,    97,    98,   188,    96,   173,     7,   100,   177,
     264,   135,   137,   138,   153,   267,   137,    24,    95,    97,
     100,     1,    98,    24,    95,    97,   100,   147,   182,   190,
     213,    46,   183,   192,   211,   295,   100,   184,     1,   209,
      24,    56,    95,    97,   100,   264,    56,   100,    98,   267,
      24,    95,    97,   100,   100,    97,   124,   292,    24,    95,
      96,    97,   255,   102,   127,    98,   267,   159,   264,   102,
     291,     1,    82,   266,    96,     1,     4,    10,    20,    21,
      22,    23,    27,    28,    29,    30,    32,    33,    35,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    59,    60,    63,
      64,    66,    67,    68,    69,    70,    72,    73,    75,    76,
      77,    78,    79,    81,   140,   141,   142,   143,   144,    24,
      95,    97,   100,   100,    24,    95,    97,   100,   102,   102,
     102,   164,   145,   215,   216,   217,   267,   108,   236,   225,
     170,   153,   153,   100,   123,    96,    98,   267,   133,   100,
      24,    95,    97,   100,   264,    46,   295,    98,    82,   207,
      98,    82,   187,    99,   136,   263,   100,   102,     1,   264,
     100,     1,   272,   293,   264,   264,   265,    24,   261,   284,
     121,    96,    98,   267,   123,   188,   153,   178,   130,   135,
     135,   134,     1,    24,    95,   120,   185,     1,   293,    82,
     207,    82,   191,   236,     1,   136,   193,   236,   197,   137,
     210,   102,   147,   215,   215,   100,   100,   120,    24,    95,
      97,   100,   100,     1,    24,   264,     1,   136,   264,   147,
     182,   212,   182,     1,     4,    10,    20,    23,    28,    29,
      32,    33,    35,    42,    46,    47,    48,    79,    95,   116,
     185,   188,   196,   198,   199,   200,   201,   204,   205,   206,
     230,   239,   242,   244,   247,   251,   254,   256,   258,   261,
     123,     1,    24,   185,   189,   133,   295,   214,    46,   189,
      24,    95,    97,     1,    46,   194,   195,   295,     1,    24,
      95,   243,   260,   261,   252,   240,    46,   203,   164,   260,
     203,    96,   184,   245,   202,   231,   248,   243,   243,    95,
     103,   276,    46,   189,    24,    82,    95,    97,    82,    95,
      98,    82,   243,   184,   184,   260,   164,   255,   200,   184,
      96,   184,   184,   184,   236,   236,     1,   194,   236,   253,
     241,   255,   259,   260,    24,    79,   246,   200,   232,   249,
     128,    99,    99,   255,    24,    99,    99,    99,    99,   277,
     260,   264,   260,   257,   260,   260,   260,   197,    24,    97,
     100,   233,    95,    98,   238,   233,   243,   233,   233,   188,
     200,     1,   235,   237,   291,   235,   233,   243,   250,   260,
     200,   200,   243,    95,   200,   243,    38,   234,   237,   257,
     200,   233,   200
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */






/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  /* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;

  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 355 "language.yacc"
    { YYACCEPT; }
    break;

  case 3:
#line 356 "language.yacc"
    { YYACCEPT; }
    break;

  case 8:
#line 367 "language.yacc"
    {
    struct pike_string *a,*b;
    copy_shared_string(a,(yyvsp[(1) - (3)].n)->u.sval.u.string);
    copy_shared_string(b,(yyvsp[(3) - (3)].n)->u.sval.u.string);
    free_node((yyvsp[(1) - (3)].n));
    free_node((yyvsp[(3) - (3)].n));
    a=add_and_free_shared_strings(a,b);
    (yyval.n)=mkstrnode(a);
    free_string(a);
  }
    break;

  case 9:
#line 379 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (2)].n); }
    break;

  case 10:
#line 380 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 11:
#line 381 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 12:
#line 382 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 13:
#line 389 "language.yacc"
    {
    STACK_LEVEL_START(0);

    ref_push_string((yyvsp[(1) - (1)].n)->u.sval.u.string);
    if (call_handle_inherit((yyvsp[(1) - (1)].n)->u.sval.u.string)) {
      (yyval.n)=mksvaluenode(Pike_sp-1);
      pop_stack();
    }
    else
      (yyval.n)=mknewintnode(0);
    if((yyval.n)->name) free_string((yyval.n)->name);
    add_ref( (yyval.n)->name=Pike_sp[-1].u.string );
    free_node((yyvsp[(1) - (1)].n));

    STACK_LEVEL_DONE(1);
  }
    break;

  case 14:
#line 406 "language.yacc"
    {
    STACK_LEVEL_START(0);

    if(Pike_compiler->last_identifier)
    {
      ref_push_string(Pike_compiler->last_identifier);
    }else{
      push_constant_text("");
    }
    (yyval.n)=(yyvsp[(1) - (1)].n);

    STACK_LEVEL_DONE(1);
  }
    break;

  case 15:
#line 423 "language.yacc"
    {
    STACK_LEVEL_START(0);

    resolv_program((yyvsp[(1) - (1)].n));
    free_node((yyvsp[(1) - (1)].n));

    STACK_LEVEL_DONE(1);
  }
    break;

  case 16:
#line 434 "language.yacc"
    {
    SET_FORCE_RESOLVE((yyval.number));
  }
    break;

  case 17:
#line 438 "language.yacc"
    {
    UNSET_FORCE_RESOLVE((yyvsp[(1) - (2)].number));
    (yyval.n) = (yyvsp[(2) - (2)].n);
  }
    break;

  case 18:
#line 445 "language.yacc"
    {
    if (((yyvsp[(1) - (5)].number) & ID_EXTERN) && (Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared inherit.");
    }
    if((yyvsp[(3) - (5)].n) && !(Pike_compiler->new_program->flags & PROGRAM_PASS_1_DONE))
    {
      struct pike_string *s=Pike_sp[-1].u.string;
      if((yyvsp[(4) - (5)].n)) s=(yyvsp[(4) - (5)].n)->u.sval.u.string;
      compiler_do_inherit((yyvsp[(3) - (5)].n),(yyvsp[(1) - (5)].number),s);
    }
    if((yyvsp[(4) - (5)].n)) free_node((yyvsp[(4) - (5)].n));
    pop_stack();
    if ((yyvsp[(3) - (5)].n)) free_node((yyvsp[(3) - (5)].n));
  }
    break;

  case 19:
#line 460 "language.yacc"
    {
    if ((yyvsp[(3) - (5)].n)) free_node((yyvsp[(3) - (5)].n));
    pop_stack();
    yyerrok;
  }
    break;

  case 20:
#line 466 "language.yacc"
    {
    if ((yyvsp[(3) - (5)].n)) free_node((yyvsp[(3) - (5)].n));
    pop_stack();
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 21:
#line 473 "language.yacc"
    {
    if ((yyvsp[(3) - (5)].n)) free_node((yyvsp[(3) - (5)].n));
    pop_stack();
    yyerror("Missing ';'.");
  }
    break;

  case 22:
#line 478 "language.yacc"
    { yyerrok; }
    break;

  case 23:
#line 480 "language.yacc"
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 24:
#line 484 "language.yacc"
    { yyerror("Missing ';'."); }
    break;

  case 25:
#line 488 "language.yacc"
    {
    resolv_constant((yyvsp[(2) - (3)].n));
    free_node((yyvsp[(2) - (3)].n));
    use_module(Pike_sp-1);
    pop_stack();
  }
    break;

  case 26:
#line 495 "language.yacc"
    {
    if (call_handle_import((yyvsp[(2) - (3)].n)->u.sval.u.string)) {
      use_module(Pike_sp-1);
      pop_stack();
    }
    free_node((yyvsp[(2) - (3)].n));
  }
    break;

  case 27:
#line 502 "language.yacc"
    { yyerrok; }
    break;

  case 28:
#line 504 "language.yacc"
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 29:
#line 508 "language.yacc"
    { yyerror("Missing ';'."); }
    break;

  case 30:
#line 512 "language.yacc"
    {
    /* This can be made more lenient in the future */

    /* Ugly hack to make sure that $3 is optimized */
    {
      int tmp=Pike_compiler->compiler_pass;
      (yyvsp[(3) - (3)].n)=mknode(F_COMMA_EXPR,(yyvsp[(3) - (3)].n),0);
      Pike_compiler->compiler_pass=tmp;
    }

    if ((Pike_compiler->current_modifiers & ID_EXTERN) &&
	(Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared constant.");
    }

    if(!is_const((yyvsp[(3) - (3)].n)))
    {
      if(Pike_compiler->compiler_pass==2)
	yyerror("Constant definition is not constant.");
      else
	add_constant((yyvsp[(1) - (3)].n)->u.sval.u.string, 0,
		     Pike_compiler->current_modifiers & ~ID_EXTERN);
    } else {
      if(!Pike_compiler->num_parse_error)
      {
	ptrdiff_t tmp=eval_low((yyvsp[(3) - (3)].n),1);
	if(tmp < 1)
	{
	  yyerror("Error in constant definition.");
	  push_undefined();
	}else{
	  pop_n_elems(DO_NOT_WARN((INT32)(tmp - 1)));
	}
      } else {
	push_undefined();
      }
      add_constant((yyvsp[(1) - (3)].n)->u.sval.u.string, Pike_sp-1,
		   Pike_compiler->current_modifiers & ~ID_EXTERN);
      pop_stack();
    }
    if((yyvsp[(3) - (3)].n)) free_node((yyvsp[(3) - (3)].n));
    free_node((yyvsp[(1) - (3)].n));
  }
    break;

  case 31:
#line 555 "language.yacc"
    { if ((yyvsp[(3) - (3)].n)) free_node((yyvsp[(3) - (3)].n)); }
    break;

  case 32:
#line 556 "language.yacc"
    { if ((yyvsp[(3) - (3)].n)) free_node((yyvsp[(3) - (3)].n)); }
    break;

  case 35:
#line 563 "language.yacc"
    {}
    break;

  case 36:
#line 564 "language.yacc"
    { yyerrok; }
    break;

  case 37:
#line 566 "language.yacc"
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 38:
#line 570 "language.yacc"
    { yyerror("Missing ';'."); }
    break;

  case 39:
#line 574 "language.yacc"
    {
    (yyval.n) = check_node_hash(mknode(F_COMMA_EXPR,(yyvsp[(1) - (1)].n),mknode(F_RETURN,mkintnode(0),0)));
    if ((yyvsp[(1) - (1)].n)) COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (1)].n));
  }
    break;

  case 40:
#line 578 "language.yacc"
    { (yyval.n) = NULL; }
    break;

  case 41:
#line 579 "language.yacc"
    { yyerror("Expected ';'."); (yyval.n) = NULL; }
    break;

  case 42:
#line 580 "language.yacc"
    { (yyval.n) = NULL; }
    break;

  case 43:
#line 585 "language.yacc"
    {
#ifdef PIKE_DEBUG
    check_type_string(check_node_hash((yyvsp[(1) - (1)].n))->u.sval.u.type);
#endif /* PIKE_DEBUG */
    if(Pike_compiler->compiler_frame->current_type)
      free_type(Pike_compiler->compiler_frame->current_type); 
    copy_pike_type(Pike_compiler->compiler_frame->current_type,
		   (yyvsp[(1) - (1)].n)->u.sval.u.type);
    free_node((yyvsp[(1) - (1)].n));
  }
    break;

  case 44:
#line 598 "language.yacc"
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
    break;

  case 45:
#line 605 "language.yacc"
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
    break;

  case 46:
#line 610 "language.yacc"
    {
    yyerror("Missing ')'.");
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
    break;

  case 48:
#line 619 "language.yacc"
    {
    yyerror("Missing '}'.");
  }
    break;

  case 50:
#line 626 "language.yacc"
    {
    yyerror("Missing '}'.");
  }
    break;

  case 51:
#line 632 "language.yacc"
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
    break;

  case 53:
#line 640 "language.yacc"
    {
    yyerror("Missing ']'.");
  }
    break;

  case 54:
#line 646 "language.yacc"
    {
    push_compiler_frame(SCOPE_LOCAL);

    if(!Pike_compiler->compiler_frame->previous ||
       !Pike_compiler->compiler_frame->previous->current_type)
    {
      yyerror("Internal compiler fault.");
      copy_pike_type(Pike_compiler->compiler_frame->current_type,
		mixed_type_string);
    }else{
      copy_pike_type(Pike_compiler->compiler_frame->current_type,
		Pike_compiler->compiler_frame->previous->current_type);
    }
  }
    break;

  case 55:
#line 664 "language.yacc"
    {
    int e;
    /* construct the function type */
    push_finished_type(Pike_compiler->compiler_frame->current_type);
    if ((yyvsp[(3) - (8)].number) && (Pike_compiler->compiler_pass == 2)) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    while(--(yyvsp[(3) - (8)].number)>=0) push_type(T_ARRAY);
    
    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    Pike_compiler->compiler_frame->current_return_type = compiler_pop_type();
    
    push_finished_type(Pike_compiler->compiler_frame->current_return_type);
    
    e=(yyvsp[(7) - (8)].number)-1;
    if(Pike_compiler->varargs)
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    push_type(T_MANY);
    for(; e>=0; e--)
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      push_type(T_FUNCTION);
    }

    {
      struct pike_type *s=compiler_pop_type();
      int i = isidentifier((yyvsp[(4) - (8)].n)->u.sval.u.string);

      if (Pike_compiler->compiler_pass == 1) {
	if ((yyvsp[(1) - (8)].number) & ID_VARIANT) {
	  /* FIXME: Lookup the type of any existing variant */
	  /* Or the types. */
	  fprintf(stderr, "Pass %d: Identifier %s:\n",
		  Pike_compiler->compiler_pass, (yyvsp[(4) - (8)].n)->u.sval.u.string->str);

	  if (i >= 0) {
	    struct identifier *id = ID_FROM_INT(Pike_compiler->new_program, i);
	    if (id) {
	      struct pike_type *new_type;
	      fprintf(stderr, "Defined, type:\n");
#ifdef PIKE_DEBUG
	      simple_describe_type(id->type);
#endif

	      new_type = or_pike_types(s, id->type, 1);
	      free_type(s);
	      s = new_type;

	      fprintf(stderr, "Resulting type:\n");
#ifdef PIKE_DEBUG
	      simple_describe_type(s);
#endif
	    } else {
	      my_yyerror("Lost identifier %s (%d).",
			 (yyvsp[(4) - (8)].n)->u.sval.u.string->str, i);
	    }
	  } else {
	    fprintf(stderr, "Not defined.\n");
	  }
	  fprintf(stderr, "New type:\n");
#ifdef PIKE_DEBUG
	  simple_describe_type(s);
#endif
	}
      } else {
	/* FIXME: Second pass reuses the type from the end of
	 * the first pass if this is a variant function.
	 */
	if (i >= 0) {
	  if (Pike_compiler->new_program->identifier_references[i].id_flags &
	      ID_VARIANT) {
	    struct identifier *id = ID_FROM_INT(Pike_compiler->new_program, i);
	    fprintf(stderr, "Pass %d: Identifier %s:\n",
		    Pike_compiler->compiler_pass, (yyvsp[(4) - (8)].n)->u.sval.u.string->str);

	    free_type(s);
	    copy_pike_type(s, id->type);

	    fprintf(stderr, "Resulting type:\n");
#ifdef PIKE_DEBUG
	    simple_describe_type(s);
#endif
	  }
	} else {
	  my_yyerror("Identifier %s lost after first pass.",
		     (yyvsp[(4) - (8)].n)->u.sval.u.string->str);
	}
      }

      (yyval.n) = mktypenode(s);
      free_type(s);
    }


/*    if(Pike_compiler->compiler_pass==1) */
    {
      /* FIXME:
       * set current_function_number for local functions as well
       */
      Pike_compiler->compiler_frame->current_function_number=
	define_function(check_node_hash((yyvsp[(4) - (8)].n))->u.sval.u.string,
			check_node_hash((yyval.n))->u.sval.u.type,
			(yyvsp[(1) - (8)].number) & (~ID_EXTERN),
			IDENTIFIER_PIKE_FUNCTION |
			(Pike_compiler->varargs?IDENTIFIER_VARARGS:0),
			0,
			OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

      Pike_compiler->varargs=0;

      if ((yyvsp[(1) - (8)].number) & ID_VARIANT) {
	fprintf(stderr, "Function number: %d\n",
		Pike_compiler->compiler_frame->current_function_number);
      }
    }
  }
    break;

  case 56:
#line 788 "language.yacc"
    {
    int e;
    if((yyvsp[(10) - (10)].n))
    {
      int f;
      node *check_args = NULL;
      struct pike_string *save_file = lex.current_file;
      int save_line = lex.current_line;
      int num_required_args = 0;
      struct identifier *i;
      lex.current_file = (yyvsp[(4) - (10)].n)->current_file;
      lex.current_line = (yyvsp[(4) - (10)].n)->line_number;

      if (((yyvsp[(1) - (10)].number) & ID_EXTERN) && (Pike_compiler->compiler_pass == 1)) {
	yywarning("Extern declared function definition.");
      }

      for(e=0; e<(yyvsp[(7) - (10)].number); e++)
      {
	if(!Pike_compiler->compiler_frame->variable[e].name ||
	   !Pike_compiler->compiler_frame->variable[e].name->len)
	{
	  my_yyerror("Missing name for argument %d.",e);
	} else {
	  if (Pike_compiler->compiler_pass == 2) {
	    if ((yyvsp[(1) - (10)].number) & ID_VARIANT) {
	      struct pike_type *arg_type =
		Pike_compiler->compiler_frame->variable[e].type;

	      /* FIXME: Generate code that checks the arguments. */
	      /* If there is a bad argument, call the fallback, and return. */
	      if (! pike_types_le(void_type_string, arg_type)) {
		/* Argument my not be void.
		 * ie it's required.
		 */
		num_required_args++;
	      }
	    } else {
	      /* FIXME: Should probably use some other flag. */
	      if ((runtime_options & RUNTIME_CHECK_TYPES) &&
		  (Pike_compiler->compiler_frame->variable[e].type !=
		   mixed_type_string)) {
		node *local_node;

		/* fprintf(stderr, "Creating soft cast node for local #%d\n", e);*/

		local_node = mklocalnode(e, 0);

		/* The following is needed to go around the optimization in
		 * mksoftcastnode().
		 */
		free_type(local_node->type);
		copy_pike_type(local_node->type, mixed_type_string);

		check_args =
		  mknode(F_COMMA_EXPR, check_args,
			 mksoftcastnode(Pike_compiler->compiler_frame->variable[e].type,
					local_node));
	      }
	    }
	  }
	}
      }

      if ((yyvsp[(1) - (10)].number) & ID_VARIANT) {
	struct pike_string *bad_arg_str;
	MAKE_CONST_STRING(bad_arg_str,
			  "Bad number of arguments!\n");

	fprintf(stderr, "Required args: %d\n", num_required_args);

	check_args =
	  mknode('?',
		 mkopernode("`<",
			    mkefuncallnode("query_num_arg", NULL),
			    mkintnode(num_required_args)),
		 mknode(':',
			mkefuncallnode("throw",
				       mkefuncallnode("aggregate",
						      mkstrnode(bad_arg_str))),
			NULL));
      }

      {
	int l = (yyvsp[(10) - (10)].n)->line_number;
	struct pike_string *f = (yyvsp[(10) - (10)].n)->current_file;
	if (check_args) {
	  /* Prepend the arg checking code. */
	  (yyvsp[(10) - (10)].n) = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, check_args, NULL), (yyvsp[(10) - (10)].n));
	}
	lex.current_line = l;
	lex.current_file = f;
      }

      f=dooptcode(check_node_hash((yyvsp[(4) - (10)].n))->u.sval.u.string,
		  check_node_hash((yyvsp[(10) - (10)].n)),
		  check_node_hash((yyvsp[(9) - (10)].n))->u.sval.u.type,
		  (yyvsp[(1) - (10)].number));

      i = ID_FROM_INT(Pike_compiler->new_program, f);
      i->opt_flags = Pike_compiler->compiler_frame->opt_flags;

      if ((yyvsp[(1) - (10)].number) & ID_VARIANT) {
	fprintf(stderr, "Function number: %d\n", f);
      }

#ifdef PIKE_DEBUG
      if(Pike_interpreter.recoveries &&
	 ((Pike_sp - Pike_interpreter.evaluator_stack) <
	  Pike_interpreter.recoveries->stack_pointer))
	Pike_fatal("Stack error (underflow)\n");

      if((Pike_compiler->compiler_pass == 1) &&
	 (f != Pike_compiler->compiler_frame->current_function_number)) {
	fprintf(stderr, "define_function()/do_opt_code() failed for symbol %s\n",
		(yyvsp[(4) - (10)].n)->u.sval.u.string->str);
	dump_program_desc(Pike_compiler->new_program);
	Pike_fatal("define_function screwed up! %d != %d\n",
	      f, Pike_compiler->compiler_frame->current_function_number);
      }
#endif

      lex.current_line = save_line;
      lex.current_file = save_file;
    }
    pop_compiler_frame();
    free_node((yyvsp[(4) - (10)].n));
    free_node((yyvsp[(8) - (10)].n));
    free_node((yyvsp[(9) - (10)].n));
  }
    break;

  case 57:
#line 920 "language.yacc"
    {
    pop_compiler_frame();
    free_node((yyvsp[(4) - (6)].n));
  }
    break;

  case 58:
#line 925 "language.yacc"
    {
    free_type(compiler_pop_type());
  }
    break;

  case 59:
#line 929 "language.yacc"
    {
    if ((yyvsp[(9) - (9)].n)) free_node((yyvsp[(9) - (9)].n));
  }
    break;

  case 60:
#line 932 "language.yacc"
    {}
    break;

  case 61:
#line 933 "language.yacc"
    {}
    break;

  case 62:
#line 934 "language.yacc"
    {}
    break;

  case 63:
#line 935 "language.yacc"
    {}
    break;

  case 64:
#line 936 "language.yacc"
    { free_node((yyvsp[(1) - (1)].n)); }
    break;

  case 65:
#line 937 "language.yacc"
    { free_node((yyvsp[(1) - (1)].n)); }
    break;

  case 66:
#line 938 "language.yacc"
    {}
    break;

  case 67:
#line 940 "language.yacc"
    {
    reset_type_stack();
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file");
  }
    break;

  case 68:
#line 946 "language.yacc"
    {
    reset_type_stack();
    yyerrok;
/*     if(Pike_compiler->num_parse_error>5) YYACCEPT; */
  }
    break;

  case 69:
#line 952 "language.yacc"
    {
    reset_type_stack();
    yyerror("Missing ';'.");
   /* yychar = '}';	*/ /* Put the '}' back on the input stream */
  }
    break;

  case 70:
#line 959 "language.yacc"
    {
      (yyval.number)=lex.pragmas;
      lex.pragmas|=(yyvsp[(1) - (2)].number);
    }
    break;

  case 71:
#line 965 "language.yacc"
    {
      lex.pragmas=(yyvsp[(3) - (5)].number);
    }
    break;

  case 72:
#line 970 "language.yacc"
    { (yyval.number)=1; }
    break;

  case 73:
#line 972 "language.yacc"
    {
    yyerror("Range indicator ('..') where elipsis ('...') expected.");
    (yyval.number)=1;
  }
    break;

  case 74:
#line 976 "language.yacc"
    { (yyval.number)=0; }
    break;

  case 76:
#line 980 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 77:
#line 981 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 78:
#line 985 "language.yacc"
    {
    if(Pike_compiler->varargs) yyerror("Can't define more arguments after ...");

    if((yyvsp[(2) - (3)].number))
    {
      push_type(T_ARRAY);
      Pike_compiler->varargs=1;
    }

    if(!(yyvsp[(3) - (3)].n))
    {
      (yyvsp[(3) - (3)].n)=mkstrnode(empty_pike_string);
    }

    if((yyvsp[(3) - (3)].n)->u.sval.u.string->len &&
       islocal((yyvsp[(3) - (3)].n)->u.sval.u.string) >= 0)
      my_yyerror("Variable '%s' appears twice in argument list.",
		 (yyvsp[(3) - (3)].n)->u.sval.u.string->str);
    
    add_local_name((yyvsp[(3) - (3)].n)->u.sval.u.string, compiler_pop_type(),0);
    free_node((yyvsp[(3) - (3)].n));
  }
    break;

  case 79:
#line 1010 "language.yacc"
    {
    free_node((yyvsp[(3) - (3)].n));
    (yyval.number)=(yyvsp[(2) - (3)].number);
  }
    break;

  case 80:
#line 1016 "language.yacc"
    { (yyval.number)=0; }
    break;

  case 82:
#line 1020 "language.yacc"
    { (yyval.number) = 1; }
    break;

  case 83:
#line 1021 "language.yacc"
    { (yyval.number) = (yyvsp[(1) - (3)].number) + 1; }
    break;

  case 84:
#line 1023 "language.yacc"
    {
    yyerror("Unexpected ':' in argument list.");
    (yyval.number) = (yyvsp[(1) - (3)].number) + 1;
  }
    break;

  case 85:
#line 1030 "language.yacc"
    { (yyval.number) = ID_NOMASK; }
    break;

  case 86:
#line 1031 "language.yacc"
    { (yyval.number) = ID_NOMASK; }
    break;

  case 87:
#line 1032 "language.yacc"
    { (yyval.number) = ID_STATIC; }
    break;

  case 88:
#line 1033 "language.yacc"
    { (yyval.number) = ID_EXTERN; }
    break;

  case 89:
#line 1034 "language.yacc"
    { (yyval.number) = ID_OPTIONAL; }
    break;

  case 90:
#line 1035 "language.yacc"
    { (yyval.number) = ID_PRIVATE | ID_STATIC; }
    break;

  case 91:
#line 1036 "language.yacc"
    { (yyval.number) = ID_INLINE; }
    break;

  case 92:
#line 1037 "language.yacc"
    { (yyval.number) = ID_PUBLIC; }
    break;

  case 93:
#line 1038 "language.yacc"
    { (yyval.number) = ID_PROTECTED; }
    break;

  case 94:
#line 1039 "language.yacc"
    { (yyval.number) = ID_INLINE; }
    break;

  case 95:
#line 1040 "language.yacc"
    { (yyval.number) = ID_VARIANT; }
    break;

  case 96:
#line 1044 "language.yacc"
    { (yyval.str) = "nomask"; }
    break;

  case 97:
#line 1045 "language.yacc"
    { (yyval.str) = "final"; }
    break;

  case 98:
#line 1046 "language.yacc"
    { (yyval.str) = "static"; }
    break;

  case 99:
#line 1047 "language.yacc"
    { (yyval.str) = "extern"; }
    break;

  case 100:
#line 1048 "language.yacc"
    { (yyval.str) = "private"; }
    break;

  case 101:
#line 1049 "language.yacc"
    { (yyval.str) = "local"; }
    break;

  case 102:
#line 1050 "language.yacc"
    { (yyval.str) = "public"; }
    break;

  case 103:
#line 1051 "language.yacc"
    { (yyval.str) = "protected"; }
    break;

  case 104:
#line 1052 "language.yacc"
    { (yyval.str) = "inline"; }
    break;

  case 105:
#line 1053 "language.yacc"
    { (yyval.str) = "optional"; }
    break;

  case 106:
#line 1054 "language.yacc"
    { (yyval.str) = "variant"; }
    break;

  case 107:
#line 1058 "language.yacc"
    { (yyval.str) = "void"; }
    break;

  case 108:
#line 1059 "language.yacc"
    { (yyval.str) = "mixed"; }
    break;

  case 109:
#line 1060 "language.yacc"
    { (yyval.str) = "array"; }
    break;

  case 110:
#line 1061 "language.yacc"
    { (yyval.str) = "mapping"; }
    break;

  case 111:
#line 1062 "language.yacc"
    { (yyval.str) = "multiset"; }
    break;

  case 112:
#line 1063 "language.yacc"
    { (yyval.str) = "object"; }
    break;

  case 113:
#line 1064 "language.yacc"
    { (yyval.str) = "function"; }
    break;

  case 114:
#line 1065 "language.yacc"
    { (yyval.str) = "program"; }
    break;

  case 115:
#line 1066 "language.yacc"
    { (yyval.str) = "string"; }
    break;

  case 116:
#line 1067 "language.yacc"
    { (yyval.str) = "float"; }
    break;

  case 117:
#line 1068 "language.yacc"
    { (yyval.str) = "int"; }
    break;

  case 118:
#line 1069 "language.yacc"
    { (yyval.str) = "enum"; }
    break;

  case 119:
#line 1070 "language.yacc"
    { (yyval.str) = "typedef"; }
    break;

  case 120:
#line 1074 "language.yacc"
    { (yyval.str) = "if"; }
    break;

  case 121:
#line 1075 "language.yacc"
    { (yyval.str) = "do"; }
    break;

  case 122:
#line 1076 "language.yacc"
    { (yyval.str) = "for"; }
    break;

  case 123:
#line 1077 "language.yacc"
    { (yyval.str) = "while"; }
    break;

  case 124:
#line 1078 "language.yacc"
    { (yyval.str) = "else"; }
    break;

  case 125:
#line 1079 "language.yacc"
    { (yyval.str) = "foreach"; }
    break;

  case 126:
#line 1080 "language.yacc"
    { (yyval.str) = "catch"; }
    break;

  case 127:
#line 1081 "language.yacc"
    { (yyval.str) = "gauge"; }
    break;

  case 128:
#line 1082 "language.yacc"
    { (yyval.str) = "class"; }
    break;

  case 129:
#line 1083 "language.yacc"
    { (yyval.str) = "break"; }
    break;

  case 130:
#line 1084 "language.yacc"
    { (yyval.str) = "case"; }
    break;

  case 131:
#line 1085 "language.yacc"
    { (yyval.str) = "constant"; }
    break;

  case 132:
#line 1086 "language.yacc"
    { (yyval.str) = "continue"; }
    break;

  case 133:
#line 1087 "language.yacc"
    { (yyval.str) = "default"; }
    break;

  case 134:
#line 1088 "language.yacc"
    { (yyval.str) = "import"; }
    break;

  case 135:
#line 1089 "language.yacc"
    { (yyval.str) = "inherit"; }
    break;

  case 136:
#line 1090 "language.yacc"
    { (yyval.str) = "lambda"; }
    break;

  case 137:
#line 1091 "language.yacc"
    { (yyval.str) = "predef"; }
    break;

  case 138:
#line 1092 "language.yacc"
    { (yyval.str) = "return"; }
    break;

  case 139:
#line 1093 "language.yacc"
    { (yyval.str) = "sscanf"; }
    break;

  case 140:
#line 1094 "language.yacc"
    { (yyval.str) = "switch"; }
    break;

  case 141:
#line 1095 "language.yacc"
    { (yyval.str) = "typeof"; }
    break;

  case 142:
#line 1096 "language.yacc"
    { (yyval.str) = "global"; }
    break;

  case 147:
#line 1103 "language.yacc"
    {
    struct pike_string *tmp=make_shared_string((yyvsp[(1) - (1)].str));
    (yyval.n)=mkstrnode(tmp);
    free_string(tmp);
  }
    break;

  case 148:
#line 1111 "language.yacc"
    {
   (yyval.number)=Pike_compiler->current_modifiers=(yyvsp[(1) - (1)].number) | (lex.pragmas & ID_MODIFIER_MASK);
 }
    break;

  case 149:
#line 1116 "language.yacc"
    { (yyval.number) = 0; }
    break;

  case 150:
#line 1117 "language.yacc"
    { (yyval.number) = (yyvsp[(1) - (2)].number) | (yyvsp[(2) - (2)].number); }
    break;

  case 151:
#line 1120 "language.yacc"
    { (yyval.number)=(yyvsp[(1) - (2)].number) + 1; }
    break;

  case 152:
#line 1121 "language.yacc"
    { (yyval.number)=0; }
    break;

  case 153:
#line 1125 "language.yacc"
    {
      struct pike_type *s = compiler_pop_type();
      (yyval.n) = mktypenode(s);
      free_type(s);
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (3)].n));
      free_node ((yyvsp[(1) - (3)].n));
    }
    break;

  case 154:
#line 1135 "language.yacc"
    {
      struct pike_type *s = compiler_pop_type();
      (yyval.n) = mktypenode(s);
      free_type(s);
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (3)].n));
      free_node ((yyvsp[(1) - (3)].n));
    }
    break;

  case 156:
#line 1146 "language.yacc"
    {
    if (Pike_compiler->compiler_pass == 2) {
       yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    push_type(T_ARRAY);
  }
    break;

  case 159:
#line 1157 "language.yacc"
    {
    if (Pike_compiler->compiler_pass == 2) {
       yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    push_type(T_ARRAY);
  }
    break;

  case 161:
#line 1167 "language.yacc"
    {
    if (Pike_compiler->compiler_pass == 2) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    push_type(T_ARRAY);
  }
    break;

  case 163:
#line 1177 "language.yacc"
    {
    struct pike_type *s = compiler_pop_type();
    (yyval.n) = mktypenode(s);
#ifdef PIKE_DEBUG
    if ((yyval.n)->u.sval.u.type != s) {
      Pike_fatal("mktypenode(%p) created node with %p\n", s, (yyval.n)->u.sval.u.type);
    }
#endif /* PIKE_DEBUG */
    free_type(s);
  }
    break;

  case 164:
#line 1190 "language.yacc"
    {
    struct pike_type *s = compiler_pop_type();
    (yyval.n) = mktypenode(s);
#ifdef PIKE_DEBUG
    if ((yyval.n)->u.sval.u.type != s) {
      Pike_fatal("mktypenode(%p) created node with %p\n", s, (yyval.n)->u.sval.u.type);
    }
#endif /* PIKE_DEBUG */
    free_type(s);
  }
    break;

  case 165:
#line 1203 "language.yacc"
    {
    struct pike_type *s = compiler_pop_type();
    (yyval.n) = mktypenode(s);
#ifdef PIKE_DEBUG
    if ((yyval.n)->u.sval.u.type != s) {
      Pike_fatal("mktypenode(%p) created node with %p\n", s, (yyval.n)->u.sval.u.type);
    }
#endif /* PIKE_DEBUG */
    free_type(s);
  }
    break;

  case 166:
#line 1215 "language.yacc"
    { push_type(T_OR); }
    break;

  case 168:
#line 1219 "language.yacc"
    { push_type(T_OR); }
    break;

  case 172:
#line 1226 "language.yacc"
    { push_type(T_FLOAT); }
    break;

  case 173:
#line 1227 "language.yacc"
    { push_type(T_VOID); }
    break;

  case 174:
#line 1228 "language.yacc"
    { push_type(T_MIXED); }
    break;

  case 175:
#line 1229 "language.yacc"
    { push_type(T_STRING); }
    break;

  case 176:
#line 1230 "language.yacc"
    {}
    break;

  case 177:
#line 1231 "language.yacc"
    {}
    break;

  case 178:
#line 1232 "language.yacc"
    {}
    break;

  case 179:
#line 1233 "language.yacc"
    {}
    break;

  case 180:
#line 1234 "language.yacc"
    { push_type(T_PROGRAM); }
    break;

  case 181:
#line 1235 "language.yacc"
    { push_type(T_ARRAY); }
    break;

  case 182:
#line 1236 "language.yacc"
    { push_type(T_MULTISET); }
    break;

  case 183:
#line 1240 "language.yacc"
    { 
    resolv_constant((yyvsp[(1) - (1)].n));

    if (Pike_sp[-1].type == T_TYPE) {
      /* "typedef" */
      push_finished_type(Pike_sp[-1].u.type);
    } else {
      /* object type */
      struct program *p = NULL;

      if (Pike_sp[-1].type == T_OBJECT) {
	if(!Pike_sp[-1].u.object->prog)
	{
	  pop_stack();
	  push_int(0);
	  yyerror("Destructed object used as program identifier.");
	}else{
	  int f=FIND_LFUN(Pike_sp[-1].u.object->prog,LFUN_CALL);
	  if(f!=-1)
	  {
	    Pike_sp[-1].subtype=f;
	    Pike_sp[-1].type=T_FUNCTION;
	  }else{
	    extern void f_object_program(INT32);
	    if (Pike_compiler->compiler_pass == 2 && !TEST_COMPAT (7, 4)) {
	      yywarning("Using object as program identifier.");
	    }
	    f_object_program(1);
	  }
	}
      }

      switch(Pike_sp[-1].type) {
	case T_FUNCTION:
        if((p = program_from_function(Pike_sp-1)))
	  push_object_type(0, p?(p->id):0);
	else
	{
	  struct pike_type *a,*b;
	  a=get_type_of_svalue(Pike_sp-1);
	  b=check_call(function_type_string,a,0);
	  push_finished_type(b);
	  free_type(a);
	  free_type(b);
	}
	break;

      
      default:
	if (Pike_compiler->compiler_pass!=1)
	  my_yyerror("Illegal program identifier (type: %s).",
		     get_name_of_type(Pike_sp[-1].type));
	pop_stack();
	push_int(0);
	push_object_type(0, 0);
	break;
	
      case T_PROGRAM:
	p = Pike_sp[-1].u.program;
	push_object_type(0, p?(p->id):0);
	break;
      }
    }
    /* Attempt to name the type. */
    if (Pike_compiler->last_identifier) {
      push_type_name(Pike_compiler->last_identifier);
    }
    pop_stack();
    free_node((yyvsp[(1) - (1)].n));
  }
    break;

  case 184:
#line 1313 "language.yacc"
    {
    (yyval.n) = mkintnode(MAX_INT_TYPE);
  }
    break;

  case 186:
#line 1318 "language.yacc"
    {
#ifdef PIKE_DEBUG
    if (((yyvsp[(2) - (2)].n)->token != F_CONSTANT) || ((yyvsp[(2) - (2)].n)->u.sval.type != T_INT)) {
      Pike_fatal("Unexpected number in negative int-range.\n");
    }
#endif /* PIKE_DEBUG */
    (yyval.n) = mkintnode(-((yyvsp[(2) - (2)].n)->u.sval.u.integer));
    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 187:
#line 1330 "language.yacc"
    {
    (yyval.n) = mkintnode(MIN_INT_TYPE);
  }
    break;

  case 189:
#line 1335 "language.yacc"
    {
#ifdef PIKE_DEBUG
    if (((yyvsp[(2) - (2)].n)->token != F_CONSTANT) || ((yyvsp[(2) - (2)].n)->u.sval.type != T_INT)) {
      Pike_fatal("Unexpected number in negative int-range.\n");
    }
#endif /* PIKE_DEBUG */
    (yyval.n) = mkintnode(-((yyvsp[(2) - (2)].n)->u.sval.u.integer));
    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 191:
#line 1348 "language.yacc"
    {
    yyerror("Elipsis ('...') where range indicator ('..') expected.");
  }
    break;

  case 192:
#line 1354 "language.yacc"
    {
    push_int_type(MIN_INT_TYPE, MAX_INT_TYPE);
  }
    break;

  case 193:
#line 1358 "language.yacc"
    {
    INT_TYPE min = MIN_INT_TYPE;
    INT_TYPE max = MAX_INT_TYPE;

    /* FIXME: Check that $4 is >= $2. */
    if((yyvsp[(4) - (5)].n)->token == F_CONSTANT) {
      if ((yyvsp[(4) - (5)].n)->u.sval.type == T_INT) {
	max = (yyvsp[(4) - (5)].n)->u.sval.u.integer;
#ifdef AUTO_BIGNUM
      } else if (is_bignum_object_in_svalue(&(yyvsp[(4) - (5)].n)->u.sval)) {
	push_int(0);
	if (is_lt(&(yyvsp[(4) - (5)].n)->u.sval, Pike_sp-1)) {
	  max = MIN_INT_TYPE;
	}
	pop_stack();
#endif /* AUTO_BIGNUM */
      }
    }

    if((yyvsp[(2) - (5)].n)->token == F_CONSTANT) {
      if ((yyvsp[(2) - (5)].n)->u.sval.type == T_INT) {
	min = (yyvsp[(2) - (5)].n)->u.sval.u.integer;
#ifdef AUTO_BIGNUM
      } else if (is_bignum_object_in_svalue(&(yyvsp[(2) - (5)].n)->u.sval)) {
	push_int(0);
	if (is_lt(Pike_sp-1, &(yyvsp[(2) - (5)].n)->u.sval)) {
	  min = MAX_INT_TYPE;
	}
	pop_stack();
#endif /* AUTO_BIGNUM */
      }
    }

    push_int_type(min, max);

    free_node((yyvsp[(2) - (5)].n));
    free_node((yyvsp[(4) - (5)].n));
  }
    break;

  case 194:
#line 1398 "language.yacc"
    { push_object_type(0, 0); }
    break;

  case 195:
#line 1399 "language.yacc"
    {
#ifdef PIKE_DEBUG
      (yyval.ptr) = Pike_sp;
#endif /* PIKE_DEBUG */
    }
    break;

  case 196:
#line 1405 "language.yacc"
    {
    /* NOTE: On entry, there are two items on the stack:
     *   Pike_sp-2:	Name of the program reference (string).
     *   Pike_sp-1:	The resolved program (program|function|zero).
     */
    struct program *p=program_from_svalue(Pike_sp-1);

#ifdef PIKE_DEBUG
    if ((yyvsp[(1) - (4)].ptr) != (Pike_sp - 2)) {
      Pike_fatal("Unexpected stack depth: %p != %p\n",
		 (yyvsp[(1) - (4)].n), Pike_sp-2);
    }
#endif /* PIKE_DEBUG */

    if(!p) {
      if (Pike_compiler->compiler_pass!=1) {
	if ((Pike_sp[-2].type == T_STRING) && (Pike_sp[-2].u.string->len > 0) &&
	    (Pike_sp[-2].u.string->len < 256)) {
	  my_yyerror("Not a valid program specifier: '%s'",
		     Pike_sp[-2].u.string->str);
	} else {
	  yyerror("Not a valid program specifier.");
	}
      }
    }
    push_object_type(0, p?(p->id):0);
    /* Attempt to name the type. */
    if (Pike_sp[-2].type == T_STRING) {
      push_type_name(Pike_sp[-2].u.string);
    }
    pop_n_elems(2);
  }
    break;

  case 197:
#line 1440 "language.yacc"
    {
    type_stack_mark();
  }
    break;

  case 198:
#line 1444 "language.yacc"
    {
    /* Add the many type if there is none. */
    if ((yyvsp[(4) - (5)].number))
    {
      if (!(yyvsp[(3) - (5)].number)) {
	/* function_type_list ends with a comma, or is empty.
	 * FIXME: Should this be a syntax error or not?
	 */
	if (Pike_compiler->compiler_pass == 1) {
	  yyerror("Missing type before ... .");
	}
	push_type(T_MIXED);
      }
    }else{
      push_type(T_VOID);
    }
  }
    break;

  case 199:
#line 1462 "language.yacc"
    {
    push_reverse_type(T_MANY);
    Pike_compiler->pike_type_mark_stackp--;
    while (*Pike_compiler->pike_type_mark_stackp+1 <
	   Pike_compiler->type_stackp) {
      push_reverse_type(T_FUNCTION);
    }
  }
    break;

  case 200:
#line 1471 "language.yacc"
    {
   push_type(T_MIXED);
   push_type(T_VOID);
   push_type(T_OR);

   push_type(T_ZERO);
   push_type(T_VOID);
   push_type(T_OR);

   push_type(T_MANY);
  }
    break;

  case 201:
#line 1484 "language.yacc"
    { (yyval.number)=0; }
    break;

  case 202:
#line 1485 "language.yacc"
    { (yyval.number)=!(yyvsp[(2) - (2)].number); }
    break;

  case 203:
#line 1488 "language.yacc"
    { (yyval.number)=1; }
    break;

  case 204:
#line 1490 "language.yacc"
    {
  }
    break;

  case 207:
#line 1496 "language.yacc"
    { push_type(T_MIXED); }
    break;

  case 208:
#line 1500 "language.yacc"
    { 
  }
    break;

  case 209:
#line 1503 "language.yacc"
    { 
  }
    break;

  case 210:
#line 1506 "language.yacc"
    { 
    push_reverse_type(T_MAPPING);
  }
    break;

  case 212:
#line 1511 "language.yacc"
    {
    push_type(T_MIXED);
    push_type(T_MIXED);
    push_type(T_MAPPING);
  }
    break;

  case 215:
#line 1525 "language.yacc"
    {
    struct pike_type *type;
    push_finished_type(Pike_compiler->compiler_frame->current_type);
    if ((yyvsp[(1) - (2)].number) && (Pike_compiler->compiler_pass == 2)) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    while((yyvsp[(1) - (2)].number)--) push_type(T_ARRAY);
    type=compiler_pop_type();
    define_variable((yyvsp[(2) - (2)].n)->u.sval.u.string, type,
		    Pike_compiler->current_modifiers);
    free_type(type);
    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 216:
#line 1538 "language.yacc"
    {}
    break;

  case 217:
#line 1540 "language.yacc"
    {
    struct pike_type *type;
    push_finished_type(Pike_compiler->compiler_frame->current_type);
    if ((yyvsp[(1) - (3)].number) && (Pike_compiler->compiler_pass == 2)) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    while((yyvsp[(1) - (3)].number)--) push_type(T_ARRAY);
    type=compiler_pop_type();
    if ((Pike_compiler->current_modifiers & ID_EXTERN) &&
	(Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared variable has initializer.");
    }
    (yyval.number)=define_variable((yyvsp[(2) - (3)].n)->u.sval.u.string, type,
			       Pike_compiler->current_modifiers & (~ID_EXTERN));
    free_type(type);
  }
    break;

  case 218:
#line 1557 "language.yacc"
    {
    Pike_compiler->init_node=mknode(F_COMMA_EXPR,Pike_compiler->init_node,
		     mkcastnode(void_type_string,
				mknode(F_ASSIGN,(yyvsp[(5) - (5)].n),
				       mkidentifiernode((yyvsp[(4) - (5)].number)))));
    free_node((yyvsp[(2) - (5)].n));
  }
    break;

  case 219:
#line 1565 "language.yacc"
    {
    free_node((yyvsp[(2) - (4)].n));
  }
    break;

  case 220:
#line 1569 "language.yacc"
    {
    yyerror("Unexpected end of file in variable definition.");
    free_node((yyvsp[(2) - (4)].n));
  }
    break;

  case 221:
#line 1574 "language.yacc"
    {
    free_node((yyvsp[(4) - (4)].n));
  }
    break;

  case 222:
#line 1581 "language.yacc"
    {
    int id;
    push_finished_type((yyvsp[(0) - (2)].n)->u.sval.u.type);
    if ((yyvsp[(1) - (2)].number) && (Pike_compiler->compiler_pass == 2)) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    while((yyvsp[(1) - (2)].number)--) push_type(T_ARRAY);
    id = add_local_name((yyvsp[(2) - (2)].n)->u.sval.u.string, compiler_pop_type(),0);
    if (id >= 0)
      (yyval.n)=mknode(F_ASSIGN,mkintnode(0),mklocalnode(id,0));
    else
      (yyval.n) = 0;
    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 223:
#line 1595 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 224:
#line 1597 "language.yacc"
    {
    int id;
    push_finished_type((yyvsp[(0) - (4)].n)->u.sval.u.type);
    if ((yyvsp[(1) - (4)].number) && (Pike_compiler->compiler_pass == 2)) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    while((yyvsp[(1) - (4)].number)--) push_type(T_ARRAY);
    id = add_local_name((yyvsp[(2) - (4)].n)->u.sval.u.string, compiler_pop_type(),0);
    if (id >= 0)
      (yyval.n)=mknode(F_ASSIGN,(yyvsp[(4) - (4)].n),mklocalnode(id,0));
    else
      (yyval.n) = 0;
    free_node((yyvsp[(2) - (4)].n));
  }
    break;

  case 225:
#line 1612 "language.yacc"
    {
    free_node((yyvsp[(4) - (4)].n));
    (yyval.n)=0;
  }
    break;

  case 226:
#line 1617 "language.yacc"
    {
    free_node((yyvsp[(2) - (4)].n));
    /* No yyerok here since we aren't done yet. */
    (yyval.n)=0;
  }
    break;

  case 227:
#line 1623 "language.yacc"
    {
    yyerror("Unexpected end of file in local variable definition.");
    free_node((yyvsp[(2) - (4)].n));
    /* No yyerok here since we aren't done yet. */
    (yyval.n)=0;
  }
    break;

  case 228:
#line 1632 "language.yacc"
    {
    int id;
    add_ref((yyvsp[(0) - (1)].n)->u.sval.u.type);
    id = add_local_name((yyvsp[(1) - (1)].n)->u.sval.u.string, (yyvsp[(0) - (1)].n)->u.sval.u.type, 0);
    if (id >= 0)
      (yyval.n)=mknode(F_ASSIGN,mkintnode(0),mklocalnode(id,0));
    else
      (yyval.n) = 0;
    free_node((yyvsp[(1) - (1)].n));
  }
    break;

  case 229:
#line 1642 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 230:
#line 1644 "language.yacc"
    {
    int id;
    add_ref((yyvsp[(0) - (3)].n)->u.sval.u.type);
    id = add_local_name((yyvsp[(1) - (3)].n)->u.sval.u.string, (yyvsp[(0) - (3)].n)->u.sval.u.type, 0);
    if (id >= 0)
      (yyval.n)=mknode(F_ASSIGN,(yyvsp[(3) - (3)].n), mklocalnode(id,0));
    else
      (yyval.n) = 0;
    free_node((yyvsp[(1) - (3)].n));
  }
    break;

  case 231:
#line 1654 "language.yacc"
    { (yyval.n)=(yyvsp[(3) - (3)].n); }
    break;

  case 232:
#line 1658 "language.yacc"
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
    break;

  case 233:
#line 1665 "language.yacc"
    {
    (yyvsp[(1) - (1)].number)=Pike_compiler->num_used_modules;
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
    break;

  case 234:
#line 1670 "language.yacc"
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;

    if((yyval.number) == -1) /* if 'first block' */
      Pike_compiler->compiler_frame->last_block_level=0; /* all variables */
    else
      Pike_compiler->compiler_frame->last_block_level=(yyvsp[(2) - (3)].number);
  }
    break;

  case 235:
#line 1680 "language.yacc"
    {
    unuse_modules(Pike_compiler->num_used_modules - (yyvsp[(1) - (6)].number));
    pop_local_variables((yyvsp[(2) - (6)].number));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(4) - (6)].number);
    if ((yyvsp[(5) - (6)].n)) COPY_LINE_NUMBER_INFO ((yyvsp[(5) - (6)].n), (yyvsp[(3) - (6)].n));
    free_node ((yyvsp[(3) - (6)].n));
    (yyval.n)=(yyvsp[(5) - (6)].n);
  }
    break;

  case 237:
#line 1692 "language.yacc"
    {
    yyerror("Missing '}'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 239:
#line 1699 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 240:
#line 1700 "language.yacc"
    { yyerror("Unexpected end of file."); (yyval.n)=0; }
    break;

  case 242:
#line 1705 "language.yacc"
    { (yyval.n)=(yyvsp[(0) - (2)].n); }
    break;

  case 243:
#line 1706 "language.yacc"
    { (yyval.n) = mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[(1) - (4)].n)), (yyvsp[(4) - (4)].n)); }
    break;

  case 245:
#line 1710 "language.yacc"
    { (yyval.n)=(yyvsp[(0) - (2)].n); }
    break;

  case 246:
#line 1711 "language.yacc"
    { (yyval.n) = mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[(1) - (4)].n)), (yyvsp[(4) - (4)].n)); }
    break;

  case 247:
#line 1716 "language.yacc"
    {
    struct pike_type *type;

    /* Ugly hack to make sure that $3 is optimized */
    {
      int tmp=Pike_compiler->compiler_pass;
      (yyvsp[(3) - (3)].n)=mknode(F_COMMA_EXPR,(yyvsp[(3) - (3)].n),0);
      optimize_node((yyvsp[(3) - (3)].n));
      Pike_compiler->compiler_pass=tmp;
      type=(yyvsp[(3) - (3)].n)->u.node.a->type;
    }

    if(!is_const((yyvsp[(3) - (3)].n)))
    {
      if(Pike_compiler->compiler_pass==2)
	yyerror("Constant definition is not constant.");
    }else{
      ptrdiff_t tmp=eval_low((yyvsp[(3) - (3)].n),1);
      if(tmp < 1)
      {
	yyerror("Error in constant definition.");
      }else{
	pop_n_elems(DO_NOT_WARN((INT32)(tmp - 1)));
	if((yyvsp[(3) - (3)].n)) free_node((yyvsp[(3) - (3)].n));
	(yyvsp[(3) - (3)].n)=mksvaluenode(Pike_sp-1);
	type=(yyvsp[(3) - (3)].n)->type;
	pop_stack();
      }
    }
    if(!type) type = mixed_type_string;
    add_ref(type);
    low_add_local_name(Pike_compiler->compiler_frame, /*->previous,*/
		       (yyvsp[(1) - (3)].n)->u.sval.u.string,
		       type, (yyvsp[(3) - (3)].n));
    free_node((yyvsp[(1) - (3)].n));
  }
    break;

  case 248:
#line 1752 "language.yacc"
    { if ((yyvsp[(3) - (3)].n)) free_node((yyvsp[(3) - (3)].n)); }
    break;

  case 249:
#line 1753 "language.yacc"
    { if ((yyvsp[(3) - (3)].n)) free_node((yyvsp[(3) - (3)].n)); }
    break;

  case 253:
#line 1761 "language.yacc"
    { yyerrok; }
    break;

  case 254:
#line 1763 "language.yacc"
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 255:
#line 1767 "language.yacc"
    { yyerror("Missing ';'."); }
    break;

  case 256:
#line 1771 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 257:
#line 1773 "language.yacc"
    {
    (yyval.n) = mknode(F_COMMA_EXPR, (yyvsp[(1) - (2)].n), mkcastnode(void_type_string, (yyvsp[(2) - (2)].n)));
  }
    break;

  case 258:
#line 1779 "language.yacc"
    {
    if((yyvsp[(2) - (2)].n))
    {
      (yyval.n)=recursive_add_call_arg((yyvsp[(1) - (2)].n),(yyvsp[(2) - (2)].n));
    }else{
      (yyval.n)=(yyvsp[(1) - (2)].n);
    }
  }
    break;

  case 260:
#line 1790 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 263:
#line 1793 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 267:
#line 1797 "language.yacc"
    { reset_type_stack(); (yyval.n)=0; yyerrok; }
    break;

  case 268:
#line 1799 "language.yacc"
    {
    reset_type_stack();
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
    (yyval.n)=0;
  }
    break;

  case 269:
#line 1806 "language.yacc"
    {
    reset_type_stack();
    yyerror("Missing ';'.");
/*    yychar = '}'; */	/* Put the '}' back on the input stream. */
    (yyval.n)=0;
  }
    break;

  case 270:
#line 1812 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 271:
#line 1816 "language.yacc"
    {
    Pike_compiler->compiler_frame->opt_flags &= ~OPT_CUSTOM_LABELS;
  }
    break;

  case 280:
#line 1830 "language.yacc"
    {
    Pike_compiler->compiler_frame->opt_flags &= ~OPT_CUSTOM_LABELS;
  }
    break;

  case 281:
#line 1834 "language.yacc"
    {
    (yyval.n) = mknode(Pike_compiler->compiler_frame->opt_flags & OPT_CUSTOM_LABELS ?
		F_CUSTOM_STMT_LABEL : F_NORMAL_STMT_LABEL,
		(yyvsp[(1) - (4)].n), (yyvsp[(4) - (4)].n));

    /* FIXME: This won't be correct if the node happens to be shared.
     * That's an issue to be solved with shared nodes in general,
     * though. */
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (4)].n));
  }
    break;

  case 283:
#line 1847 "language.yacc"
    {(yyval.n) = 0;}
    break;

  case 284:
#line 1850 "language.yacc"
    { (yyval.n)=mknode(F_BREAK,(yyvsp[(2) - (2)].n),0); }
    break;

  case 285:
#line 1851 "language.yacc"
    { (yyval.n)=mknode(F_DEFAULT,0,0); }
    break;

  case 286:
#line 1853 "language.yacc"
    {
    (yyval.n)=mknode(F_DEFAULT,0,0); yyerror("Expected ':' after default.");
  }
    break;

  case 287:
#line 1858 "language.yacc"
    { (yyval.n)=mknode(F_CONTINUE,(yyvsp[(2) - (2)].n),0); }
    break;

  case 288:
#line 1861 "language.yacc"
    {
    push_compiler_frame(SCOPE_LOCAL);
  }
    break;

  case 289:
#line 1867 "language.yacc"
    {
    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);
    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    copy_pike_type(Pike_compiler->compiler_frame->current_return_type,
		   any_type_string);
  }
    break;

  case 290:
#line 1875 "language.yacc"
    {
    (yyval.number) = Pike_compiler->varargs;
    Pike_compiler->varargs = 0;
  }
    break;

  case 291:
#line 1880 "language.yacc"
    {
    struct pike_type *type;
    char buf[80];
    int f,e;
    struct pike_string *name;
    struct pike_string *save_file = lex.current_file;
    int save_line = lex.current_line;
    lex.current_file = (yyvsp[(2) - (7)].n)->current_file;
    lex.current_line = (yyvsp[(2) - (7)].n)->line_number;

    debug_malloc_touch((yyvsp[(7) - (7)].n));
    (yyvsp[(7) - (7)].n)=mknode(F_COMMA_EXPR,(yyvsp[(7) - (7)].n),mknode(F_RETURN,mkintnode(0),0));
    if (Pike_compiler->compiler_pass == 2)
      /* Doing this in pass 1 might induce too strict checks on types
       * in cases where we got placeholders. */
      type=find_return_type((yyvsp[(7) - (7)].n));
    else
      type = NULL;

    if(type) {
      push_finished_type(type);
      free_type(type);
    } else
      push_type(T_MIXED);
    
    e=(yyvsp[(5) - (7)].number)-1;
    if((yyvsp[(6) - (7)].number))
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    Pike_compiler->varargs=0;
    push_type(T_MANY);
    for(; e>=0; e--) {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      push_type(T_FUNCTION);
    }
    
    type=compiler_pop_type();

    sprintf(buf,"__lambda_%ld_%ld_line_%d",
	    (long)Pike_compiler->new_program->id,
	    (long)(Pike_compiler->local_class_counter++ & 0xffffffff), /* OSF/1 cc bug. */
	    (int) lex.current_line);
    name=make_shared_string(buf);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: LAMBDA: %s 0x%08lx 0x%08lx\n",
	    Pike_compiler->compiler_pass, buf, (long)Pike_compiler->new_program->id, Pike_compiler->local_class_counter-1);
#endif /* LAMBDA_DEBUG */
    if(Pike_compiler->compiler_pass == 2)
      Pike_compiler->compiler_frame->current_function_number=isidentifier(name);

    f=dooptcode(name,
		(yyvsp[(7) - (7)].n),
		type,
		ID_STATIC | ID_PRIVATE | ID_INLINE);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d:   lexical_scope: 0x%08x\n",
	    Pike_compiler->compiler_pass,
	    Pike_compiler->compiler_frame->lexical_scope);
#endif /* LAMBDA_DEBUG */

    if(Pike_compiler->compiler_frame->lexical_scope & SCOPE_SCOPED) {
      (yyval.n) = mktrampolinenode(f, Pike_compiler->compiler_frame->previous);
    } else {
      (yyval.n) = mkidentifiernode(f);
    }
    free_string(name);
    free_type(type);
    lex.current_line = save_line;
    lex.current_file = save_file;
    free_node ((yyvsp[(2) - (7)].n));
    pop_compiler_frame();
  }
    break;

  case 292:
#line 1960 "language.yacc"
    {
    pop_compiler_frame();
    (yyval.n) = mkintnode(0);
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[(2) - (4)].n));
    free_node((yyvsp[(2) - (4)].n));
  }
    break;

  case 293:
#line 1969 "language.yacc"
    {
    char buf[40];
    struct pike_string *name;
    struct pike_type *type;
    int id,e;
    node *n;
    struct identifier *i=0;

    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);
    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    copy_pike_type(Pike_compiler->compiler_frame->current_return_type,
		   (yyvsp[(0) - (3)].n)->u.sval.u.type);


    /***/
    push_finished_type(Pike_compiler->compiler_frame->current_return_type);
    
    e=(yyvsp[(3) - (3)].number)-1;
    if(Pike_compiler->varargs)
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    push_type(T_MANY);
    for(; e>=0; e--) {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
    push_type(T_FUNCTION);
    }
    
    type=compiler_pop_type();
    /***/

    sprintf(buf,"__lambda_%ld_%ld_line_%d",
	    (long)Pike_compiler->new_program->id,
	    (long)(Pike_compiler->local_class_counter++ & 0xffffffff), /* OSF/1 cc bug. */
	    (int) (yyvsp[(1) - (3)].n)->line_number);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: LAMBDA: %s 0x%08lx 0x%08lx\n",
	    Pike_compiler->compiler_pass, buf, (long)Pike_compiler->new_program->id, Pike_compiler->local_class_counter-1);
#endif /* LAMBDA_DEBUG */

    name=make_shared_string(buf);

    if(Pike_compiler->compiler_pass > 1)
    {
      id=isidentifier(name);
    }else{
      id=define_function(name,
			 type,
			 ID_INLINE,
			 IDENTIFIER_PIKE_FUNCTION |
			 (Pike_compiler->varargs?IDENTIFIER_VARARGS:0),
			 0,
			 OPT_SIDE_EFFECT|OPT_EXTERNAL_DEPEND);
    }
    Pike_compiler->varargs=0;
    Pike_compiler->compiler_frame->current_function_number=id;

    n=0;
    if(Pike_compiler->compiler_pass > 1 &&
       (i=ID_FROM_INT(Pike_compiler->new_program, id)))
    {
      if(i->identifier_flags & IDENTIFIER_SCOPED)
	n = mktrampolinenode(id, Pike_compiler->compiler_frame->previous);
      else
	n = mkidentifiernode(id);
    }

    low_add_local_name(Pike_compiler->compiler_frame->previous,
		       (yyvsp[(1) - (3)].n)->u.sval.u.string, type, n);

    (yyval.number)=id;
    free_string(name);
  }
    break;

  case 294:
#line 2049 "language.yacc"
    {
    int localid;
    struct identifier *i=ID_FROM_INT(Pike_compiler->new_program, (yyvsp[(4) - (5)].number));
    struct pike_string *save_file = lex.current_file;
    int save_line = lex.current_line;
    lex.current_file = (yyvsp[(1) - (5)].n)->current_file;
    lex.current_line = (yyvsp[(1) - (5)].n)->line_number;

    (yyvsp[(5) - (5)].n)=mknode(F_COMMA_EXPR,(yyvsp[(5) - (5)].n),mknode(F_RETURN,mkintnode(0),0));

    debug_malloc_touch((yyvsp[(5) - (5)].n));
    dooptcode(i->name,
	      (yyvsp[(5) - (5)].n),
	      i->type,
	      ID_STATIC | ID_PRIVATE | ID_INLINE);

    i->opt_flags = Pike_compiler->compiler_frame->opt_flags;

    lex.current_line = save_line;
    lex.current_file = save_file;
    pop_compiler_frame();
    free_node((yyvsp[(1) - (5)].n));

    /* WARNING: If the local function adds more variables we are screwed */
    /* WARNING2: if add_local_name stops adding local variables at the end,
     *           this has to be fixed.
     */

    localid=Pike_compiler->compiler_frame->current_number_of_locals-1;
    if(Pike_compiler->compiler_frame->variable[localid].def)
    {
      (yyval.n)=copy_node(Pike_compiler->compiler_frame->variable[localid].def);
    }else{
      if(Pike_compiler->compiler_frame->lexical_scope & 
	 (SCOPE_SCOPE_USED | SCOPE_SCOPED))
      {
	(yyval.n) = mktrampolinenode((yyvsp[(4) - (5)].number),Pike_compiler->compiler_frame);
      }else{
	(yyval.n) = mkidentifiernode((yyvsp[(4) - (5)].number));
      }
    }
  }
    break;

  case 295:
#line 2092 "language.yacc"
    {
    pop_compiler_frame();
    (yyval.n)=mkintnode(0);
  }
    break;

  case 296:
#line 2099 "language.yacc"
    {
    char buf[40];
    struct pike_string *name;
    struct pike_type *type;
    int id,e;
    node *n;
    struct identifier *i=0;

    /***/
    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);
    
    push_finished_type((yyvsp[(0) - (4)].n)->u.sval.u.type);
    if ((yyvsp[(1) - (4)].number) && (Pike_compiler->compiler_pass == 2)) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    while((yyvsp[(1) - (4)].number)--) push_type(T_ARRAY);

    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    Pike_compiler->compiler_frame->current_return_type=compiler_pop_type();

    /***/
    push_finished_type(Pike_compiler->compiler_frame->current_return_type);
    
    e=(yyvsp[(4) - (4)].number)-1;
    if(Pike_compiler->varargs)
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    push_type(T_MANY);
    for(; e>=0; e--) {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      push_type(T_FUNCTION);
    }
    
    type=compiler_pop_type();
    /***/


    sprintf(buf,"__lambda_%ld_%ld_line_%d",
	    (long)Pike_compiler->new_program->id,
	    (long)(Pike_compiler->local_class_counter++ & 0xffffffff), /* OSF/1 cc bug. */
	    (int) (yyvsp[(2) - (4)].n)->line_number);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: LAMBDA: %s 0x%08lx 0x%08lx\n",
	    Pike_compiler->compiler_pass, buf, (long)Pike_compiler->new_program->id, Pike_compiler->local_class_counter-1);
#endif /* LAMBDA_DEBUG */

    name=make_shared_string(buf);

    if(Pike_compiler->compiler_pass > 1)
    {
      id=isidentifier(name);
    }else{
      id=define_function(name,
			 type,
			 ID_INLINE,
			 IDENTIFIER_PIKE_FUNCTION|
			 (Pike_compiler->varargs?IDENTIFIER_VARARGS:0),
			 0,
			 OPT_SIDE_EFFECT|OPT_EXTERNAL_DEPEND);
    }
    Pike_compiler->varargs=0;
    Pike_compiler->compiler_frame->current_function_number=id;

    n=0;
    if(Pike_compiler->compiler_pass > 1 &&
       (i=ID_FROM_INT(Pike_compiler->new_program, id)))
    {
      if(i->identifier_flags & IDENTIFIER_SCOPED)
	n = mktrampolinenode(id, Pike_compiler->compiler_frame->previous);
      else
	n = mkidentifiernode(id);
    }

    low_add_local_name(Pike_compiler->compiler_frame->previous,
		       (yyvsp[(2) - (4)].n)->u.sval.u.string, type, n);
    (yyval.number)=id;
    free_string(name);
  }
    break;

  case 297:
#line 2185 "language.yacc"
    {
    int localid;
    struct identifier *i=ID_FROM_INT(Pike_compiler->new_program, (yyvsp[(5) - (6)].number));
    struct pike_string *save_file = lex.current_file;
    int save_line = lex.current_line;
    lex.current_file = (yyvsp[(2) - (6)].n)->current_file;
    lex.current_line = (yyvsp[(2) - (6)].n)->line_number;

    debug_malloc_touch((yyvsp[(6) - (6)].n));
    (yyvsp[(6) - (6)].n)=mknode(F_COMMA_EXPR,(yyvsp[(6) - (6)].n),mknode(F_RETURN,mkintnode(0),0));


    debug_malloc_touch((yyvsp[(6) - (6)].n));
    dooptcode(i->name,
	      (yyvsp[(6) - (6)].n),
	      i->type,
	      ID_STATIC | ID_PRIVATE | ID_INLINE);

    i->opt_flags = Pike_compiler->compiler_frame->opt_flags;

    lex.current_line = save_line;
    lex.current_file = save_file;
    pop_compiler_frame();
    free_node((yyvsp[(2) - (6)].n));

    /* WARNING: If the local function adds more variables we are screwed */
    /* WARNING2: if add_local_name stops adding local variables at the end,
     *           this has to be fixed.
     */

    localid=Pike_compiler->compiler_frame->current_number_of_locals-1;
    if(Pike_compiler->compiler_frame->variable[localid].def)
    {
      (yyval.n)=copy_node(Pike_compiler->compiler_frame->variable[localid].def);
    }else{
      if(Pike_compiler->compiler_frame->lexical_scope & 
	 (SCOPE_SCOPE_USED | SCOPE_SCOPED))
      {
        (yyval.n) = mktrampolinenode((yyvsp[(5) - (6)].number),Pike_compiler->compiler_frame);
      }else{
        (yyval.n) = mkidentifiernode((yyvsp[(5) - (6)].number));
      }
    }
  }
    break;

  case 298:
#line 2230 "language.yacc"
    {
    pop_compiler_frame();
    free_node((yyvsp[(2) - (4)].n));
    (yyval.n)=mkintnode(0);
  }
    break;

  case 299:
#line 2238 "language.yacc"
    {
    struct pike_type *type;

    if (Pike_compiler->varargs) {
      yyerror("Can't define more variables after ...");
    }

    push_finished_type(Pike_compiler->compiler_frame->current_type);
    if ((yyvsp[(3) - (5)].number) && (Pike_compiler->compiler_pass == 2)) {
      yywarning("The *-syntax in types is obsolete. Use array instead.");
    }
    while((yyvsp[(3) - (5)].number)--) push_type(T_ARRAY);
    if ((yyvsp[(4) - (5)].number)) {
      push_type(T_ARRAY);
      Pike_compiler->varargs = 1;
    }
    type=compiler_pop_type();

    if(islocal((yyvsp[(5) - (5)].n)->u.sval.u.string) >= 0)
      my_yyerror("Variable '%s' appears twice in create argument list.",
		 (yyvsp[(5) - (5)].n)->u.sval.u.string->str);

    /* Add the identifier both globally and locally. */
    define_variable((yyvsp[(5) - (5)].n)->u.sval.u.string, type,
		    Pike_compiler->current_modifiers);
    add_local_name((yyvsp[(5) - (5)].n)->u.sval.u.string, type, 0);

    /* free_type(type); */
    free_node((yyvsp[(5) - (5)].n));
    (yyval.number)=0;
  }
    break;

  case 300:
#line 2269 "language.yacc"
    { (yyval.number)=0; }
    break;

  case 301:
#line 2272 "language.yacc"
    { (yyval.number) = 1; }
    break;

  case 302:
#line 2273 "language.yacc"
    { (yyval.number) = (yyvsp[(1) - (3)].number) + 1; }
    break;

  case 303:
#line 2275 "language.yacc"
    {
    yyerror("Unexpected ':' in create argument list.");
    (yyval.number) = (yyvsp[(1) - (3)].number) + 1;
  }
    break;

  case 304:
#line 2281 "language.yacc"
    { (yyval.number)=0; }
    break;

  case 306:
#line 2286 "language.yacc"
    {
    push_compiler_frame(SCOPE_LOCAL);
  }
    break;

  case 307:
#line 2291 "language.yacc"
    { (yyval.number) = 0; }
    break;

  case 308:
#line 2293 "language.yacc"
    {
    int e;
    node *create_code = NULL;
    struct pike_type *type = NULL;
    struct pike_string *create_string = NULL;
    int f;

    MAKE_CONST_STRING(create_string, "create");

    /* First: Deduce the type for the create() function. */
    push_type(T_VOID); /* Return type. */
    e = (yyvsp[(3) - (4)].number)-1;
    if (Pike_compiler->varargs) {
      /* Varargs */
      push_finished_type(Pike_compiler->compiler_frame->variable[e--].type);
      pop_type_stack(T_ARRAY); /* Pop one level of array. */
    } else {
      /* Not varargs. */
      push_type(T_VOID);
    }
    push_type(T_MANY);
    for(; e >= 0; e--) {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      push_type(T_FUNCTION);
    }

    type = compiler_pop_type();

    /* Second: Declare the function. */

    Pike_compiler->compiler_frame->current_function_number=
      define_function(create_string, type,
		      ID_INLINE | ID_STATIC,
		      IDENTIFIER_PIKE_FUNCTION |
		      (Pike_compiler->varargs?IDENTIFIER_VARARGS:0),
		      0,
		      OPT_SIDE_EFFECT);

    Pike_compiler->varargs = 0;

    /* Third: Generate the initialization code.
     *
     * global_arg = [type]local_arg;
     * [,..]
     */

    for(e=0; e<(yyvsp[(3) - (4)].number); e++)
    {
      if(!Pike_compiler->compiler_frame->variable[e].name ||
	 !Pike_compiler->compiler_frame->variable[e].name->len)
      {
	my_yyerror("Missing name for argument %d.",e);
      } else {
	node *local_node = mklocalnode(e, 0);

	/* FIXME: Should probably use some other flag. */
	if ((runtime_options & RUNTIME_CHECK_TYPES) &&
	    (Pike_compiler->compiler_pass == 2) &&
	    (Pike_compiler->compiler_frame->variable[e].type !=
	     mixed_type_string)) {
	  /* fprintf(stderr, "Creating soft cast node for local #%d\n", e);*/

	  /* The following is needed to go around the optimization in
	   * mksoftcastnode().
	   */
	  free_type(local_node->type);
	  copy_pike_type(local_node->type, mixed_type_string);
	  
	  local_node = mksoftcastnode(Pike_compiler->compiler_frame->
				      variable[e].type, local_node);
	}
	create_code =
	  mknode(F_COMMA_EXPR, create_code,
		 mknode(F_ASSIGN, local_node,
			mkidentifiernode(isidentifier(Pike_compiler->
						      compiler_frame->
						      variable[e].name))));
      }
    }

    /* Fourth: Add a return 0; at the end. */

    create_code = mknode(F_COMMA_EXPR,
			 mknode(F_POP_VALUE, create_code, NULL),
			 mknode(F_RETURN, mkintnode(0), NULL));

    /* Fifth: Define the function. */

    f=dooptcode(create_string, check_node_hash(create_code),
		type, ID_STATIC);

#ifdef PIKE_DEBUG
    if(Pike_interpreter.recoveries &&
       Pike_sp-Pike_interpreter.evaluator_stack < Pike_interpreter.recoveries->stack_pointer)
      Pike_fatal("Stack error (underflow)\n");

    if(Pike_compiler->compiler_pass == 1 &&
       f!=Pike_compiler->compiler_frame->current_function_number)
      Pike_fatal("define_function screwed up! %d != %d\n",
	    f, Pike_compiler->compiler_frame->current_function_number);
#endif

    /* Done. */

    pop_compiler_frame();
    free_node((yyvsp[(4) - (4)].n));
    free_type(type);
  }
    break;

  case 310:
#line 2404 "language.yacc"
    { yyerrok; }
    break;

  case 311:
#line 2406 "language.yacc"
    {
		  yyerror("End of file where program definition expected.");
		}
    break;

  case 312:
#line 2412 "language.yacc"
    {
    if(!(yyvsp[(4) - (4)].n))
    {
      struct pike_string *s;
      char buffer[42];
      sprintf(buffer,"__class_%ld_%ld_line_%d",
	      (long)Pike_compiler->new_program->id,
	      (long)Pike_compiler->local_class_counter++,
	      (int) (yyvsp[(3) - (4)].n)->line_number);
      s=make_shared_string(buffer);
      (yyvsp[(4) - (4)].n)=mkstrnode(s);
      free_string(s);
      (yyvsp[(1) - (4)].number)|=ID_STATIC | ID_PRIVATE | ID_INLINE;
    }
    /* fprintf(stderr, "LANGUAGE.YACC: CLASS start\n"); */
    if(Pike_compiler->compiler_pass==1)
    {
      if ((yyvsp[(1) - (4)].number) & ID_EXTERN) {
	yywarning("Extern declared class definition.");
      }
      low_start_new_program(0, 1, (yyvsp[(4) - (4)].n)->u.sval.u.string,
			    (yyvsp[(1) - (4)].number),
			    &(yyval.number));

      /* fprintf(stderr, "Pass 1: Program %s has id %d\n",
	 $4->u.sval.u.string->str, Pike_compiler->new_program->id); */

      store_linenumber((yyvsp[(3) - (4)].n)->line_number, (yyvsp[(3) - (4)].n)->current_file);
      debug_malloc_name(Pike_compiler->new_program,
			(yyvsp[(3) - (4)].n)->current_file->str,
			(yyvsp[(3) - (4)].n)->line_number);
    }else{
      int i;
      struct identifier *id;
      int tmp=Pike_compiler->compiler_pass;
      i=isidentifier((yyvsp[(4) - (4)].n)->u.sval.u.string);
      if(i<0)
      {
	/* Seriously broken... */
	yyerror("Pass 2: program not defined!");
	low_start_new_program(0, 2, 0,
			      (yyvsp[(1) - (4)].number),
			      &(yyval.number));
      }else{
	id=ID_FROM_INT(Pike_compiler->new_program, i);
	if(IDENTIFIER_IS_CONSTANT(id->identifier_flags))
	{
	  struct svalue *s;
	  if ((id->func.offset >= 0) &&
	      ((s = &PROG_FROM_INT(Pike_compiler->new_program,i)->
		constants[id->func.offset].sval)->type == T_PROGRAM))
	  {
	    low_start_new_program(s->u.program, 2,
				  (yyvsp[(4) - (4)].n)->u.sval.u.string,
				  (yyvsp[(1) - (4)].number),
				  &(yyval.number));

	    /* fprintf(stderr, "Pass 2: Program %s has id %d\n",
	       $4->u.sval.u.string->str, Pike_compiler->new_program->id); */

	  }else{
	    yyerror("Pass 2: constant redefined!");
	    low_start_new_program(0, 2, 0,
				  (yyvsp[(1) - (4)].number),
				  &(yyval.number));
	  }
	}else{
	  yyerror("Pass 2: class constant no longer constant!");
	  low_start_new_program(0, 2, 0,
				(yyvsp[(1) - (4)].number),
				&(yyval.number));
	}
      }
      Pike_compiler->compiler_pass=tmp;
    }
  }
    break;

  case 313:
#line 2489 "language.yacc"
    {
    struct program *p;
    if(Pike_compiler->compiler_pass == 1)
      p=end_first_pass(0);
    else
      p=end_first_pass(1);

    /* fprintf(stderr, "LANGUAGE.YACC: CLASS end\n"); */

    if(p) {
      free_program(p);
    } else if (!Pike_compiler->num_parse_error) {
      /* Make sure code in this class is aware that something went wrong. */
      Pike_compiler->num_parse_error = 1;
    }

    (yyval.n)=mkidentifiernode((yyvsp[(5) - (7)].number));

    free_node ((yyvsp[(3) - (7)].n));
    free_node((yyvsp[(4) - (7)].n));
    check_tree((yyval.n),0);
  }
    break;

  case 315:
#line 2514 "language.yacc"
    { (yyval.n) = 0; }
    break;

  case 316:
#line 2518 "language.yacc"
    {
    safe_inc_enum();
  }
    break;

  case 317:
#line 2522 "language.yacc"
    {
    pop_stack();

    /* This can be made more lenient in the future */

    /* Ugly hack to make sure that $2 is optimized */
    {
      int tmp=Pike_compiler->compiler_pass;
      (yyvsp[(2) - (2)].n)=mknode(F_COMMA_EXPR,(yyvsp[(2) - (2)].n),0);
      Pike_compiler->compiler_pass=tmp;
    }

    if(!is_const((yyvsp[(2) - (2)].n)))
    {
      if(Pike_compiler->compiler_pass==2)
	yyerror("Enum definition is not constant.");
      push_int(0);
    } else {
      if(!Pike_compiler->num_parse_error)
      {
	ptrdiff_t tmp=eval_low((yyvsp[(2) - (2)].n),1);
	if(tmp < 1)
	{
	  yyerror("Error in enum definition.");
	  push_int(0);
	}else{
	  pop_n_elems(DO_NOT_WARN((INT32)(tmp - 1)));
	}
      } else {
	push_int(0);
      }
    }
    if((yyvsp[(2) - (2)].n)) free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 319:
#line 2560 "language.yacc"
    {
    if ((yyvsp[(1) - (2)].n)) {
      add_constant((yyvsp[(1) - (2)].n)->u.sval.u.string, Pike_sp-1,
		   (Pike_compiler->current_modifiers & ~ID_EXTERN) | ID_INLINE);
    }
    free_node((yyvsp[(1) - (2)].n));
    /* Update the type. */
    {
      struct pike_type *current = pop_unfinished_type();
      struct pike_type *new = get_type_of_svalue(Pike_sp-1);
      struct pike_type *res = or_pike_types(new, current, 1);
      free_type(current);
      free_type(new);
      type_stack_mark();
      push_finished_type(res);
      free_type(res);
    }
  }
    break;

  case 322:
#line 2585 "language.yacc"
    {
    if ((Pike_compiler->current_modifiers & ID_EXTERN) &&
	(Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared enum.");
    }

    push_int(-1);	/* Last enum-value. */
    type_stack_mark();
    push_type(T_ZERO);	/* Joined type so far. */
  }
    break;

  case 323:
#line 2596 "language.yacc"
    {
    struct pike_type *t = pop_unfinished_type();
    pop_stack();
    if ((yyvsp[(4) - (7)].n)) {
      ref_push_type_value(t);
      add_constant((yyvsp[(4) - (7)].n)->u.sval.u.string, Pike_sp-1,
		   (Pike_compiler->current_modifiers & ~ID_EXTERN) | ID_INLINE);
      pop_stack();
      free_node((yyvsp[(4) - (7)].n));
    }
    (yyval.n) = mktypenode(t);
    free_type(t);
  }
    break;

  case 324:
#line 2612 "language.yacc"
    {
    struct pike_type *t = compiler_pop_type();

    if ((Pike_compiler->current_modifiers & ID_EXTERN) &&
	(Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared typedef.");
    }

    if ((yyvsp[(4) - (5)].n)) {
      ref_push_type_value(t);
      add_constant((yyvsp[(4) - (5)].n)->u.sval.u.string, Pike_sp-1,
		   (Pike_compiler->current_modifiers & ~ID_EXTERN) | ID_INLINE);
      pop_stack();
      free_node((yyvsp[(4) - (5)].n));
    }
    free_type(t);
  }
    break;

  case 325:
#line 2632 "language.yacc"
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
    break;

  case 326:
#line 2636 "language.yacc"
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(2) - (3)].number);
  }
    break;

  case 327:
#line 2642 "language.yacc"
    {
    (yyval.n) = mknode('?', (yyvsp[(6) - (9)].n),
		mknode(':',
		       mkcastnode(void_type_string, (yyvsp[(8) - (9)].n)),
		       mkcastnode(void_type_string, (yyvsp[(9) - (9)].n))));
    (yyval.n) = mkcastnode(void_type_string, (yyval.n));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(3) - (9)].n));
    free_node ((yyvsp[(3) - (9)].n));
    pop_local_variables((yyvsp[(2) - (9)].number));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(4) - (9)].number);
  }
    break;

  case 329:
#line 2656 "language.yacc"
    { yyerror("Missing ')'."); }
    break;

  case 330:
#line 2658 "language.yacc"
    {
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 331:
#line 2664 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 332:
#line 2665 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (2)].n); }
    break;

  case 334:
#line 2669 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 336:
#line 2673 "language.yacc"
    { yyerror("Unexpected end of file."); (yyval.n)=0; }
    break;

  case 337:
#line 2674 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 338:
#line 2678 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 340:
#line 2682 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (2)].n); }
    break;

  case 341:
#line 2684 "language.yacc"
    { (yyval.n)=mknode(':',(yyvsp[(2) - (4)].n),(yyvsp[(4) - (4)].n)); }
    break;

  case 342:
#line 2688 "language.yacc"
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
    break;

  case 343:
#line 2692 "language.yacc"
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(2) - (3)].number);
  }
    break;

  case 344:
#line 2698 "language.yacc"
    {
    if ((yyvsp[(7) - (9)].n)) {
      (yyval.n)=mknode(F_FOREACH,
		mknode(F_VAL_LVAL,(yyvsp[(6) - (9)].n),(yyvsp[(7) - (9)].n)),
		(yyvsp[(9) - (9)].n));
    } else {
      /* Error in lvalue */
      free_node((yyvsp[(6) - (9)].n));
      (yyval.n)=(yyvsp[(9) - (9)].n);
    }
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(3) - (9)].n));
    free_node ((yyvsp[(3) - (9)].n));
    pop_local_variables((yyvsp[(2) - (9)].number));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(4) - (9)].number);
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
    break;

  case 345:
#line 2718 "language.yacc"
    {
    (yyval.n)=mknode(F_DO,(yyvsp[(3) - (8)].n),(yyvsp[(6) - (8)].n));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(2) - (8)].n));
    free_node ((yyvsp[(2) - (8)].n));
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
    break;

  case 346:
#line 2725 "language.yacc"
    {
    free_node ((yyvsp[(2) - (5)].n));
    (yyval.n)=0;
    yyerror("Missing '(' in do-while loop.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 347:
#line 2732 "language.yacc"
    {
    free_node ((yyvsp[(2) - (4)].n));
    (yyval.n)=0;
    yyerror("Missing 'while' in do-while loop.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 349:
#line 2742 "language.yacc"
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 350:
#line 2749 "language.yacc"
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
    break;

  case 351:
#line 2753 "language.yacc"
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(2) - (3)].number);
  }
    break;

  case 352:
#line 2760 "language.yacc"
    {
    (yyval.n)=mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[(6) - (12)].n)),
	      mknode(F_FOR,(yyvsp[(8) - (12)].n),mknode(':',(yyvsp[(12) - (12)].n),(yyvsp[(10) - (12)].n))));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(3) - (12)].n));
    free_node ((yyvsp[(3) - (12)].n));
    pop_local_variables((yyvsp[(2) - (12)].number));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(4) - (12)].number);
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
    break;

  case 353:
#line 2773 "language.yacc"
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
    break;

  case 354:
#line 2777 "language.yacc"
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(2) - (3)].number);
  }
    break;

  case 355:
#line 2783 "language.yacc"
    {
    (yyval.n)=mknode(F_FOR,(yyvsp[(6) - (8)].n),mknode(':',(yyvsp[(8) - (8)].n),NULL));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(3) - (8)].n));
    free_node ((yyvsp[(3) - (8)].n));
    pop_local_variables((yyvsp[(2) - (8)].number));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(4) - (8)].number);
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
    break;

  case 356:
#line 2793 "language.yacc"
    { (yyval.n)=mkintnode(1); }
    break;

  case 358:
#line 2798 "language.yacc"
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
    break;

  case 359:
#line 2802 "language.yacc"
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(2) - (3)].number);
  }
    break;

  case 360:
#line 2808 "language.yacc"
    {
    (yyval.n)=mknode(F_SWITCH,(yyvsp[(6) - (8)].n),(yyvsp[(8) - (8)].n));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(3) - (8)].n));
    free_node ((yyvsp[(3) - (8)].n));
    pop_local_variables((yyvsp[(2) - (8)].number));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[(4) - (8)].number);
  }
    break;

  case 361:
#line 2818 "language.yacc"
    {
    (yyval.n)=mknode(F_CASE,(yyvsp[(2) - (3)].n),0);
  }
    break;

  case 362:
#line 2822 "language.yacc"
    {
     (yyval.n)=mknode(F_CASE_RANGE,(yyvsp[(2) - (5)].n),(yyvsp[(4) - (5)].n));
  }
    break;

  case 363:
#line 2826 "language.yacc"
    {
     (yyval.n)=mknode(F_CASE_RANGE,0,(yyvsp[(3) - (4)].n));
  }
    break;

  case 365:
#line 2833 "language.yacc"
    {
    yyerror("Missing ':'.");
  }
    break;

  case 366:
#line 2837 "language.yacc"
    {
    yyerror("Missing ':'.");
  }
    break;

  case 367:
#line 2841 "language.yacc"
    {
    yyerror("Missing ':'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 368:
#line 2848 "language.yacc"
    {
    if(!TEST_COMPAT(0,6) &&
       !match_types(Pike_compiler->compiler_frame->current_return_type,
		    void_type_string))
    {
      yytype_error("Must return a value for a non-void function.",
		   Pike_compiler->compiler_frame->current_return_type,
		   void_type_string, 0);
    }
    (yyval.n)=mknode(F_RETURN,mkintnode(0),0);
  }
    break;

  case 369:
#line 2860 "language.yacc"
    {
    (yyval.n)=mknode(F_RETURN,(yyvsp[(2) - (3)].n),0);
  }
    break;

  case 370:
#line 2865 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 371:
#line 2866 "language.yacc"
    { (yyval.n)=mkcastnode(void_type_string, (yyvsp[(1) - (1)].n));  }
    break;

  case 372:
#line 2869 "language.yacc"
    { (yyval.n)=mkcastnode(void_type_string, (yyvsp[(1) - (1)].n));  }
    break;

  case 373:
#line 2871 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 376:
#line 2876 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 378:
#line 2880 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (2)].n); free_node((yyvsp[(1) - (2)].n)); }
    break;

  case 379:
#line 2881 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (2)].n); free_node((yyvsp[(1) - (2)].n)); }
    break;

  case 380:
#line 2882 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (2)].n); free_node((yyvsp[(1) - (2)].n)); }
    break;

  case 381:
#line 2883 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (2)].n); free_node((yyvsp[(1) - (2)].n)); }
    break;

  case 383:
#line 2889 "language.yacc"
    {
    (yyval.n) = mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[(1) - (3)].n)), (yyvsp[(3) - (3)].n)); 
  }
    break;

  case 385:
#line 2895 "language.yacc"
    { (yyval.n)=mknode(F_PUSH_ARRAY,(yyvsp[(2) - (2)].n),0); }
    break;

  case 387:
#line 2898 "language.yacc"
    { (yyval.n)=mknode(F_ASSIGN,(yyvsp[(3) - (3)].n),(yyvsp[(1) - (3)].n)); }
    break;

  case 388:
#line 2899 "language.yacc"
    { (yyval.n)=(yyvsp[(1) - (3)].n); reset_type_stack(); yyerrok; }
    break;

  case 389:
#line 2900 "language.yacc"
    { (yyval.n)=(yyvsp[(3) - (3)].n); }
    break;

  case 390:
#line 2902 "language.yacc"
    {
    (yyval.n)=mknode(F_ASSIGN,(yyvsp[(5) - (5)].n),mknode(F_ARRAY_LVALUE,(yyvsp[(2) - (5)].n),0));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (5)].n));
    free_node ((yyvsp[(1) - (5)].n));
  }
    break;

  case 391:
#line 2907 "language.yacc"
    { (yyval.n)=mknode((yyvsp[(2) - (3)].number),(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 392:
#line 2908 "language.yacc"
    { (yyval.n)=(yyvsp[(1) - (3)].n); reset_type_stack(); yyerrok; }
    break;

  case 393:
#line 2909 "language.yacc"
    { (yyval.n)=(yyvsp[(3) - (3)].n); }
    break;

  case 394:
#line 2911 "language.yacc"
    {
    (yyval.n)=mknode((yyvsp[(4) - (5)].number),mknode(F_ARRAY_LVALUE,(yyvsp[(2) - (5)].n),0),(yyvsp[(5) - (5)].n));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (5)].n));
    free_node ((yyvsp[(1) - (5)].n));
  }
    break;

  case 395:
#line 2917 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (4)].n); free_node ((yyvsp[(1) - (4)].n)); reset_type_stack(); yyerrok; }
    break;

  case 397:
#line 2922 "language.yacc"
    { (yyval.n)=mknode('?',(yyvsp[(1) - (5)].n),mknode(':',(yyvsp[(3) - (5)].n),(yyvsp[(5) - (5)].n))); }
    break;

  case 398:
#line 2925 "language.yacc"
    { (yyval.number)=F_AND_EQ; }
    break;

  case 399:
#line 2926 "language.yacc"
    { (yyval.number)=F_OR_EQ; }
    break;

  case 400:
#line 2927 "language.yacc"
    { (yyval.number)=F_XOR_EQ; }
    break;

  case 401:
#line 2928 "language.yacc"
    { (yyval.number)=F_LSH_EQ; }
    break;

  case 402:
#line 2929 "language.yacc"
    { (yyval.number)=F_RSH_EQ; }
    break;

  case 403:
#line 2930 "language.yacc"
    { (yyval.number)=F_ADD_EQ; }
    break;

  case 404:
#line 2931 "language.yacc"
    { (yyval.number)=F_SUB_EQ; }
    break;

  case 405:
#line 2932 "language.yacc"
    { (yyval.number)=F_MULT_EQ; }
    break;

  case 406:
#line 2933 "language.yacc"
    { (yyval.number)=F_MOD_EQ; }
    break;

  case 407:
#line 2934 "language.yacc"
    { (yyval.number)=F_DIV_EQ; }
    break;

  case 408:
#line 2937 "language.yacc"
    { (yyval.number)=0; }
    break;

  case 409:
#line 2937 "language.yacc"
    { (yyval.number)=1; }
    break;

  case 410:
#line 2939 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 413:
#line 2945 "language.yacc"
    { (yyval.n)=mknode(F_ARG_LIST,(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 414:
#line 2948 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 417:
#line 2954 "language.yacc"
    {
    if ((yyvsp[(3) - (3)].n)) {
      (yyval.n)=mknode(F_ARG_LIST,(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n));
    } else {
      /* Error in assoc_pair */
      (yyval.n)=(yyvsp[(1) - (3)].n);
    }
  }
    break;

  case 419:
#line 2966 "language.yacc"
    {
    (yyval.n)=mknode(F_ARG_LIST,(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n));
  }
    break;

  case 420:
#line 2969 "language.yacc"
    { free_node((yyvsp[(1) - (3)].n)); (yyval.n)=0; }
    break;

  case 422:
#line 2973 "language.yacc"
    { (yyval.n)=mknode(F_LOR,(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 423:
#line 2974 "language.yacc"
    { (yyval.n)=mknode(F_LAND,(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 424:
#line 2975 "language.yacc"
    { (yyval.n)=mkopernode("`|",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 425:
#line 2976 "language.yacc"
    { (yyval.n)=mkopernode("`^",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 426:
#line 2977 "language.yacc"
    { (yyval.n)=mkopernode("`&",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 427:
#line 2978 "language.yacc"
    { (yyval.n)=mkopernode("`==",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 428:
#line 2979 "language.yacc"
    { (yyval.n)=mkopernode("`!=",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 429:
#line 2980 "language.yacc"
    { (yyval.n)=mkopernode("`>",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 430:
#line 2981 "language.yacc"
    { (yyval.n)=mkopernode("`>=",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 431:
#line 2982 "language.yacc"
    { (yyval.n)=mkopernode("`<",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 432:
#line 2983 "language.yacc"
    { (yyval.n)=mkopernode("`<=",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 433:
#line 2984 "language.yacc"
    { (yyval.n)=mkopernode("`<<",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 434:
#line 2985 "language.yacc"
    { (yyval.n)=mkopernode("`>>",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 435:
#line 2986 "language.yacc"
    { (yyval.n)=mkopernode("`+",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 436:
#line 2987 "language.yacc"
    { (yyval.n)=mkopernode("`-",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 437:
#line 2988 "language.yacc"
    { (yyval.n)=mkopernode("`*",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 438:
#line 2989 "language.yacc"
    { (yyval.n)=mkopernode("`%",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 439:
#line 2990 "language.yacc"
    { (yyval.n)=mkopernode("`/",(yyvsp[(1) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 459:
#line 3013 "language.yacc"
    {
    (yyval.n) = mkcastnode((yyvsp[(1) - (2)].n)->u.sval.u.type, (yyvsp[(2) - (2)].n));
    free_node((yyvsp[(1) - (2)].n));
  }
    break;

  case 460:
#line 3018 "language.yacc"
    {
    (yyval.n) = mksoftcastnode((yyvsp[(1) - (2)].n)->u.sval.u.type, (yyvsp[(2) - (2)].n));
    free_node((yyvsp[(1) - (2)].n));
  }
    break;

  case 461:
#line 3022 "language.yacc"
    { (yyval.n)=mknode(F_INC,(yyvsp[(2) - (2)].n),0); }
    break;

  case 462:
#line 3023 "language.yacc"
    { (yyval.n)=mknode(F_DEC,(yyvsp[(2) - (2)].n),0); }
    break;

  case 463:
#line 3024 "language.yacc"
    { (yyval.n)=mkopernode("`!",(yyvsp[(2) - (2)].n),0); }
    break;

  case 464:
#line 3025 "language.yacc"
    { (yyval.n)=mkopernode("`~",(yyvsp[(2) - (2)].n),0); }
    break;

  case 465:
#line 3026 "language.yacc"
    { (yyval.n)=mkopernode("`-",(yyvsp[(2) - (2)].n),0); }
    break;

  case 467:
#line 3030 "language.yacc"
    { (yyval.n)=mknode(F_POST_INC,(yyvsp[(1) - (2)].n),0); }
    break;

  case 468:
#line 3031 "language.yacc"
    { (yyval.n)=mknode(F_POST_DEC,(yyvsp[(1) - (2)].n),0); }
    break;

  case 469:
#line 3053 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 470:
#line 3055 "language.yacc"
    {
    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);
    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    copy_pike_type(Pike_compiler->compiler_frame->current_return_type,
		   any_type_string);

    /* block code */
    (yyvsp[(1) - (3)].number)=Pike_compiler->num_used_modules;
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
    break;

  case 471:
#line 3067 "language.yacc"
    {
    struct pike_type *type;
    char buf[40];
    int f/*, e */;
    struct pike_string *name;
    struct pike_string *save_file = lex.current_file;
    int save_line = lex.current_line;
    lex.current_file = (yyvsp[(2) - (7)].n)->current_file;
    lex.current_line = (yyvsp[(2) - (7)].n)->line_number;

    /* block code */
    unuse_modules(Pike_compiler->num_used_modules - (yyvsp[(1) - (7)].number));
    pop_local_variables((yyvsp[(4) - (7)].number));

    debug_malloc_touch((yyvsp[(5) - (7)].n));
    (yyvsp[(5) - (7)].n)=mknode(F_COMMA_EXPR,(yyvsp[(5) - (7)].n),mknode(F_RETURN,mkintnode(0),0));
    if (Pike_compiler->compiler_pass == 2)
      /* Doing this in pass 1 might induce too strict checks on types
       * in cases where we got placeholders. */
      type=find_return_type((yyvsp[(5) - (7)].n));
    else
      type = NULL;

    if(type) {
      push_finished_type(type);
      free_type(type);
    } else
      push_type(T_MIXED);
    
    push_type(T_VOID);
    push_type(T_MANY);
/*
    e=$5-1;
    for(; e>=0; e--)
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
*/
    
    type=compiler_pop_type();

    sprintf(buf,"__lambda_%ld_%ld_line_%d",
	    (long)Pike_compiler->new_program->id,
	    (long)(Pike_compiler->local_class_counter++ & 0xffffffff), /* OSF/1 cc bug. */
	    (int) lex.current_line);
    name=make_shared_string(buf);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: IMPLICIT LAMBDA: %s 0x%08lx 0x%08lx\n",
	    Pike_compiler->compiler_pass, buf, (long)Pike_compiler->new_program->id, Pike_compiler->local_class_counter-1);
#endif /* LAMBDA_DEBUG */
    
    f=dooptcode(name,
		(yyvsp[(5) - (7)].n),
		type,
		ID_STATIC | ID_PRIVATE | ID_INLINE);

    if(Pike_compiler->compiler_frame->lexical_scope & SCOPE_SCOPED) {
      (yyval.n) = mktrampolinenode(f,Pike_compiler->compiler_frame->previous);
    } else {
      (yyval.n) = mkidentifiernode(f);
    }

    lex.current_line = save_line;
    lex.current_file = save_file;
    free_node ((yyvsp[(2) - (7)].n));
    free_string(name);
    free_type(type);
    pop_compiler_frame();
  }
    break;

  case 474:
#line 3139 "language.yacc"
    { (yyval.n)=mkfloatnode((FLOAT_TYPE)(yyvsp[(1) - (1)].fnum)); }
    break;

  case 483:
#line 3149 "language.yacc"
    {
      (yyval.n)=mkapplynode((yyvsp[(1) - (4)].n),(yyvsp[(3) - (4)].n));
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(2) - (4)].n));
      free_node ((yyvsp[(2) - (4)].n));
    }
    break;

  case 484:
#line 3155 "language.yacc"
    {
    (yyval.n)=mkapplynode((yyvsp[(1) - (4)].n), NULL);
    free_node ((yyvsp[(2) - (4)].n));
    yyerrok;
  }
    break;

  case 485:
#line 3161 "language.yacc"
    {
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
    (yyval.n)=mkapplynode((yyvsp[(1) - (4)].n), NULL);
    free_node ((yyvsp[(2) - (4)].n));
  }
    break;

  case 486:
#line 3168 "language.yacc"
    {
    yyerror("Missing ')'.");
    (yyval.n)=mkapplynode((yyvsp[(1) - (4)].n), NULL);
    free_node ((yyvsp[(2) - (4)].n));
  }
    break;

  case 487:
#line 3174 "language.yacc"
    {
    yyerror("Missing ')'.");
    (yyval.n)=mkapplynode((yyvsp[(1) - (4)].n), NULL);
    free_node ((yyvsp[(2) - (4)].n));
  }
    break;

  case 488:
#line 3180 "language.yacc"
    {
    (yyval.n)=mknode(F_AUTO_MAP_MARKER, (yyvsp[(1) - (4)].n), 0);
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(2) - (4)].n));
    free_node ((yyvsp[(2) - (4)].n));
  }
    break;

  case 489:
#line 3186 "language.yacc"
    {
    (yyval.n)=mknode(F_INDEX,(yyvsp[(1) - (4)].n),(yyvsp[(3) - (4)].n));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(2) - (4)].n));
    free_node ((yyvsp[(2) - (4)].n));
  }
    break;

  case 490:
#line 3193 "language.yacc"
    {
    (yyval.n)=mknode(F_RANGE,(yyvsp[(1) - (6)].n),mknode(F_ARG_LIST,(yyvsp[(3) - (6)].n),(yyvsp[(5) - (6)].n)));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(2) - (6)].n));
    free_node ((yyvsp[(2) - (6)].n));
  }
    break;

  case 491:
#line 3199 "language.yacc"
    {
    (yyval.n)=(yyvsp[(1) - (4)].n);
    free_node ((yyvsp[(2) - (4)].n));
    yyerrok;
  }
    break;

  case 492:
#line 3205 "language.yacc"
    {
    (yyval.n)=(yyvsp[(1) - (4)].n); yyerror("Missing ']'.");
    yyerror("Unexpected end of file.");
    free_node ((yyvsp[(2) - (4)].n));
  }
    break;

  case 493:
#line 3211 "language.yacc"
    {(yyval.n)=(yyvsp[(1) - (4)].n); yyerror("Missing ']'."); free_node ((yyvsp[(2) - (4)].n));}
    break;

  case 494:
#line 3213 "language.yacc"
    {(yyval.n)=(yyvsp[(1) - (4)].n); yyerror("Missing ']'."); free_node ((yyvsp[(2) - (4)].n));}
    break;

  case 495:
#line 3215 "language.yacc"
    {(yyval.n)=(yyvsp[(1) - (4)].n); yyerror("Missing ']'."); free_node ((yyvsp[(2) - (4)].n));}
    break;

  case 496:
#line 3217 "language.yacc"
    {
    (yyval.n)=(yyvsp[(2) - (3)].n);
    if ((yyval.n))
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (3)].n));
    free_node ((yyvsp[(1) - (3)].n));
  }
    break;

  case 497:
#line 3224 "language.yacc"
    {
      (yyval.n)=mkefuncallnode("aggregate",(yyvsp[(3) - (5)].n));
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (5)].n));
      free_node ((yyvsp[(1) - (5)].n));
    }
    break;

  case 498:
#line 3232 "language.yacc"
    {
      (yyval.n)=mkefuncallnode("aggregate_mapping",(yyvsp[(3) - (5)].n));
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (5)].n));
      free_node ((yyvsp[(1) - (5)].n));
      free_node ((yyvsp[(2) - (5)].n));
    }
    break;

  case 499:
#line 3239 "language.yacc"
    {
      (yyval.n)=mkefuncallnode("aggregate_multiset",(yyvsp[(3) - (4)].n));
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(2) - (4)].n));
      free_node ((yyvsp[(2) - (4)].n));
    }
    break;

  case 500:
#line 3245 "language.yacc"
    {
      yyerror("Missing '>'.");
      (yyval.n)=mkefuncallnode("aggregate_multiset",(yyvsp[(3) - (4)].n));
      COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(2) - (4)].n));
      free_node ((yyvsp[(2) - (4)].n));
    }
    break;

  case 501:
#line 3251 "language.yacc"
    { (yyval.n)=(yyvsp[(1) - (3)].n); yyerrok; }
    break;

  case 502:
#line 3253 "language.yacc"
    {
    (yyval.n)=(yyvsp[(1) - (3)].n); yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 503:
#line 3257 "language.yacc"
    { (yyval.n)=(yyvsp[(1) - (3)].n); yyerror("Missing ')'."); }
    break;

  case 504:
#line 3258 "language.yacc"
    { (yyval.n)=(yyvsp[(1) - (3)].n); yyerror("Missing ')'."); }
    break;

  case 505:
#line 3259 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (4)].n); yyerrok; }
    break;

  case 506:
#line 3260 "language.yacc"
    {
    yyerror("Missing '>'.");
    (yyval.n)=(yyvsp[(2) - (4)].n); yyerrok;
  }
    break;

  case 507:
#line 3265 "language.yacc"
    {
    (yyval.n)=(yyvsp[(2) - (4)].n); yyerror("Missing '>)'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 508:
#line 3269 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (4)].n); yyerror("Missing '>)'."); }
    break;

  case 509:
#line 3270 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (4)].n); yyerror("Missing '>)'."); }
    break;

  case 510:
#line 3272 "language.yacc"
    {
    (yyval.n)=mknode(F_ARROW,(yyvsp[(1) - (4)].n),(yyvsp[(4) - (4)].n));
    COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(3) - (4)].n));
    free_node ((yyvsp[(3) - (4)].n));
  }
    break;

  case 511:
#line 3277 "language.yacc"
    {(yyval.n)=(yyvsp[(1) - (4)].n); free_node ((yyvsp[(3) - (4)].n));}
    break;

  case 513:
#line 3282 "language.yacc"
    {
    int i;

    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(3) - (3)].n)->u.sval.u.string);

    if (((i = find_shared_string_identifier(Pike_compiler->last_identifier,
					    Pike_compiler->new_program)) >= 0) ||
	((i = really_low_find_shared_string_identifier(Pike_compiler->last_identifier,
						       Pike_compiler->new_program,
						       SEE_STATIC|
						       SEE_PRIVATE)) >= 0)) {
      struct reference *ref = Pike_compiler->new_program->identifier_references + i;
      if (!TEST_COMPAT (7, 2) &&
	  IDENTIFIER_IS_VARIABLE (
	    ID_FROM_PTR (Pike_compiler->new_program, ref)->identifier_flags)) {
	/* Allowing local:: on variables would lead to pathological
	 * behavior: If a non-local variable in a class is referenced
	 * both with and without local::, both references would
	 * address the same variable in all cases except where an
	 * inheriting program overrides it (c.f. [bug 1252]).
	 *
	 * Furthermore, that's not how it works currently; if this
	 * error is removed then local:: will do nothing on variables
	 * except forcing a lookup in the closest surrounding class
	 * scope. */
	yyerror ("Cannot make local references to variables.");
	(yyval.n) = 0;
      }
      else {
	if (!(ref->id_flags & ID_HIDDEN)) {
	  /* We need to generate a new reference. */
	  int d;
	  struct reference funp = *ref;
	  funp.id_flags = (funp.id_flags & ~ID_INHERITED) | ID_INLINE|ID_HIDDEN;
	  i = -1;
	  for(d = 0; d < (int)Pike_compiler->new_program->num_identifier_references; d++) {
	    struct reference *refp;
	    refp = Pike_compiler->new_program->identifier_references + d;

	    if(!MEMCMP((char *)refp,(char *)&funp,sizeof funp)) {
	      i = d;
	      break;
	    }
	  }
	  if (i < 0) {
	    add_to_identifier_references(funp);
	    i = Pike_compiler->new_program->num_identifier_references - 1;
	  }
	}
	(yyval.n) = mkidentifiernode(i);
      }
    } else {
      if (Pike_compiler->compiler_pass == 2) {
	my_yyerror("'%s' not defined in local scope.",
		   Pike_compiler->last_identifier->str);
	(yyval.n) = 0;
      } else {
	(yyval.n) = mknode(F_UNDEFINED, 0, 0);
      }
    }

    free_node((yyvsp[(3) - (3)].n));
  }
    break;

  case 514:
#line 3347 "language.yacc"
    {
    (yyval.n)=0;
  }
    break;

  case 516:
#line 3354 "language.yacc"
    {
    (yyval.n)=index_node((yyvsp[(1) - (3)].n), Pike_compiler->last_identifier?Pike_compiler->last_identifier->str:NULL,
		  (yyvsp[(3) - (3)].n)->u.sval.u.string);
    free_node((yyvsp[(1) - (3)].n));
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(3) - (3)].n)->u.sval.u.string);
    free_node((yyvsp[(3) - (3)].n));
  }
    break;

  case 517:
#line 3363 "language.yacc"
    {
    struct pike_string *dot;
    MAKE_CONST_STRING(dot, ".");
    if (call_handle_import(dot)) {
      node *tmp=mkconstantsvaluenode(Pike_sp-1);
      pop_stack();
      (yyval.n)=index_node(tmp, ".", (yyvsp[(2) - (2)].n)->u.sval.u.string);
      free_node(tmp);
    }
    else
      (yyval.n)=mknewintnode(0);
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(2) - (2)].n)->u.sval.u.string);
    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 518:
#line 3379 "language.yacc"
    {
    (yyval.n) = resolve_identifier ((yyvsp[(3) - (3)].n)->u.sval.u.string);
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(3) - (3)].n)->u.sval.u.string);
    free_node ((yyvsp[(3) - (3)].n));
  }
    break;

  case 519:
#line 3385 "language.yacc"
    {}
    break;

  case 520:
#line 3386 "language.yacc"
    {}
    break;

  case 521:
#line 3390 "language.yacc"
    {
    int e = -1;

    inherit_state = Pike_compiler;

    for (inherit_depth = 0;; inherit_depth++, inherit_state = inherit_state->previous) {
      int inh = find_inherit(inherit_state->new_program, (yyvsp[(1) - (2)].n)->u.sval.u.string);
      if (inh) {
	e = inh;
	break;
      }
      if (inherit_depth == compilation_depth) break;
      if (!TEST_COMPAT (7, 2) &&
	  ID_FROM_INT (inherit_state->previous->new_program,
		       inherit_state->previous->parent_identifier)->name ==
	  (yyvsp[(1) - (2)].n)->u.sval.u.string) {
	e = 0;
	break;
      }
    }
    if (e == -1) {
      if (TEST_COMPAT (7, 2))
	my_yyerror("No such inherit %s.", (yyvsp[(1) - (2)].n)->u.sval.u.string->str);
      else {
	if ((yyvsp[(1) - (2)].n)->u.sval.u.string == this_program_string) {
	  inherit_state = Pike_compiler;
	  inherit_depth = 0;
	  e = 0;
	}
	else
	  my_yyerror("No inherit or surrounding class %s.", (yyvsp[(1) - (2)].n)->u.sval.u.string->str);
      }
    }
    free_node((yyvsp[(1) - (2)].n));
    (yyval.number) = e;
  }
    break;

  case 522:
#line 3427 "language.yacc"
    {
    inherit_state = Pike_compiler;
    for (inherit_depth = 0; inherit_depth < compilation_depth;
	 inherit_depth++, inherit_state = inherit_state->previous) {}
    (yyval.number) = 0;
  }
    break;

  case 523:
#line 3434 "language.yacc"
    {
    if ((yyvsp[(1) - (3)].number) >= 0) {
      int e = 0;
#if 0
      /* FIXME: The inherit modifiers aren't kept. */
      if (!(inherit_state->new_program->inherits[(yyvsp[(1) - (3)].number)].flags & ID_PRIVATE)) {
#endif /* 0 */
	e = find_inherit(inherit_state->new_program->inherits[(yyvsp[(1) - (3)].number)].prog,
			 (yyvsp[(2) - (3)].n)->u.sval.u.string);
#if 0
      }
#endif /* 0 */
      if (!e) {
	if (inherit_state->new_program->inherits[(yyvsp[(1) - (3)].number)].name) {
	  my_yyerror("No such inherit %s::%s.",
		     inherit_state->new_program->inherits[(yyvsp[(1) - (3)].number)].name->str,
		     (yyvsp[(2) - (3)].n)->u.sval.u.string->str);
	} else {
	  my_yyerror("No such inherit %s.", (yyvsp[(2) - (3)].n)->u.sval.u.string->str);
	}
	(yyval.number) = -1;
      } else {
	/* We know stuff about the inherit structure... */
	(yyval.number) = e + (yyvsp[(1) - (3)].number);
      }
    }
    free_node((yyvsp[(2) - (3)].n));
  }
    break;

  case 524:
#line 3462 "language.yacc"
    { (yyval.number) = -1; }
    break;

  case 525:
#line 3466 "language.yacc"
    {
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(1) - (1)].n)->u.sval.u.string);

    if(((yyval.n)=lexical_islocal(Pike_compiler->last_identifier)))
    {
      /* done, nothing to do here */
    }else if(!((yyval.n)=find_module_identifier(Pike_compiler->last_identifier,1)) &&
	     !((yyval.n) = program_magic_identifier (Pike_compiler, 0, 0,
					      Pike_compiler->last_identifier, 0))) {
      if((Pike_compiler->flags & COMPILATION_FORCE_RESOLVE) ||
	 (Pike_compiler->compiler_pass==2)) {
	my_yyerror("Undefined identifier \"%s\".",
		   Pike_compiler->last_identifier->str);
	/* FIXME: Add this identifier as a constant in the current program to
	 *        avoid multiple reporting of the same identifier.
	 * NOTE: This should then only be done in the second pass.
	 */	
	(yyval.n)=0;
      }else{
	(yyval.n)=mknode(F_UNDEFINED,0,0);
      }
    }
    free_node((yyvsp[(1) - (1)].n));
  }
    break;

  case 526:
#line 3492 "language.yacc"
    {
    node *tmp2;
    extern dynamic_buffer used_modules;

    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(3) - (3)].n)->u.sval.u.string);

    tmp2=mkconstantsvaluenode((struct svalue *) used_modules.s.str );
    (yyval.n)=index_node(tmp2, "predef", (yyvsp[(3) - (3)].n)->u.sval.u.string);
    if(!(yyval.n)->name)
      add_ref( (yyval.n)->name=(yyvsp[(3) - (3)].n)->u.sval.u.string );
    free_node(tmp2);
    free_node((yyvsp[(3) - (3)].n));
  }
    break;

  case 527:
#line 3507 "language.yacc"
    {
    (yyval.n)=0;
  }
    break;

  case 528:
#line 3511 "language.yacc"
    {
    if ((yyvsp[(1) - (2)].number) >= 0) {
      int id;

      if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
      copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(2) - (2)].n)->u.sval.u.string);

      if ((yyvsp[(1) - (2)].number) > 0)
	id = low_reference_inherited_identifier(inherit_state,
						(yyvsp[(1) - (2)].number),
						Pike_compiler->last_identifier,
						SEE_STATIC);
      else
	id = really_low_find_shared_string_identifier(Pike_compiler->last_identifier,
						      inherit_state->new_program,
						      SEE_STATIC|SEE_PRIVATE);

      if (id != -1) {
	if (inherit_depth > 0) {
	  (yyval.n) = mkexternalnode(inherit_state->new_program, id);
	} else {
	  (yyval.n) = mkidentifiernode(id);
	}
      } else if (((yyval.n) = program_magic_identifier (inherit_state, inherit_depth, (yyvsp[(1) - (2)].number),
						 Pike_compiler->last_identifier, 1))) {
	/* All done. */
      }
      else {
	if ((Pike_compiler->flags & COMPILATION_FORCE_RESOLVE) ||
	    (Pike_compiler->compiler_pass == 2)) {
	  if (inherit_state->new_program->inherits[(yyvsp[(1) - (2)].number)].name) {
	    my_yyerror("Undefined identifier \"%s::%s\".",
		       inherit_state->new_program->inherits[(yyvsp[(1) - (2)].number)].name->str,
		       Pike_compiler->last_identifier->str);
	  } else {
	    my_yyerror("Undefined identifier \"%s\".",
		       Pike_compiler->last_identifier->str);
	  }
	  (yyval.n)=0;
	}
	else
	  (yyval.n)=mknode(F_UNDEFINED,0,0);
      }
    } else {
      (yyval.n)=0;
    }

    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 529:
#line 3560 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 530:
#line 3561 "language.yacc"
    { (yyval.n)=0; }
    break;

  case 531:
#line 3563 "language.yacc"
    {
    int e,i;

    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[(2) - (2)].n)->u.sval.u.string);

    (yyval.n)=0;
    for(e=1;e<(int)Pike_compiler->new_program->num_inherits;e++)
    {
      if(Pike_compiler->new_program->inherits[e].inherit_level!=1) continue;
      i=low_reference_inherited_identifier(0,e,(yyvsp[(2) - (2)].n)->u.sval.u.string,SEE_STATIC);
      if(i==-1) continue;
      if((yyval.n))
      {
	(yyval.n)=mknode(F_ARG_LIST,(yyval.n),mkidentifiernode(i));
      }else{
	(yyval.n)=mkidentifiernode(i);
      }
    }
    if(!(yyval.n))
    {
      if (!((yyval.n) = program_magic_identifier (Pike_compiler, 0, -1,
					   (yyvsp[(2) - (2)].n)->u.sval.u.string, 1)))
      {
	if (Pike_compiler->compiler_pass == 2) {
	  if (TEST_COMPAT(7,2)) {
	    yywarning("Undefined identifier \"::%s.\"",
		      (yyvsp[(2) - (2)].n)->u.sval.u.string->str);
	  } else {
	    my_yyerror("Undefined identifier \"::%s\".",
		       (yyvsp[(2) - (2)].n)->u.sval.u.string->str);
	  }
	}
	(yyval.n)=mkintnode(0);
      }
    }else{
      if((yyval.n)->token==F_ARG_LIST) (yyval.n)=mkefuncallnode("aggregate",(yyval.n));
    }
    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 532:
#line 3604 "language.yacc"
    {
    (yyval.n)=0;
  }
    break;

  case 533:
#line 3609 "language.yacc"
    { (yyval.n)=mkintnode(0); }
    break;

  case 535:
#line 3611 "language.yacc"
    { yyerror("Unexpected end of file."); (yyval.n)=0; }
    break;

  case 536:
#line 3614 "language.yacc"
    { (yyval.n)=mkintnode(MAX_INT_TYPE); }
    break;

  case 538:
#line 3616 "language.yacc"
    { yyerror("Unexpected end of file."); (yyval.n)=mkintnode(MAX_INT_TYPE); }
    break;

  case 539:
#line 3620 "language.yacc"
    {
    (yyval.n)=mkopernode("`/",
		  mkopernode("`-",
			     mkopernode("`-",
					mkefuncallnode("gethrvtime",
						       mkintnode(1)),
					mknode(F_COMMA_EXPR,
					       mknode(F_POP_VALUE, (yyvsp[(2) - (2)].n), NULL),
					       mkefuncallnode("gethrvtime",
							      mkintnode(1)))),
			     NULL),
		  mkfloatnode((FLOAT_TYPE)1e9));
  }
    break;

  case 540:
#line 3635 "language.yacc"
    {
    struct pike_type *t;
    node *tmp;

    /* FIXME: Why build the node at all? */
    /* Because the optimizer cannot optimize the root node of the
     * tree properly -Hubbe
     */
    tmp=mknode(F_COMMA_EXPR, (yyvsp[(3) - (4)].n), 0);
    optimize_node(tmp);

    t=(tmp && CAR(tmp) && CAR(tmp)->type ? CAR(tmp)->type : mixed_type_string);
    if(TEST_COMPAT(7,0))
    {
      struct pike_string *s=describe_type(t);
      (yyval.n) = mkstrnode(s);
      free_string(s);
    }else{
      (yyval.n) = mktypenode(t);
    }
    free_node(tmp);
  }
    break;

  case 541:
#line 3657 "language.yacc"
    { (yyval.n)=0; yyerrok; }
    break;

  case 542:
#line 3658 "language.yacc"
    { (yyval.n)=0; yyerror("Missing ')'."); }
    break;

  case 543:
#line 3660 "language.yacc"
    {
    (yyval.n)=0; yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 544:
#line 3664 "language.yacc"
    { (yyval.n)=0; yyerror("Missing ')'."); }
    break;

  case 545:
#line 3667 "language.yacc"
    { (yyval.n)=(yyvsp[(2) - (3)].n); }
    break;

  case 546:
#line 3668 "language.yacc"
    { (yyval.n)=0; yyerrok; }
    break;

  case 547:
#line 3670 "language.yacc"
    {
    (yyval.n)=0; yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 548:
#line 3674 "language.yacc"
    { (yyval.n)=0; yyerror("Missing ')'."); }
    break;

  case 549:
#line 3675 "language.yacc"
    { (yyval.n)=0; yyerror("Missing ')'."); }
    break;

  case 551:
#line 3677 "language.yacc"
    { (yyval.n)=0; yyerror("Bad expression for catch."); }
    break;

  case 552:
#line 3681 "language.yacc"
    {
       Pike_compiler->catch_level++;
     }
    break;

  case 553:
#line 3685 "language.yacc"
    {
       (yyval.n)=mknode(F_CATCH,(yyvsp[(3) - (3)].n),NULL);
       Pike_compiler->catch_level--;
     }
    break;

  case 554:
#line 3692 "language.yacc"
    {
    (yyval.n)=mknode(F_SSCANF,mknode(F_ARG_LIST,(yyvsp[(3) - (7)].n),(yyvsp[(5) - (7)].n)),(yyvsp[(6) - (7)].n));
  }
    break;

  case 555:
#line 3696 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (7)].n));
    free_node((yyvsp[(5) - (7)].n));
    yyerrok;
  }
    break;

  case 556:
#line 3703 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (7)].n));
    free_node((yyvsp[(5) - (7)].n));
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 557:
#line 3711 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (7)].n));
    free_node((yyvsp[(5) - (7)].n));
    yyerror("Missing ')'.");
  }
    break;

  case 558:
#line 3718 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (7)].n));
    free_node((yyvsp[(5) - (7)].n));
    yyerror("Missing ')'.");
  }
    break;

  case 559:
#line 3725 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (5)].n));
    yyerrok;
  }
    break;

  case 560:
#line 3731 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (5)].n));
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 561:
#line 3738 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (5)].n));
    yyerror("Missing ')'.");
  }
    break;

  case 562:
#line 3744 "language.yacc"
    {
    (yyval.n)=0;
    free_node((yyvsp[(3) - (5)].n));
    yyerror("Missing ')'.");
  }
    break;

  case 563:
#line 3749 "language.yacc"
    { (yyval.n)=0; yyerrok; }
    break;

  case 564:
#line 3751 "language.yacc"
    {
    (yyval.n)=0; yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
    break;

  case 565:
#line 3755 "language.yacc"
    { (yyval.n)=0; yyerror("Missing ')'."); }
    break;

  case 566:
#line 3756 "language.yacc"
    { (yyval.n)=0; yyerror("Missing ')'."); }
    break;

  case 568:
#line 3761 "language.yacc"
    { (yyval.n)=mknode(F_ARRAY_LVALUE, (yyvsp[(2) - (3)].n),0); COPY_LINE_NUMBER_INFO ((yyval.n), (yyvsp[(1) - (3)].n)); free_node ((yyvsp[(1) - (3)].n)); }
    break;

  case 569:
#line 3763 "language.yacc"
    {
    int id = add_local_name((yyvsp[(2) - (2)].n)->u.sval.u.string,compiler_pop_type(),0);
    if (id >= 0)
      (yyval.n)=mklocalnode(id,-1);
    else
      (yyval.n) = 0;
    free_node((yyvsp[(2) - (2)].n));
  }
    break;

  case 570:
#line 3772 "language.yacc"
    { (yyval.n)=mknewintnode(0); }
    break;

  case 571:
#line 3774 "language.yacc"
    { (yyval.n)=mknode(F_LVALUE_LIST,(yyvsp[(1) - (2)].n),(yyvsp[(2) - (2)].n)); }
    break;

  case 572:
#line 3777 "language.yacc"
    { (yyval.n) = 0; }
    break;

  case 573:
#line 3778 "language.yacc"
    { (yyval.n) = mknode(F_LVALUE_LIST,(yyvsp[(2) - (3)].n),(yyvsp[(3) - (3)].n)); }
    break;

  case 575:
#line 3783 "language.yacc"
    {
    struct pike_string *a,*b;
    copy_shared_string(a,(yyvsp[(1) - (2)].n)->u.sval.u.string);
    copy_shared_string(b,(yyvsp[(2) - (2)].n)->u.sval.u.string);
    free_node((yyvsp[(1) - (2)].n));
    free_node((yyvsp[(2) - (2)].n));
    a=add_and_free_shared_strings(a,b);
    (yyval.n)=mkstrnode(a);
    free_string(a);
  }
    break;

  case 577:
#line 3802 "language.yacc"
    { yyerror("array is a reserved word."); }
    break;

  case 578:
#line 3804 "language.yacc"
    { yyerror("class is a reserved word."); }
    break;

  case 579:
#line 3806 "language.yacc"
    { yyerror("enum is a reserved word."); }
    break;

  case 580:
#line 3808 "language.yacc"
    { yyerror("float is a reserved word.");}
    break;

  case 581:
#line 3810 "language.yacc"
    { yyerror("function is a reserved word.");}
    break;

  case 582:
#line 3812 "language.yacc"
    { yyerror("int is a reserved word."); }
    break;

  case 583:
#line 3814 "language.yacc"
    { yyerror("mapping is a reserved word."); }
    break;

  case 584:
#line 3816 "language.yacc"
    { yyerror("mixed is a reserved word."); }
    break;

  case 585:
#line 3818 "language.yacc"
    { yyerror("multiset is a reserved word."); }
    break;

  case 586:
#line 3820 "language.yacc"
    { yyerror("object is a reserved word."); }
    break;

  case 587:
#line 3822 "language.yacc"
    { yyerror("program is a reserved word."); }
    break;

  case 588:
#line 3824 "language.yacc"
    { yyerror("string is a reserved word."); }
    break;

  case 589:
#line 3826 "language.yacc"
    { yyerror("typedef is a reserved word."); }
    break;

  case 590:
#line 3828 "language.yacc"
    { yyerror("void is a reserved word."); }
    break;

  case 591:
#line 3833 "language.yacc"
    { yyerror("inline is a reserved word."); }
    break;

  case 592:
#line 3835 "language.yacc"
    { yyerror("local is a reserved word."); }
    break;

  case 593:
#line 3837 "language.yacc"
    { yyerror("nomask is a reserved word."); }
    break;

  case 594:
#line 3839 "language.yacc"
    { yyerror("predef is a reserved word."); }
    break;

  case 595:
#line 3841 "language.yacc"
    { yyerror("private is a reserved word."); }
    break;

  case 596:
#line 3843 "language.yacc"
    { yyerror("protected is a reserved word."); }
    break;

  case 597:
#line 3845 "language.yacc"
    { yyerror("public is a reserved word."); }
    break;

  case 598:
#line 3847 "language.yacc"
    { yyerror("optional is a reserved word."); }
    break;

  case 599:
#line 3849 "language.yacc"
    { yyerror("variant is a reserved word."); }
    break;

  case 600:
#line 3851 "language.yacc"
    { yyerror("static is a reserved word."); }
    break;

  case 601:
#line 3853 "language.yacc"
    { yyerror("extern is a reserved word."); }
    break;

  case 602:
#line 3855 "language.yacc"
    { yyerror("final is a reserved word.");}
    break;

  case 603:
#line 3857 "language.yacc"
    { yyerror("do is a reserved word."); }
    break;

  case 604:
#line 3859 "language.yacc"
    { yyerror("else without if."); }
    break;

  case 605:
#line 3861 "language.yacc"
    { yyerror("return is a reserved word."); }
    break;

  case 606:
#line 3863 "language.yacc"
    { yyerror("import is a reserved word."); }
    break;

  case 607:
#line 3865 "language.yacc"
    { yyerror("inherit is a reserved word."); }
    break;

  case 608:
#line 3867 "language.yacc"
    { yyerror("catch is a reserved word."); }
    break;

  case 609:
#line 3869 "language.yacc"
    { yyerror("gauge is a reserved word."); }
    break;

  case 610:
#line 3871 "language.yacc"
    { yyerror("lambda is a reserved word."); }
    break;

  case 611:
#line 3873 "language.yacc"
    { yyerror("sscanf is a reserved word."); }
    break;

  case 612:
#line 3875 "language.yacc"
    { yyerror("switch is a reserved word."); }
    break;

  case 613:
#line 3877 "language.yacc"
    { yyerror("typeof is a reserved word."); }
    break;

  case 614:
#line 3879 "language.yacc"
    { yyerror("break is a reserved word."); }
    break;

  case 615:
#line 3881 "language.yacc"
    { yyerror("case is a reserved word."); }
    break;

  case 616:
#line 3883 "language.yacc"
    { yyerror("continue is a reserved word."); }
    break;

  case 617:
#line 3885 "language.yacc"
    { yyerror("default is a reserved word."); }
    break;

  case 618:
#line 3887 "language.yacc"
    { yyerror("for is a reserved word."); }
    break;

  case 619:
#line 3889 "language.yacc"
    { yyerror("foreach is a reserved word."); }
    break;

  case 620:
#line 3891 "language.yacc"
    { yyerror("if is a reserved word."); }
    break;


/* Line 1267 of yacc.c.  */
#line 8891 "y.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 3904 "language.yacc"


void yyerror(char *str)
{
  extern int cumulative_parse_error;

  STACK_LEVEL_START(0);

#ifdef PIKE_DEBUG
  if(Pike_interpreter.recoveries && Pike_sp-Pike_interpreter.evaluator_stack < Pike_interpreter.recoveries->stack_pointer)
    Pike_fatal("Stack error (underflow)\n");
#endif

  if (Pike_compiler->num_parse_error > 20) return;
  Pike_compiler->num_parse_error++;
  cumulative_parse_error++;

  if ((error_handler && error_handler->prog) || get_master())
  {
    if (lex.current_file) {
      ref_push_string(lex.current_file);
    } else {
      /* yyerror() can be called from define_function(), which
       * can be called by the C module initialization code.
       */
      push_constant_text("");
    }
    push_int(lex.current_line);
    push_text(str);
    low_safe_apply_handler("compile_error", error_handler, compat_handler, 3);
    pop_stack();
  }else{
    if (lex.current_file) {
      (void)fprintf(stderr, "%s:%ld: %s\n",
		    lex.current_file->str,
		    (long)lex.current_line,
		    str);
    } else {
      (void)fprintf(stderr, "NULL:%ld: %s\n",
		    (long)lex.current_line,
		    str);
    }
    fflush(stderr);
  }

  STACK_LEVEL_DONE(0);
}

static int low_islocal(struct compiler_frame *f,
		       struct pike_string *str)
{
  int e;
  for(e=f->current_number_of_locals-1;e>=0;e--)
    if(f->variable[e].name==str)
      return e;
  return -1;
}



int low_add_local_name(struct compiler_frame *frame,
		       struct pike_string *str,
		       struct pike_type *type,
		       node *def)
{

  if (str->len && !TEST_COMPAT(7,0)) {
    int tmp=low_islocal(frame,str);
    if(tmp>=0 && tmp >= frame->last_block_level)
    {
      if(str->size_shift)
	my_yyerror("Duplicate local variable, "
		   "previous declaration on line %d\n",
		   frame->variable[tmp].line);
      else
	my_yyerror("Duplicate local variable '%s', "
		   "previous declaration on line %d\n",
		   STR0(str), frame->variable[tmp].line);
    }

    if(type == void_type_string)
    {
      if(str->size_shift)
	my_yyerror("Local variables cannot be of type of 'void'.\n");
      else
	my_yyerror("Local variable '%s' is void.\n",STR0(str));
    }
  }

  debug_malloc_touch(def);
  debug_malloc_touch(type);
  debug_malloc_touch(str);
  if (frame->current_number_of_locals == MAX_LOCAL-1)
  {
    yyerror("Too many local variables.");
    free_type(type);
    if (def) free_node(def);
    return -1;
  }else {
    reference_shared_string(str);
#ifdef PIKE_DEBUG
    check_type_string(type);
#endif /* PIKE_DEBUG */
    if (pike_types_le(type, void_type_string)) {
      if (Pike_compiler->compiler_pass != 1) {
	yywarning("Declaring local variable with type void "
		  "(converted to type zero).");
      }
      free_type(type);
      copy_pike_type(type, zero_type_string);
    }
    frame->variable[frame->current_number_of_locals].type = type;
    frame->variable[frame->current_number_of_locals].name = str;
    frame->variable[frame->current_number_of_locals].def = def;

    frame->variable[frame->current_number_of_locals].line=lex.current_line;
    frame->variable[frame->current_number_of_locals].file=lex.current_file;
    add_ref(lex.current_file);

    frame->current_number_of_locals++;
    if(frame->current_number_of_locals > 
       frame->max_number_of_locals)
    {
      frame->max_number_of_locals=
	frame->current_number_of_locals;
    }

    return frame->current_number_of_locals-1;
  }
}


/* argument must be a shared string */
/* Note that this function eats a reference to 'type' */
/* If def is nonzero, it also eats a ref to def */
int add_local_name(struct pike_string *str,
		   struct pike_type *type,
		   node *def)
{
  return low_add_local_name(Pike_compiler->compiler_frame,
			    str,
			    type,
			    def);
}



int islocal(struct pike_string *str)
{
  return low_islocal(Pike_compiler->compiler_frame, str);
}

/* argument must be a shared string */
static node *lexical_islocal(struct pike_string *str)
{
  int e,depth=0;
  struct compiler_frame *f=Pike_compiler->compiler_frame;
  
  while(1)
  {
    for(e=f->current_number_of_locals-1;e>=0;e--)
    {
      if(f->variable[e].name==str)
      {
	struct compiler_frame *q=Pike_compiler->compiler_frame;

	while(q!=f) 
	{
	  q->lexical_scope|=SCOPE_SCOPED;
	  q=q->previous;
	}

	if(depth) {
	  q->lexical_scope|=SCOPE_SCOPE_USED;

	  if(q->min_number_of_locals < e+1)
	    q->min_number_of_locals = e+1;
	}

	if(f->variable[e].def) {
	  /*fprintf(stderr, "Found prior definition of \"%s\"\n", str->str); */
	  return copy_node(f->variable[e].def);
	}

	return mklocalnode(e,depth);
      }
    }
    if(!(f->lexical_scope & SCOPE_LOCAL)) return 0;
    depth++;
    f=f->previous;
  }
}

static void safe_inc_enum(void)
{
  JMP_BUF recovery;
  STACK_LEVEL_START(1);

  if (SETJMP_SP(recovery, 1)) {
    handle_compile_exception ("Bad implicit enum value (failed to add 1).");
    push_int(0);
  } else {
    push_int(1);
    f_add(2);
  }
  UNSETJMP(recovery);
  STACK_LEVEL_DONE(1);
}


static int call_handle_import(struct pike_string *s)
{
  int args;

  ref_push_string(s);
  ref_push_string(lex.current_file);
  if (error_handler && error_handler->prog) {
    ref_push_object(error_handler);
    args = 3;
  }
  else args = 2;

  if (safe_apply_handler("handle_import", error_handler, compat_handler,
			 args, BIT_MAPPING|BIT_OBJECT|BIT_PROGRAM|BIT_ZERO))
    if (Pike_sp[-1].type != T_INT)
      return 1;
    else {
      pop_stack();
      if (!s->size_shift)
	my_yyerror("Couldn't find module to import: %s",s->str);
      else
	yyerror("Couldn't find module to import");
    }
  else
    handle_compile_exception ("Error finding module to import");

  return 0;
}

void cleanup_compiler(void)
{
}

