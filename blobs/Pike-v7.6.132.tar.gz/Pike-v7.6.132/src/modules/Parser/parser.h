/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: a7d1dbb355c9511ffa62c57fc69c27632fc3011f $
*/

void init_parser_html(void);
void init_parser_rcs(void);
void exit_parser_rcs(void);
