/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 64d3a6fe41acb77d42904db37a4f31b9ae67c013 $
*/

@TOP@
