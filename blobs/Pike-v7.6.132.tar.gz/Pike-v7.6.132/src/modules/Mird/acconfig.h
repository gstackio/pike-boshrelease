/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 4554f5a34a22b06e0ac087f47298b2bede495849 $
*/

/* Define if you have the `mird' library (-lmird). */
#undef HAVE_LIBMIRD

/* Define if you have the <mird.h> header file. */
#undef HAVE_MIRD_H
