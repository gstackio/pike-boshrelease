/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 13e3d78dc42a381e0413850a3522d71003239b81 $
*/

#undef HAVE_LIBFT2
#undef HAVE_FT_FT2BUILD
@TOP@
@BOTTOM@

/* Define if you have a declaration of ft_encoding_latin_1 */
#undef HAVE_DECL_FT_ENCODING_LATIN_1
