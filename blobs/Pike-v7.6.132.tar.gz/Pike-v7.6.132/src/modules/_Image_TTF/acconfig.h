/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 251730ca08e0f044ade53f3c4cb50f4c3e6f0dfc $
*/

@TOP@
@BOTTOM@

/* Define this if you have -lttf. */
#undef HAVE_LIBTTF

/* Define this if TT_Horizontal_Header has the member Reserved0 */
#undef HAVE_TT_H_H_Reserved0
