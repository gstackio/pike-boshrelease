/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 17f293c235296269a74855a4a05f348d935df88a $
*/

#ifndef IMAGE_MACHINE_H
#define IMAGE_MACHINE_H

/* nasm exists and can be used to make .o-files */
#undef ASSEMBLY_OK

/* Define if you have the m library (-lm).  */
#undef HAVE_LIBM

@TOP@
@BOTTOM@

#endif
