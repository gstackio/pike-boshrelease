/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 77076727955ecaec7c1530a7340c982d25c2c933 $
*/

STRING(height);
STRING(width);
STRING(bpp);
STRING(depth);
STRING(compression);
STRING(top);
STRING(left);
STRING(right);
STRING(bottom);
STRING(mask_top);
STRING(mask_left);
STRING(mask_right);
STRING(mask_bottom);
STRING(mask_flags);
STRING(mask_default_color);
STRING(opacity);
STRING(clipping);
STRING(flags);
STRING(mode);
STRING(extra_data);
STRING(id);
STRING(color_data);
STRING(channels);
STRING(name);
STRING(data);
STRING(image_data);
STRING(layers);
STRING(mask);
STRING(name);
STRING(properties);
STRING(tiles);
STRING(type);
STRING(resources);
