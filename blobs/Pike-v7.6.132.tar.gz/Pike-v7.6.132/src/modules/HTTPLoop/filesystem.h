/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 9a8916ea1f5a169aab3a37b803f1103f4d0828a1 $
*/

struct file_ret *aap_find_file( char *s, int len,
                                char *ho, int hlen, 
                                struct filesystem *f );

void set_filesystem( struct args *a, struct pstring loc )
{
}
