/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 8f3334be227a2c90cf6b2f888411c851e0432e1b $
*/

#ifndef GMP_MACHINE_H
#define GMP_MACHINE_H

@TOP@
@BOTTOM@

/* Define this if you have an embeddable perl */
#undef HAVE_PERL

#endif
