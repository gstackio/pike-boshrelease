/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: e6bbdb304a7f1c9fdce836c18eb61067d8aa764b $
*/

#ifndef IMAGE_GIF_CONFIG_H
#define IMAGE_GIF_CONFIG_H

@TOP@

/* Define this to enable gif support */
#undef WITH_GIF

@BOTTOM@

#endif /* !IMAGE_GIF_CONFIG_H */
