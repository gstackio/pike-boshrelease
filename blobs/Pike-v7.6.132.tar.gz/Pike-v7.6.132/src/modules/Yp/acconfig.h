/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: af468625bf89aefec261b95b1aa4e69d0215dd1e $
*/

#ifndef YP_MACHINE_H
#define YP_MACHINE_H

@TOP@
@BOTTOM@

/* The last argument to yp_order() is a YP_ORDER_TYPE * */
#define YP_ORDER_TYPE	unsigned

#endif
