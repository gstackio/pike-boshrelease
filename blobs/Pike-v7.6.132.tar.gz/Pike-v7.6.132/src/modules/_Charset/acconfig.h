/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 6161c45ffd75e9ffd0aac59b1d1e2520b040b624 $
*/


