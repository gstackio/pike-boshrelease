/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: e61a46c2c97f89880fe4acaa36fc3abd770dd4f2 $
*/

void pgresult_init(void);
