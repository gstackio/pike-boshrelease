/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 742598cc6809738bd2c1f010ee62396e8ea5afaa $
*/

#define PIKE_MAJOR_VERSION 7
#define PIKE_MINOR_VERSION 6
#define PIKE_BUILD_VERSION 132

/* Prototypes begin here */
void f_version(INT32 args);
/* Prototypes end here */
