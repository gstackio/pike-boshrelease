/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 99088f64e80731f5f2d3dafa6d94841627bf8db4 $
*/

#define HSIZE 10007
