#line 1 "/Users/hww3/pike/src/post_modules/_ADT/adt.cmod"
/* -*- c -*-
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 1862c1daf9f8fd291f95b599efef99ff2db8ca66 $
*/
#include "global.h"

#include "module_support.h"
#include "sequence.h"
#include "circular_list.h"

#line 15 "/Users/hww3/pike/src/post_modules/_ADT/adt.cmod"
PIKE_MODULE_INIT
{
  ;
  pike_init_Sequence_module();
  pike_init_CircularList_module();
}

PIKE_MODULE_EXIT
{
  pike_exit_Sequence_module();  
  pike_exit_CircularList_module();  
  ;
} 

