#line 1 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
/* -*- c -*-
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: ed9e5c7cff4ee70844d4f81834136ba2b958a68e $
*/

#include "global.h"

#include "object.h"
#include "svalue.h"
#include "array.h"
#include "pike_error.h"
#include "interpret.h"
#include "stralloc.h"
#include "program.h"

#include "program_id.h"

#include "module_support.h"
#include "sequence.h"


/*! @module ADT
 */


/*! @class Sequence
 *! The sequence work similar to an array but has the possibilities to 
 *! insert and remove elements. It also has a more powerful iterator.
 */


#undef class_Sequence_defined
#define class_Sequence_defined
struct program *Sequence_program=NULL;
static int Sequence_program_fun_num=-1;

#undef var_pos_Sequence_defined
#define var_pos_Sequence_defined

#undef var_a_Sequence_defined
#define var_a_Sequence_defined

#undef THIS
#define THIS ((struct Sequence_struct *)(Pike_interpreter.frame_pointer->current_storage))

#undef THIS_SEQUENCE
#define THIS_SEQUENCE ((struct Sequence_struct *)(Pike_interpreter.frame_pointer->current_storage))

#undef OBJ2_SEQUENCE
#define OBJ2_SEQUENCE(o) ((struct Sequence_struct *)(o->storage+Sequence_storage_offset))

#undef GET_SEQUENCE_STORAGE
#define GET_SEQUENCE_STORAGE ((struct Sequence_struct *)(o->storage+Sequence_storage_offset)
static ptrdiff_t Sequence_storage_offset;
struct Sequence_struct {

#ifdef var_pos_Sequence_defined
#line 38 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
int pos;
#endif /* var_pos_Sequence_defined */

#ifdef var_a_Sequence_defined
#line 39 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct array *a;
#endif /* var_a_Sequence_defined */
};
/*if there is more than one reference to this array copy it. */

  static inline void should_copy()
  {
    if (THIS->a->refs > 1)
    {
      free_array(THIS->a);
      THIS->a = copy_array(THIS->a);
    }
  }    


/*! @decl mixed `[](int index)
 *! Index operator.
 *! 
 *! @param index
 *!   The index to get the value for, could be negative to index from the end.
 *!
 *! @returns
 *!   The value at the index @[index].
 *!
 *! @throws 
 *!   An error if the index is out of range.
 */

  #define f_Sequence_cq__backtick_5B_5D_defined
ptrdiff_t f_Sequence_cq__backtick_5B_5D_fun_num = 0;
void f_Sequence_cq__backtick_5B_5D(INT32 args) {
#line 67 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * index;
#line 67 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`[]",args,1);
#line 67 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
index=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
#line 67 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      
    simple_array_index_no_free(Pike_sp, THIS->a, index);
    Pike_sp++;
  }
  

}
/*! @decl mixed `[]=(int index, mixed value)
 *! Index assign operator.
 *! Set the value at the index @[index] to be @[value].
 *! 
 *! @param index 
 *!   The index to set.
 *!
 *! @param value
 *!   The new value.
 *!
 *! @returns
 *!   The new value at the index @[index].
 *!
 */
  
  #define f_Sequence_cq__backtick_5B_5D_eq_defined
ptrdiff_t f_Sequence_cq__backtick_5B_5D_eq_fun_num = 0;
void f_Sequence_cq__backtick_5B_5D_eq(INT32 args) {
#line 89 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * index;
#line 89 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * value;
#line 89 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 2) wrong_number_of_args_error("`[]=",args,2);
#line 89 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
index=Pike_sp+0-2; dmalloc_touch_svalue(Pike_sp+0-2);
#line 89 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
value=Pike_sp+1-2; dmalloc_touch_svalue(Pike_sp+1-2);
#line 89 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
    should_copy();  	
    simple_set_index(THIS->a, index, value);
  } 


}
/*! @decl Sequence `+(Sequence coll)
 *! Addition operator
 *! Append the content of @[coll] to thies sequence and return the results 
 *! as a new @[Sequence].
 *! 
 *! @param coll 
 *!   The sequence to append to his sequence.
 *!
 *! @returns
 *!   The result of the append as a new @[Sequence]. 
 */

  #define f_Sequence_cq__backtick_add_defined
ptrdiff_t f_Sequence_cq__backtick_add_fun_num = 0;
void f_Sequence_cq__backtick_add(INT32 args) {
#line 107 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object * coll;
#line 107 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`+",args,1);
#line 107 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_OBJECT) SIMPLE_BAD_ARG_ERROR("`+",1,"object");
#line 107 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(coll=Pike_sp[0-1].u.object);
{
    /*Should work  om collection classes too */
    if (coll->prog == Sequence_program)
    {
      ref_push_array(THIS->a);
      ref_push_array(OBJ2_SEQUENCE(coll)->a);
      push_array(add_arrays(Pike_sp-2, 2));
  
      push_object(clone_object(Sequence_program, 1));
    }
    else
    {
      SIMPLE_BAD_ARG_ERROR("`+",1,"ADT.Sequence");
    }
  }

  
}
/*! @decl Sequence `-(Sequence coll)
 *! Subtraction operator
 *! Removes those values in this sequence that also are present in @[coll] 
 *! and return the results as a new @[Sequence].
 *! 
 *! @param coll 
 *!   The sequence to subtract from this sequence.
 *!
 *! @returns
 *!   The result of the subtraction as a new @[Sequence]. 
 */

  #define f_Sequence_cq__backtick_2D_defined
ptrdiff_t f_Sequence_cq__backtick_2D_fun_num = 0;
void f_Sequence_cq__backtick_2D(INT32 args) {
#line 137 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object * coll;
#line 137 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`-",args,1);
#line 137 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_OBJECT) SIMPLE_BAD_ARG_ERROR("`-",1,"object");
#line 137 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(coll=Pike_sp[0-1].u.object);
{
    /*Should work on collection classes too */
    if (coll->prog == Sequence_program)
    {
      push_array(subtract_arrays(THIS->a, OBJ2_SEQUENCE(coll)->a));
  
      push_object(clone_object(Sequence_program, 1));
    }
    else
    {
      SIMPLE_BAD_ARG_ERROR("`-",1,"ADT.Sequence");
    }
  }
    
  
}
/*! @decl Sequence `&(Sequence coll)
 *! And operator
 *! Perform an and on this sequence and the @[coll] sequence by only returning 
 *! those values that is present in both sequences as a new @[Sequence].
 *! The remaining values is in the same order as they are in this sequence and
 *! the values are compared using `==.
 *!
 *! @param coll 
 *!   The sequence to and to this sequence.
 *!
 *! @returns
 *!   The result of the and as a new @[Sequence]. 
 */

  #define f_Sequence_cq__backtick_26_defined
ptrdiff_t f_Sequence_cq__backtick_26_fun_num = 0;
void f_Sequence_cq__backtick_26(INT32 args) {
#line 167 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object * coll;
#line 167 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`&",args,1);
#line 167 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_OBJECT) SIMPLE_BAD_ARG_ERROR("`&",1,"object");
#line 167 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(coll=Pike_sp[0-1].u.object);
{
    /*Should work on collection classes too */
    if (coll->prog == Sequence_program)
    {
      push_array(and_arrays(THIS->a,
			    OBJ2_SEQUENCE(coll)->a));
  
      push_object(clone_object(Sequence_program, 1));
    }
    else
    {
      SIMPLE_BAD_ARG_ERROR("`&",1,"ADT.Sequence");
    }
  }

  
}
/*! @decl Sequence `|(Sequence coll)
 *! Or operator
 *! Perform an or on this sequence and the @[coll] sequence by returning 
 *! those values that is present in both sequences as a new @[Sequence].
 *! The values are compared using `==.
 *!
 *! @param coll 
 *!   The sequence to or with this sequence.
 *!
 *! @returns
 *!   The result of the or as a new @[Sequence]. 
 */

  #define f_Sequence_cq__backtick_7C_defined
ptrdiff_t f_Sequence_cq__backtick_7C_fun_num = 0;
void f_Sequence_cq__backtick_7C(INT32 args) {
#line 197 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object * coll;
#line 197 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`|",args,1);
#line 197 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_OBJECT) SIMPLE_BAD_ARG_ERROR("`|",1,"object");
#line 197 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(coll=Pike_sp[0-1].u.object);
{
    /*Should work on collection classes too */
    if (coll->prog == Sequence_program)
    {
      push_array(merge_array_with_order(THIS->a, 
					OBJ2_SEQUENCE(coll)->a,
					PIKE_ARRAY_OP_OR));
  
      push_object(clone_object(Sequence_program, 1));
    }
    else
    {
      SIMPLE_BAD_ARG_ERROR("`|",1,"ADT.Sequence");
    }
  }


}
/*! @decl Sequence `^(Sequence coll)
 *! Xor operator
 *! Perform a xor on this sequence and the @[coll] sequence by returning 
 *! those values that is present in one of the sequences but not in both 
 *! adapters as a new @[Sequence].
 *! The values are compared using `==.
 *!
 *! @param coll 
 *!   The sequence to xor with this sequence.
 *!
 *! @returns
 *!   The result of the xor as a new @[Sequence]. 
 */

  #define f_Sequence_cq__backtick_5E_defined
ptrdiff_t f_Sequence_cq__backtick_5E_fun_num = 0;
void f_Sequence_cq__backtick_5E(INT32 args) {
#line 229 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object * coll;
#line 229 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`^",args,1);
#line 229 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_OBJECT) SIMPLE_BAD_ARG_ERROR("`^",1,"object");
#line 229 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(coll=Pike_sp[0-1].u.object);
{
    /*Should work on collection classes too */
    if (coll->prog == Sequence_program)
    {
      push_array(merge_array_with_order(THIS->a, 
					OBJ2_SEQUENCE(coll)->a,
					PIKE_ARRAY_OP_XOR));
  
      push_object(clone_object(Sequence_program, 1));
    }
    else
    {
      SIMPLE_BAD_ARG_ERROR("`^",1,"ADT.Sequence");
    }
  }


  }
/*! @decl int(0..1) _equal(mixed coll)
   *!
   *! @returns
   *!   Returns @tt{true@} if the object @[coll] is a @[Sequence]
   *!   and contains the same values in the same order.
   */

  #define f_Sequence_cq__equal_defined
ptrdiff_t f_Sequence_cq__equal_fun_num = 0;
void f_Sequence_cq__equal(INT32 args) {
#line 254 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * coll;
#line 254 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("_equal",args,1);
#line 254 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
coll=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
    if (coll->type == T_OBJECT && 
	coll->u.object->prog == Sequence_program)
    {
      struct Sequence_struct *adapter = OBJ2_SEQUENCE(coll->u.object);
      do { INT_TYPE ret_=((array_equal_p(THIS->a, adapter->a, 0))); pop_stack(); push_int(ret_); return; }while(0);
#line 261 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
    do { INT_TYPE ret_=(0); pop_stack(); push_int(ret_); return; }while(0);
#line 263 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

  }
/*! @decl array _indices()
   *!
   *! @returns
   *!   The indices in this adapter as an array.
   */

  #define f_Sequence_cq__indices_defined
ptrdiff_t f_Sequence_cq__indices_fun_num = 0;
void f_Sequence_cq__indices(INT32 args) {
#line 271 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("_indices",args,0);
{
    ptrdiff_t size = THIS->a->size;
    struct array *a;
    
    a=allocate_array_no_init(size,0);
    while(--size>=0)
    {
      ITEM(a)[size].u.integer = DO_NOT_WARN((INT_TYPE)size);
    }
    a->type_field = BIT_INT;
    do { struct array * ret_=(a);  push_array(ret_); return; }while(0);
#line 283 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

}
/*! @decl void _insert_element(int index, mixed value)
 *! Insert an element in the sequence at the position @[index], the value
 *! at the position @[index] and all above will have their index increased 
 *! with one.
 *! 
 *! @param index 
 *!   The index to insert the value at.
 *!
 *! @param value
 *!   The new value.
 *!
 */

  #define f_Sequence_cq__insert_element_defined
ptrdiff_t f_Sequence_cq__insert_element_fun_num = 0;
void f_Sequence_cq__insert_element(INT32 args) {
#line 298 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
INT_TYPE index;
#line 298 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * value;
#line 298 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 2) wrong_number_of_args_error("_insert_element",args,2);
#line 298 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-2].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("_insert_element",1,"int");
index=Pike_sp[0-2].u.integer;
#line 298 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
value=Pike_sp+1-2; dmalloc_touch_svalue(Pike_sp+1-2);
{
    FIX_AND_CHECK_INDEX(index, THIS->a->size, 1);
    should_copy();
    THIS->a = array_insert(THIS->a, value, index);
   
  }

}
/*! @decl mixed _remove_element(int index)
 *!  Remove the values at index @[index] from the sequence.
 *! 
 *! @param index 
 *!   The index to remove.
 *!
 *! @returns
 *!   The removed value.
 */

  #define f_Sequence_cq__remove_element_defined
ptrdiff_t f_Sequence_cq__remove_element_fun_num = 0;
void f_Sequence_cq__remove_element(INT32 args) {
#line 316 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
INT_TYPE index;
#line 316 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("_remove_element",args,1);
#line 316 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("_remove_element",1,"int");
index=Pike_sp[0-1].u.integer;
#line 317 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
    struct svalue s;

    FIX_AND_CHECK_INDEX(index, THIS->a->size, 0);

    s = *(THIS->a->item + index);    
    should_copy();
    THIS->a = array_remove(THIS->a, index);
    push_svalue(&s);
  }


}
/*! @decl int _search(mixed value, void|int start)
 *!   Search the sequence for a specific value. Return the index of the first 
 *!   value that is equal to @[value]. If no value was found @expr{UNDEFINED@} 
 *!   is returned instead.
 *! 
 *! @param value
 *!   The value to find.
 *!
 *! @param start
 *!   If a start value is supplied it will start searching at the index 
 *!   @[start].
 *!
 *! @returns
 *!   Returns the index of the found value or @expr{UNDEFINED@}.
 */

  #define f_Sequence_cq__search_defined
ptrdiff_t f_Sequence_cq__search_fun_num = 0;
void f_Sequence_cq__search(INT32 args) {
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * value;
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * start;
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args < 1) wrong_number_of_args_error("_search",args,1);
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args > 2) wrong_number_of_args_error("_search",args,2);
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
value=Pike_sp+0-args; dmalloc_touch_svalue(Pike_sp+0-args);
if (args > 1) {
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[1-args].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("_search",2,"void|int");
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
start=Pike_sp+1-args; dmalloc_touch_svalue(Pike_sp+1-args);
} else start=0;
#line 346 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
    if(args == 2)
    { 
      if (start->type != PIKE_T_INT)
      { 
	SIMPLE_BAD_ARG_ERROR("_search",2,"int");
      }
      do { INT_TYPE ret_=(array_search(THIS->a, value, start->u.integer)); pop_n_elems(args); push_int(ret_); return; }while(0);
#line 354 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
    else 
    {
      do { INT_TYPE ret_=(array_search(THIS->a,value,0)); pop_n_elems(args); push_int(ret_); return; }while(0);
#line 358 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
  }
  
}
/*! @decl int _sizeof()
 *!
 *! @returns
 *!   The number of elements in this adapter.
 */

  #define f_Sequence_cq__sizeof_defined
ptrdiff_t f_Sequence_cq__sizeof_fun_num = 0;
void f_Sequence_cq__sizeof(INT32 args) {
#line 367 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("_sizeof",args,0);
{
    do { INT_TYPE ret_=(THIS->a->size);  push_int(ret_); return; }while(0);
#line 370 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

  }
/*! @decl array _values()
   *!
   *! @returns
   *!   The values in this adapter as an array.
   */
  
  #define f_Sequence_cq__values_defined
ptrdiff_t f_Sequence_cq__values_fun_num = 0;
void f_Sequence_cq__values(INT32 args) {
#line 378 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("_values",args,0);
{
    struct array *a;
     a=copy_array(THIS->a);
    do { struct array * ret_=(a);  push_array(ret_); return; }while(0);
#line 383 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

  
}
/*! @decl void add(mixed value)
 *!   Add a value at the end of the sequence.
 *!
 *! @param value
 *!   The value to add.
 */

  #define f_Sequence_add_defined
ptrdiff_t f_Sequence_add_fun_num = 0;
void f_Sequence_add(INT32 args) {
#line 393 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * value;
#line 393 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("add",args,1);
#line 393 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
value=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
    should_copy();
    THIS->a=append_array(THIS->a, value);
  }


}
/*! @decl mixed cast(string type)
 *! Cast operator.
 *!
 *! @param type
 *!   Casts to this type.
 *!
 *!   Casts to the following types are supported:
 *!   @string
 *!     @value "array"
 *!       Cast the content of this sequence to an array.
 *!   @endstring
 *!
 *! @returns
 *!   An array with the contents of this sequence.
 */

  #define f_Sequence_cast_defined
ptrdiff_t f_Sequence_cast_fun_num = 0;
void f_Sequence_cast(INT32 args) {
#line 416 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct pike_string * type;
#line 416 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("cast",args,1);
#line 416 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_STRING) SIMPLE_BAD_ARG_ERROR("cast",1,"string");
#line 416 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(type=Pike_sp[0-1].u.string);
{
    struct pike_string *array_t;
    MAKE_CONST_STRING( array_t, "array" );
    
    if (type == array_t)
    {
           push_array(copy_array(THIS->a));
      
    }
    else
    {
      Pike_error("Cannot cast to %s\n", type->str );
    }
  }

  }
/*! @decl void clear()
   *!   Clear the contents of the sequence.
   *!
   */

  #define f_Sequence_clear_defined
ptrdiff_t f_Sequence_clear_fun_num = 0;
void f_Sequence_clear(INT32 args) {
#line 437 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("clear",args,0);
{
    should_copy();
    THIS->a=resize_array(THIS->a, 0);
  }   

  }
/*! @decl int delete_value(mixed value)
   *!   Remove the first occurrence of the value @[value] from the sequence.
   *!
   *! @param value
   *!   The value to remove from the sequence.
   *!
   *! @returns
   *!   The index of the removed element or -1 if there was no value to 
   *!   remove.
   */
  
  #define f_Sequence_delete_value_defined
ptrdiff_t f_Sequence_delete_value_fun_num = 0;
void f_Sequence_delete_value(INT32 args) {
#line 454 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * value;
#line 454 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("delete_value",args,1);
#line 454 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
value=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
    INT32 index = array_search(THIS->a, value, 0);
    if (index > -1)
    {
      should_copy();
      THIS->a = array_remove(THIS->a, index);
    }
    do { INT_TYPE ret_=(index); pop_stack(); push_int(ret_); return; }while(0);
#line 463 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

  }
/*! @decl int(0..1) is_empty()
   *!
   *! @returns
   *!   Returns @expr{1@} if the sequence is empty otherwise @expr{0@}. 
   */

  #define f_Sequence_is_empty_defined
ptrdiff_t f_Sequence_is_empty_fun_num = 0;
void f_Sequence_is_empty(INT32 args) {
#line 471 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("is_empty",args,0);
{
    do { INT_TYPE ret_=(!(THIS->a->size));  push_int(ret_); return; }while(0);
#line 474 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

  }
/*! @decl int max_size()
   *!
   *! @returns
   *!   Returns -1.
   */

  #define f_Sequence_max_size_defined
ptrdiff_t f_Sequence_max_size_fun_num = 0;
void f_Sequence_max_size(INT32 args) {
#line 482 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("max_size",args,0);
{
    do { INT_TYPE ret_=(-1);  push_int(ret_); return; }while(0);
#line 485 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

  
  }
/*! @decl void create(array|int arg)
   *!   Creates a new @[Sequence] around the array arg or a new
   *!   @[Sequence] with the size of arg.
   */

  #define f_Sequence_create_defined
ptrdiff_t f_Sequence_create_fun_num = 0;
void f_Sequence_create(INT32 args) {
#line 493 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * arg;
#line 493 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("create",args,1);
#line 493 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
arg=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
    if (arg->type == T_INT)
    {
      THIS->a =allocate_array_no_init(arg->u.integer, 0);
      THIS->a->type_field = BIT_INT;
    }
    else if (arg->type == T_ARRAY)
    {
      add_ref(THIS->a=arg->u.array);
    } 
    pop_n_elems(args);
  }


  
  }
/*! @decl SequenceIterator _get_iterator(void|int ind)
   *!   Create and initiate a new SequenceIterator that could be used
   *!   to iterate over this sequence.
   *!
   *! @param ind
   *!   If an @[ind] value is supplied the iterator will be positioned at
   *!   that index.
   *!
   *! @returns
   *!   An iterator.
   */


  
  /*! @decl SequenceIterator first()
   *!   Create and initiate a new SequenceIterator that could be used
   *!   to iterate over this sequence.
   *!
   *! @returns
   *!   An iterator positioned at the first element in the sequence.
   */

  
  /*! @decl SequenceIterator last()
   *!   Create and initiate a new SequenceIterator that could be used
   *!   to iterate over this sequence.
   *!
   *! @returns
   *!   An iterator positioned after the last element in the sequence.
   */


  
#undef internal_init_Sequence_defined
#define internal_init_Sequence_defined

#undef Sequence_event_handler_defined
#define Sequence_event_handler_defined
static void init_Sequence_struct(void)
#line 542 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
    THIS->a=0;
    THIS->pos=0;
  }

  
#undef internal_exit_Sequence_defined
#define internal_exit_Sequence_defined

#undef Sequence_event_handler_defined
#define Sequence_event_handler_defined
static void exit_Sequence_struct(void)
#line 548 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
    free_array(THIS->a);
  }

  /*! @class SequenceIterator
   *!    This is the iterator for the Sequence. It implements the 
   *!    IndexIterator and the OutputIterator
   */  
  
  
#undef class_Sequence_SequenceIterator_defined
#define class_Sequence_SequenceIterator_defined
struct program *Sequence_SequenceIterator_program=NULL;
static int Sequence_SequenceIterator_program_fun_num=-1;

#undef var_pos_Sequence_SequenceIterator_defined
#define var_pos_Sequence_SequenceIterator_defined

#undef var_sequence_Sequence_SequenceIterator_defined
#define var_sequence_Sequence_SequenceIterator_defined

#undef var_obj_Sequence_SequenceIterator_defined
#define var_obj_Sequence_SequenceIterator_defined

#undef THIS
#define THIS ((struct Sequence_SequenceIterator_struct *)(Pike_interpreter.frame_pointer->current_storage))

#undef THIS_SEQUENCE_SEQUENCEITERATOR
#define THIS_SEQUENCE_SEQUENCEITERATOR ((struct Sequence_SequenceIterator_struct *)(Pike_interpreter.frame_pointer->current_storage))

#undef OBJ2_SEQUENCE_SEQUENCEITERATOR
#define OBJ2_SEQUENCE_SEQUENCEITERATOR(o) ((struct Sequence_SequenceIterator_struct *)(o->storage+Sequence_SequenceIterator_storage_offset))

#undef GET_SEQUENCE_SEQUENCEITERATOR_STORAGE
#define GET_SEQUENCE_SEQUENCEITERATOR_STORAGE ((struct Sequence_SequenceIterator_struct *)(o->storage+Sequence_SequenceIterator_storage_offset)
static ptrdiff_t Sequence_SequenceIterator_storage_offset;
struct Sequence_SequenceIterator_struct {

#ifdef var_pos_Sequence_SequenceIterator_defined
#line 559 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
int pos;
#endif /* var_pos_Sequence_SequenceIterator_defined */

#ifdef var_sequence_Sequence_SequenceIterator_defined
#line 560 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct Sequence_struct *sequence;
#endif /* var_sequence_Sequence_SequenceIterator_defined */

#ifdef var_obj_Sequence_SequenceIterator_defined
#line 561 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object *obj;
#endif /* var_obj_Sequence_SequenceIterator_defined */
};
/*! @decl void create(object sequence, void|int start)
   *!   Creates a new iterator for the sequence @[sequence]. If start is
   *!   supplied it will try to position the iterator at @[start].
   *! 
   */

    #define f_Sequence_SequenceIterator_create_defined
ptrdiff_t f_Sequence_SequenceIterator_create_fun_num = 0;
void f_Sequence_SequenceIterator_create(INT32 args) {
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object * sequence;
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * start;
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args < 1) wrong_number_of_args_error("create",args,1);
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args > 2) wrong_number_of_args_error("create",args,2);
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-args].type != PIKE_T_OBJECT) SIMPLE_BAD_ARG_ERROR("create",1,"object");
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(sequence=Pike_sp[0-args].u.object);
if (args > 1) {
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[1-args].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("create",2,"void|int");
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
start=Pike_sp+1-args; dmalloc_touch_svalue(Pike_sp+1-args);
} else start=0;
#line 571 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      
      if (sequence->prog != Sequence_program)
      {
	SIMPLE_BAD_ARG_ERROR("create",1,"ADT.Sequence");
      
      }
      else
      {
	THIS->sequence = OBJ2_SEQUENCE(sequence);
	add_ref(THIS->obj = sequence);
	if (args == 2) /* if there was an start index supplied */
	{
	  THIS->pos=start->u.integer;
	  if (THIS->sequence->a && ((THIS->pos > THIS->sequence->a->size) 
				   || (THIS->pos < 0)))
	  {
	      Pike_error("Index %d is out of array range 0 - %d.\n", 
			 THIS->pos, 
			 THIS->sequence->a->size);
	  }
	}
	else
	{
	  THIS->pos = 0;
	}
      }
      
    }
    
    }
/*! @decl int index()
     *!   
     *! @returns
     *!    The index at the current position.
     */

    #define f_Sequence_SequenceIterator_index_defined
ptrdiff_t f_Sequence_SequenceIterator_index_fun_num = 0;
void f_Sequence_SequenceIterator_index(INT32 args) {
#line 607 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("index",args,0);
{
      if(!THIS->sequence || 
	 !THIS->sequence->a || 
	 THIS->pos >= THIS->sequence->a->size) 
      {
	push_int(0);
	Pike_sp[-1].subtype=NUMBER_UNDEFINED;
      }
      else
      {
      	do { INT_TYPE ret_=(THIS->pos);  push_int(ret_); return; }while(0);
#line 619 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
    }
    
    
    }
/*! @decl mixed value()
     *!   
     *! @returns
     *!    The value at the current position.
     */

    #define f_Sequence_SequenceIterator_value_defined
ptrdiff_t f_Sequence_SequenceIterator_value_fun_num = 0;
void f_Sequence_SequenceIterator_value(INT32 args) {
#line 629 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("value",args,0);
{
      if(!THIS->sequence || 
	 !THIS->sequence->a || 
	 THIS->pos >= THIS->sequence->a->size) 
      {
	push_int(0);
	Pike_sp[-1].subtype=NUMBER_UNDEFINED;
      }
      else
      {
	push_svalue(THIS->sequence->a->item + THIS->pos);
      }
    }


    }
/*! @decl SequenceIterator `+(int steps)
     *!   Move the iterator @[steps] steps forward (negative value on @[steps]
     *!   will cause the iterator to move backwards) and return the result
     *!   as a new iterator.
     *! @returns
     *!    A new iterator positioned @[steps] steps forward.
     */    

    #define f_Sequence_SequenceIterator_cq__backtick_add_defined
ptrdiff_t f_Sequence_SequenceIterator_cq__backtick_add_fun_num = 0;
void f_Sequence_SequenceIterator_cq__backtick_add(INT32 args) {
#line 653 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
INT_TYPE steps;
#line 653 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`+",args,1);
#line 653 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("`+",1,"int");
steps=Pike_sp[0-1].u.integer;
#line 654 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      struct object *o=low_clone(Sequence_SequenceIterator_program);
      struct Sequence_SequenceIterator_struct *new;
      new = OBJ2_SEQUENCE_SEQUENCEITERATOR(o);
      new[0]=*THIS;
      add_ref(THIS->obj);
      new->pos+=steps;
      if (new->pos < 0) 
      { 
	new->pos = 0;
      }
      else if (new->pos > new->sequence->a->size) 
      { 
	new->pos = new->sequence->a->size; 
      }
      do { struct object * ret_=(o); pop_stack(); push_object(ret_); return; }while(0);
#line 670 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}    

    }
/*! @decl SequenceIterator `+=(int steps)
     *!   Move this iterator @[steps] steps forward (negative value on @[steps]
     *!   will cause the iterator to move backwards) and return the result.
     *!
     *! @returns
     *!    This iterator positioned @[steps] steps forward.
     */    


    #define f_Sequence_SequenceIterator_cq__backtick_add_eq_defined
ptrdiff_t f_Sequence_SequenceIterator_cq__backtick_add_eq_fun_num = 0;
void f_Sequence_SequenceIterator_cq__backtick_add_eq(INT32 args) {
#line 681 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
INT_TYPE steps;
#line 681 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`+=",args,1);
#line 681 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("`+=",1,"int");
steps=Pike_sp[0-1].u.integer;
#line 682 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      THIS->pos+=steps;
      if (THIS->pos < 0) 
      { 
	THIS->pos = 0;
      }
      else if (THIS->pos > THIS->sequence->a->size) 
      { 
	THIS->pos = THIS->sequence->a->size; 
      }
      
      do { struct object * ret_=(Pike_fp->current_object); add_ref(ret_); pop_stack(); push_object(ret_); return; }while(0);
#line 694 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}


    }
/*! @decl SequenceIterator `-(int steps)
     *!   Move the iterator @[steps] steps backwards (negative value on 
     *!   @[steps] will cause the iterator to move forwards) and return 
     *!   the result as a new iterator.
     *! @returns
     *!    A new iterator positioned @[steps] steps backwards.
     */    

    #define f_Sequence_SequenceIterator_cq__backtick_2D_defined
ptrdiff_t f_Sequence_SequenceIterator_cq__backtick_2D_fun_num = 0;
void f_Sequence_SequenceIterator_cq__backtick_2D(INT32 args) {
#line 705 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
INT_TYPE steps;
#line 705 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`-",args,1);
#line 705 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("`-",1,"int");
steps=Pike_sp[0-1].u.integer;
#line 706 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      struct object *o=low_clone(Sequence_SequenceIterator_program);
      struct Sequence_SequenceIterator_struct *new;
      new = OBJ2_SEQUENCE_SEQUENCEITERATOR(o);
      new[0]=*THIS;
      add_ref(THIS->obj);
      new->pos-=steps;
      if (new->pos < 0) 
      { 
	new->pos = 0;
      }
      else if (new->pos > new->sequence->a->size) 
      { 
	new->pos = new->sequence->a->size; 
      }
      do { struct object * ret_=(o); pop_stack(); push_object(ret_); return; }while(0);
#line 722 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

    
    }
/*! @decl int(0..1) has_next(void|int steps)
     *! @returns
     *!    Returns @tt{true@} if it is possible to move @[steps] steps
     *!    forwards, if @[steps] weren't supplied it check if it is
     *!    possible to move one step forward.
     */    

    #define f_Sequence_SequenceIterator_has_next_defined
ptrdiff_t f_Sequence_SequenceIterator_has_next_fun_num = 0;
void f_Sequence_SequenceIterator_has_next(INT32 args) {
#line 732 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * steps;
#line 732 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args > 1) wrong_number_of_args_error("has_next",args,1);
if (args > 0) {
#line 732 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-args].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("has_next",1,"void|int");
#line 732 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
steps=Pike_sp+0-args; dmalloc_touch_svalue(Pike_sp+0-args);
} else steps=0;
#line 733 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      if (args==0)
      {
	do { INT_TYPE ret_=((THIS->sequence && THIS->sequence->a && 
		(THIS->pos + 1) <= THIS->sequence->a->size)); pop_n_elems(args); push_int(ret_); return; }while(0);
#line 738 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
      else
      {	
	do { INT_TYPE ret_=((THIS->sequence && THIS->sequence->a && 
		(THIS->pos + steps->u.integer) >= 0 &&
		(THIS->pos + steps->u.integer) <= THIS->sequence->a->size)); pop_n_elems(args); push_int(ret_); return; }while(0);
#line 744 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
    }
    
    
    }
/*! @decl int(0..1) has_previous(void|int steps)
     *! @returns
     *!    Returns @tt{true@} if it is possible to move @[steps] steps
     *!    backwards, if @[steps] weren't supplied it check if it is
     *!    possible to move one step backward.
     */  

    #define f_Sequence_SequenceIterator_has_previous_defined
ptrdiff_t f_Sequence_SequenceIterator_has_previous_fun_num = 0;
void f_Sequence_SequenceIterator_has_previous(INT32 args) {
#line 755 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * steps;
#line 755 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args > 1) wrong_number_of_args_error("has_previous",args,1);
if (args > 0) {
#line 755 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-args].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("has_previous",1,"void|int");
#line 755 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
steps=Pike_sp+0-args; dmalloc_touch_svalue(Pike_sp+0-args);
} else steps=0;
#line 756 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      if (args==0)
      {
	do { INT_TYPE ret_=((THIS->sequence && THIS->sequence->a &&
		(THIS->pos) > 0)); pop_n_elems(args); push_int(ret_); return; }while(0);
#line 761 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
      else
      {
	do { INT_TYPE ret_=((THIS->sequence && THIS->sequence->a &&
		(THIS->pos - steps->u.integer) >= 0 &&
		(THIS->pos - steps->u.integer) <= THIS->sequence->a->size)); pop_n_elems(args); push_int(ret_); return; }while(0);
#line 767 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
    }

    
    }
/*! @decl int(0..1) `!()
     *! @returns
     *!    Returns @tt{false@} if the iterator has reached the end.
     */  

    #define f_Sequence_SequenceIterator_cq__backtick_21_defined
ptrdiff_t f_Sequence_SequenceIterator_cq__backtick_21_fun_num = 0;
void f_Sequence_SequenceIterator_cq__backtick_21(INT32 args) {
#line 776 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("`!",args,0);
{
      do { INT_TYPE ret_=((THIS->sequence && THIS->sequence->a &&
	      THIS->pos  == THIS->sequence->a->size));  push_int(ret_); return; }while(0);
#line 780 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

    
    }
/*! @decl int(0..1) _equal(mixed iter)
     *!    Compare this iterator with another iterator.
     *! 
     *! @param iter
     *!    The iterator to compare with.
     *! @returns
     *!    Returns @tt{true@} if both iterators iterates over the same
     *!    objects and are positioned at the same spot.
     */  

    #define f_Sequence_SequenceIterator_cq__equal_defined
ptrdiff_t f_Sequence_SequenceIterator_cq__equal_fun_num = 0;
void f_Sequence_SequenceIterator_cq__equal(INT32 args) {
#line 793 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * iter;
#line 793 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("_equal",args,1);
#line 793 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
iter=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
      if (iter->type == T_OBJECT && 
	  iter->u.object->prog == Sequence_SequenceIterator_program)
      {
	/*to do: Check so that it is an SequenceIterator */
	struct Sequence_SequenceIterator_struct *i = 
	  OBJ2_SEQUENCE_SEQUENCEITERATOR(iter->u.object);
	do { INT_TYPE ret_=((THIS->sequence == i->sequence && THIS->pos == i->pos)); pop_stack(); push_int(ret_); return; }while(0);
#line 802 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
      else
      {
	do { INT_TYPE ret_=(0); pop_stack(); push_int(ret_); return; }while(0);
#line 806 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
    }
	
    
    }
/*! @decl int(0..1) `<(mixed iter)
     *!    Less then operator.
     *!
     *! @returns
     *!    Returns @tt{true@} if this iterator has a lower index
     *!    then @[iter].
     */  

    #define f_Sequence_SequenceIterator_cq__backtick_3C_defined
ptrdiff_t f_Sequence_SequenceIterator_cq__backtick_3C_fun_num = 0;
void f_Sequence_SequenceIterator_cq__backtick_3C(INT32 args) {
#line 818 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * iter;
#line 818 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`<",args,1);
#line 818 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
iter=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
      if (iter->type == T_OBJECT &&
	  iter->u.object->prog == Sequence_SequenceIterator_program)
      {
	/*to do: Check so that it is an SequenceIterator */
	struct Sequence_SequenceIterator_struct *i = 
	  OBJ2_SEQUENCE_SEQUENCEITERATOR(iter->u.object);
	do { INT_TYPE ret_=((THIS->pos < i->pos)); pop_stack(); push_int(ret_); return; }while(0);
#line 827 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
      else
      {
	SIMPLE_BAD_ARG_ERROR("`<",1,"ADT.Sequence.SequenceIterator");
      }
    }


    }
/*! @decl int(0..1) `>(mixed iter)
     *!    Greater then operator.
     *!
     *! @returns
     *!    Returns @tt{true@} if this iterator has a higher index
     *!    then @[iter].
     */


    #define f_Sequence_SequenceIterator_cq__backtick_3E_defined
ptrdiff_t f_Sequence_SequenceIterator_cq__backtick_3E_fun_num = 0;
void f_Sequence_SequenceIterator_cq__backtick_3E(INT32 args) {
#line 844 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * iter;
#line 844 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("`>",args,1);
#line 844 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
iter=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
      if (iter->type == T_OBJECT &&
	  iter->u.object->prog == Sequence_SequenceIterator_program)
      {
	/*to do: Check so that it is an SequenceIterator */
	struct Sequence_SequenceIterator_struct *i = 
	  OBJ2_SEQUENCE_SEQUENCEITERATOR(iter->u.object);
	do { INT_TYPE ret_=((THIS->pos > i->pos)); pop_stack(); push_int(ret_); return; }while(0);
#line 853 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
      else
      {
	SIMPLE_BAD_ARG_ERROR("`>",1,"ADT.Sequence.SequenceIterator");
      }
    }

    
    }
/*! @decl int distance(object iter)
     *!
     *! @param iter
     *!    The iterator to measure the distance to.
     *! @returns
     *!    Returns distance between this iterator and @[iter].
     *! @throws
     *!    An error if the two iterator could not be compared.
     */  

    #define f_Sequence_SequenceIterator_distance_defined
ptrdiff_t f_Sequence_SequenceIterator_distance_fun_num = 0;
void f_Sequence_SequenceIterator_distance(INT32 args) {
#line 871 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct object * iter;
#line 871 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("distance",args,1);
#line 871 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-1].type != PIKE_T_OBJECT) SIMPLE_BAD_ARG_ERROR("distance",1,"object");
#line 871 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
debug_malloc_pass(iter=Pike_sp[0-1].u.object);
{
      if (iter->prog == Sequence_SequenceIterator_program)
      {
	
	struct Sequence_SequenceIterator_struct *i = 
	  OBJ2_SEQUENCE_SEQUENCEITERATOR(iter);
	do { INT_TYPE ret_=((i->pos - THIS->pos)); pop_stack(); push_int(ret_); return; }while(0);
#line 879 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}
      else
      {
	SIMPLE_BAD_ARG_ERROR("distance",1,"ADT.Sequence.SequenceIterator");
      }
    }
    
    }
/*! @decl Sequence get_collection()
     *!
     *! @returns
     *!    Returns the Sequence this iterator currently iterates over.
     */  


    #define f_Sequence_SequenceIterator_get_collection_defined
ptrdiff_t f_Sequence_SequenceIterator_get_collection_fun_num = 0;
void f_Sequence_SequenceIterator_get_collection(INT32 args) {
#line 893 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("get_collection",args,0);
{
      do { struct object * ret_=(THIS->obj); add_ref(ret_);  push_object(ret_); return; }while(0);
#line 896 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
}

    
    }
/*! @decl mixed set_value(mixed val)
     *!    Set the value at the current position.
     *!
     *! @param val
     *!    The new value.
     *! @returns
     *!    Returns the old value.
     */  


    #define f_Sequence_SequenceIterator_set_value_defined
ptrdiff_t f_Sequence_SequenceIterator_set_value_fun_num = 0;
void f_Sequence_SequenceIterator_set_value(INT32 args) {
#line 909 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * val;
#line 909 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 1) wrong_number_of_args_error("set_value",args,1);
#line 909 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
val=Pike_sp+0-1; dmalloc_touch_svalue(Pike_sp+0-1);
{
      if (THIS->sequence && THIS->sequence->a &&
	  THIS->pos < THIS->sequence->a->size)
      {
	struct svalue ind;
	struct svalue retval;

	/*if there is someone else using the array but the adapter */
	if (THIS->sequence->a->refs > 1)
	{
	  /*copy it */
	  free_array(THIS->sequence->a);
	  THIS->sequence->a = copy_array(THIS->sequence->a);
	}

	ind.u.integer = THIS->pos;
	ind.type = T_INT;
	simple_array_index_no_free(&retval, THIS->sequence->a, &ind);
	simple_set_index(THIS->sequence->a, &ind, val);
	push_svalue(&retval);
      }
      else
      {
	push_int(0);
	Pike_sp[-1].subtype=NUMBER_UNDEFINED;
      }
    }
    
    }

#undef internal_init_Sequence_SequenceIterator_defined
#define internal_init_Sequence_SequenceIterator_defined

#undef Sequence_SequenceIterator_event_handler_defined
#define Sequence_SequenceIterator_event_handler_defined
static void init_Sequence_SequenceIterator_struct(void)
#line 939 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      THIS->sequence=0;
      THIS->pos=0;
    }

    
#undef internal_exit_Sequence_SequenceIterator_defined
#define internal_exit_Sequence_SequenceIterator_defined

#undef Sequence_SequenceIterator_event_handler_defined
#define Sequence_SequenceIterator_event_handler_defined
static void exit_Sequence_SequenceIterator_struct(void)
#line 945 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
      free_object(THIS->obj);
    }
    
  
#ifdef Sequence_SequenceIterator_event_handler_defined
static void Sequence_SequenceIterator_event_handler(int ev) {
  switch(ev) {

#ifdef internal_init_Sequence_SequenceIterator_defined
  case PROG_EVENT_INIT: init_Sequence_SequenceIterator_struct(); break;

#endif /* internal_init_Sequence_SequenceIterator_defined */

#ifdef internal_exit_Sequence_SequenceIterator_defined
  case PROG_EVENT_EXIT: exit_Sequence_SequenceIterator_struct(); break;

#endif /* internal_exit_Sequence_SequenceIterator_defined */
  default: break; 
  }
}

#endif /* Sequence_SequenceIterator_event_handler_defined */
/*End SequenceIterator */
  /*! @endclass
  */
  
  #define f_Sequence_cq__get_iterator_defined
ptrdiff_t f_Sequence_cq__get_iterator_fun_num = 0;
void f_Sequence_cq__get_iterator(INT32 args) {
#line 955 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
struct svalue * ind;
#line 955 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args > 1) wrong_number_of_args_error("_get_iterator",args,1);
if (args > 0) {
#line 955 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(Pike_sp[0-args].type != PIKE_T_INT) SIMPLE_BAD_ARG_ERROR("_get_iterator",1,"void|int");
#line 955 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
ind=Pike_sp+0-args; dmalloc_touch_svalue(Pike_sp+0-args);
} else ind=0;
#line 956 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
{
    ref_push_object(Pike_fp->current_object);
    if (args > 0)
    {
      push_svalue(ind);
    }
    push_object(clone_object(Sequence_SequenceIterator_program, args+1));
  }

  

  }
#define f_Sequence_first_defined
ptrdiff_t f_Sequence_first_fun_num = 0;
void f_Sequence_first(INT32 args) {
#line 967 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("first",args,0);
{
    ref_push_object(Pike_fp->current_object);
    push_object(clone_object(Sequence_SequenceIterator_program, 1));
  }



  }
#define f_Sequence_last_defined
ptrdiff_t f_Sequence_last_fun_num = 0;
void f_Sequence_last(INT32 args) {
#line 975 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
if(args != 0) wrong_number_of_args_error("last",args,0);
{
    struct svalue ind;
    ind.u.integer=THIS_SEQUENCE->a->size;
    ind.type=T_INT;
    ref_push_object(Pike_fp->current_object);
    push_svalue(&ind);
    push_object(clone_object(Sequence_SequenceIterator_program, 2));
  }

  
}

#ifdef Sequence_event_handler_defined
static void Sequence_event_handler(int ev) {
  switch(ev) {

#ifdef internal_init_Sequence_defined
  case PROG_EVENT_INIT: init_Sequence_struct(); break;

#endif /* internal_init_Sequence_defined */

#ifdef internal_exit_Sequence_defined
  case PROG_EVENT_EXIT: exit_Sequence_struct(); break;

#endif /* internal_exit_Sequence_defined */
  default: break; 
  }
}

#endif /* Sequence_event_handler_defined */
/*End of Sequence */
/*! @endclass    
  */

/*! @endmodule
 */


#line 997 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
void pike_init_Sequence_module(void)
{
  
#ifdef class_Sequence_defined

#ifdef PROG_SEQUENCE_ID
#line 35 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  START_NEW_PROGRAM_ID(SEQUENCE);
#else
#line 35 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  start_new_program();

#endif /* PROG_SEQUENCE_ID */

#ifndef tObjImpl_SEQUENCE

#undef tObjImpl_SEQUENCE
#define tObjImpl_SEQUENCE tObj

#endif /* tObjImpl_SEQUENCE */

#ifdef THIS_SEQUENCE

  Sequence_storage_offset=ADD_STORAGE(struct Sequence_struct);

#endif /* THIS_SEQUENCE */

#ifdef class_Sequence_SequenceIterator_defined

#ifdef PROG_SEQUENCE_SEQUENCEITERATOR_ID
#line 557 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  START_NEW_PROGRAM_ID(SEQUENCE_SEQUENCEITERATOR);
#else
#line 557 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  start_new_program();

#endif /* PROG_SEQUENCE_SEQUENCEITERATOR_ID */

#ifndef tObjImpl_SEQUENCE_SEQUENCEITERATOR

#undef tObjImpl_SEQUENCE_SEQUENCEITERATOR
#define tObjImpl_SEQUENCE_SEQUENCEITERATOR tObj

#endif /* tObjImpl_SEQUENCE_SEQUENCEITERATOR */

#ifdef THIS_SEQUENCE_SEQUENCEITERATOR

  Sequence_SequenceIterator_storage_offset=ADD_STORAGE(struct Sequence_SequenceIterator_struct);

#endif /* THIS_SEQUENCE_SEQUENCEITERATOR */

#ifdef Sequence_SequenceIterator_event_handler_defined
  pike_set_prog_event_callback(Sequence_SequenceIterator_event_handler);

#endif /* Sequence_SequenceIterator_event_handler_defined */

#ifdef f_Sequence_SequenceIterator_create_defined
  f_Sequence_SequenceIterator_create_fun_num =
#line 570 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("create", f_Sequence_SequenceIterator_create, tFunc(tObj tOr(tVoid,"\10\200\0\0\0\177\377\377\377"),tVoid), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_create_defined */

#ifdef f_Sequence_SequenceIterator_index_defined
  f_Sequence_SequenceIterator_index_fun_num =
#line 607 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("index", f_Sequence_SequenceIterator_index, tFunc(tNone,"\10\200\0\0\0\177\377\377\377"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_index_defined */

#ifdef f_Sequence_SequenceIterator_value_defined
  f_Sequence_SequenceIterator_value_fun_num =
#line 629 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("value", f_Sequence_SequenceIterator_value, tFunc(tNone,tMix), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_value_defined */

#ifdef f_Sequence_SequenceIterator_cq__backtick_add_defined
  f_Sequence_SequenceIterator_cq__backtick_add_fun_num =
#line 653 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`+", f_Sequence_SequenceIterator_cq__backtick_add, tFunc("\10\200\0\0\0\177\377\377\377",tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_cq__backtick_add_defined */

#ifdef f_Sequence_SequenceIterator_cq__backtick_add_eq_defined
  f_Sequence_SequenceIterator_cq__backtick_add_eq_fun_num =
#line 681 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`+=", f_Sequence_SequenceIterator_cq__backtick_add_eq, tFunc("\10\200\0\0\0\177\377\377\377",tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_cq__backtick_add_eq_defined */

#ifdef f_Sequence_SequenceIterator_cq__backtick_2D_defined
  f_Sequence_SequenceIterator_cq__backtick_2D_fun_num =
#line 705 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`-", f_Sequence_SequenceIterator_cq__backtick_2D, tFunc("\10\200\0\0\0\177\377\377\377",tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_cq__backtick_2D_defined */

#ifdef f_Sequence_SequenceIterator_has_next_defined
  f_Sequence_SequenceIterator_has_next_fun_num =
#line 732 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("has_next", f_Sequence_SequenceIterator_has_next, tFunc(tOr(tVoid,"\10\200\0\0\0\177\377\377\377"),"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_has_next_defined */

#ifdef f_Sequence_SequenceIterator_has_previous_defined
  f_Sequence_SequenceIterator_has_previous_fun_num =
#line 755 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("has_previous", f_Sequence_SequenceIterator_has_previous, tFunc(tOr(tVoid,"\10\200\0\0\0\177\377\377\377"),"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_has_previous_defined */

#ifdef f_Sequence_SequenceIterator_cq__backtick_21_defined
  f_Sequence_SequenceIterator_cq__backtick_21_fun_num =
#line 776 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`!", f_Sequence_SequenceIterator_cq__backtick_21, tFunc(tNone,"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_cq__backtick_21_defined */

#ifdef f_Sequence_SequenceIterator_cq__equal_defined
  f_Sequence_SequenceIterator_cq__equal_fun_num =
#line 793 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_equal", f_Sequence_SequenceIterator_cq__equal, tFunc(tMix,"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_cq__equal_defined */

#ifdef f_Sequence_SequenceIterator_cq__backtick_3C_defined
  f_Sequence_SequenceIterator_cq__backtick_3C_fun_num =
#line 818 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`<", f_Sequence_SequenceIterator_cq__backtick_3C, tFunc(tMix,"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_cq__backtick_3C_defined */

#ifdef f_Sequence_SequenceIterator_cq__backtick_3E_defined
  f_Sequence_SequenceIterator_cq__backtick_3E_fun_num =
#line 844 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`>", f_Sequence_SequenceIterator_cq__backtick_3E, tFunc(tMix,"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_cq__backtick_3E_defined */

#ifdef f_Sequence_SequenceIterator_distance_defined
  f_Sequence_SequenceIterator_distance_fun_num =
#line 871 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("distance", f_Sequence_SequenceIterator_distance, tFunc(tObj,"\10\200\0\0\0\177\377\377\377"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_distance_defined */

#ifdef f_Sequence_SequenceIterator_get_collection_defined
  f_Sequence_SequenceIterator_get_collection_fun_num =
#line 893 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("get_collection", f_Sequence_SequenceIterator_get_collection, tFunc(tNone,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_get_collection_defined */

#ifdef f_Sequence_SequenceIterator_set_value_defined
  f_Sequence_SequenceIterator_set_value_fun_num =
#line 909 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("set_value", f_Sequence_SequenceIterator_set_value, tFunc(tMix,tMix), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_SequenceIterator_set_value_defined */
#line 557 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  Sequence_SequenceIterator_program=end_program();
#line 557 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  Sequence_SequenceIterator_program_fun_num=add_program_constant("SequenceIterator",Sequence_SequenceIterator_program,0);

#endif /* class_Sequence_SequenceIterator_defined */

#ifdef Sequence_event_handler_defined
  pike_set_prog_event_callback(Sequence_event_handler);

#endif /* Sequence_event_handler_defined */

#ifdef f_Sequence_cq__backtick_5B_5D_defined
  f_Sequence_cq__backtick_5B_5D_fun_num =
#line 67 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`[]", f_Sequence_cq__backtick_5B_5D, tFunc(tMix,tMix), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__backtick_5B_5D_defined */

#ifdef f_Sequence_cq__backtick_5B_5D_eq_defined
  f_Sequence_cq__backtick_5B_5D_eq_fun_num =
#line 89 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`[]=", f_Sequence_cq__backtick_5B_5D_eq, tFunc(tMix tMix,tMix), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__backtick_5B_5D_eq_defined */

#ifdef f_Sequence_cq__backtick_add_defined
  f_Sequence_cq__backtick_add_fun_num =
#line 107 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`+", f_Sequence_cq__backtick_add, tFunc(tObj,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__backtick_add_defined */

#ifdef f_Sequence_cq__backtick_2D_defined
  f_Sequence_cq__backtick_2D_fun_num =
#line 137 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`-", f_Sequence_cq__backtick_2D, tFunc(tObj,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__backtick_2D_defined */

#ifdef f_Sequence_cq__backtick_26_defined
  f_Sequence_cq__backtick_26_fun_num =
#line 167 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`&", f_Sequence_cq__backtick_26, tFunc(tObj,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__backtick_26_defined */

#ifdef f_Sequence_cq__backtick_7C_defined
  f_Sequence_cq__backtick_7C_fun_num =
#line 197 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`|", f_Sequence_cq__backtick_7C, tFunc(tObj,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__backtick_7C_defined */

#ifdef f_Sequence_cq__backtick_5E_defined
  f_Sequence_cq__backtick_5E_fun_num =
#line 229 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("`^", f_Sequence_cq__backtick_5E, tFunc(tObj,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__backtick_5E_defined */

#ifdef f_Sequence_cq__equal_defined
  f_Sequence_cq__equal_fun_num =
#line 254 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_equal", f_Sequence_cq__equal, tFunc(tMix,"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__equal_defined */

#ifdef f_Sequence_cq__indices_defined
  f_Sequence_cq__indices_fun_num =
#line 271 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_indices", f_Sequence_cq__indices, tFunc(tNone,tArray), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__indices_defined */

#ifdef f_Sequence_cq__insert_element_defined
  f_Sequence_cq__insert_element_fun_num =
#line 298 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_insert_element", f_Sequence_cq__insert_element, tFunc("\10\200\0\0\0\177\377\377\377" tMix,tVoid), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__insert_element_defined */

#ifdef f_Sequence_cq__remove_element_defined
  f_Sequence_cq__remove_element_fun_num =
#line 316 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_remove_element", f_Sequence_cq__remove_element, tFunc("\10\200\0\0\0\177\377\377\377",tMix), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__remove_element_defined */

#ifdef f_Sequence_cq__search_defined
  f_Sequence_cq__search_fun_num =
#line 345 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_search", f_Sequence_cq__search, tFunc(tMix tOr(tVoid,"\10\200\0\0\0\177\377\377\377"),"\10\200\0\0\0\177\377\377\377"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__search_defined */

#ifdef f_Sequence_cq__sizeof_defined
  f_Sequence_cq__sizeof_fun_num =
#line 367 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_sizeof", f_Sequence_cq__sizeof, tFunc(tNone,"\10\200\0\0\0\177\377\377\377"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__sizeof_defined */

#ifdef f_Sequence_cq__values_defined
  f_Sequence_cq__values_fun_num =
#line 378 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_values", f_Sequence_cq__values, tFunc(tNone,tArray), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__values_defined */

#ifdef f_Sequence_add_defined
  f_Sequence_add_fun_num =
#line 393 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("add", f_Sequence_add, tFunc(tMix,tVoid), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_add_defined */

#ifdef f_Sequence_cast_defined
  f_Sequence_cast_fun_num =
#line 416 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("cast", f_Sequence_cast, tFunc(tString,tMix), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cast_defined */

#ifdef f_Sequence_clear_defined
  f_Sequence_clear_fun_num =
#line 437 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("clear", f_Sequence_clear, tFunc(tNone,tVoid), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_clear_defined */

#ifdef f_Sequence_delete_value_defined
  f_Sequence_delete_value_fun_num =
#line 454 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("delete_value", f_Sequence_delete_value, tFunc(tMix,"\10\200\0\0\0\177\377\377\377"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_delete_value_defined */

#ifdef f_Sequence_is_empty_defined
  f_Sequence_is_empty_fun_num =
#line 471 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("is_empty", f_Sequence_is_empty, tFunc(tNone,"\10\0\0\0\0\0\0\0\1"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_is_empty_defined */

#ifdef f_Sequence_max_size_defined
  f_Sequence_max_size_fun_num =
#line 482 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("max_size", f_Sequence_max_size, tFunc(tNone,"\10\200\0\0\0\177\377\377\377"), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_max_size_defined */

#ifdef f_Sequence_create_defined
  f_Sequence_create_fun_num =
#line 493 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("create", f_Sequence_create, tFunc(tOr(tArray,"\10\200\0\0\0\177\377\377\377"),tVoid), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_create_defined */

#ifdef f_Sequence_cq__get_iterator_defined
  f_Sequence_cq__get_iterator_fun_num =
#line 955 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("_get_iterator", f_Sequence_cq__get_iterator, tFunc(tOr(tVoid,"\10\200\0\0\0\177\377\377\377"),tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_cq__get_iterator_defined */

#ifdef f_Sequence_first_defined
  f_Sequence_first_fun_num =
#line 967 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("first", f_Sequence_first, tFunc(tNone,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_first_defined */

#ifdef f_Sequence_last_defined
  f_Sequence_last_fun_num =
#line 975 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    ADD_FUNCTION2("last", f_Sequence_last, tFunc(tNone,tObj), 0, OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT);

#endif /* f_Sequence_last_defined */
#line 35 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  Sequence_program=end_program();
#line 35 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
  Sequence_program_fun_num=add_program_constant("Sequence",Sequence_program,0);

#endif /* class_Sequence_defined */
#line 999 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
;
}

void pike_exit_Sequence_module(void)
{
  
#ifdef class_Sequence_defined

#ifdef class_Sequence_SequenceIterator_defined
  if(Sequence_SequenceIterator_program) {
#line 557 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    free_program(Sequence_SequenceIterator_program);
    Sequence_SequenceIterator_program=0;
  }

#endif /* class_Sequence_SequenceIterator_defined */
  if(Sequence_program) {
#line 35 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
    free_program(Sequence_program);
    Sequence_program=0;
  }

#endif /* class_Sequence_defined */
#line 1005 "/Users/hww3/pike/src/post_modules/_ADT/sequence.cmod"
} 

    

