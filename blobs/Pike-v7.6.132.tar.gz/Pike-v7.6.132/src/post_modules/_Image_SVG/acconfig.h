/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: fae71b866553ea0355119ab33a79c12d260ef1a8 $
*/

#undef HAVE_SVG
@TOP@
@BOTTOM@
