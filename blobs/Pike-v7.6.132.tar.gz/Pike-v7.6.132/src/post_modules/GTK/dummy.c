/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: d28241f62e2a06a4e1d0946a2a8e80ed6d9dfbc8 $
*/

#include "global.h"
#include "pgtk_config.h"
#include "module.h"

RCSID("$Id: d28241f62e2a06a4e1d0946a2a8e80ed6d9dfbc8 $");

/* Well... Sort of basic, right? :-) */

PIKE_MODULE_INIT
{
}

PIKE_MODULE_EXIT
{
}
