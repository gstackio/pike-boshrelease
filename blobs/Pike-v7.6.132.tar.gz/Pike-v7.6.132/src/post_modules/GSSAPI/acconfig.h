/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 2c2e0b5773ef9447da77669ea3af9379b6a41f8a $
*/

#undef HAVE_GSSAPI
