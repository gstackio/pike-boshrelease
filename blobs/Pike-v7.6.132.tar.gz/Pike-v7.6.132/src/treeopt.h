/* Tree transformation code.
 *
 * This file was generated from "/Users/hww3/pike/src/treeopt.in" by
 * $Id: 5baa88eb6eeb8c03a9a92e21f10c4f3368607402 $
 *
 * Do NOT edit!
 */

case '?':
  if (!CAR(n)) {
    if (!CDR(n)) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""'?'{601}(-{602}, -{603})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{604}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else {
      if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""'?'{605}(-{606}, ':'{607}(*, 0 = *{609}))""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{610}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CDDR(n),
            tmp1 = CDDR(n);
          );
          goto use_tmp1;
        }
      }
    }
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""'?'{611}(0 = *{612}, -{613})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{614}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((CAAR(n)->u.sval.type == T_FUNCTION) &&
              (CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == f_not)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{621}(F_APPLY{622}(F_CONSTANT{623}[CAAR(n)->u.sval.type == T_FUNCTION][CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == f_not], 0 = *{624}), ':'{625}(1 = *{626}, 2 = *{627}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""'?'{628}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CDAR(n),
                  ADD_NODE_REF2(CDDR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode('?', CDAR(n), mknode(':', CDDR(n), CADR(n)));
                  )));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    }
    if (CDR(n)->token == ':') {
      if (!CADR(n)) {
        if (!CDDR(n)) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{615}(0 = *{616}, ':'{617}(-{618}, -{619}))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{620}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      } else if (!CDDR(n)) {
      } else {
        if ((CDDR(n) == CADR(n))
#ifdef SHARED_NODES_MK2
          || (CDDR(n) && CADR(n) &&
              ((CDDR(n)->master?CDDR(n)->master:CDDR(n))==
               (CADR(n)->master?CADR(n)->master:CADR(n))))
#endif /* SHARED_NODES_MK2 */
          ) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{645}(0 = *{646}, ':'{647}(1 = *{648}, $CADR(n)$))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{649}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
            ADD_NODE_REF2(CADR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAR(n), CADR(n));
            ));
            goto use_tmp1;
          }
        }
        {
          if (CADR(n)->token == F_COMMA_EXPR) {
            if (!CDDR(n)) {
            } else {
              if ((CDDR(n) == CDADR(n))
#ifdef SHARED_NODES_MK2
                || (CDDR(n) && CDADR(n) &&
                    ((CDDR(n)->master?CDDR(n)->master:CDDR(n))==
                     (CDADR(n)->master?CDADR(n)->master:CDADR(n))))
#endif /* SHARED_NODES_MK2 */
                ) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{652}(0 = *{653}, ':'{654}(F_COMMA_EXPR{655}(1 = *{656}, 2 = *{657}), $CDADR(n)$))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_COMMA_EXPR{658}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAR(n),
                  ADD_NODE_REF2(CAADR(n),
                  ADD_NODE_REF2(CDADR(n),
                    tmp1 = mknode(F_COMMA_EXPR, mknode('?', CAR(n), mknode(':', CAADR(n), 0)), CDADR(n));
                  )));
                  goto use_tmp1;
                }
              }
              {
                if (CDDR(n)->token == F_COMMA_EXPR) {
                  {
                    if ((CDDDR(n) == CDADR(n))
#ifdef SHARED_NODES_MK2
                      || (CDDDR(n) && CDADR(n) &&
                          ((CDDDR(n)->master?CDDDR(n)->master:CDDDR(n))==
                           (CDADR(n)->master?CDADR(n)->master:CDADR(n))))
#endif /* SHARED_NODES_MK2 */
                      ) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""'?'{678}(0 = *{679}, ':'{680}(F_COMMA_EXPR{681}(1 = *{682}, 2 = *{683}), F_COMMA_EXPR{684}(3 = *{685}, $CDADR(n)$)))""\n");
                        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "=> ""F_COMMA_EXPR{686}""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                        ADD_NODE_REF2(CAR(n),
                        ADD_NODE_REF2(CAADR(n),
                        ADD_NODE_REF2(CADDR(n),
                        ADD_NODE_REF2(CDADR(n),
                          tmp1 = mknode(F_COMMA_EXPR, mknode('?', CAR(n), mknode(':', CAADR(n), CADDR(n))), CDADR(n));
                        ))));
                        goto use_tmp1;
                      }
                    }
                  }
                }
              }
            }
          }
          if (CDDR(n)->token == F_COMMA_EXPR) {
            {
              if ((CDDDR(n) == CADR(n))
#ifdef SHARED_NODES_MK2
                || (CDDDR(n) && CADR(n) &&
                    ((CDDDR(n)->master?CDDDR(n)->master:CDDDR(n))==
                     (CADR(n)->master?CADR(n)->master:CADR(n))))
#endif /* SHARED_NODES_MK2 */
                ) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""'?'{665}(0 = *{666}, ':'{667}(1 = *{668}, F_COMMA_EXPR{669}(2 = *{670}, $CADR(n)$)))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_COMMA_EXPR{671}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAR(n),
                  ADD_NODE_REF2(CADDR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_COMMA_EXPR, mknode('?', CAR(n), mknode(':', 0, CADDR(n))), CADR(n));
                  )));
                  goto use_tmp1;
                }
              }
            }
          }
          if (!CDDR(n)) {
          } else {
            if (((pike_types_le(CADR(n)->type, void_type_string) !=
		   pike_types_le(CDDR(n)->type, void_type_string)))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""'?'{693}(*, ':'{695}(0 = +{696}, +{697}[(pike_types_le(CADR(n)->type, void_type_string) !=\n\t\t   pike_types_le(CDDR(n)->type, void_type_string))]))""\n");
                }
#endif /* PIKE_DEBUG */
              {
                yyerror("The arguments to ?: may not be void.");
              }
            }
          }
        }
      }
    }
    if (( node_is_tossable(CAR(n)) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
          } else {
            if (CADR(n)->token == F_RETURN) {
              {
                if ((CAADR(n) == CAR(n))
#ifdef SHARED_NODES_MK2
                  || (CAADR(n) && CAR(n) &&
                      ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                       (CAR(n)->master?CAR(n)->master:CAR(n))))
#endif /* SHARED_NODES_MK2 */
                  ) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""'?'{1183}(0 = +{1184}[ node_is_tossable(CAR(n)) ], ':'{1185}(F_RETURN{1186}($CAR(n)$, *), 1 = *{1188}))""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    struct pike_type *type = CAR(n)->type;
                    struct pike_string *tmpname;
                    int tmpvar;
                    void add_local_name(struct pike_string *, struct pike_type *, node *);

                    MAKE_CONST_STRING(tmpname, " ");
                    tmpvar = islocal(tmpname);
                    if(tmpvar == -1)
                    {
                      add_ref(mixed_type_string);
                      add_local_name(tmpname, mixed_type_string, 0);
                      tmpvar = islocal(tmpname);
                    }
                    
                    ADD_NODE_REF2(CDDR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode('?', mknode(F_ASSIGN, CAR(n), mklocalnode(tmpvar,0)),
                  	      mknode(':',mknode(F_RETURN,
                  				mksoftcastnode(type, mklocalnode(tmpvar,0)),
                  				0),
                  		     CDDR(n)));
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    }
    if ((node_is_false(CAR(n)))) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{639}(+{640}[node_is_false(CAR(n))], ':'{641}(*, 0 = *{643}))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{644}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CDDR(n),
              tmp1 = CDDR(n);
            );
            goto use_tmp1;
          }
        }
      }
    }
    if ((node_is_true(CAR(n)))) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""'?'{633}(+{634}[node_is_true(CAR(n))], ':'{635}(0 = *{636}, *))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{638}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CADR(n),
              tmp1 = CADR(n);
            );
            goto use_tmp1;
          }
        }
      }
    }
  }
  break;

case F_ADD_EQ:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
  } else {
    if (CDR(n)->token == F_CONSTANT) {
      if ((CDR(n)->u.sval.type == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == -1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_ADD_EQ{760}(0 = *{761}, 1 = F_CONSTANT{762}[CDR(n)->u.sval.type == T_INT][(CDR(n)->u.sval.u.integer) == -1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC{763}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_DEC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
      if ((CDR(n)->u.sval.type == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == 1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_ADD_EQ{754}(0 = *{755}, 1 = F_CONSTANT{756}[CDR(n)->u.sval.type == T_INT][(CDR(n)->u.sval.u.integer) == 1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC{757}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_INC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
    }
    if (( CAR(n)->token != F_AUTO_MAP_MARKER )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_CONSTANT) {
          if ((CDR(n)->u.sval.type == T_INT) &&
              (!(CDR(n)->u.sval.u.integer))) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_ADD_EQ{750}(0 = +{751}[ CAR(n)->token != F_AUTO_MAP_MARKER ], 1 = F_CONSTANT{752}[CDR(n)->u.sval.type == T_INT][!(CDR(n)->u.sval.u.integer)])""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""0 = *{753}""\n");
              }
#endif /* PIKE_DEBUG */
            goto use_car;
          }
        }
      }
    }
  }
  break;

case F_APPLY:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_APPLY{6}(-{7}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{9}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, CDR(n), 0), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (CAR(n)->token == F_CONSTANT) {
      if ((CAR(n)->u.sval.type == T_FUNCTION) &&
          (CAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_add)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                {
                  if ((CAADR(n) == CAR(n))
#ifdef SHARED_NODES_MK2
                    || (CAADR(n) && CAR(n) &&
                        ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                         (CAR(n)->master?CAR(n)->master:CAR(n))))
#endif /* SHARED_NODES_MK2 */
                    ) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_APPLY{57}(0 = F_CONSTANT{58}[CAR(n)->u.sval.type == T_FUNCTION][CAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_add], 2 = F_ARG_LIST{59}(F_APPLY{60}($CAR(n)$, 1 = *{61}), 3 = *{62}))""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                        node *arglist = CDR(n);
#ifdef SHARED_NODES
                        sub_node(n);
#endif /* SHARED_NODES */
                        ADD_NODE_REF2(CDADR(n),
                        ADD_NODE_REF2(CDDR(n),
                    		  _CDR(n) = mknode(F_ARG_LIST, CDADR(n), CDDR(n))));
#ifdef SHARED_NODES
                        n->hash = hash_node(n);
                        n->node_info |= OPT_DEFROSTED;
#endif /* SHARED_NODES */
                        _CDR(n)->parent = NULL;
                        fix_type_field(_CDR(n));
                        free_node(arglist);
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Result:    ");
                          print_tree(n);
                        }
#endif /* PIKE_DEBUG */
                        continue;
                      }
                  }
                }
              }
            }
          }
        }
      }
      if ((CAR(n)->u.sval.type == T_FUNCTION) &&
          (CAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_minus)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                {
                  if ((CAADR(n) == CAR(n))
#ifdef SHARED_NODES_MK2
                    || (CAADR(n) && CAR(n) &&
                        ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                         (CAR(n)->master?CAR(n)->master:CAR(n))))
#endif /* SHARED_NODES_MK2 */
                    ) {
                    if (!CDADR(n)) {
                    } else {
                      if (CDADR(n)->token == F_ARG_LIST) {
                        if (!CADADR(n)) {
                        } else {
                          if (!CDDADR(n)) {
                          } else {
#ifdef PIKE_DEBUG
                              if (l_flag > 4) {
                                fprintf(stderr, "Match: ""F_APPLY{63}(0 = F_CONSTANT{64}[CAR(n)->u.sval.type == T_FUNCTION][CAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_minus], 2 = F_ARG_LIST{65}(F_APPLY{66}($CAR(n)$, 1 = F_ARG_LIST{67}(+{68}, +{69})), 3 = *{70}))""\n");
                              }
#endif /* PIKE_DEBUG */
                            {
                                node *arglist = CDR(n);
#ifdef SHARED_NODES
                                sub_node(n);
#endif /* SHARED_NODES */
                                ADD_NODE_REF2(CDADR(n),
                                ADD_NODE_REF2(CDDR(n),
                            		  _CDR(n) = mknode(F_ARG_LIST, CDADR(n), CDDR(n))));
#ifdef SHARED_NODES
                                n->hash = hash_node(n);
                                n->node_info |= OPT_DEFROSTED;
#endif /* SHARED_NODES */
                                _CDR(n)->parent = NULL;
                                fix_type_field(_CDR(n));
                                free_node(arglist);
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Result:    ");
                                  print_tree(n);
                                }
#endif /* PIKE_DEBUG */
                                continue;
                              }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((CAR(n)->u.sval.type == T_FUNCTION) &&
          (CAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_multiply)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_ARG_LIST) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_APPLY) {
                {
                  if ((CAADR(n) == CAR(n))
#ifdef SHARED_NODES_MK2
                    || (CAADR(n) && CAR(n) &&
                        ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                         (CAR(n)->master?CAR(n)->master:CAR(n))))
#endif /* SHARED_NODES_MK2 */
                    ) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_APPLY{71}(0 = F_CONSTANT{72}[CAR(n)->u.sval.type == T_FUNCTION][CAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_multiply], 2 = F_ARG_LIST{73}(F_APPLY{74}($CAR(n)$, 1 = *{75}), 3 = *{76}))""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                        node *arglist = CDR(n);
#ifdef SHARED_NODES
                        sub_node(n);
#endif /* SHARED_NODES */
                        ADD_NODE_REF2(CDADR(n),
                        ADD_NODE_REF2(CDDR(n),
                    		  _CDR(n) = mknode(F_ARG_LIST, CDADR(n), CDDR(n))));
#ifdef SHARED_NODES
                        n->hash = hash_node(n);
                        n->node_info |= OPT_DEFROSTED;
#endif /* SHARED_NODES */
                        _CDR(n)->parent = NULL;
                        fix_type_field(_CDR(n));
                        free_node(arglist);
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Result:    ");
                          print_tree(n);
                        }
#endif /* PIKE_DEBUG */
                        continue;
                      }
                  }
                }
              }
            }
          }
        }
      }
      if ((CAR(n)->u.sval.type == T_FUNCTION) &&
          (CAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->function == f_sizeof)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_APPLY) {
            if (!CADR(n)) {
            } else {
              if (CADR(n)->token == F_CONSTANT) {
                if ((CADR(n)->u.sval.type == T_FUNCTION) &&
                    (CADR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
                    (CADR(n)->u.sval.u.efun->function == f_multiply)) {
                  if (!CDDR(n)) {
                  } else {
                    if (CDDR(n)->token == F_ARG_LIST) {
                      if (!CADDR(n)) {
                      } else {
                        if ((!match_types(object_type_string, CADDR(n)->type))) {
                          if (!CDDDR(n)) {
                          } else {
                            if ((pike_types_le(CDDDR(n)->type, int_type_string))) {
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Match: ""F_APPLY{43}(0 = F_CONSTANT{44}[CAR(n)->u.sval.type == T_FUNCTION][CAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_sizeof], F_APPLY{45}(1 = F_CONSTANT{46}[CADR(n)->u.sval.type == T_FUNCTION][CADR(n)->u.sval.subtype == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_multiply], F_ARG_LIST{47}(2 = +{48}[!match_types(object_type_string, CADDR(n)->type)], 3 = +{49}[pike_types_le(CDDDR(n)->type, int_type_string)])))""\n");
                                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "=> ""F_APPLY{50}""\n");
                                }
#endif /* PIKE_DEBUG */
                              {
                                ADD_NODE_REF2(CADR(n),
                                ADD_NODE_REF2(CAR(n),
                                ADD_NODE_REF2(CADDR(n),
                                ADD_NODE_REF2(CDDDR(n),
                                  tmp1 = mknode(F_APPLY, CADR(n), mknode(F_ARG_LIST, mknode(F_APPLY, CAR(n), CADDR(n)), CDDDR(n)));
                                ))));
                                goto use_tmp1;
                              }
                            }
                          }
                        }
                        if ((pike_types_le(CADDR(n)->type, int_type_string))) {
                          if (!CDDDR(n)) {
                          } else {
                            if ((!match_types(object_type_string, CDDDR(n)->type))) {
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Match: ""F_APPLY{29}(0 = F_CONSTANT{30}[CAR(n)->u.sval.type == T_FUNCTION][CAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->function == f_sizeof], F_APPLY{31}(1 = F_CONSTANT{32}[CADR(n)->u.sval.type == T_FUNCTION][CADR(n)->u.sval.subtype == FUNCTION_BUILTIN][CADR(n)->u.sval.u.efun->function == f_multiply], F_ARG_LIST{33}(2 = +{34}[pike_types_le(CADDR(n)->type, int_type_string)], 3 = +{35}[!match_types(object_type_string, CDDDR(n)->type)])))""\n");
                                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "=> ""F_APPLY{36}""\n");
                                }
#endif /* PIKE_DEBUG */
                              {
                                ADD_NODE_REF2(CADR(n),
                                ADD_NODE_REF2(CADDR(n),
                                ADD_NODE_REF2(CAR(n),
                                ADD_NODE_REF2(CDDDR(n),
                                  tmp1 = mknode(F_APPLY, CADR(n), mknode(F_ARG_LIST, CADDR(n), mknode(F_APPLY, CAR(n), CDDDR(n))));
                                ))));
                                goto use_tmp1;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      if ((CAR(n)->u.sval.type == T_FUNCTION) &&
          (CAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
          (CAR(n)->u.sval.u.efun->optimize) &&
          ( (tmp1=CAR(n)->u.sval.u.efun->optimize(n)) )) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_APPLY{0}(F_CONSTANT{1}[CAR(n)->u.sval.type == T_FUNCTION][CAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAR(n)->u.sval.u.efun->optimize][ (tmp1=CAR(n)->u.sval.u.efun->optimize(n)) ], *)""\n");
          }
#endif /* PIKE_DEBUG */
        {
          goto use_tmp1;
        }
      }
      if ((CAR(n)->u.sval.type == T_PROGRAM) &&
          (CAR(n)->u.sval.u.program->optimize) &&
          ( (tmp1=CAR(n)->u.sval.u.program->optimize(n)) )) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_APPLY{3}(F_CONSTANT{4}[CAR(n)->u.sval.type == T_PROGRAM][CAR(n)->u.sval.u.program->optimize][ (tmp1=CAR(n)->u.sval.u.program->optimize(n)) ], *)""\n");
          }
#endif /* PIKE_DEBUG */
        {
          goto use_tmp1;
        }
      }
    }
  }
  break;

case F_ARG_LIST:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_ARG_LIST{397}(-{398}, 0 = *{399})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{400}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_ARG_LIST{401}(0 = *{402}, -{403})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{404}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_BREAK) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_ARG_LIST{413}(0 = F_BREAK{414}, +{415}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{416}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_BREAK) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARG_LIST{429}(0 = F_COMMA_EXPR{430}(*, F_BREAK{432}), +{433}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{434}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_CONTINUE) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARG_LIST{423}(0 = F_COMMA_EXPR{424}(*, F_CONTINUE{426}), +{427}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{428}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_RETURN) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARG_LIST{417}(0 = F_COMMA_EXPR{418}(*, F_RETURN{420}), +{421}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{422}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONTINUE) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_ARG_LIST{409}(0 = F_CONTINUE{410}, +{411}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{412}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_RETURN) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_ARG_LIST{405}(0 = F_RETURN{406}, +{407}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{408}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
  }
  break;

case F_ARROW:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_ARROW{796}(-{797}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{799}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, CDR(n), 0), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (CAR(n)->token == F_CONSTANT) {
      if ((CAR(n)->u.sval.type == T_OBJECT) &&
          (CAR(n)->u.sval.u.object->prog)) {
        if (!CDR(n)) {
        } else {
          if (CDR(n)->token == F_CONSTANT) {
            if ((CDR(n)->u.sval.type == T_STRING)) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_ARROW{804}(0 = F_CONSTANT{805}[CAR(n)->u.sval.type == T_OBJECT][CAR(n)->u.sval.u.object->prog], 1 = F_CONSTANT{806}[CDR(n)->u.sval.type == T_STRING])""\n");
                }
#endif /* PIKE_DEBUG */
              {
                /*
                if (find_identifier("`->", CAR(n)->u.sval.u.object->prog) == -1) {
                  int i = find_shared_string_identifier(CDR(n)->u.sval.u.string,
              					  CAR(n)->u.sval.u.object->prog);
                  if (i) {
                    struct identifier *id = ID_FROM_INT(CAR(n)->u.sval.u.object->prog, i);
                    if (IDENTIFIER_IS_VARIABLE(id->identifier_flags))
              	goto next_arrow_opt;
                  }
                  ref_push_object(CAR(n)->u.sval.u.object);
                  ref_push_string(CDR(n)->u.sval.u.string);
                  f_index(2);
                  tmp1 = mksvaluenode(sp-1);
                  pop_stack();
                  goto use_tmp1;
                }
               next_arrow_opt:
                ;
                */
              }
            }
          }
        }
      }
    }
  }
  break;

case F_CAST:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_CAST{185}(-{186}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{188}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else {
    if (CAR(n)->token == F_CAST) {
      if ((CAR(n)->type == n->type)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_CAST{192}(1 = F_CAST{193}[CAR(n)->type == n->type], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""1 = *{197}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    } else if (CAR(n)->token == F_CONSTANT) {
      if ((CAR(n)->type == n->type)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""0 = F_CAST{198}(1 = F_CONSTANT{199}[CAR(n)->type == n->type], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""1 = *{203}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    }
    if ((CAR(n)->type == void_type_string)) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_CAST{189}(0 = +{190}[CAR(n)->type == void_type_string], *)""\n");
        }
#endif /* PIKE_DEBUG */
      {
        yywarning("Casting a void expression\n");
        
        ADD_NODE_REF2(CAR(n),
          tmp1 = CAR(n);
        );
        goto use_tmp1;
      }
    }
  }
  break;

case F_COMMA_EXPR:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_COMMA_EXPR{214}(-{215}, 0 = *{216})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{217}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_COMMA_EXPR{218}(0 = *{219}, -{220})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{221}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_ARG_LIST) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_COMMA_EXPR{287}(F_ARG_LIST{288}(0 = *{289}, 1 = *{290}), 2 = *{291})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_COMMA_EXPR{292}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
        ADD_NODE_REF2(CDR(n),
          tmp1 = mknode(F_COMMA_EXPR, mknode(F_COMMA_EXPR, CAAR(n), CDAR(n)), CDR(n));
        )));
        goto use_tmp1;
      }
    } else if (CAR(n)->token == F_ASSIGN) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_LOCAL) {
          if (!CDR(n)) {
          } else {
            if (CDR(n)->token == F_COMMA_EXPR) {
              if (!CADR(n)) {
              } else {
                if (CADR(n)->token == F_DEC) {
                  if (!CDADR(n)) {
                    if (!CAADR(n)) {
                    } else {
                      if (CAADR(n)->token == F_LOCAL) {
                        if ((CDAR(n)->u.integer.a == CAADR(n)->u.integer.a) &&
                            (CDAR(n)->u.integer.b == CAADR(n)->u.integer.b)) {
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "Match: ""F_COMMA_EXPR{379}(F_ASSIGN{380}(0 = *{381}, 1 = F_LOCAL{382}), F_COMMA_EXPR{383}(F_DEC{384}(F_LOCAL{385}[CDAR(n)->u.integer.a == CAADR(n)->u.integer.a][CDAR(n)->u.integer.b == CAADR(n)->u.integer.b], -{386}), 2 = *{387}))""\n");
                            }
#endif /* PIKE_DEBUG */
                          {
                              
                            ADD_NODE_REF2(CDDR(n),
                            ADD_NODE_REF2(CDAR(n),
                            ADD_NODE_REF2(CAAR(n),
                              tmp1 = mknode(F_COMMA_EXPR,
                          		mknode(F_ASSIGN,
                          		       mkefuncallnode("`-",
                          				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                          		       CDAR(n)),
                          		CDDR(n));
                            )));
                            goto use_tmp1;
                            }
                        }
                      }
                    }
                  }
                } else if (CADR(n)->token == F_INC) {
                  if (!CDADR(n)) {
                    if (!CAADR(n)) {
                    } else {
                      if (CAADR(n)->token == F_LOCAL) {
                        if ((CDAR(n)->u.integer.a == CAADR(n)->u.integer.a) &&
                            (CDAR(n)->u.integer.b == CAADR(n)->u.integer.b)) {
#ifdef PIKE_DEBUG
                            if (l_flag > 4) {
                              fprintf(stderr, "Match: ""F_COMMA_EXPR{388}(F_ASSIGN{389}(0 = *{390}, 1 = F_LOCAL{391}), F_COMMA_EXPR{392}(F_INC{393}(F_LOCAL{394}[CDAR(n)->u.integer.a == CAADR(n)->u.integer.a][CDAR(n)->u.integer.b == CAADR(n)->u.integer.b], -{395}), 2 = *{396}))""\n");
                            }
#endif /* PIKE_DEBUG */
                          {
                              
                            ADD_NODE_REF2(CDDR(n),
                            ADD_NODE_REF2(CDAR(n),
                            ADD_NODE_REF2(CAAR(n),
                              tmp1 = mknode(F_COMMA_EXPR,
                          		mknode(F_ASSIGN,
                          		       mkefuncallnode("`+",
                          				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                          		       CDAR(n)),
                          		CDDR(n));
                            )));
                            goto use_tmp1;
                            }
                        }
                      }
                    }
                  }
                }
              }
            } else if (CDR(n)->token == F_DEC) {
              if (!CDDR(n)) {
                if (!CADR(n)) {
                } else {
                  if (CADR(n)->token == F_LOCAL) {
                    if (( CDAR(n)->u.integer.a == CADR(n)->u.integer.a ) &&
                        ( CDAR(n)->u.integer.b == CADR(n)->u.integer.b )) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_COMMA_EXPR{365}(F_ASSIGN{366}(0 = *{367}, 1 = F_LOCAL{368}), F_DEC{369}(F_LOCAL{370}[ CDAR(n)->u.integer.a == CADR(n)->u.integer.a ][ CDAR(n)->u.integer.b == CADR(n)->u.integer.b ], -{371}))""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                          
                        ADD_NODE_REF2(CDAR(n),
                        ADD_NODE_REF2(CAAR(n),
                          tmp1 = mknode(F_ASSIGN,
                      		mkefuncallnode("`-",
                      			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                        ));
                        goto use_tmp1;
                        }
                    }
                  }
                }
              }
            } else if (CDR(n)->token == F_INC) {
              if (!CDDR(n)) {
                if (!CADR(n)) {
                } else {
                  if (CADR(n)->token == F_LOCAL) {
                    if (( CDAR(n)->u.integer.a == CADR(n)->u.integer.a ) &&
                        ( CDAR(n)->u.integer.b == CADR(n)->u.integer.b )) {
#ifdef PIKE_DEBUG
                        if (l_flag > 4) {
                          fprintf(stderr, "Match: ""F_COMMA_EXPR{372}(F_ASSIGN{373}(0 = *{374}, 1 = F_LOCAL{375}), F_INC{376}(F_LOCAL{377}[ CDAR(n)->u.integer.a == CADR(n)->u.integer.a ][ CDAR(n)->u.integer.b == CADR(n)->u.integer.b ], -{378}))""\n");
                        }
#endif /* PIKE_DEBUG */
                      {
                          
                        ADD_NODE_REF2(CDAR(n),
                        ADD_NODE_REF2(CAAR(n),
                          tmp1 = mknode(F_ASSIGN,
                      		mkefuncallnode("`+",
                      			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                        ));
                        goto use_tmp1;
                        }
                    }
                  }
                }
              }
            }
          }
        }
        if ((!depend_p(CDAR(n), CDAR(n)))) {
          if (!CDR(n)) {
          } else {
            if (CDR(n)->token == F_COMMA_EXPR) {
              if (!CADR(n)) {
              } else {
                if (CADR(n)->token == F_DEC) {
                  {
                    if ((CAADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                      || (CAADR(n) && CDAR(n) &&
                          ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                           (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                      ) {
                      if (!CDADR(n)) {
#ifdef PIKE_DEBUG
                          if (l_flag > 4) {
                            fprintf(stderr, "Match: ""F_COMMA_EXPR{349}(F_ASSIGN{350}(0 = *{351}, 1 = +{352}[!depend_p(CDAR(n), CDAR(n))]), F_COMMA_EXPR{353}(F_DEC{354}($CDAR(n)$, -{355}), 2 = *{356}))""\n");
                          }
#endif /* PIKE_DEBUG */
                        {
                            
                          ADD_NODE_REF2(CDDR(n),
                          ADD_NODE_REF2(CDAR(n),
                          ADD_NODE_REF2(CAAR(n),
                            tmp1 = mknode(F_COMMA_EXPR,
                        		mknode(F_ASSIGN,
                        		       mkefuncallnode("`-",
                        				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                        		       CDAR(n)),
                        		CDDR(n));
                          )));
                          goto use_tmp1;
                          }
                      }
                    }
                  }
                } else if (CADR(n)->token == F_INC) {
                  {
                    if ((CAADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                      || (CAADR(n) && CDAR(n) &&
                          ((CAADR(n)->master?CAADR(n)->master:CAADR(n))==
                           (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                      ) {
                      if (!CDADR(n)) {
#ifdef PIKE_DEBUG
                          if (l_flag > 4) {
                            fprintf(stderr, "Match: ""F_COMMA_EXPR{357}(F_ASSIGN{358}(0 = *{359}, 1 = +{360}[!depend_p(CDAR(n), CDAR(n))]), F_COMMA_EXPR{361}(F_INC{362}($CDAR(n)$, -{363}), 2 = *{364}))""\n");
                          }
#endif /* PIKE_DEBUG */
                        {
                            
                          ADD_NODE_REF2(CDDR(n),
                          ADD_NODE_REF2(CDAR(n),
                          ADD_NODE_REF2(CAAR(n),
                            tmp1 = mknode(F_COMMA_EXPR,
                        		mknode(F_ASSIGN,
                        		       mkefuncallnode("`+",
                        				      mknode(F_ARG_LIST, CAAR(n), mkintnode(1))),
                        		       CDAR(n)),
                        		CDDR(n));
                          )));
                          goto use_tmp1;
                          }
                      }
                    }
                  }
                }
              }
            } else if (CDR(n)->token == F_DEC) {
              {
                if ((CADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                  || (CADR(n) && CDAR(n) &&
                      ((CADR(n)->master?CADR(n)->master:CADR(n))==
                       (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                  ) {
                  if (!CDDR(n)) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_COMMA_EXPR{337}(F_ASSIGN{338}(0 = *{339}, 1 = +{340}[!depend_p(CDAR(n), CDAR(n))]), F_DEC{341}($CDAR(n)$, -{342}))""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                        
                      ADD_NODE_REF2(CDAR(n),
                      ADD_NODE_REF2(CAAR(n),
                        tmp1 = mknode(F_ASSIGN,
                    		mkefuncallnode("`-",
                    			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                      ));
                      goto use_tmp1;
                      }
                  }
                }
              }
            } else if (CDR(n)->token == F_INC) {
              {
                if ((CADR(n) == CDAR(n))
#ifdef SHARED_NODES_MK2
                  || (CADR(n) && CDAR(n) &&
                      ((CADR(n)->master?CADR(n)->master:CADR(n))==
                       (CDAR(n)->master?CDAR(n)->master:CDAR(n))))
#endif /* SHARED_NODES_MK2 */
                  ) {
                  if (!CDDR(n)) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_COMMA_EXPR{343}(F_ASSIGN{344}(0 = *{345}, 1 = +{346}[!depend_p(CDAR(n), CDAR(n))]), F_INC{347}($CDAR(n)$, -{348}))""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                        
                      ADD_NODE_REF2(CDAR(n),
                      ADD_NODE_REF2(CAAR(n),
                        tmp1 = mknode(F_ASSIGN,
                    		mkefuncallnode("`+",
                    			       mknode(F_ARG_LIST, CAAR(n), mkintnode(1))), CDAR(n));
                      ));
                      goto use_tmp1;
                      }
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_BREAK) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_COMMA_EXPR{315}(0 = F_BREAK{316}, +{317}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{318}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_CAST) {
      if (!CDR(n)) {
      } else {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_COMMA_EXPR{274}(F_CAST{275}(0 = *{276}, *), 1 = +{278})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_COMMA_EXPR{279}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
          ADD_NODE_REF2(CDR(n),
            tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CDR(n));
          ));
          goto use_tmp1;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_BREAK) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{331}(0 = F_COMMA_EXPR{332}(*, F_BREAK{334}), +{335}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{336}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_CONSTANT) {
          if (!CDR(n)) {
          } else {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_COMMA_EXPR{230}(F_COMMA_EXPR{231}(0 = *{232}, F_CONSTANT{233}), 1 = +{234})""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_COMMA_EXPR{235}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAAR(n),
              ADD_NODE_REF2(CDR(n),
                tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CDR(n));
              ));
              goto use_tmp1;
            }
          }
        } else if (CDAR(n)->token == F_CONTINUE) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{325}(0 = F_COMMA_EXPR{326}(*, F_CONTINUE{328}), +{329}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{330}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_POP_VALUE) {
          if (!CDR(n)) {
          } else {
            if (CDR(n)->token == F_POP_VALUE) {
              if (!CADR(n)) {
              } else {
                if ((!(CADR(n)->tree_info & OPT_APPLY))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_COMMA_EXPR{258}(F_COMMA_EXPR{259}(0 = *{260}, F_POP_VALUE{261}(1 = *{262}, *)), F_POP_VALUE{264}(2 = +{265}[!(CADR(n)->tree_info & OPT_APPLY)], *))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_COMMA_EXPR{267}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADAR(n),
                    ADD_NODE_REF2(CADR(n),
                      tmp1 = mknode(F_COMMA_EXPR, CAAR(n), mknode(F_POP_VALUE, mknode(F_COMMA_EXPR, CADAR(n), CADR(n)), 0));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDAR(n)->token == F_RETURN) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{319}(0 = F_COMMA_EXPR{320}(*, F_RETURN{322}), +{323}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{324}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        }
        if ((node_is_tossable(CDAR(n)))) {
          if (!CDR(n)) {
          } else {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_COMMA_EXPR{238}(F_COMMA_EXPR{239}(0 = *{240}, +{241}[node_is_tossable(CDAR(n))]), 1 = +{242})""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_COMMA_EXPR{243}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAAR(n),
              ADD_NODE_REF2(CDR(n),
                tmp1 = mknode(F_COMMA_EXPR, CAAR(n), CDR(n));
              ));
              goto use_tmp1;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONSTANT) {
      if (!CDR(n)) {
      } else {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_COMMA_EXPR{222}(F_CONSTANT{223}, 0 = +{224})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{225}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
    } else if (CAR(n)->token == F_CONTINUE) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_COMMA_EXPR{311}(0 = F_CONTINUE{312}, +{313}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{314}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_POP_VALUE) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_POP_VALUE) {
          if (!CADR(n)) {
          } else {
            if ((!(CADR(n)->tree_info & OPT_APPLY))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_COMMA_EXPR{246}(F_POP_VALUE{247}(0 = *{248}, *), F_POP_VALUE{250}(1 = +{251}[!(CADR(n)->tree_info & OPT_APPLY)], *))""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""F_POP_VALUE{253}""\n");
                }
#endif /* PIKE_DEBUG */
              {
                ADD_NODE_REF2(CAAR(n),
                ADD_NODE_REF2(CADR(n),
                  tmp1 = mknode(F_POP_VALUE, mknode(F_COMMA_EXPR, CAAR(n), CADR(n)), 0);
                ));
                goto use_tmp1;
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_RETURN) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_COMMA_EXPR{307}(0 = F_RETURN{308}, +{309}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{310}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
    if (CDR(n)->token == F_CAST) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_COMMA_EXPR{282}(0 = *{283}, 1 = F_CAST{284}(2 = *{285}, *))""\n");
        }
#endif /* PIKE_DEBUG */
      {
        struct pike_type *type = CDR(n)->type;
        
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CAR(n),
          tmp1 = mkcastnode(type, mknode(F_COMMA_EXPR, CAR(n), CADR(n)));
        ));
        goto use_tmp1;
      }
    } else if (CDR(n)->token == F_COMMA_EXPR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_COMMA_EXPR{297}(0 = *{298}, F_COMMA_EXPR{299}(1 = *{300}, 2 = *{301}))""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_COMMA_EXPR{302}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAR(n),
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CDDR(n),
          tmp1 = mknode(F_COMMA_EXPR, mknode(F_COMMA_EXPR, CAR(n), CADR(n)), CDDR(n));
        )));
        goto use_tmp1;
      }
    }
    if ((node_is_tossable(CAR(n)))) {
      if (!CDR(n)) {
      } else {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_COMMA_EXPR{226}(+{227}[node_is_tossable(CAR(n))], 0 = +{228})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{229}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
    }
  }
  break;

case F_DO:
  if (!CAR(n)) {
    if (!CDR(n)) {
    } else {
      if ((node_is_true(CDR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_DO{815}(-{816}, 0 = +{817}[node_is_true(CDR(n))])""\n");
          }
#endif /* PIKE_DEBUG */
        {
          /* Infinite loop */
          
          ADD_NODE_REF2(CDR(n),
            tmp1 = mknode(F_DO, mkefuncallnode("sleep", mkintnode(255)), CDR(n));
          );
          goto use_tmp1;
        }
      }
    }
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if ((!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_DO{807}(0 = +{808}[!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE))], -{809})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{810}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    }
  } else {
    if ((!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)))) {
      if (!CDR(n)) {
      } else {
        if ((node_is_false(CDR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_DO{811}(0 = +{812}[!(CAR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE))], +{813}[node_is_false(CDR(n))])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{814}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
  }
  break;

case F_FOR:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_FOR{895}(-{896}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{898}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if (CAR(n)->token == F_DEC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1010}(F_DEC{1011}(0 = *{1012}, *), -{1014})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1015}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      } else if (CAR(n)->token == F_INC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{914}(F_INC{915}(0 = *{916}, *), -{918})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC_NEQ_LOOP{919}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      } else if (CAR(n)->token == F_POST_DEC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{1058}(F_POST_DEC{1059}(0 = *{1060}, *), -{1062})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1063}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      } else if (CAR(n)->token == F_POST_INC) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{962}(F_POST_INC{963}(0 = *{964}, *), -{966})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC_NEQ_LOOP{967}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), 0);
          );
          goto use_tmp1;
        }
      }
      if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{907}(+{908}[node_is_false(CAR(n))], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""-{910}""\n");
          }
#endif /* PIKE_DEBUG */
        goto zap_node;
      }
      if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOR{911}(0 = +{912}[node_is_true(CAR(n))], -{913})""\n");
          }
#endif /* PIKE_DEBUG */
        {
          /* Infinite loop */
          
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_FOR, CAR(n), mknode(':',
        				mkefuncallnode("sleep", mkintnode(255)),
        				0));
          );
          goto use_tmp1;
        }
      }
    }
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((CAAR(n)->u.sval.type == T_FUNCTION) &&
              (CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == ':') {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1118}(0 = F_APPLY{1119}(1 = F_CONSTANT{1120}[CAAR(n)->u.sval.type == T_FUNCTION][CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN], 2 = *{1121}), 4 = ':'{1122}(3 = *{1123}, *))""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  node **last;

                  /* Last is a pointer to the place where the incrementor is in the
                   * tree. This is needed so we can nullify this pointer later and
                   * free the rest of the tree
                   */
                  last = &_CDR(CDR(n));
                  tmp1 = *last;

                  /* We're not interested in casts to void */
                  while(tmp1 &&
                	( (tmp1->token == F_CAST && tmp1->type == void_type_string) ||
                	  tmp1->token == F_POP_VALUE))
                  {
                    last = &_CAR(tmp1);
                    tmp1 = *last;
                  }

                  /* If there is an incrementor, and it is one of x++, ++x, x-- or ++x */
                  if(tmp1 && (tmp1->token == F_INC ||
                	      tmp1->token == F_POST_INC ||
                	      tmp1->token == F_DEC ||
                	      tmp1->token == F_POST_DEC))
                  {
                    node **arg1, **arg2;
                    int oper;
                    int inc;
                    int token;

                    /* does it increment or decrement ? */
                    inc = (tmp1->token==F_INC || tmp1->token==F_POST_INC);

                    /* for(; arg1 oper arg2; z ++) p; */

                    if(CAAR(n)->u.sval.u.efun->function == f_gt)
                      oper = F_GT;
                    else if(CAAR(n)->u.sval.u.efun->function == f_ge)
                      oper = F_GE;
                    else if(CAAR(n)->u.sval.u.efun->function == f_lt)
                      oper = F_LT;
                    else if(CAAR(n)->u.sval.u.efun->function == f_le)
                      oper = F_LE;
                    else if(CAAR(n)->u.sval.u.efun->function == f_ne)
                      oper = F_NE;
                    else
                      goto next_for_opt;

                    if(count_args(CDAR(n)) != 2)
                      goto next_for_opt;

                    arg1 = my_get_arg(&_CDR(CAR(n)), 0);
                    arg2 = my_get_arg(&_CDR(CAR(n)), 1);

                    /* it was not on the form for(; x op y; z++) p; */
                    if(!node_is_eq(*arg1, CAR(tmp1)) || /* x == z */
                       depend_p(*arg2, *arg2) ||	/* does y depend on y? */
                       depend_p(*arg2, *arg1) ||	/* does y depend on x? */
                       depend_p(*arg2, CADR(n)) ||		/* does y depend on p? */
                       depend_p(*arg2, tmp1))		/* does y depend on z? */
                    {
                      /* it was not on the form for(; x op y; z++) p; */
                      if(!node_is_eq(*arg2, CAR(tmp1)) || /* y == z */
                	 depend_p(*arg1, *arg2) ||	/* does x depend on y? */
                	 depend_p(*arg1, *arg1) ||	/* does x depend on x? */
                	 depend_p(*arg1, CADR(n)) ||		/* does x depend on p? */
                	 depend_p(*arg1, tmp1))		/* does x depend on z? */
                      {
                	/* it was not on the form for(; x op y; y++) p; */
                	goto next_for_opt;
                      }else{
                	node **tmparg;
                	/* for(; x op y; y++) p; -> for(; y op^-1 x; y++) p; */
                	
                	switch(oper)
                	{
                	case F_LT: oper = F_GT; break;
                	case F_LE: oper = F_GE; break;
                	case F_GT: oper = F_LT; break;
                	case F_GE: oper = F_LE; break;
                	}
                	    
                	tmparg = arg1;
                	arg1 = arg2;
                	arg2 = tmparg;
                      }
                    }

                    if(inc)
                    {
                      if(oper == F_LE) {
                	static struct pike_string *plus_name;
                	node *n;
                	if ((!plus_name && !(plus_name = findstring("`+"))) ||
                	    !(n=find_module_identifier(plus_name, 0))) {
                	  my_yyerror("Internally used efun undefined: `+");
                	  tmp3 = mkintnode(0);
                        } else {
                	  ADD_NODE_REF2(*arg2,
                	    tmp3 = mkapplynode(n, mknode(F_ARG_LIST, *arg2, mkintnode(1)));
                	  );
                	}
                      } else if(oper == F_LT) {
                	ADD_NODE_REF2(*arg2,
                	  tmp3 = *arg2;
                	);
                      } else
                	goto next_for_opt;
                    }else{
                      if(oper == F_GE) {
                	static struct pike_string *minus_name;
                	node *n;
                	if ((!minus_name && !(minus_name = findstring("`-"))) ||
                	    !(n=find_module_identifier(minus_name, 0))) {
                	  my_yyerror("Internally used efun undefined: `-");
                	  tmp3 = mkintnode(0);
                        } else {
                	  ADD_NODE_REF2(*arg2,
                	    tmp3 = mkapplynode(n, mknode(F_ARG_LIST, *arg2, mkintnode(1)));
                	  );
                	}
                      } else if(oper == F_GT) {
                	ADD_NODE_REF2(*arg2,
                	  tmp3 = *arg2;
                	);
                      } else
                	goto next_for_opt;
                    }
                    if(oper == F_NE)
                    {
                      if(inc)
                	token = F_INC_NEQ_LOOP;
                      else
                	token = F_DEC_NEQ_LOOP;
                    }else{
                      if(inc)
                	token = F_INC_LOOP;
                      else
                	token = F_DEC_LOOP;
                    }

                    tmp1=CAR(*last);
                    ADD_NODE_REF(CAR(*last));
                    ADD_NODE_REF2(*arg1,
                    ADD_NODE_REF2(CADR(n),
                      tmp2 = mknode(token, mknode(F_VAL_LVAL, tmp3, *arg1), CADR(n));
                    ));

                    tmp1 = mknode(F_COMMA_EXPR, mkcastnode(void_type_string,
                					   mknode(inc ? F_DEC : F_INC, tmp1, 0)), tmp2);
                    goto use_tmp1;
                  }
                 next_for_opt:
                  ;
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_DEC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1020}(F_DEC{1021}(0 = *{1022}, *), ':'{1024}(-{1025}, 1 = +{1026}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1027}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1032}(F_DEC{1033}(0 = *{1034}, *), ':'{1036}(1 = +{1037}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{1038}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1039}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{1044}(F_DEC{1045}(0 = *{1046}, *), ':'{1048}(1 = +{1049}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{1050}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1051}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_INC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{924}(F_INC{925}(0 = *{926}, *), ':'{928}(-{929}, 1 = +{930}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{931}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{936}(F_INC{937}(0 = *{938}, *), ':'{940}(1 = +{941}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{942}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{943}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{948}(F_INC{949}(0 = *{950}, *), ':'{952}(1 = +{953}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{954}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_INC_NEQ_LOOP{955}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(0), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_POST_DEC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1068}(F_POST_DEC{1069}(0 = *{1070}, *), ':'{1072}(-{1073}, 1 = +{1074}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1075}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{1080}(F_POST_DEC{1081}(0 = *{1082}, *), ':'{1084}(1 = +{1085}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{1086}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1087}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{1092}(F_POST_DEC{1093}(0 = *{1094}, *), ':'{1096}(1 = +{1097}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{1098}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_DEC_NEQ_LOOP{1099}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_DEC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(-1), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_POST_INC) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == ':') {
          if (!CADR(n)) {
            if (!CDDR(n)) {
            } else {
              if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{972}(F_POST_INC{973}(0 = *{974}, *), ':'{976}(-{977}, 1 = +{978}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{979}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), CDDR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else if (!CDDR(n)) {
            if (!CADR(n)) {
            } else {
              if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOR{984}(F_POST_INC{985}(0 = *{986}, *), ':'{988}(1 = +{989}[!(CADR(n)->tree_info & OPT_CONTINUE)], -{990}))""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_INC_NEQ_LOOP{991}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CADR(n),
                    tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), CADR(n));
                  ));
                  goto use_tmp1;
                }
              }
            }
          } else {
            if ((!(CADR(n)->tree_info & OPT_CONTINUE))) {
              if (!CDDR(n)) {
              } else {
                if ((!(CDDR(n)->tree_info & OPT_CONTINUE))) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_FOR{996}(F_POST_INC{997}(0 = *{998}, *), ':'{1000}(1 = +{1001}[!(CADR(n)->tree_info & OPT_CONTINUE)], 2 = +{1002}[!(CDDR(n)->tree_info & OPT_CONTINUE)]))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_INC_NEQ_LOOP{1003}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CAAR(n),
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CDDR(n),
                      tmp1 = mknode(F_INC_NEQ_LOOP, mknode(F_VAL_LVAL, mkintnode(1), CAAR(n)), mknode(F_COMMA_EXPR, CADR(n), CDDR(n)));
                    )));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    }
    if (CDR(n)->token == ':') {
      if (!CADR(n)) {
        if (!CDDR(n)) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_FOR{899}(0 = *{900}, ':'{901}(-{902}, -{903}))""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_FOR{904}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
              tmp1 = mknode(F_FOR, CAR(n), 0);
            );
            goto use_tmp1;
          }
        }
      } else if (!CDDR(n)) {
      } else {
        if (CDDR(n)->token == F_CAST) {
          if ((CDDR(n)->type == void_type_string)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_FOR{1106}(0 = *{1107}, ':'{1108}(1 = *{1109}, F_CAST{1110}[CDDR(n)->type == void_type_string](2 = *{1111}, *)))""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_FOR{1113}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAR(n),
              ADD_NODE_REF2(CADR(n),
              ADD_NODE_REF2(CADDR(n),
                tmp1 = mknode(F_FOR, CAR(n), mknode(':', CADR(n), CADDR(n)));
              )));
              goto use_tmp1;
            }
          }
        }
      }
    }
    if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_FOR{907}(+{908}[node_is_false(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{910}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    }
  }
  break;

case F_FOREACH:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if (CAR(n)->token == F_VAL_LVAL) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOREACH{818}(F_VAL_LVAL{819}(0 = *{820}, *), -{822})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_POP_VALUE{823}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_POP_VALUE, CAAR(n), 0);
          );
          goto use_tmp1;
        }
      }
    }
  } else {
    if (CAR(n)->token == F_VAL_LVAL) {
      if (!CAAR(n)) {
      } else if (!CDAR(n)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_FOREACH{844}(F_VAL_LVAL{845}(0 = *{846}, -{847}), 1 = *{848})""\n");
          }
#endif /* PIKE_DEBUG */
        {
            
          ADD_NODE_REF2(CDR(n),
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_LOOP, mkefuncallnode("sizeof", CAAR(n)), CDR(n));
          ));
          goto use_tmp1;
          }
      } else {
        if (CAAR(n)->token == F_APPLY) {
          if (!CAAAR(n)) {
          } else {
            if (CAAAR(n)->token == F_CONSTANT) {
              if ((CAAAR(n)->u.sval.type == T_FUNCTION) &&
                  (CAAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
                  (CAAAR(n)->u.sval.u.efun->function == f_divide)) {
                if (!CDAAR(n)) {
                } else {
                  if (CDAAR(n)->token == F_ARG_LIST) {
                    if (!CADAAR(n)) {
                    } else {
                      if ((CADAAR(n)->type == string_type_string)) {
                        if (!CDDAAR(n)) {
                        } else {
                          if (CDDAAR(n)->token == F_CONSTANT) {
                            if ((CDDAAR(n)->u.sval.type == T_STRING) &&
                                (CDDAAR(n)->u.sval.u.string->len == 1)) {
#ifdef PIKE_DEBUG
                                if (l_flag > 4) {
                                  fprintf(stderr, "Match: ""F_FOREACH{856}(F_VAL_LVAL{857}(F_APPLY{858}(F_CONSTANT{859}[CAAAR(n)->u.sval.type == T_FUNCTION][CAAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAAAR(n)->u.sval.u.efun->function == f_divide], F_ARG_LIST{860}(0 = +{861}[CADAAR(n)->type == string_type_string], 1 = F_CONSTANT{862}[CDDAAR(n)->u.sval.type == T_STRING][CDDAAR(n)->u.sval.u.string->len == 1])), 2 = *{863}), 3 = *{864})""\n");
                                }
#endif /* PIKE_DEBUG */
                              {
                                extern struct program *string_split_iterator_program;
                                node *vars;
                                p_wchar2 split = index_shared_string(CDDAAR(n)->u.sval.u.string, 0);

                                ADD_NODE_REF2(CDAR(n),
                                  if (CDAR(n)->token == ':') {
                                    vars = CDAR(n);
                                  } else {
                                    /* Old-style. Convert to new-style. */
                                    vars = mknode(':', NULL, CDAR(n));
                                  }
                                );

                                
                                ADD_NODE_REF2(CDR(n),
                                ADD_NODE_REF2(CADAAR(n),
                                  tmp1 = mknode(F_FOREACH,
                              	      mknode(F_VAL_LVAL,
                              		     mkapplynode(mkprgnode(string_split_iterator_program),
                              				 mknode(F_ARG_LIST, CADAAR(n),
                              					mkintnode(split))),
                              		     vars),
                              	      CDR(n));
                                ));
                                goto use_tmp1;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
              if ((CAAAR(n)->u.sval.type == T_FUNCTION) &&
                  (CAAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
                  (CAAAR(n)->u.sval.u.efun->function == f_minus)) {
                if (!CDAAR(n)) {
                } else {
                  if (CDAAR(n)->token == F_ARG_LIST) {
                    if (!CADAAR(n)) {
                    } else {
                      if (CADAAR(n)->token == F_APPLY) {
                        if (!CAADAAR(n)) {
                        } else {
                          if (CAADAAR(n)->token == F_CONSTANT) {
                            if ((CAADAAR(n)->u.sval.type == T_FUNCTION) &&
                                (CAADAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
                                (CAADAAR(n)->u.sval.u.efun->function == f_divide)) {
                              if (!CDADAAR(n)) {
                              } else {
                                if (CDADAAR(n)->token == F_ARG_LIST) {
                                  if (!CADADAAR(n)) {
                                  } else {
                                    if ((CADADAAR(n)->type == string_type_string)) {
                                      if (!CDDADAAR(n)) {
                                      } else {
                                        if (CDDADAAR(n)->token == F_CONSTANT) {
                                          if ((CDDADAAR(n)->u.sval.type == T_STRING) &&
                                              (CDDADAAR(n)->u.sval.u.string->len == 1)) {
                                            if (!CDDAAR(n)) {
                                            } else {
                                              if (CDDAAR(n)->token == F_APPLY) {
                                                if (!CADDAAR(n)) {
                                                } else {
                                                  if (CADDAAR(n)->token == F_CONSTANT) {
                                                    if ((CADDAAR(n)->u.sval.type == T_FUNCTION) &&
                                                        (CADDAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
                                                        (CADDAAR(n)->u.sval.u.efun->function == f_allocate)) {
                                                      if (!CDDDAAR(n)) {
                                                      } else {
                                                        if (CDDDAAR(n)->token == F_ARG_LIST) {
                                                          if (!CADDDAAR(n)) {
                                                          } else {
                                                            if (CADDDAAR(n)->token == F_CONSTANT) {
                                                              if ((CADDDAAR(n)->u.sval.type == T_INT) &&
                                                                  (CADDDAAR(n)->u.sval.u.integer == 1)) {
                                                                if (!CDDDDAAR(n)) {
                                                                } else {
                                                                  if (CDDDDAAR(n)->token == F_CONSTANT) {
                                                                    if ((CDDDDAAR(n)->u.sval.type == T_STRING) &&
                                                                        (CDDDDAAR(n)->u.sval.u.string->len == 0)) {
#ifdef PIKE_DEBUG
                                                                        if (l_flag > 4) {
                                                                          fprintf(stderr, "Match: ""F_FOREACH{878}(F_VAL_LVAL{879}(F_APPLY{880}(F_CONSTANT{881}[CAAAR(n)->u.sval.type == T_FUNCTION][CAAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAAAR(n)->u.sval.u.efun->function == f_minus], F_ARG_LIST{882}(F_APPLY{883}(F_CONSTANT{884}[CAADAAR(n)->u.sval.type == T_FUNCTION][CAADAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAADAAR(n)->u.sval.u.efun->function == f_divide], F_ARG_LIST{885}(0 = +{886}[CADADAAR(n)->type == string_type_string], 1 = F_CONSTANT{887}[CDDADAAR(n)->u.sval.type == T_STRING][CDDADAAR(n)->u.sval.u.string->len == 1])), F_APPLY{888}(F_CONSTANT{889}[CADDAAR(n)->u.sval.type == T_FUNCTION][CADDAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CADDAAR(n)->u.sval.u.efun->function == f_allocate], F_ARG_LIST{890}(F_CONSTANT{891}[CADDDAAR(n)->u.sval.type == T_INT][CADDDAAR(n)->u.sval.u.integer == 1], F_CONSTANT{892}[CDDDDAAR(n)->u.sval.type == T_STRING][CDDDDAAR(n)->u.sval.u.string->len == 0])))), 2 = *{893}), 3 = *{894})""\n");
                                                                        }
#endif /* PIKE_DEBUG */
                                                                      {
                                                                        extern struct program *string_split_iterator_program;
                                                                        node *vars;
                                                                        p_wchar2 split = index_shared_string(CDDADAAR(n)->u.sval.u.string, 0);

                                                                        ADD_NODE_REF2(CDAR(n),
                                                                          if (CDAR(n)->token == ':') {
                                                                            vars = CDAR(n);
                                                                          } else {
                                                                            /* Old-style. Convert to new-style. */
                                                                            vars = mknode(':', NULL, CDAR(n));
                                                                          }
                                                                        );

                                                                        
                                                                        ADD_NODE_REF2(CDR(n),
                                                                        ADD_NODE_REF2(CADADAAR(n),
                                                                          tmp1 = mknode(F_FOREACH,
                                                                      	      mknode(F_VAL_LVAL,
                                                                      		     mkapplynode(mkprgnode(string_split_iterator_program),
                                                                      				 mknode(F_ARG_LIST, CADADAAR(n),
                                                                      					mknode(F_ARG_LIST,
                                                                      					       mkintnode(split),
                                                                      					       mkintnode(1)))),
                                                                      		     vars),
                                                                      	      CDR(n));
                                                                        ));
                                                                        goto use_tmp1;
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              } else if (CDDAAR(n)->token == F_CONSTANT) {
                                                if ((CDDAAR(n)->u.sval.type == T_ARRAY) &&
                                                    (CDDAAR(n)->u.sval.u.array->size == 1) &&
                                                    (CDDAAR(n)->u.sval.u.array->item[0].type == T_STRING) &&
                                                    (CDDAAR(n)->u.sval.u.array->item[0].u.string->len == 0)) {
#ifdef PIKE_DEBUG
                                                    if (l_flag > 4) {
                                                      fprintf(stderr, "Match: ""F_FOREACH{865}(F_VAL_LVAL{866}(F_APPLY{867}(F_CONSTANT{868}[CAAAR(n)->u.sval.type == T_FUNCTION][CAAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAAAR(n)->u.sval.u.efun->function == f_minus], F_ARG_LIST{869}(F_APPLY{870}(F_CONSTANT{871}[CAADAAR(n)->u.sval.type == T_FUNCTION][CAADAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAADAAR(n)->u.sval.u.efun->function == f_divide], F_ARG_LIST{872}(0 = +{873}[CADADAAR(n)->type == string_type_string], 1 = F_CONSTANT{874}[CDDADAAR(n)->u.sval.type == T_STRING][CDDADAAR(n)->u.sval.u.string->len == 1])), F_CONSTANT{875}[CDDAAR(n)->u.sval.type == T_ARRAY][CDDAAR(n)->u.sval.u.array->size == 1][CDDAAR(n)->u.sval.u.array->item[0].type == T_STRING][CDDAAR(n)->u.sval.u.array->item[0].u.string->len == 0])), 2 = *{876}), 3 = *{877})""\n");
                                                    }
#endif /* PIKE_DEBUG */
                                                  {
                                                    extern struct program *string_split_iterator_program;
                                                    node *vars;
                                                    p_wchar2 split = index_shared_string(CDDADAAR(n)->u.sval.u.string, 0);

                                                    ADD_NODE_REF2(CDAR(n),
                                                      if (CDAR(n)->token == ':') {
                                                        vars = CDAR(n);
                                                      } else {
                                                        /* Old-style. Convert to new-style. */
                                                        vars = mknode(':', NULL, CDAR(n));
                                                      }
                                                    );

                                                    
                                                    ADD_NODE_REF2(CDR(n),
                                                    ADD_NODE_REF2(CADADAAR(n),
                                                      tmp1 = mknode(F_FOREACH,
                                                  	      mknode(F_VAL_LVAL,
                                                  		     mkapplynode(mkprgnode(string_split_iterator_program),
                                                  				 mknode(F_ARG_LIST, CADADAAR(n),
                                                  					mknode(F_ARG_LIST,
                                                  					       mkintnode(split),
                                                  					       mkintnode(1)))),
                                                  		     vars),
                                                  	      CDR(n));
                                                    ));
                                                    goto use_tmp1;
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        if (CDAR(n)->token == ':') {
          if (!CADAR(n)) {
            if (!CDDAR(n)) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_FOREACH{849}(F_VAL_LVAL{850}(0 = *{851}, ':'{852}(-{853}, -{854})), 1 = *{855})""\n");
                }
#endif /* PIKE_DEBUG */
              {
                  
                ADD_NODE_REF2(CDR(n),
                ADD_NODE_REF2(CAAR(n),
                  tmp1 = mknode(F_LOOP, mkefuncallnode("sizeof", CAAR(n)), CDR(n));
                ));
                goto use_tmp1;
                }
            }
          }
        }
        if (( pike_types_le(CAAR(n)->type, array_type_string) )) {
          if (!CDAR(n)) {
          } else {
            if (CDAR(n)->token == ':') {
              if (!CADAR(n)) {
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "Match: ""F_FOREACH{832}(F_VAL_LVAL{833}(0 = +{834}[ pike_types_le(CAAR(n)->type, array_type_string) ], ':'{835}(-{836}, 1 = *{837})), 2 = *{838})""\n");
                  }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                  if (l_flag > 4) {
                    fprintf(stderr, "=> ""F_FOREACH{839}""\n");
                  }
#endif /* PIKE_DEBUG */
                {
                  ADD_NODE_REF2(CAAR(n),
                  ADD_NODE_REF2(CDDAR(n),
                  ADD_NODE_REF2(CDR(n),
                    tmp1 = mknode(F_FOREACH, mknode(F_VAL_LVAL, CAAR(n), CDDAR(n)), CDR(n));
                  )));
                  goto use_tmp1;
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_INC_LOOP:
  if (!CAR(n)) {
  } else {
    if (CAR(n)->token == F_VAL_LVAL) {
      if (!CDAR(n)) {
      } else {
        if (( !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
						OPT_CASE|OPT_CONTINUE|
						OPT_BREAK|OPT_RETURN)) )) {
          if (!CDR(n)) {
          } else {
            if (( !(CDR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)) ) &&
                ( !depend2_p(CDR(n), CDAR(n)) )) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_INC_LOOP{1125}(F_VAL_LVAL{1126}(0 = *{1127}, 1 = +{1128}[ !(CDAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n\t\t\t\t\t\tOPT_CASE|OPT_CONTINUE|\n\t\t\t\t\t\tOPT_BREAK|OPT_RETURN)) ]), 2 = +{1129}[ !(CDR(n)->tree_info & (OPT_BREAK|OPT_CONTINUE)) ][ !depend2_p(CDR(n), CDAR(n)) ])""\n");
                }
#endif /* PIKE_DEBUG */
              {
                  
                ADD_NODE_REF2(CDAR(n),
                ADD_NODE_REF2(CDAR(n),
                ADD_NODE_REF2(CAAR(n),
                ADD_NODE_REF2(CAAR(n),
                ADD_NODE_REF2(CDR(n),
                  tmp1 = mknode(F_COMMA_EXPR,
              		mknode(F_LOOP,
              		       mkefuncallnode("`+",
              				      mknode(F_ARG_LIST, mkintnode(-1),
              					     mknode(F_ARG_LIST,
              						    mkefuncallnode("`-", CDAR(n)),
              						    CAAR(n)))), CDR(n)),
              		mkcastnode(void_type_string, mknode(F_ASSIGN, CAAR(n), CDAR(n))));
                )))));
                goto use_tmp1;
                }
            }
          }
        }
      }
    }
  }
  break;

case F_INDEX:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_INDEX{782}(-{783}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{785}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CDR(n),
        tmp1 = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, CDR(n), 0), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (( !match_types(CAR(n)->type, object_type_string) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_CONSTANT) {
          if ((CDR(n)->u.sval.type == T_STRING)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_INDEX{790}(0 = +{791}[ !match_types(CAR(n)->type, object_type_string) ], 1 = F_CONSTANT{792}[CDR(n)->u.sval.type == T_STRING])""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""F_ARROW{793}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CAR(n),
              ADD_NODE_REF2(CDR(n),
                tmp1 = mknode(F_ARROW, CAR(n), CDR(n));
              ));
              goto use_tmp1;
            }
          }
        }
      }
    }
  }
  break;

case F_LAND:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LAND{538}(-{539}, 0 = *{540})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{541}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LAND{597}(0 = +{598}[node_is_false(CAR(n))], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{600}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
      if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LAND{593}(+{594}[node_is_true(CAR(n))], 0 = *{595})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{596}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
    }
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LAND{542}(0 = *{543}, -{544})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_COMMA_EXPR{545}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CAR(n),
        tmp1 = mknode(F_COMMA_EXPR, CAR(n), mkintnode(0));
      );
      goto use_tmp1;
    }
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((CAAR(n)->u.sval.type == T_FUNCTION) &&
              (CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == f_not)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == F_APPLY) {
                {
                  if ((CADR(n) == CAAR(n))
#ifdef SHARED_NODES_MK2
                    || (CADR(n) && CAAR(n) &&
                        ((CADR(n)->master?CADR(n)->master:CADR(n))==
                         (CAAR(n)->master?CAAR(n)->master:CAAR(n))))
#endif /* SHARED_NODES_MK2 */
                    ) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_LAND{548}(F_APPLY{549}(0 = F_CONSTANT{550}[CAAR(n)->u.sval.type == T_FUNCTION][CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == f_not], 1 = *{551}), F_APPLY{552}($CAAR(n)$, 2 = *{553}))""\n");
                      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "=> ""F_APPLY{554}""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                      ADD_NODE_REF2(CAAR(n),
                      ADD_NODE_REF2(CDAR(n),
                      ADD_NODE_REF2(CDDR(n),
                        tmp1 = mknode(F_APPLY, CAAR(n), mknode(F_LOR, CDAR(n), CDDR(n)));
                      )));
                      goto use_tmp1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_ASSIGN) {
      if (!CDAR(n)) {
      } else {
        if ((node_is_false(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LAND{577}(0 = F_ASSIGN{578}(*, +{580}[node_is_false(CDAR(n))]), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{582}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
        if ((node_is_true(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LAND{569}(0 = F_ASSIGN{570}(*, +{572}[node_is_true(CDAR(n))]), 2 = *{573})""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{574}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
            ADD_NODE_REF2(CDR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAR(n), CDR(n));
            ));
            goto use_tmp1;
          }
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LAND{583}(F_COMMA_EXPR{584}(0 = *{585}, 1 = *{586}), 2 = *{587})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_COMMA_EXPR{588}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
        ADD_NODE_REF2(CDR(n),
          tmp1 = mknode(F_COMMA_EXPR, CAAR(n), mknode(F_LAND, CDAR(n), CDR(n)));
        )));
        goto use_tmp1;
      }
    }
    if (CDR(n)->token == F_LAND) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LAND{559}(0 = *{560}, F_LAND{561}(1 = *{562}, 2 = *{563}))""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_LAND{564}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAR(n),
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CDDR(n),
          tmp1 = mknode(F_LAND, mknode(F_LAND, CAR(n), CADR(n)), CDDR(n));
        )));
        goto use_tmp1;
      }
    }
    if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LAND{597}(0 = +{598}[node_is_false(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{600}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    }
    if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LAND{593}(+{594}[node_is_true(CAR(n))], 0 = *{595})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{596}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_cdr;
    }
  }
  break;

case F_LOOP:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LOOP{826}(0 = *{827}, -{828})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_POP_VALUE{829}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      ADD_NODE_REF2(CAR(n),
        tmp1 = mknode(F_POP_VALUE, CAR(n), 0);
      );
      goto use_tmp1;
    }
  } else {
    if (CDR(n)->token == F_POP_VALUE) {
      if (!CDDR(n)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LOOP{1130}(0 = *{1131}, F_POP_VALUE{1132}(1 = *{1133}, -{1134}))""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_LOOP{1135}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
          ADD_NODE_REF2(CADR(n),
            tmp1 = mknode(F_LOOP, CAR(n), CADR(n));
          ));
          goto use_tmp1;
        }
      }
    }
    if (( !depend_p(CAR(n), CAR(n)) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_DEC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1158}(0 = +{1159}[ !depend_p(CAR(n), CAR(n)) ], F_DEC{1160}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1161}[ !depend_p(CADR(n), CADR(n)) ], -{1162}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1163}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_SUB_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDR(n)->token == F_INC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1138}(0 = +{1139}[ !depend_p(CAR(n), CAR(n)) ], F_INC{1140}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1141}[ !depend_p(CADR(n), CADR(n)) ], -{1142}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1143}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_ADD_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDR(n)->token == F_POST_DEC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1168}(0 = +{1169}[ !depend_p(CAR(n), CAR(n)) ], F_POST_DEC{1170}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1171}[ !depend_p(CADR(n), CADR(n)) ], -{1172}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1173}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_SUB_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        } else if (CDR(n)->token == F_POST_INC) {
          if (( pike_types_le(CDR(n)->type, int_type_string) )) {
            if (!CDDR(n)) {
              if (!CADR(n)) {
              } else {
                if (( !depend_p(CADR(n), CADR(n)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1148}(0 = +{1149}[ !depend_p(CAR(n), CAR(n)) ], F_POST_INC{1150}[ pike_types_le(CDR(n)->type, int_type_string) ](1 = +{1151}[ !depend_p(CADR(n), CADR(n)) ], -{1152}))""\n");
                    }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "=> ""F_POP_VALUE{1153}""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                    ADD_NODE_REF2(CADR(n),
                    ADD_NODE_REF2(CAR(n),
                      tmp1 = mknode(F_POP_VALUE, mknode(F_ADD_EQ, CADR(n), CAR(n)), 0);
                    ));
                    goto use_tmp1;
                  }
                }
              }
            }
          }
        }
      }
    }
    if (( !depend_p(CAR(n), CAR(n))) &&
        ( !(CAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|
			    OPT_CASE|OPT_CONTINUE|
			    OPT_BREAK|OPT_RETURN)) )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_ADD_EQ) {
          if (!CADR(n)) {
          } else {
            if (( !depend_p(CADR(n), CADR(n)) )) {
              if (!CDDR(n)) {
              } else {
                if (( !depend_p(CDDR(n), CADR(n)) ) &&
                    ( !depend_p(CDDR(n), CDDR(n)) ) &&
                    ( !(CDDR(n)->tree_info & OPT_SIDE_EFFECT) ) &&
                    ( (((CDDR(n)->type == int_type_string) &&
		    (CADR(n)->type == int_type_string)) ||
		   (CDDR(n)->type == string_type_string)) )) {
#ifdef PIKE_DEBUG
                    if (l_flag > 4) {
                      fprintf(stderr, "Match: ""F_LOOP{1178}(0 = +{1179}[ !depend_p(CAR(n), CAR(n))][ !(CAR(n)->tree_info & (OPT_SIDE_EFFECT|OPT_ASSIGNMENT|\n\t\t\t    OPT_CASE|OPT_CONTINUE|\n\t\t\t    OPT_BREAK|OPT_RETURN)) ], F_ADD_EQ{1180}(1 = +{1181}[ !depend_p(CADR(n), CADR(n)) ], 2 = +{1182}[ !depend_p(CDDR(n), CADR(n)) ][ !depend_p(CDDR(n), CDDR(n)) ][ !(CDDR(n)->tree_info & OPT_SIDE_EFFECT) ][ (((CDDR(n)->type == int_type_string) &&\n\t\t    (CADR(n)->type == int_type_string)) ||\n\t\t   (CDDR(n)->type == string_type_string)) ]))""\n");
                    }
#endif /* PIKE_DEBUG */
                  {
                      
                    ADD_NODE_REF2(CAR(n),
                    ADD_NODE_REF2(CAR(n),
                    ADD_NODE_REF2(CDDR(n),
                    ADD_NODE_REF2(CADR(n),
                      tmp1 = mknode(F_POP_VALUE,
                  		mknode('?',
                  		       mkefuncallnode("`>",
                  				      mknode(F_ARG_LIST,
                  					     CAR(n), mkintnode(0))),
                  		       mknode(':',
                  			      mknode(F_ADD_EQ,
                  				     CADR(n),
                  				     mkefuncallnode("`*",
                  						    mknode(F_ARG_LIST,
                  							   CDDR(n), CAR(n)))),
                  			      mkintnode(0))),
                  		NULL);
                    ))));
                    goto use_tmp1;
                    }
                }
              }
            }
          }
        }
      }
    }
  }
  break;

case F_LOR:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LOR{473}(-{474}, 0 = *{475})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{476}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
    if (!CAR(n)) {
    } else {
      if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LOR{530}(+{531}[node_is_false(CAR(n))], 0 = *{532})""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{533}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_cdr;
      }
      if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LOR{534}(0 = +{535}[node_is_true(CAR(n))], *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{537}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    }
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LOR{477}(0 = *{478}, -{479})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{480}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((CAAR(n)->u.sval.type == T_FUNCTION) &&
              (CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == f_not)) {
            if (!CDR(n)) {
            } else {
              if (CDR(n)->token == F_APPLY) {
                {
                  if ((CADR(n) == CAAR(n))
#ifdef SHARED_NODES_MK2
                    || (CADR(n) && CAAR(n) &&
                        ((CADR(n)->master?CADR(n)->master:CADR(n))==
                         (CAAR(n)->master?CAAR(n)->master:CAAR(n))))
#endif /* SHARED_NODES_MK2 */
                    ) {
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "Match: ""F_LOR{481}(F_APPLY{482}(0 = F_CONSTANT{483}[CAAR(n)->u.sval.type == T_FUNCTION][CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == f_not], 1 = *{484}), F_APPLY{485}($CAAR(n)$, 2 = *{486}))""\n");
                      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                      if (l_flag > 4) {
                        fprintf(stderr, "=> ""F_APPLY{487}""\n");
                      }
#endif /* PIKE_DEBUG */
                    {
                      ADD_NODE_REF2(CAAR(n),
                      ADD_NODE_REF2(CDAR(n),
                      ADD_NODE_REF2(CDDR(n),
                        tmp1 = mknode(F_APPLY, CAAR(n), mknode(F_LAND, CDAR(n), CDDR(n)));
                      )));
                      goto use_tmp1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else if (CAR(n)->token == F_ASSIGN) {
      if (!CDAR(n)) {
      } else {
        if ((node_is_false(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LOR{502}(0 = F_ASSIGN{503}(*, +{505}[node_is_false(CDAR(n))]), 2 = *{506})""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""F_COMMA_EXPR{507}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAR(n),
            ADD_NODE_REF2(CDR(n),
              tmp1 = mknode(F_COMMA_EXPR, CAR(n), CDR(n));
            ));
            goto use_tmp1;
          }
        }
        if ((node_is_true(CDAR(n)))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LOR{520}(0 = F_ASSIGN{521}(*, +{523}[node_is_true(CDAR(n))]), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{525}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LOR{510}(F_COMMA_EXPR{511}(0 = *{512}, 1 = *{513}), 2 = *{514})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_COMMA_EXPR{515}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
        ADD_NODE_REF2(CDR(n),
          tmp1 = mknode(F_COMMA_EXPR, CAAR(n), mknode(F_LOR, CDAR(n), CDR(n)));
        )));
        goto use_tmp1;
      }
    }
    if (CDR(n)->token == F_CONSTANT) {
      if ((CDR(n)->u.sval.type == T_INT) &&
          (!CDR(n)->u.sval.u.integer)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_LOR{526}(0 = *{527}, F_CONSTANT{528}[CDR(n)->u.sval.type == T_INT][!CDR(n)->u.sval.u.integer])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""0 = *{529}""\n");
          }
#endif /* PIKE_DEBUG */
        goto use_car;
      }
    } else if (CDR(n)->token == F_LOR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LOR{492}(0 = *{493}, F_LOR{494}(1 = *{495}, 2 = *{496}))""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_LOR{497}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAR(n),
        ADD_NODE_REF2(CADR(n),
        ADD_NODE_REF2(CDDR(n),
          tmp1 = mknode(F_LOR, mknode(F_LOR, CAR(n), CADR(n)), CDDR(n));
        )));
        goto use_tmp1;
      }
    }
    if ((node_is_false(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LOR{530}(+{531}[node_is_false(CAR(n))], 0 = *{532})""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{533}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_cdr;
    }
    if ((node_is_true(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_LOR{534}(0 = +{535}[node_is_true(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{537}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    }
  }
  break;

case F_LVALUE_LIST:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LVALUE_LIST{435}(-{436}, 0 = *{437})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{438}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_cdr;
  } else if (!CDR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_LVALUE_LIST{439}(0 = *{440}, -{441})""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""0 = *{442}""\n");
      }
#endif /* PIKE_DEBUG */
    goto use_car;
  } else {
    if (CAR(n)->token == F_BREAK) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LVALUE_LIST{451}(0 = F_BREAK{452}, +{453}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{454}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_COMMA_EXPR) {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == F_BREAK) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_LVALUE_LIST{467}(0 = F_COMMA_EXPR{468}(*, F_BREAK{470}), +{471}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{472}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_CONTINUE) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_LVALUE_LIST{461}(0 = F_COMMA_EXPR{462}(*, F_CONTINUE{464}), +{465}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{466}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        } else if (CDAR(n)->token == F_RETURN) {
          if (!CDR(n)) {
          } else {
            if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "Match: ""F_LVALUE_LIST{455}(0 = F_COMMA_EXPR{456}(*, F_RETURN{458}), +{459}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
                }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
                if (l_flag > 4) {
                  fprintf(stderr, "=> ""0 = *{460}""\n");
                }
#endif /* PIKE_DEBUG */
              goto use_car;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONTINUE) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LVALUE_LIST{447}(0 = F_CONTINUE{448}, +{449}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{450}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    } else if (CAR(n)->token == F_RETURN) {
      if (!CDR(n)) {
      } else {
        if ((!(CDR(n)->tree_info & OPT_CASE))) {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_LVALUE_LIST{443}(0 = F_RETURN{444}, +{445}[!(CDR(n)->tree_info & OPT_CASE)])""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""0 = *{446}""\n");
            }
#endif /* PIKE_DEBUG */
          goto use_car;
        }
      }
    }
  }
  break;

case F_NOT:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_NOT{698}(-{699}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""1 = T_INT{701}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      tmp1 = mkintnode(1);
      goto use_tmp1;
    }
  } else {
    if (CAR(n)->token == F_EQ) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_NOT{734}(F_EQ{735}(0 = *{736}, 1 = *{737}), *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_NE{739}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
          tmp1 = mknode(F_NE, CAAR(n), CDAR(n));
        ));
        goto use_tmp1;
      }
    } else if (CAR(n)->token == F_GE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_NOT{726}(F_GE{727}(0 = *{728}, 1 = *{729}), *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_LT{731}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
          tmp1 = mknode(F_LT, CAAR(n), CDAR(n));
        ));
        goto use_tmp1;
      }
    } else if (CAR(n)->token == F_GT) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_NOT{710}(F_GT{711}(0 = *{712}, 1 = *{713}), *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_LE{715}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
          tmp1 = mknode(F_LE, CAAR(n), CDAR(n));
        ));
        goto use_tmp1;
      }
    } else if (CAR(n)->token == F_LE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_NOT{718}(F_LE{719}(0 = *{720}, 1 = *{721}), *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_GT{723}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
          tmp1 = mknode(F_GT, CAAR(n), CDAR(n));
        ));
        goto use_tmp1;
      }
    } else if (CAR(n)->token == F_LT) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_NOT{702}(F_LT{703}(0 = *{704}, 1 = *{705}), *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_GE{707}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
          tmp1 = mknode(F_GE, CAAR(n), CDAR(n));
        ));
        goto use_tmp1;
      }
    } else if (CAR(n)->token == F_NE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_NOT{742}(F_NE{743}(0 = *{744}, 1 = *{745}), *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""F_EQ{747}""\n");
        }
#endif /* PIKE_DEBUG */
      {
        ADD_NODE_REF2(CAAR(n),
        ADD_NODE_REF2(CDAR(n),
          tmp1 = mknode(F_EQ, CAAR(n), CDAR(n));
        ));
        goto use_tmp1;
      }
    }
  }
  break;

case F_POP_VALUE:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_POP_VALUE{77}(-{78}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""-{80}""\n");
      }
#endif /* PIKE_DEBUG */
    goto zap_node;
  } else {
    if (CAR(n)->token == '?') {
      if (!CDAR(n)) {
      } else {
        if (CDAR(n)->token == ':') {
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "Match: ""F_POP_VALUE{169}('?'{170}(0 = *{171}, ':'{172}(1 = *{173}, 2 = *{174})), *)""\n");
            }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
            if (l_flag > 4) {
              fprintf(stderr, "=> ""'?'{176}""\n");
            }
#endif /* PIKE_DEBUG */
          {
            ADD_NODE_REF2(CAAR(n),
            ADD_NODE_REF2(CADAR(n),
            ADD_NODE_REF2(CDDAR(n),
              tmp1 = mknode('?', CAAR(n), mknode(':', mknode(F_POP_VALUE, CADAR(n), 0), mknode(F_POP_VALUE, CDDAR(n), 0)));
            )));
            goto use_tmp1;
          }
        }
      }
    } else if (CAR(n)->token == F_BREAK) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{121}(0 = F_BREAK{122}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{124}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_CASE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{125}(0 = F_CASE{126}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{128}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_CASE_RANGE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{129}(0 = F_CASE_RANGE{130}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{132}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_CAST) {
      if ((!(CAR(n)->node_info & OPT_SIDE_EFFECT))) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_POP_VALUE{85}(F_CAST{86}[!(CAR(n)->node_info & OPT_SIDE_EFFECT)](0 = *{87}, *), *)""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_POP_VALUE{90}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAAR(n),
            tmp1 = mknode(F_POP_VALUE, CAAR(n), 0);
          );
          goto use_tmp1;
        }
      }
    } else if (CAR(n)->token == F_CONSTANT) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{93}(F_CONSTANT{94}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{96}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_CONTINUE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{117}(0 = F_CONTINUE{118}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{120}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_DEC_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{149}(0 = F_DEC_LOOP{150}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{152}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_DEC_NEQ_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{157}(0 = F_DEC_NEQ_LOOP{158}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{160}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_DEFAULT) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{133}(0 = F_DEFAULT{134}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{136}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_EXTERNAL) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{109}(F_EXTERNAL{110}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{112}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_FOR) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{137}(0 = F_FOR{138}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{140}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_FOREACH) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{141}(0 = F_FOREACH{142}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{144}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_GLOBAL) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{105}(F_GLOBAL{106}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{108}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_INC_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{145}(0 = F_INC_LOOP{146}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{148}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_INC_NEQ_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{153}(0 = F_INC_NEQ_LOOP{154}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{156}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_LOCAL) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{101}(F_LOCAL{102}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{104}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    } else if (CAR(n)->token == F_LOOP) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{161}(0 = F_LOOP{162}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{164}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_POP_VALUE) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{81}(0 = F_POP_VALUE{82}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{84}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_RETURN) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{113}(0 = F_RETURN{114}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{116}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    } else if (CAR(n)->token == F_SWITCH) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{165}(0 = F_SWITCH{166}, *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""0 = *{168}""\n");
        }
#endif /* PIKE_DEBUG */
      goto use_car;
    }
    if ((node_is_tossable(CAR(n)))) {
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "Match: ""F_POP_VALUE{97}(+{98}[node_is_tossable(CAR(n))], *)""\n");
        }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
        if (l_flag > 4) {
          fprintf(stderr, "=> ""-{100}""\n");
        }
#endif /* PIKE_DEBUG */
      goto zap_node;
    }
  }
  break;

case F_PUSH_ARRAY:
  if (!CAR(n)) {
  } else {
    if (CAR(n)->token == F_APPLY) {
      if (!CAAR(n)) {
      } else {
        if (CAAR(n)->token == F_CONSTANT) {
          if ((CAAR(n)->u.sval.type == T_FUNCTION) &&
              (CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN) &&
              (CAAR(n)->u.sval.u.efun->function == debug_f_aggregate)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_PUSH_ARRAY{20}(F_APPLY{21}(F_CONSTANT{22}[CAAR(n)->u.sval.type == T_FUNCTION][CAAR(n)->u.sval.subtype == FUNCTION_BUILTIN][CAAR(n)->u.sval.u.efun->function == debug_f_aggregate], 0 = *{23}), *)""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""0 = *{25}""\n");
              }
#endif /* PIKE_DEBUG */
            {
              ADD_NODE_REF2(CDAR(n),
                tmp1 = CDAR(n);
              );
              goto use_tmp1;
            }
          }
        }
      }
    } else if (CAR(n)->token == F_CONSTANT) {
      if ((CAR(n)->u.sval.type == T_ARRAY)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_PUSH_ARRAY{26}(0 = F_CONSTANT{27}[CAR(n)->u.sval.type == T_ARRAY], *)""\n");
          }
#endif /* PIKE_DEBUG */
        {
            struct array *a = CAR(n)->u.sval.u.array;
            node *n = NULL;
            int i;
            for(i=0; i<a->size; i++) {
              if (n) {
        	n = mknode(F_ARG_LIST, n, mksvaluenode(a->item+i));
              } else {
        	/* i is always 0 here. */
        	n = mksvaluenode(a->item);
              }
            }
            
          tmp1 = n;
          goto use_tmp1;
          }
      }
    }
  }
  break;

case F_RANGE:
  if (!CDR(n)) {
  } else {
    if (CDR(n)->token == F_ARG_LIST) {
      if (!CDDR(n)) {
      } else {
        if (CDDR(n)->token == F_CONSTANT) {
          if ((CDDR(n)->u.sval.type == T_FLOAT) &&
              (CDDR(n)->u.sval.u.float_number < 0.0)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_RANGE{209}(*, F_ARG_LIST{211}(*, F_CONSTANT{213}[CDDR(n)->u.sval.type == T_FLOAT][CDDR(n)->u.sval.u.float_number < 0.0]))""\n");
              }
#endif /* PIKE_DEBUG */
            {
              yywarning("Range end is negative.");
            }
          }
          if ((CDDR(n)->u.sval.type == T_INT) &&
              (CDDR(n)->u.sval.u.integer < 0)) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_RANGE{204}(*, F_ARG_LIST{206}(*, F_CONSTANT{208}[CDDR(n)->u.sval.type == T_INT][CDDR(n)->u.sval.u.integer < 0]))""\n");
              }
#endif /* PIKE_DEBUG */
            {
              yywarning("Range end is negative.");
            }
          }
        }
      }
    }
  }
  break;

case F_RETURN:
  if (!CAR(n)) {
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "Match: ""F_RETURN{14}(-{15}, *)""\n");
      }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
      if (l_flag > 4) {
        fprintf(stderr, "=> ""F_RETURN{17}""\n");
      }
#endif /* PIKE_DEBUG */
    {
      tmp1 = mknode(F_RETURN, mkintnode(0), 0);
      goto use_tmp1;
    }
  }
  break;

case F_SUB_EQ:
  if (!CAR(n)) {
  } else if (!CDR(n)) {
  } else {
    if (CDR(n)->token == F_CONSTANT) {
      if ((CDR(n)->u.sval.type == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == -1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_SUB_EQ{776}(0 = *{777}, 1 = F_CONSTANT{778}[CDR(n)->u.sval.type == T_INT][(CDR(n)->u.sval.u.integer) == -1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_INC{779}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_INC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
      if ((CDR(n)->u.sval.type == T_INT) &&
          ((CDR(n)->u.sval.u.integer) == 1)) {
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "Match: ""F_SUB_EQ{770}(0 = *{771}, 1 = F_CONSTANT{772}[CDR(n)->u.sval.type == T_INT][(CDR(n)->u.sval.u.integer) == 1])""\n");
          }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
          if (l_flag > 4) {
            fprintf(stderr, "=> ""F_DEC{773}""\n");
          }
#endif /* PIKE_DEBUG */
        {
          ADD_NODE_REF2(CAR(n),
            tmp1 = mknode(F_DEC, CAR(n), 0);
          );
          goto use_tmp1;
        }
      }
    }
    if (( CAR(n)->token != F_AUTO_MAP_MARKER )) {
      if (!CDR(n)) {
      } else {
        if (CDR(n)->token == F_CONSTANT) {
          if ((CDR(n)->u.sval.type == T_INT) &&
              (!(CDR(n)->u.sval.u.integer))) {
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "Match: ""F_SUB_EQ{766}(0 = +{767}[ CAR(n)->token != F_AUTO_MAP_MARKER ], 1 = F_CONSTANT{768}[CDR(n)->u.sval.type == T_INT][!(CDR(n)->u.sval.u.integer)])""\n");
              }
#endif /* PIKE_DEBUG */
#ifdef PIKE_DEBUG
              if (l_flag > 4) {
                fprintf(stderr, "=> ""0 = *{769}""\n");
              }
#endif /* PIKE_DEBUG */
            goto use_car;
          }
        }
      }
    }
  }
  break;

