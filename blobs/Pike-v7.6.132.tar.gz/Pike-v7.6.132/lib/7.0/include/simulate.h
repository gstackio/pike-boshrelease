#define list multiset
#define perror(X) werror(X)
#define efun predef
#define regexp(X,Y) filter((X),Regexp(Y)->match)
import Simulate;
