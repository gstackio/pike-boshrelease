/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
*/

#undef FUNCPROTO
#undef HAVE_GNOME
#undef HAVE_DPMS
#undef PGTK_AUTO_UTF8
#undef HAVE_GTK22
#undef HAVE_GTK24
#undef HAVE_GTK26
#undef HAVE_GTK28
#undef HAVE_GTK210
#undef HAVE_GTK212
#undef HAVE_GTK214
#undef HAVE_GTK216
#undef HAVE_GTK218
#undef HAVE_GTK220
#undef HAVE_GTK222
#undef HAVE_GTK224
#undef HAVE_ATK
#undef HAVE_ATK18
#undef HAVE_PANGO
#undef HAVE_PANGO110
#undef HAVE_PANGO18
#undef HAVE_PANGO16
#undef HAVE_PANGO14
#undef HAVE_PANGO12
#undef HAVE_GNOMECANVAS
#undef HAVE_GTKDATABOX
#undef HAVE_GTKSOURCEVIEW
#undef HAVE_GTKSOURCEVIEW11
#undef HAVE_G_SIGNAL_CONNECT_DATA_WITH_SIX_ARGS
#undef HAVE_PANGO_BETA
#undef HAVE_GLADE
#undef HAVE_GNOMEUI
#undef HAVE_CAIRO
