/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
*/

extern void f_discdate(INT32 argc);
extern void f_stardate (INT32 args);
