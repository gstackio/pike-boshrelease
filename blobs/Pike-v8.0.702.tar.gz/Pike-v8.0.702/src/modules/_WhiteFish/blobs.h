
void init_blobs_program(void);
void exit_blobs_program(void);
