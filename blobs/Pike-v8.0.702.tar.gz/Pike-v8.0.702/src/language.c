/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 120 "language.yacc" /* yacc.c:339  */

/* This is the grammar definition of Pike. */

#include "global.h"
#ifdef HAVE_MEMORY_H
#include <memory.h>
#endif

#include "interpret.h"
#include "array.h"
#include "object.h"
#include "mapping.h"
#include "stralloc.h"
#include "las.h"
#include "interpret.h"
#include "program.h"
#include "pike_types.h"
#include "constants.h"
#include "pike_macros.h"
#include "pike_error.h"
#include "docode.h"
#include "pike_embed.h"
#include "opcodes.h"
#include "operators.h"
#include "bignum.h"

#define YYMAXDEPTH	1000

#ifdef PIKE_DEBUG
#ifndef YYDEBUG
/* May also be defined by machine.h */
#define YYDEBUG 1
#endif /* YYDEBUG */
#endif

/* Get verbose parse error reporting. */
#define YYERROR_VERBOSE	1

/* #define LAMBDA_DEBUG	1 */

static void yyerror_reserved(const char *keyword);
static struct pike_string *get_new_name(struct pike_string *prefix);
int add_local_name(struct pike_string *, struct pike_type *, node *);
int low_add_local_name(struct compiler_frame *,
		       struct pike_string *, struct pike_type *, node *);
static void mark_lvalues_as_used(node *n);
static node *lexical_islocal(struct pike_string *);
static node *safe_inc_enum(node *n);
static node *find_versioned_identifier(struct pike_string *identifier,
				       int major, int minor);
static int call_handle_import(struct pike_string *s);

static int inherit_depth;
static struct program_state *inherit_state = NULL;

/*
 * Kludge for Bison not using prototypes.
 */
#ifndef __GNUC__
#ifndef __cplusplus
static void __yy_memcpy(char *to, const char *from,
			unsigned int count);
#endif /* !__cplusplus */
#endif /* !__GNUC__ */


#line 133 "y.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "y.tab.h".  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    TOK_ARROW = 258,
    TOK_CONSTANT = 259,
    TOK_FLOAT = 260,
    TOK_STRING = 261,
    TOK_NUMBER = 262,
    TOK_INC = 263,
    TOK_DEC = 264,
    TOK_RETURN = 265,
    TOK_EQ = 266,
    TOK_GE = 267,
    TOK_LE = 268,
    TOK_NE = 269,
    TOK_NOT = 270,
    TOK_LSH = 271,
    TOK_RSH = 272,
    TOK_LAND = 273,
    TOK_LOR = 274,
    TOK_SWITCH = 275,
    TOK_SSCANF = 276,
    TOK_CATCH = 277,
    TOK_FOREACH = 278,
    TOK_LEX_EOF = 279,
    TOK_ADD_EQ = 280,
    TOK_AND_EQ = 281,
    TOK_ARRAY_ID = 282,
    TOK_ATTRIBUTE_ID = 283,
    TOK_BREAK = 284,
    TOK_CASE = 285,
    TOK_CLASS = 286,
    TOK_COLON_COLON = 287,
    TOK_CONTINUE = 288,
    TOK_DEFAULT = 289,
    TOK_DEPRECATED_ID = 290,
    TOK_DIV_EQ = 291,
    TOK_DO = 292,
    TOK_DOT_DOT = 293,
    TOK_DOT_DOT_DOT = 294,
    TOK_ELSE = 295,
    TOK_ENUM = 296,
    TOK_EXTERN = 297,
    TOK_FLOAT_ID = 298,
    TOK_FOR = 299,
    TOK_FUNCTION_ID = 300,
    TOK_GAUGE = 301,
    TOK_GLOBAL = 302,
    TOK_IDENTIFIER = 303,
    TOK_RESERVED = 304,
    TOK_IF = 305,
    TOK_IMPORT = 306,
    TOK_INHERIT = 307,
    TOK_INLINE = 308,
    TOK_LOCAL_ID = 309,
    TOK_FINAL_ID = 310,
    TOK_FUNCTION_NAME = 311,
    TOK_INT_ID = 312,
    TOK_LAMBDA = 313,
    TOK_MULTISET_ID = 314,
    TOK_MULTISET_END = 315,
    TOK_MULTISET_START = 316,
    TOK_LSH_EQ = 317,
    TOK_MAPPING_ID = 318,
    TOK_MIXED_ID = 319,
    TOK_MOD_EQ = 320,
    TOK_MULT_EQ = 321,
    TOK_NO_MASK = 322,
    TOK_OBJECT_ID = 323,
    TOK_OR_EQ = 324,
    TOK_PRIVATE = 325,
    TOK_PROGRAM_ID = 326,
    TOK_PROTECTED = 327,
    TOK_PREDEF = 328,
    TOK_PUBLIC = 329,
    TOK_RSH_EQ = 330,
    TOK_STATIC = 331,
    TOK_STRING_ID = 332,
    TOK_SUB_EQ = 333,
    TOK_TYPEDEF = 334,
    TOK_TYPEOF = 335,
    TOK_VARIANT = 336,
    TOK_VERSION = 337,
    TOK_VOID_ID = 338,
    TOK_WHILE = 339,
    TOK_XOR_EQ = 340,
    TOK_OPTIONAL = 341,
    TOK_SAFE_INDEX = 342,
    TOK_SAFE_START_INDEX = 343,
    TOK_BITS = 344
  };
#endif
/* Tokens.  */
#define TOK_ARROW 258
#define TOK_CONSTANT 259
#define TOK_FLOAT 260
#define TOK_STRING 261
#define TOK_NUMBER 262
#define TOK_INC 263
#define TOK_DEC 264
#define TOK_RETURN 265
#define TOK_EQ 266
#define TOK_GE 267
#define TOK_LE 268
#define TOK_NE 269
#define TOK_NOT 270
#define TOK_LSH 271
#define TOK_RSH 272
#define TOK_LAND 273
#define TOK_LOR 274
#define TOK_SWITCH 275
#define TOK_SSCANF 276
#define TOK_CATCH 277
#define TOK_FOREACH 278
#define TOK_LEX_EOF 279
#define TOK_ADD_EQ 280
#define TOK_AND_EQ 281
#define TOK_ARRAY_ID 282
#define TOK_ATTRIBUTE_ID 283
#define TOK_BREAK 284
#define TOK_CASE 285
#define TOK_CLASS 286
#define TOK_COLON_COLON 287
#define TOK_CONTINUE 288
#define TOK_DEFAULT 289
#define TOK_DEPRECATED_ID 290
#define TOK_DIV_EQ 291
#define TOK_DO 292
#define TOK_DOT_DOT 293
#define TOK_DOT_DOT_DOT 294
#define TOK_ELSE 295
#define TOK_ENUM 296
#define TOK_EXTERN 297
#define TOK_FLOAT_ID 298
#define TOK_FOR 299
#define TOK_FUNCTION_ID 300
#define TOK_GAUGE 301
#define TOK_GLOBAL 302
#define TOK_IDENTIFIER 303
#define TOK_RESERVED 304
#define TOK_IF 305
#define TOK_IMPORT 306
#define TOK_INHERIT 307
#define TOK_INLINE 308
#define TOK_LOCAL_ID 309
#define TOK_FINAL_ID 310
#define TOK_FUNCTION_NAME 311
#define TOK_INT_ID 312
#define TOK_LAMBDA 313
#define TOK_MULTISET_ID 314
#define TOK_MULTISET_END 315
#define TOK_MULTISET_START 316
#define TOK_LSH_EQ 317
#define TOK_MAPPING_ID 318
#define TOK_MIXED_ID 319
#define TOK_MOD_EQ 320
#define TOK_MULT_EQ 321
#define TOK_NO_MASK 322
#define TOK_OBJECT_ID 323
#define TOK_OR_EQ 324
#define TOK_PRIVATE 325
#define TOK_PROGRAM_ID 326
#define TOK_PROTECTED 327
#define TOK_PREDEF 328
#define TOK_PUBLIC 329
#define TOK_RSH_EQ 330
#define TOK_STATIC 331
#define TOK_STRING_ID 332
#define TOK_SUB_EQ 333
#define TOK_TYPEDEF 334
#define TOK_TYPEOF 335
#define TOK_VARIANT 336
#define TOK_VERSION 337
#define TOK_VOID_ID 338
#define TOK_WHILE 339
#define TOK_XOR_EQ 340
#define TOK_OPTIONAL 341
#define TOK_SAFE_INDEX 342
#define TOK_SAFE_START_INDEX 343
#define TOK_BITS 344

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 188 "language.yacc" /* yacc.c:355  */

  int number;
  FLOAT_TYPE fnum;
  struct node_s *n;
  char *str;
  void *ptr;

#line 359 "y.tab.c" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif



int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */
#line 196 "language.yacc" /* yacc.c:358  */

/* Need to be included after YYSTYPE is defined. */
#define INCLUDED_FROM_LANGUAGE_YACC
#include "lex.h"
#include "pike_compiler.h"
#line 203 "language.yacc" /* yacc.c:358  */

/* Include <stdio.h> our selves, so that we can do our magic
 * without being disturbed... */
#include <stdio.h>
int yylex(YYSTYPE *yylval);
/* Bison is stupid, and tries to optimize for space... */
#ifdef YYBISON
#define short int
#endif /* YYBISON */


#line 392 "y.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned /* short */ int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef /* short */ int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   8651

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  114
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  204
/* YYNRULES -- Number of rules.  */
#define YYNRULES  663
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  992

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   344

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,   100,    94,     2,
     107,   108,    99,    97,   106,    98,   113,   101,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   104,   103,
      96,    90,    95,    91,   112,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   109,     2,   110,    93,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   111,    92,   105,   102,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   385,   385,   386,   390,   391,   392,   395,   396,   399,
     400,   401,   402,   408,   433,   450,   462,   462,   472,   487,
     493,   500,   506,   507,   512,   515,   522,   530,   531,   536,
     539,   612,   613,   616,   617,   620,   621,   622,   627,   630,
     635,   636,   637,   641,   654,   661,   667,   674,   676,   681,
     682,   688,   695,   697,   703,   722,   725,   734,   774,   731,
     962,   978,   977,   985,   986,   987,   988,   989,   990,   991,
     992,   998,  1004,  1012,  1010,  1023,  1024,  1029,  1032,  1033,
    1034,  1037,  1067,  1074,  1075,  1078,  1079,  1080,  1088,  1095,
    1096,  1102,  1103,  1104,  1105,  1106,  1107,  1108,  1109,  1113,
    1114,  1115,  1116,  1117,  1118,  1119,  1120,  1121,  1122,  1123,
    1127,  1128,  1129,  1130,  1131,  1132,  1133,  1134,  1135,  1136,
    1137,  1138,  1139,  1140,  1141,  1142,  1146,  1147,  1148,  1149,
    1150,  1151,  1152,  1153,  1154,  1155,  1156,  1157,  1158,  1159,
    1160,  1161,  1162,  1163,  1164,  1165,  1166,  1167,  1168,  1171,
    1171,  1171,  1173,  1173,  1174,  1182,  1189,  1190,  1193,  1197,
    1203,  1212,  1221,  1230,  1233,  1243,  1253,  1253,  1255,  1268,
    1281,  1294,  1295,  1298,  1299,  1302,  1302,  1305,  1306,  1307,
    1308,  1309,  1310,  1311,  1312,  1313,  1314,  1315,  1316,  1321,
    1327,  1331,  1337,  1346,  1445,  1448,  1449,  1462,  1465,  1466,
    1478,  1479,  1486,  1489,  1494,  1529,  1536,  1542,  1543,  1543,
    1577,  1578,  1579,  1587,  1591,  1586,  1618,  1631,  1632,  1635,
    1637,  1636,  1642,  1643,  1647,  1650,  1653,  1646,  1658,  1666,
    1667,  1670,  1686,  1688,  1687,  1743,  1747,  1752,  1759,  1771,
    1772,  1787,  1792,  1798,  1807,  1819,  1820,  1835,  1839,  1846,
    1851,  1860,  1845,  1887,  1888,  1899,  1900,  1901,  1906,  1912,
    1913,  1918,  1919,  1924,  1962,  1963,  1966,  1967,  1970,  1971,
    1972,  1977,  1981,  1982,  1988,  1990,  1991,  1992,  1993,  1994,
    1995,  1996,  1997,  1998,  1999,  2006,  2013,  2016,  2020,  2021,
    2022,  2023,  2024,  2025,  2026,  2027,  2031,  2030,  2047,  2048,
    2051,  2052,  2053,  2059,  2062,  2070,  2078,  2086,  2077,  2222,
    2241,  2240,  2368,  2384,  2383,  2514,  2530,  2572,  2575,  2576,
    2577,  2584,  2585,  2588,  2589,  2598,  2598,  2599,  2600,  2608,
    2685,  2607,  2863,  2864,  2867,  2868,  2872,  2873,  2939,  2945,
    2946,  2947,  2952,  2962,  2967,  2951,  2983,  3004,  3008,  3003,
    3028,  3029,  3030,  3037,  3038,  3041,  3052,  3055,  3056,  3057,
    3061,  3062,  3065,  3066,  3071,  3075,  3070,  3098,  3106,  3113,
    3122,  3123,  3131,  3135,  3130,  3155,  3159,  3154,  3175,  3176,
    3180,  3184,  3179,  3199,  3203,  3207,  3213,  3214,  3218,  3222,
    3229,  3240,  3246,  3247,  3250,  3252,  3253,  3256,  3257,  3260,
    3261,  3262,  3263,  3264,  3268,  3269,  3275,  3276,  3278,  3279,
    3280,  3281,  3282,  3291,  3292,  3293,  3294,  3300,  3307,  3308,
    3311,  3312,  3313,  3314,  3315,  3316,  3317,  3318,  3319,  3320,
    3323,  3323,  3325,  3326,  3330,  3331,  3334,  3335,  3338,  3339,
    3348,  3351,  3355,  3358,  3359,  3360,  3361,  3362,  3363,  3364,
    3365,  3366,  3367,  3368,  3369,  3370,  3371,  3372,  3373,  3374,
    3375,  3376,  3377,  3378,  3379,  3380,  3381,  3382,  3383,  3384,
    3385,  3386,  3387,  3388,  3389,  3390,  3391,  3392,  3393,  3394,
    3397,  3398,  3403,  3408,  3409,  3410,  3411,  3412,  3415,  3416,
    3417,  3439,  3443,  3440,  3535,  3541,  3547,  3554,  3560,  3569,
    3580,  3581,  3582,  3583,  3584,  3585,  3586,  3587,  3588,  3589,
    3590,  3591,  3592,  3598,  3604,  3611,  3641,  3673,  3679,  3685,
    3687,  3689,  3691,  3699,  3706,  3716,  3723,  3730,  3731,  3736,
    3737,  3738,  3739,  3743,  3748,  3749,  3750,  3756,  3786,  3794,
    3797,  3798,  3865,  3871,  3872,  3881,  3882,  3885,  3886,  3895,
    3972,  3980,  4010,  4013,  4039,  4055,  4062,  4070,  4086,  4090,
    4097,  4102,  4148,  4149,  4150,  4185,  4193,  4194,  4196,  4198,
    4203,  4210,  4225,  4241,  4242,  4243,  4248,  4251,  4252,  4253,
    4258,  4259,  4260,  4261,  4265,  4264,  4275,  4282,  4289,  4297,
    4304,  4311,  4317,  4324,  4330,  4336,  4337,  4342,  4343,  4346,
    4347,  4353,  4364,  4368,  4374,  4375,  4381,  4382,  4413,  4414,
    4427,  4428,  4442,  4443,  4454,  4473,  4474,  4476,  4478,  4480,
    4482,  4484,  4486,  4488,  4490,  4492,  4494,  4496,  4498,  4500,
    4502,  4504,  4506,  4508,  4518,  4520,  4522,  4524,  4526,  4528,
    4530,  4532,  4534,  4536,  4538,  4540,  4542,  4544,  4546,  4548,
    4550,  4552,  4554,  4556,  4558,  4560,  4562,  4564,  4566,  4568,
    4570,  4572,  4574,  4576
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_ARROW", "TOK_CONSTANT", "TOK_FLOAT",
  "TOK_STRING", "TOK_NUMBER", "TOK_INC", "TOK_DEC", "TOK_RETURN", "TOK_EQ",
  "TOK_GE", "TOK_LE", "TOK_NE", "TOK_NOT", "TOK_LSH", "TOK_RSH",
  "TOK_LAND", "TOK_LOR", "TOK_SWITCH", "TOK_SSCANF", "TOK_CATCH",
  "TOK_FOREACH", "TOK_LEX_EOF", "TOK_ADD_EQ", "TOK_AND_EQ", "TOK_ARRAY_ID",
  "TOK_ATTRIBUTE_ID", "TOK_BREAK", "TOK_CASE", "TOK_CLASS",
  "TOK_COLON_COLON", "TOK_CONTINUE", "TOK_DEFAULT", "TOK_DEPRECATED_ID",
  "TOK_DIV_EQ", "TOK_DO", "TOK_DOT_DOT", "TOK_DOT_DOT_DOT", "TOK_ELSE",
  "TOK_ENUM", "TOK_EXTERN", "TOK_FLOAT_ID", "TOK_FOR", "TOK_FUNCTION_ID",
  "TOK_GAUGE", "TOK_GLOBAL", "TOK_IDENTIFIER", "TOK_RESERVED", "TOK_IF",
  "TOK_IMPORT", "TOK_INHERIT", "TOK_INLINE", "TOK_LOCAL_ID",
  "TOK_FINAL_ID", "TOK_FUNCTION_NAME", "TOK_INT_ID", "TOK_LAMBDA",
  "TOK_MULTISET_ID", "TOK_MULTISET_END", "TOK_MULTISET_START",
  "TOK_LSH_EQ", "TOK_MAPPING_ID", "TOK_MIXED_ID", "TOK_MOD_EQ",
  "TOK_MULT_EQ", "TOK_NO_MASK", "TOK_OBJECT_ID", "TOK_OR_EQ",
  "TOK_PRIVATE", "TOK_PROGRAM_ID", "TOK_PROTECTED", "TOK_PREDEF",
  "TOK_PUBLIC", "TOK_RSH_EQ", "TOK_STATIC", "TOK_STRING_ID", "TOK_SUB_EQ",
  "TOK_TYPEDEF", "TOK_TYPEOF", "TOK_VARIANT", "TOK_VERSION", "TOK_VOID_ID",
  "TOK_WHILE", "TOK_XOR_EQ", "TOK_OPTIONAL", "TOK_SAFE_INDEX",
  "TOK_SAFE_START_INDEX", "TOK_BITS", "'='", "'?'", "'|'", "'^'", "'&'",
  "'>'", "'<'", "'+'", "'-'", "'*'", "'%'", "'/'", "'~'", "';'", "':'",
  "'}'", "','", "'('", "')'", "'['", "']'", "'{'", "'@'", "'.'", "$accept",
  "all", "program", "real_string_or_identifier", "optional_rename_inherit",
  "low_program_ref", "program_ref", "inherit_ref", "@1", "inheritance",
  "import", "constant_name", "constant_list", "constant", "block_or_semi",
  "type_or_error", "open_paren_with_line_info", "close_paren_or_missing",
  "close_brace_or_missing", "close_brace_or_eof",
  "open_bracket_with_line_info", "close_bracket_or_missing",
  "push_compiler_frame0", "optional_constant", "def", "@2", "@3", "$@4",
  "@5", "optional_dot_dot_dot", "optional_identifier", "new_arg_name",
  "func_args", "arguments", "arguments2", "modifier", "magic_identifiers1",
  "magic_identifiers2", "magic_identifiers3", "magic_identifiers",
  "magic_identifier", "modifiers", "modifier_list", "attribute",
  "optional_attributes", "optional_stars", "cast", "soft_cast", "type2",
  "simple_type", "simple_type2", "simple_identifier_type", "full_type",
  "type", "type3", "basic_type", "identifier_type", "number_or_maxint",
  "number_or_minint", "expected_dot_dot", "opt_int_range",
  "opt_string_width", "opt_object_type", "@6", "opt_program_type",
  "opt_function_type", "$@7", "$@8", "function_type_list",
  "function_type_list2", "$@9", "opt_array_type", "opt_mapping_type",
  "$@10", "$@11", "$@12", "name_list", "new_name", "@13", "new_local_name",
  "new_local_name2", "line_number_info", "block", "@14", "@15", "@16",
  "end_block", "failsafe_block", "propagated_type", "local_name_list",
  "local_name_list2", "local_constant_name", "local_constant_list",
  "local_constant", "statements", "statement_with_semicolon",
  "normal_label_statement", "statement", "labeled_statement", "$@17",
  "optional_label", "break", "default", "continue", "push_compiler_frame1",
  "implicit_identifier", "lambda", "$@18", "@19", "local_function", "@20",
  "local_function2", "@21", "create_arg", "create_arguments2",
  "create_arguments", "optional_create_arguments", "failsafe_program",
  "@22", "class", "@23", "@24", "simple_identifier", "enum_value",
  "enum_def", "propagated_enum_value", "enum_list", "enum", "$@25", "@26",
  "@27", "typedef", "cond", "@28", "@29", "end_cond", "optional_else_part",
  "safe_lvalue", "safe_expr0", "foreach_optional_lvalue",
  "foreach_lvalues", "foreach", "@30", "@31", "do", "expected_semicolon",
  "for", "@32", "@33", "while", "@34", "@35", "for_expr", "switch", "@36",
  "@37", "case", "expected_colon", "return", "unused", "unused2",
  "optional_comma_expr", "safe_comma_expr", "comma_expr", "comma_expr2",
  "expr00", "expr0", "expr01", "assign", "optional_comma", "expr_list",
  "expr_list2", "m_expr_list", "m_expr_list2", "assoc_pair", "expr1",
  "expr2", "expr3", "optional_block", "@38", "apply", "implicit_modifiers",
  "expr4", "idents2", "idents", "string_or_identifier",
  "inherit_specifier", "low_idents", "range_bound", "gauge", "typeof",
  "catch_arg", "catch", "$@39", "sscanf", "lvalue", "low_lvalue_list",
  "lvalue_list", "string_segment", "string", "string_constant",
  "real_string_constant", "bad_identifier", "bad_expr_ident", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
      61,    63,   124,    94,    38,    62,    60,    43,    45,    42,
      37,    47,   126,    59,    58,   125,    44,    40,    41,    91,
      93,   123,    64,    46
};
# endif

#define YYPACT_NINF -820

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-820)))

#define YYTABLE_NINF -661

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -820,    57,  1079,  -820,   425,  -820,   409,  -820,  -820,  -820,
    -820,  -820,   355,   808,  -820,  -820,  -820,  -820,   477,  -820,
    7822,    -4,    32,  -820,  -820,    58,    65,   154,   114,   198,
    7278,  -820,  -820,   210,  7346,  -820,  -820,   770,  6834,  -820,
    6886,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
     216,  7890,  7958,  -820,  -820,  7414,  -820,  -820,   271,   278,
    -820,  -820,   435,   235,  -820,   -10,   265,  8026,  8026,   484,
     107,   954,   209,    34,   229,  -820,   273,   292,   209,   306,
    -820,   310,   328,   292,  -820,  7686,  -820,  -820,  -820,   296,
     302,  -820,    48,   374,   450,  -820,  -820,   380,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  3166,
    -820,  -820,  3166,  -820,  7482,  3166,  -820,  -820,  -820,   366,
    -820,  -820,  -820,   521,  7210,   386,  -820,   296,    50,   398,
    6834,  -820,  -820,   302,  5607,  -820,  -820,   363,  -820,  -820,
    -820,  -820,  -820,   393,  5659,  -820,  -820,  -820,  -820,  6834,
     438,  -820,  4122,   302,  5538,  -820,  -820,  -820,  -820,  -820,
    6721,  6721,  6698,   416,    53,  -820,  1147,   517,    61,  -820,
      58,   453,  6698,  6698,  -820,  -820,  2243,  6412,  6698,  6698,
    -820,  -820,  -820,  -820,  5817,  -820,  -820,  -820,   316,  5896,
    -820,   296,  -820,  -820,  -820,  -820,    50,  7025,  -820,   467,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,   110,  -820,  -820,   302,   226,   302,    86,   460,   283,
    6782,   464,  -820,   470,   568,   187,  6834,   954,   473,   311,
    -820,  -820,  -820,  -820,  -820,    13,  -820,  8094,   322,  -820,
     416,  -820,    62,   517,  -820,   453,  3275,   317,   317,  5477,
    -820,   285,  3602,    62,  -820,  2352,  -820,  -820,  -820,  8162,
    -820,  2838,  3711,  -820,  -820,   182,  6507,  6209,   331,  -820,
     455,  -820,  6412,   540,   -18,  -820,   317,  5788,   507,   513,
    -820,  -820,  -820,  4296,  4365,  4434,  4503,  4572,  4641,  4710,
    4779,  6698,  4848,  4917,  4986,  5055,  5124,  5193,  5262,  5331,
    5400,  5469,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  3820,
    -820,  2947,  1588,  3929,  6616,  6616,   518,  6952,  -820,   627,
     302,  -820,   526,  6834,  -820,  -820,  -820,   380,   580,   530,
    -820,  -820,  -820,  -820,  -820,  -820,    33,   101,  -820,   549,
    -820,  -820,  6834,   550,   361,   232,  -820,  -820,   -18,   196,
      80,  -820,   246,  -820,  8230,   570,  -820,   555,   561,  -820,
    -820,  -820,  -820,   237,  6616,  -820,  -820,    -7,   562,   365,
     564,  -820,  -820,  -820,  -820,   565,  6412,   339,   559,   569,
    -820,   956,  7025,  6834,  -820,  6616,  -820,   570,   566,  -820,
    -820,  6412,  -820,  7011,  -820,   628,  -820,   420,  -820,   420,
    -820,   628,  -820,   413,  -820,   413,  -820,  5848,  -820,  7028,
     573,  -820,  5830,  -820,   553,  -820,  6723,  -820,   420,  -820,
     420,  -820,   485,  -820,   485,  -820,  -820,  -820,  -820,  -820,
    -820,  7129,   633,  5991,  -820,  -820,   634,   421,   576,   197,
    -820,  6318,   575,  -820,   577,   187,  -820,  -820,  -820,  -820,
      43,    46,  -820,   596,  -820,   582,  -820,  -820,   368,  -820,
    -820,   587,   194,  -820,  -820,   687,   588,  -820,  -820,  -820,
    3384,    70,  6616,   590,  8298,  -820,  -820,  -820,  -820,  -820,
     439,  6616,  -820,  -820,  -820,  -820,  8366,  -820,   589,  -820,
      28,  -820,   594,  -820,   611,  -820,  -820,    71,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  6507,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,   597,   592,  -820,  -820,  -820,  -820,
    4038,  -820,   599,  3056,  -820,  -820,  -820,  -820,   507,  -820,
    6616,  6616,  6698,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,   600,   187,  -820,  -820,  -820,  -820,   593,   593,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  6100,
    6834,  -820,   506,   601,  -820,  -820,  -820,  -820,  -820,  3166,
    -820,  -820,   163,  -820,  -820,  6834,  -820,  -820,  6834,  -820,
    -820,  6616,  -820,  -820,  -820,  6782,   621,   622,  -820,  -820,
    -820,  -820,    44,    90,   624,  -820,  3166,    74,  -820,  3166,
    -820,  -820,   613,  -820,  -820,  5563,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  6100,  -820,  -820,  -820,
     612,  -820,  -820,    54,  -820,  -820,  -820,  4210,  -820,  8434,
    -820,  -820,  -820,  6834,   380,   380,  -820,  6782,  -820,   625,
     510,   293,  -820,   468,   626,  3493,    75,  6616,  -820,  -820,
    -820,  6782,  -820,  -820,  -820,  -820,  -820,   629,  -820,  -820,
    7754,  -820,  -820,   163,  -820,   370,   632,   601,    37,  6834,
    6834,  -820,  8026,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  8502,  -820,   601,    59,  -820,  1479,
      59,  -820,  -820,   673,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,    59,   645,  -820,
    -820,  -820,  -820,  -820,   532,  7550,  1260,   630,   639,   180,
    1369,   180,  1155,  8561,   641,     1,   642,  5708,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,    24,  -820,
      24,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,    24,
    -820,  -820,  -820,  -820,    37,  -820,  -820,  -820,  -820,   447,
     663,  -820,   347,   667,  -820,  -820,  -820,  -820,    24,  -820,
    -820,  -820,  -820,  -820,  2461,   640,  -820,  -820,  1698,  -820,
     655,  -820,  -820,  -820,  -820,  -820,  1479,  -820,  -820,  3166,
    -820,  -820,  3166,  -820,  7618,  3166,  -820,  -820,  -820,   339,
    1807,  -820,   239,  -820,  1698,  -820,  -820,  -820,  -820,  -820,
     670,  -820,  -820,   654,   656,  -820,   339,  -820,  -820,    19,
     657,  -820,   659,   662,  2461,  6616,  -820,  -820,  2461,  2025,
    2461,  2461,   394,   384,   394,    24,  -820,   394,   394,  -820,
    -820,  -820,  1698,  2649,  2743,   394,    24,  2134,  1698,  1698,
    -820,  -820,  -820,   675,  -820,  -820,  1698,  -820,    24,  -820,
     730,  -820,  2555,  -820,  1916,  1698,  -820,  -820,   394,  -820,
    1698,  -820
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       6,     0,     0,     1,     0,     3,     0,     5,    64,    65,
      66,     4,   161,   155,    69,    70,    71,    72,     0,   606,
       0,     0,   553,   556,   607,     0,     0,     0,     0,     0,
       0,   543,   608,   548,     0,   248,   342,     0,     0,    73,
       0,    67,    68,    91,    97,    94,    89,    88,    93,    96,
      95,    90,    98,    92,   157,    28,    27,    29,   648,   655,
     654,   651,   662,   616,   617,   657,   658,   618,   659,   660,
     619,   646,   647,   620,   644,   621,   661,   622,   652,   564,
     633,   663,   649,   650,   634,   635,   645,   623,   624,   653,
     627,   625,   626,   636,   628,   638,   629,   639,   637,   640,
     643,   630,   631,   656,   642,   632,   641,   565,   615,   550,
       0,     0,     0,   554,    25,     0,   549,   563,   561,   562,
      26,   609,     0,     0,    33,     0,     0,    80,    80,     0,
       0,     0,   223,     0,     0,   177,   216,   202,   223,   228,
     179,   207,   210,   202,   178,     0,   172,   175,   176,   193,
     548,     6,     0,   160,    55,   162,    43,   168,   555,   557,
     558,   559,   560,   546,   544,   545,   551,   552,    37,     0,
      36,    38,     0,    35,     0,     0,    78,   329,    79,     0,
      23,    22,    24,     0,     0,     0,    17,    14,   610,    13,
       0,   186,   190,     0,     0,   213,   183,     0,   181,   187,
     224,   182,   184,     0,     0,   185,   206,   180,   332,     0,
       0,   333,     0,     0,     0,    56,   163,   359,   502,   501,
     499,   499,   499,   654,   651,   358,     0,   635,   653,   248,
     637,   656,   499,   499,    44,    51,     0,   499,   499,   499,
     507,    32,   357,   408,   418,   443,   480,   511,     0,   488,
     510,   540,   504,   505,   503,   506,   500,     0,    30,     0,
      34,    31,   330,   343,    20,    19,    21,    11,   612,     7,
       9,     8,    10,    18,     0,     0,   610,     0,     0,     0,
     430,     0,   198,     0,     0,     0,     0,     0,     0,     0,
     171,   346,    50,    49,    74,     0,   159,     0,     0,   229,
       0,   584,     0,     0,   248,     0,     0,   483,   484,     0,
     485,   488,     0,     0,   583,     0,   249,   582,   571,     0,
     305,     0,     0,   487,   486,     0,   432,   436,     0,   174,
       0,   404,   499,     0,   166,   167,   599,   193,   604,     0,
     602,   481,   482,     0,     0,     0,     0,     0,     0,     0,
       0,   499,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   508,   509,   248,   489,   490,   425,   420,   429,
     423,   428,   427,   421,   424,   426,   422,   248,   248,     0,
     248,     0,     0,     0,   499,   499,   323,     0,   613,     0,
     611,   222,     0,     0,   192,   191,   431,   219,    77,   430,
     217,   205,   203,   199,   200,   201,   194,     0,    15,     0,
     212,   211,   431,     0,    54,   232,    63,   163,     0,     0,
       0,   585,     0,   163,     0,   169,   170,     0,   399,   248,
     541,   542,   304,     0,   499,   434,   406,     0,   430,     0,
       0,   528,   529,   530,   527,    48,   499,     0,    53,   430,
     438,   488,   602,     0,   164,   499,   522,   166,     0,   601,
     165,   499,   603,     0,   467,   449,   470,   452,   472,   454,
     468,   450,   473,   455,   474,   456,   463,   445,   462,   444,
       0,   464,   446,   465,   447,   466,   448,   469,   451,   471,
     453,   475,   457,   476,   458,   477,   459,   478,   460,   479,
     461,     0,     0,   499,   410,   409,     0,     0,     0,     0,
     569,   499,     0,   567,   404,     0,   414,   413,   411,   415,
     156,     0,   341,   334,   339,   344,   614,   189,     0,    76,
      75,     0,   220,   218,   195,     0,     0,   225,   209,   158,
       0,     0,   499,     0,     0,   230,   596,   598,   597,   595,
       0,   499,   579,   581,   580,   578,     0,   259,   400,   403,
     244,   261,   401,   402,   245,   577,   250,     0,   533,   531,
     534,   535,   532,   407,   525,   526,   431,   433,   575,   576,
     574,   573,   572,    47,     0,     0,   389,   387,   386,   388,
       0,    52,     0,     0,   437,   173,   405,   600,   604,   417,
     499,   499,   499,   539,   137,   144,   146,   145,   132,   131,
     112,   113,   135,   136,   134,   138,   139,   114,   127,   130,
     124,   102,   122,   128,   118,   133,   148,   152,   153,   126,
     140,   141,   107,   104,   100,   119,   123,   142,   116,   115,
     111,    99,   117,   103,   120,   106,   143,   105,   101,   121,
     125,   147,   109,   110,   129,   108,   149,   150,   151,   154,
     536,   537,   404,     0,   538,   496,   497,   498,   491,   491,
     518,   519,   520,   521,   517,   570,   568,   512,   513,   499,
       0,   318,   430,    46,   321,   327,   328,     6,   331,     0,
     337,   338,     0,   188,   214,     0,   196,   204,     0,   235,
     236,   499,    60,    57,   237,   430,   231,   232,   592,   594,
     593,   591,     0,   238,   239,   258,     0,     0,   258,     0,
     251,   309,     0,   435,   523,     0,   442,   441,   524,   440,
     439,   605,   412,   416,   419,   515,   499,   248,   495,   494,
       0,   163,   156,   156,   322,    45,   324,     0,   335,   336,
     254,   253,   345,     0,   221,   226,   234,   430,    85,     0,
     430,    77,    83,     0,     0,     0,     0,   499,   163,   246,
     312,   430,   310,   163,   247,   272,   307,     0,   304,   514,
      77,   320,   319,     0,   340,     0,     0,    46,     0,     0,
     431,    84,    80,   588,   590,   589,   587,   586,   242,   243,
     240,   315,   313,   241,     0,   260,    46,     0,   262,     0,
       0,   516,   492,     0,   317,   326,   215,   227,    58,    42,
      41,    40,    62,    39,    87,    86,    81,     0,   238,    82,
     256,   257,   255,   311,     0,     0,     0,   655,   662,   657,
       0,   659,   302,   248,   661,   553,   663,     0,   375,   286,
     276,   280,   252,   279,   275,   287,   273,   295,     0,   294,
       0,   277,   291,   289,   290,   288,   292,   293,   278,     0,
     394,   308,   272,   316,     0,   314,   284,   283,   285,     0,
       0,   266,     0,     0,   398,   371,   370,   390,     0,   397,
     248,   248,   298,   300,     0,     0,   303,   301,     0,   248,
       0,   248,   248,   281,   282,   274,     0,    59,   270,     0,
     269,   271,     0,   268,     0,     0,   391,   381,   365,     0,
       0,   383,     0,   373,     0,   348,   376,   493,   265,   263,
       0,   267,   264,     0,     0,   385,     0,   396,   369,     0,
       0,   297,     0,     0,     0,   499,   384,   368,     0,     0,
       0,     0,     0,     0,     0,     0,   393,     0,     0,   352,
     351,   350,     0,     0,     0,     0,     0,     0,     0,     0,
     382,   356,   361,     0,   355,   362,     0,   367,     0,   379,
     353,   377,     0,   366,     0,     0,   349,   363,     0,   354,
       0,   374
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -820,  -820,  -148,  -820,  -820,   486,  -820,  -820,  -820,  -820,
       7,   607,  -820,  -820,   -92,   108,  -169,  -722,  -820,  -820,
     247,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -695,
    -126,  -162,  -649,  -442,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,  -489,  -820,  -820,  -820,  -208,  -820,  -820,  -820,  -820,
    -820,  -820,   134,  -232,  -193,   218,   -15,  -820,  -820,  -505,
     643,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,  -820,
    -820,   652,  -820,  -820,  -820,  -820,  -820,   375,  -820,  -679,
    -820,   -34,  -168,  -820,  -820,  -820,  -763,  -439,    79,  -820,
    -820,  -121,  -820,  -820,   -74,  -820,  -820,  -347,  -820,  -820,
     -42,  -820,  -820,  -820,  -523,  -820,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -111,  -820,  -820,  -820,  -820,  -820,   552,
    -820,  -820,   660,  -820,    52,  -820,  -820,   556,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -142,  -820,  -158,  -157,  -175,
    -820,  -820,  -820,  -820,  -820,  -819,  -820,  -820,  -820,  -820,
    -820,  -820,  -820,  -820,  -820,  -820,  -820,  -554,  -820,  -176,
    -820,  -820,  -567,   106,  -150,   234,   334,  -340,  -251,  -253,
     -48,  -820,  -820,  -820,   227,  8246,   128,  -820,   142,  -820,
    -820,  -820,  -109,  -820,    -6,  -820,  -820,  -820,  -479,  -820,
    -820,   508,  -820,  -820,  -820,  -448,  -313,  -568,     3,    82,
    -134,  -820,    -8,   -13
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,     2,   270,   185,   186,   409,   130,   131,     8,
     850,   124,   125,    10,   822,   154,   236,   746,   584,   294,
     237,   592,   541,   216,    11,   757,   874,   543,   151,   531,
     177,   758,   772,   759,   760,    54,   656,   657,   658,   659,
     660,    12,    13,   155,    40,   804,   238,   239,   333,   156,
     423,   424,   761,   425,   146,   329,   426,   536,   285,   406,
     198,   207,   202,   203,   205,   196,   280,   753,   398,   399,
     695,   191,   201,   286,   698,   786,   298,   299,   701,   557,
     561,   320,   851,   429,   720,   775,   752,   833,   768,   558,
     562,   881,   882,   853,   809,   854,   855,   856,   857,   900,
     893,   858,   859,   860,   567,   432,   240,   722,   810,   563,
     807,   559,   827,   681,   682,   683,   521,   688,   783,    41,
     262,   386,   523,   690,   524,   749,   525,    42,   128,   387,
     692,    14,   861,   901,   942,   962,   986,   972,   241,   973,
     965,   862,   891,   934,   863,   887,   864,   899,   940,   865,
     902,   943,   978,   866,   890,   933,   867,   590,   868,   955,
     869,   936,   956,   889,   428,   435,   331,   243,   383,   762,
     437,   438,   448,   449,   450,   244,   245,   246,   738,   872,
     247,   248,   249,   250,   251,    29,    30,    31,   515,   252,
     253,   318,   254,   313,   255,   338,   339,   462,    32,   256,
     189,   271,   178,   257
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
      28,   127,   179,   212,   328,   334,   385,   108,   297,     9,
     679,   480,   107,   598,   392,   258,   290,   108,   261,   458,
     815,   108,   119,   148,   663,   148,   126,   400,   109,  -304,
     731,   680,   149,  -547,   149,   192,   121,   717,   819,   903,
     534,   904,   413,   947,  -430,   763,   852,   685,   885,   192,
     905,   306,   306,   574,  -584,  -431,    19,     3,   317,   277,
     830,   820,  -248,   314,  -547,   818,   792,  -430,   306,   916,
     686,   702,   721,   776,   453,   770,   801,   418,  -431,   295,
     381,   550,  -548,   831,   829,   813,   330,   392,    33,   805,
     111,  -304,   460,   173,   808,   334,   174,   112,   108,   108,
     457,   575,   108,   160,   162,  -296,    24,   165,   183,   110,
     274,   307,   308,   311,   108,   108,   388,   802,   716,   412,
     150,  -430,   150,   311,   311,   187,   948,   886,   336,   311,
     311,   535,   108,   585,   317,  -304,   967,   211,   381,   381,
     821,   193,   381,   927,   764,   317,   533,   977,   316,   396,
     461,  -430,  -604,   121,  -430,   213,   330,   687,   736,   984,
    -584,   108,  -431,   306,  -584,  -431,   126,   381,  -248,   315,
     316,   108,   145,   316,   157,   148,   272,   703,  -306,   148,
     765,   771,   771,   274,   149,   577,   551,   750,   149,   148,
     766,   121,   393,   209,   148,   321,   594,  -304,   149,   148,
     740,   385,   113,   149,  -299,   537,   441,   389,   149,   544,
     -12,   184,   601,   188,   334,   556,    19,   114,   451,     9,
     546,   670,   335,   336,   340,   404,   405,   115,   892,   457,
     116,   337,  -431,  -431,   311,   311,   311,   311,   311,   311,
     311,   311,   311,   311,   311,   311,   311,   311,   311,   311,
     311,   311,   311,   680,   680,   812,   147,   777,   147,   121,
     595,   568,   734,   938,   158,   148,    24,   684,   751,   888,
     552,   148,   150,   895,   149,   276,   150,   306,   445,   121,
     149,   187,   381,  -299,   108,   442,   150,   443,   364,   415,
     444,   150,   306,   365,   366,   276,   150,   569,  -431,   547,
     671,   548,   672,   166,   549,   673,   108,   674,    19,   337,
     167,   431,   335,   120,   452,   787,   190,   335,   209,   340,
     364,   337,   542,   939,   275,   172,   337,   919,   279,   806,
     501,   529,   530,   508,   391,   894,   194,   336,   289,   -61,
     570,   921,   571,   502,   503,   572,   506,    35,   279,   553,
     310,   554,   336,   937,   555,   175,   390,    36,    24,    34,
     323,   324,   150,   586,   281,   935,   341,   342,   150,   188,
     282,   871,   377,   378,   108,   209,   337,   952,   148,   211,
     195,   954,   946,   957,   958,   209,    35,   149,   875,   578,
     920,   395,   234,   121,   235,   566,    36,   148,   380,   197,
     979,  -197,  -197,   209,   377,   378,   149,    37,   147,   115,
      18,   108,   147,   200,   397,    19,   564,  -208,   959,   411,
     407,   427,   147,   453,   234,   416,   235,   147,   417,   744,
     380,   335,   147,   340,    38,   204,   347,   348,   148,   454,
     337,    20,   587,   588,   589,   665,   335,   149,   340,    15,
     913,   540,   283,   914,   215,   337,    21,    22,    23,   168,
     209,   284,   209,   708,  -231,    24,    39,  -231,   579,   309,
     580,   908,   209,   581,   601,   150,   693,   263,   816,   309,
     309,   214,    25,   327,   332,   309,   309,   963,   513,   273,
     964,    26,   793,   311,   150,   274,   382,   337,   147,   960,
     287,    55,   961,   242,   147,   337,   242,   791,   180,   242,
     357,   358,   359,   360,   361,   974,   974,   357,   358,   359,
     360,   361,    27,   312,   666,   169,   667,   528,    16,   668,
      17,   108,   748,   780,   974,   150,   707,   909,   170,   747,
     171,   291,   709,   108,   710,   264,   528,   711,   714,   319,
     910,   922,   911,   327,   382,   382,   876,   169,   382,   769,
     322,   455,   774,   456,   343,   344,   345,   346,   394,   347,
     348,   794,   401,   795,   446,   403,   796,   941,   402,   332,
      56,   410,    57,   382,   359,   360,   361,   181,   459,   182,
     309,   309,   309,   309,   309,   309,   309,   309,   309,   309,
     309,   309,   309,   309,   309,   309,   309,   309,   309,   513,
     742,   147,   743,   461,   789,   970,   790,   676,   529,   530,
     823,   980,   981,   463,   265,   520,   266,   824,   825,   983,
     147,   781,   782,   526,   527,   877,   532,   878,   989,   832,
     344,   345,   832,   991,   347,   348,   420,   354,   355,   356,
     357,   358,   359,   360,   361,   436,   440,   538,   539,   832,
     436,   447,   453,   565,   586,   148,   826,   455,   576,   591,
     583,   147,   582,   337,   149,   593,   597,   602,   404,   405,
     148,   661,   664,   148,   669,   677,   689,   678,   691,   149,
     148,   694,   149,   332,   696,   715,   697,   705,   382,   149,
     718,   719,   725,   778,   737,   724,   823,   728,   332,   745,
     735,   540,   542,   505,   767,   436,   514,   517,   518,   519,
     771,   873,   779,   355,   356,   357,   358,   359,   360,   361,
     337,   457,   457,   788,   797,   765,   108,  -380,   148,   811,
     817,   211,   148,   587,   588,   589,  -364,   149,  -372,  -347,
     457,   149,   928,   912,     9,   929,   148,   915,   932,   924,
     909,   944,   150,   945,   949,   149,   950,   108,   573,   951,
     985,   129,   814,   408,   148,   148,   -16,   150,   982,   108,
     150,   260,   907,   149,   149,   513,   206,   150,   741,   596,
     199,   108,   545,   931,   306,   306,   714,   773,   906,   896,
     362,   784,   -16,   337,   363,   210,   975,   987,   988,   898,
     723,   739,   966,   306,   157,   968,   969,   -16,   -16,   -16,
     730,   421,   108,   976,     0,     0,   -16,   883,     0,   754,
     337,     0,   755,     0,   337,   150,     0,   662,     0,   150,
       0,    28,   513,   -16,     0,     0,   990,     0,     0,   309,
      43,     0,   -16,   150,   336,   336,   917,   918,     0,     0,
       0,    44,    45,    46,     0,   923,     0,   925,   926,     0,
       0,   150,   150,   336,     0,    47,   704,     0,    48,     0,
      49,     0,    50,   -16,    51,   712,     0,   785,   337,    52,
       0,     0,   337,     0,    53,     0,     0,     0,   147,     0,
     337,   108,     0,     0,     0,     0,   883,     0,     0,     0,
     436,     0,     0,   147,   337,   870,   147,     0,   337,     0,
       0,     0,     0,   147,   727,     0,     0,   447,     0,    33,
       0,     0,     0,     0,   732,   733,     0,     0,   337,     0,
       0,     0,   337,   337,   337,   337,     0,     0,   335,   335,
     340,   340,     0,     0,     0,     0,   337,   337,   337,   364,
      19,   337,   337,   337,   365,   366,     0,   335,     0,   340,
     337,   147,     0,     0,     0,   147,   337,     0,   337,   337,
       0,   367,   368,     0,   337,     0,    20,     0,     0,   147,
       0,     0,   369,     0,     0,     0,     0,     0,     0,     0,
       0,    21,    22,    23,   870,     0,     0,   147,   147,     0,
      24,     0,   870,     0,     0,     0,     0,     0,   370,     0,
       0,   371,   372,   242,     0,   373,     0,    25,     0,     0,
     870,   374,     0,     0,   375,   756,    26,     0,     0,     0,
       0,   376,     0,   377,   378,     0,   379,     0,     0,     0,
     242,     0,     0,   242,     0,     0,     0,     0,     0,     0,
       0,     0,  -599,   234,     0,   235,  -599,    27,   870,   380,
       0,     0,     0,     0,   870,   870,     0,     0,     0,    -2,
       4,     0,   870,  -156,     0,  -156,     0,     0,     0,     0,
       0,   870,     0,     0,     0,     0,   870,     0,     0,   800,
       0,   803,     0,     5,     0,     0,  -156,  -156,     0,     0,
    -156,  -156,     0,     0,  -156,     0,     0,     0,     0,     0,
    -156,  -156,  -156,     0,  -156,     0,  -156,  -156,  -156,     0,
       6,  -156,  -156,  -156,  -156,  -156,  -156,     0,  -156,     0,
       0,     0,  -156,  -156,     0,     0,  -156,  -156,   314,  -156,
    -156,  -156,  -156,  -156,     0,  -156,  -156,     0,  -156,     0,
    -156,  -156,  -156,     0,     0,  -156,     0,     0,     0,     0,
       0,  -652,  -652,  -652,     0,     0,     0,     0,     0,     0,
    -660,  -660,     7,  -652,     0,     0,     0,     0,     0,     0,
    -156,  -660,  -156,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,  -652,
     332,   332,  -652,  -652,     0,     0,  -652,  -660,     0,     0,
    -660,  -660,  -652,     0,  -660,  -652,     0,     0,     0,   332,
    -660,     0,  -652,  -660,     0,     0,     0,  -652,     0,     0,
    -660,     0,     0,   242,     0,  -660,   242,     0,     0,   242,
    -652,     0,  -652,  -652,   315,  -652,     0,  -652,   316,   897,
       0,   884,     0,     0,     0,   218,    19,   219,   220,   221,
      58,     0,     0,     0,     0,   222,     0,     0,     0,   953,
      59,   223,   224,    62,   885,  -648,  -648,   132,   133,    65,
      66,  -499,    20,    68,    69,   134,  -648,    71,     0,     0,
      72,  -499,    74,   135,    76,   136,   226,    21,    22,    23,
      81,    82,    83,    84,   227,    86,    24,   137,   228,   138,
       0,   229,  -648,   139,   140,  -648,  -648,    93,   141,  -648,
      95,   142,    97,   230,    99,  -648,   100,   143,  -648,     0,
     231,   104,    26,   144,     0,  -648,   106,     0,     0,     0,
    -648,     0,     0,     0,     0,     0,     0,     0,   232,     0,
       0,     0,   233,   886,     0,     0,     0,   234,     0,   235,
     884,     0,     0,    27,   218,    19,   219,   220,   221,    58,
       0,     0,     0,     0,   222,     0,     0,     0,     0,    59,
     223,   224,    62,     0,  -658,  -658,   132,   133,    65,    66,
    -499,    20,    68,    69,   134,  -658,    71,   404,   405,    72,
    -499,    74,   135,    76,   136,   226,    21,    22,    23,    81,
      82,    83,    84,   227,    86,    24,   137,   228,   138,     0,
     229,  -658,   139,   140,  -658,  -658,    93,   141,  -658,    95,
     142,    97,   230,    99,  -658,   100,   143,  -658,     0,   231,
     104,    26,   144,     0,  -658,   106,     0,     0,     0,  -658,
       0,     0,     0,     0,     0,     0,     0,   232,     0,     0,
       0,   233,     0,     0,     0,     0,   234,     0,   235,     0,
     834,     0,    27,   835,   218,    19,   219,   220,   221,   836,
       0,     0,     0,     0,   222,     0,     0,     0,     0,   837,
     223,   224,   838,   750,     0,     0,   132,   133,   839,   840,
    -499,    20,   841,   842,   134,     0,   843,     0,     0,    72,
    -499,    74,   135,   844,   136,   226,    21,   845,    23,   846,
     847,    83,    84,   227,    86,    24,   137,   228,   138,     0,
     229,     0,   139,   140,     0,     0,    93,   141,     0,    95,
     142,    97,   230,    99,     0,   100,   143,     0,     0,   231,
     104,    26,   144,   848,     0,   106,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   232,     0,     0,
       0,   233,   849,     0,   751,     0,   234,     0,   235,   509,
     316,     0,    27,   218,    19,   219,   220,   221,    58,     0,
       0,     0,     0,   222,     0,     0,     0,     0,    59,   223,
     224,    62,   510,     0,     0,   132,   133,    65,    66,  -499,
      20,    68,    69,   134,     0,    71,  -566,  -566,    72,  -499,
      74,   135,    76,   136,   226,    21,    22,    23,    81,    82,
      83,    84,   227,    86,    24,   137,   228,   138,     0,   229,
       0,   139,   140,     0,     0,    93,   141,     0,    95,   142,
      97,   230,    99,     0,   100,   143,     0,     0,   231,   104,
      26,   144,     0,     0,   106,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   511,     0,   232,   512,     0,     0,
     233,     0,     0,     0,     0,   234,     0,   235,     0,   834,
       0,    27,   835,   218,    19,   219,   220,   221,   836,     0,
       0,     0,     0,   222,     0,     0,     0,     0,   837,   223,
     224,   838,     0,     0,     0,   132,   133,   839,   840,  -499,
      20,   841,   842,   134,     0,   843,     0,     0,    72,  -499,
      74,   135,   844,   136,   226,    21,   845,    23,   846,   847,
      83,    84,   227,    86,    24,   137,   228,   138,     0,   229,
       0,   139,   140,     0,     0,    93,   141,     0,    95,   142,
      97,   230,    99,     0,   100,   143,     0,     0,   231,   104,
      26,   144,   848,     0,   106,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   232,     0,     0,     0,
     233,   849,     0,     0,     0,   234,     0,   235,   884,   316,
       0,    27,   218,    19,   219,   220,   221,    58,     0,     0,
       0,     0,   222,     0,     0,     0,     0,    59,   223,   224,
      62,  -395,     0,     0,   132,   133,    65,    66,  -499,    20,
      68,    69,   134,     0,    71,     0,     0,    72,  -499,    74,
     135,    76,   136,   226,    21,    22,    23,    81,    82,    83,
      84,   227,    86,    24,   137,   228,   138,     0,   229,     0,
     139,   140,     0,     0,    93,   141,     0,    95,   142,    97,
     230,    99,     0,   100,   143,     0,     0,   231,   104,    26,
     144,     0,     0,   106,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   232,     0,     0,     0,   233,
    -395,  -395,  -395,     0,   234,     0,   235,   884,     0,     0,
      27,   218,    19,   219,   220,   221,    58,     0,     0,     0,
       0,   222,     0,     0,     0,     0,    59,   223,   224,    62,
    -392,     0,     0,   132,   133,    65,    66,  -499,    20,    68,
      69,   134,     0,    71,     0,     0,    72,  -499,    74,   135,
      76,   136,   226,    21,    22,    23,    81,    82,    83,    84,
     227,    86,    24,   137,   228,   138,     0,   229,     0,   139,
     140,     0,     0,    93,   141,     0,    95,   142,    97,   230,
      99,     0,   100,   143,     0,     0,   231,   104,    26,   144,
       0,     0,   106,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   232,     0,     0,     0,   233,     0,
       0,  -392,     0,   234,  -392,   235,   884,     0,     0,    27,
     218,    19,   219,   220,   221,    58,     0,     0,     0,     0,
     222,     0,     0,     0,     0,    59,   223,   224,    62,  -392,
       0,     0,   132,   133,    65,    66,  -499,    20,    68,    69,
     134,     0,    71,     0,     0,    72,  -499,    74,   135,    76,
     136,   226,    21,    22,    23,    81,    82,    83,    84,   227,
      86,    24,   137,   228,   138,     0,   229,     0,   139,   140,
       0,     0,    93,   141,     0,    95,   142,    97,   230,    99,
       0,   100,   143,     0,     0,   231,   104,    26,   144,     0,
       0,   106,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   232,     0,     0,     0,   233,  -392,     0,
       0,     0,   234,     0,   235,   884,     0,     0,    27,   218,
      19,   219,   220,   221,    58,     0,     0,     0,     0,   222,
       0,     0,     0,     0,    59,   223,   224,    62,  -378,     0,
       0,   132,   133,    65,    66,  -499,    20,    68,    69,   134,
       0,    71,     0,     0,    72,  -499,    74,   135,    76,   136,
     226,    21,    22,    23,    81,    82,    83,    84,   227,    86,
      24,   137,   228,   138,     0,   229,     0,   139,   140,     0,
       0,    93,   141,     0,    95,   142,    97,   230,    99,     0,
     100,   143,     0,     0,   231,   104,    26,   144,     0,     0,
     106,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   232,     0,     0,     0,   233,  -378,     0,     0,
       0,   234,     0,   235,   325,     0,     0,    27,   218,    19,
     219,   220,   221,    58,     0,     0,     0,     0,   222,     0,
       0,     0,     0,    59,   223,   224,    62,     0,     0,     0,
     132,   133,    65,    66,  -499,    20,    68,    69,   134,     0,
      71,     0,     0,    72,  -499,    74,   135,    76,   136,   226,
      21,    22,    23,    81,    82,    83,    84,   227,    86,    24,
     137,   228,   138,     0,   229,     0,   139,   140,     0,     0,
      93,   141,     0,    95,   142,    97,   230,    99,     0,   100,
     143,     0,     0,   231,   104,    26,   144,     0,     0,   106,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   232,     0,     0,     0,   233,     0,     0,     0,     0,
     234,     0,   235,   422,   326,     0,    27,   218,    19,   219,
     220,   221,    58,     0,     0,     0,     0,   222,     0,     0,
       0,     0,    59,   223,   224,    62,     0,     0,     0,   132,
     133,    65,    66,  -499,    20,    68,    69,   134,     0,    71,
       0,     0,    72,  -499,    74,   135,    76,   136,   226,    21,
      22,    23,    81,    82,    83,    84,   227,    86,    24,   137,
     228,   138,     0,   229,     0,   139,   140,     0,     0,    93,
     141,     0,    95,   142,    97,   230,    99,     0,   100,   143,
       0,     0,   231,   104,    26,   144,     0,     0,   106,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     232,     0,     0,     0,   233,     0,     0,     0,     0,   234,
       0,   235,   884,     0,     0,    27,   218,    19,   219,   220,
     221,    58,     0,     0,     0,     0,   222,     0,     0,     0,
       0,    59,   223,   224,    62,     0,     0,     0,   132,   133,
      65,    66,  -499,    20,    68,    69,   134,     0,    71,     0,
       0,    72,  -499,    74,   135,    76,   136,   226,    21,    22,
      23,    81,    82,    83,    84,   227,    86,    24,   137,   228,
     138,     0,   229,     0,   139,   140,     0,     0,    93,   141,
       0,    95,   142,    97,   230,    99,     0,   100,   143,     0,
       0,   231,   104,    26,   144,     0,     0,   106,     0,     0,
       0,     0,     0,     0,     0,     0,   971,     0,     0,   232,
     218,    19,   219,   233,     0,    58,     0,     0,   234,     0,
     235,     0,     0,     0,    27,    59,   223,   224,    62,  -360,
       0,     0,   132,   133,    65,    66,  -499,    20,    68,    69,
     134,     0,    71,     0,     0,    72,  -499,    74,   135,    76,
     136,   226,    21,    22,    23,    81,    82,    83,    84,   227,
      86,    24,   137,   228,   138,     0,   229,     0,   139,   140,
       0,     0,    93,   141,     0,    95,   142,    97,   230,    99,
       0,   100,   143,     0,     0,   231,   104,    26,   144,     0,
       0,   106,     0,     0,     0,     0,     0,     0,     0,     0,
     971,     0,     0,     0,   218,    19,   219,     0,     0,    58,
    -360,     0,   234,  -360,   235,     0,     0,     0,    27,    59,
     223,   224,    62,     0,     0,     0,   132,   133,    65,    66,
    -499,    20,    68,    69,   134,     0,    71,     0,     0,    72,
    -499,    74,   135,    76,   136,   226,    21,    22,    23,    81,
      82,    83,    84,   227,    86,    24,   137,   228,   138,     0,
     229,     0,   139,   140,     0,     0,    93,   141,     0,    95,
     142,    97,   230,    99,     0,   100,   143,     0,     0,   231,
     104,    26,   144,     0,     0,   106,     0,     0,     0,     0,
       0,     0,     0,     0,   971,     0,     0,     0,   218,    19,
     219,     0,  -360,    58,     0,     0,   234,     0,   235,     0,
       0,     0,    27,    59,   223,   224,    62,     0,     0,     0,
     132,   133,    65,    66,  -499,    20,    68,    69,   134,     0,
      71,     0,     0,    72,  -499,    74,   135,    76,   136,   226,
      21,    22,    23,    81,    82,    83,    84,   227,    86,    24,
     137,   228,   138,     0,   229,     0,   139,   140,     0,     0,
      93,   141,     0,    95,   142,    97,   230,    99,     0,   100,
     143,     0,     0,   231,   104,    26,   144,     0,     0,   106,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   433,
       0,     0,     0,   218,    19,   219,   220,   221,    58,     0,
     234,     0,   235,   222,     0,     0,    27,     0,    59,   223,
     224,    62,     0,     0,     0,     0,     0,    65,    66,  -499,
      20,    68,    69,     0,     0,    71,     0,     0,    72,  -499,
      74,     0,    76,     0,   226,    21,    22,    23,    81,    82,
      83,    84,   227,    86,    24,     0,   228,     0,  -432,   229,
       0,     0,     0,     0,     0,    93,     0,     0,    95,     0,
      97,   230,    99,     0,   100,     0,     0,     0,   231,   104,
      26,     0,     0,     0,   106,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   232,     0,     0,     0,
     233,     0,     0,     0,     0,   234,  -432,   235,   507,     0,
     434,    27,   218,    19,   219,   220,   221,    58,     0,     0,
       0,     0,   222,     0,     0,     0,     0,    59,   223,   224,
      62,     0,     0,     0,     0,     0,    65,    66,  -499,    20,
      68,    69,     0,     0,    71,     0,     0,    72,  -499,    74,
       0,    76,     0,   226,    21,    22,    23,    81,    82,    83,
      84,   227,    86,    24,     0,   228,     0,     0,   229,     0,
       0,     0,     0,     0,    93,     0,     0,    95,     0,    97,
     230,    99,     0,   100,     0,     0,     0,   231,   104,    26,
       0,     0,     0,   106,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   232,     0,     0,     0,   233,
       0,     0,     0,     0,   234,  -432,   235,   729,     0,   434,
      27,   218,    19,   219,   220,   221,    58,     0,     0,     0,
       0,   222,     0,     0,     0,     0,    59,   223,   224,    62,
       0,     0,     0,     0,     0,    65,    66,  -499,    20,    68,
      69,     0,     0,    71,     0,     0,    72,  -499,    74,     0,
      76,     0,   226,    21,    22,    23,    81,    82,    83,    84,
     227,    86,    24,     0,   228,     0,     0,   229,     0,     0,
       0,     0,     0,    93,     0,     0,    95,     0,    97,   230,
      99,     0,   100,     0,     0,     0,   231,   104,    26,     0,
       0,     0,   106,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   232,     0,     0,     0,   233,     0,
       0,     0,     0,   234,  -431,   235,  -431,   217,     0,    27,
       0,   218,    19,   219,   220,   221,    58,     0,     0,     0,
       0,   222,     0,     0,     0,     0,    59,   223,   224,    62,
     225,     0,     0,     0,     0,    65,    66,  -499,    20,    68,
      69,     0,     0,    71,     0,     0,    72,  -499,    74,     0,
      76,     0,   226,    21,    22,    23,    81,    82,    83,    84,
     227,    86,    24,     0,   228,     0,     0,   229,     0,     0,
       0,     0,     0,    93,     0,     0,    95,     0,    97,   230,
      99,     0,   100,     0,     0,     0,   231,   104,    26,     0,
       0,     0,   106,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   232,     0,     0,     0,   233,     0,
       0,     0,     0,   234,     0,   235,   325,     0,     0,    27,
     218,    19,   219,   220,   221,    58,     0,     0,     0,     0,
     222,     0,     0,     0,     0,    59,   223,   224,    62,     0,
       0,     0,     0,     0,    65,    66,  -499,    20,    68,    69,
       0,     0,    71,     0,     0,    72,  -499,    74,     0,    76,
       0,   226,    21,    22,    23,    81,    82,    83,    84,   227,
      86,    24,     0,   228,     0,     0,   229,     0,     0,     0,
       0,     0,    93,     0,     0,    95,     0,    97,   230,    99,
       0,   100,     0,     0,     0,   231,   104,    26,     0,     0,
       0,   106,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   232,     0,     0,     0,   233,     0,     0,
       0,     0,   234,     0,   235,   699,   326,     0,    27,  -233,
    -233,  -233,  -233,  -233,  -233,     0,     0,     0,     0,  -233,
       0,     0,     0,     0,  -233,  -233,  -233,  -233,   700,     0,
       0,     0,     0,  -233,  -233,  -233,  -233,  -233,  -233,     0,
       0,  -233,     0,     0,  -233,  -233,  -233,     0,  -233,     0,
    -233,  -233,  -233,  -233,  -233,  -233,  -233,  -233,  -233,  -233,
    -233,     0,  -233,     0,     0,  -233,     0,     0,     0,     0,
       0,  -233,     0,     0,  -233,     0,  -233,  -233,  -233,     0,
    -233,     0,     0,     0,  -233,  -233,  -233,     0,     0,     0,
    -233,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  -233,     0,     0,     0,  -233,     0,     0,     0,
       0,  -233,     0,  -233,   798,     0,     0,  -233,   218,    19,
     219,   220,   221,    58,     0,     0,     0,     0,   222,     0,
       0,     0,     0,    59,   223,   224,    62,   799,     0,     0,
       0,     0,    65,    66,  -499,    20,    68,    69,     0,     0,
      71,     0,     0,    72,  -499,    74,     0,    76,     0,   226,
      21,    22,    23,    81,    82,    83,    84,   227,    86,    24,
       0,   228,     0,     0,   229,     0,     0,     0,     0,     0,
      93,     0,     0,    95,     0,    97,   230,    99,     0,   100,
       0,     0,     0,   231,   104,    26,     0,     0,     0,   106,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   232,     0,     0,     0,   233,     0,     0,     0,     0,
     234,     0,   235,   419,     0,     0,    27,   218,    19,   219,
     220,   221,    58,     0,     0,     0,     0,   222,     0,     0,
       0,     0,    59,   223,   224,    62,     0,     0,     0,     0,
       0,    65,    66,  -499,    20,    68,    69,     0,     0,    71,
       0,     0,    72,  -499,    74,     0,    76,     0,   226,    21,
      22,    23,    81,    82,    83,    84,   227,    86,    24,     0,
     228,     0,     0,   229,     0,     0,     0,     0,     0,    93,
       0,     0,    95,     0,    97,   230,    99,     0,   100,     0,
       0,     0,   231,   104,    26,     0,     0,     0,   106,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     232,     0,     0,     0,   233,     0,     0,     0,     0,   234,
       0,   235,   439,     0,     0,    27,   218,    19,   219,   220,
     221,    58,     0,     0,     0,     0,   222,     0,     0,     0,
       0,    59,   223,   224,    62,     0,     0,     0,     0,     0,
      65,    66,  -499,    20,    68,    69,     0,     0,    71,     0,
       0,    72,  -499,    74,     0,    76,     0,   226,    21,    22,
      23,    81,    82,    83,    84,   227,    86,    24,     0,   228,
       0,     0,   229,     0,     0,     0,     0,     0,    93,     0,
       0,    95,     0,    97,   230,    99,     0,   100,     0,     0,
       0,   231,   104,    26,     0,     0,     0,   106,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   232,
       0,     0,     0,   233,     0,     0,     0,     0,   234,     0,
     235,   504,     0,     0,    27,   218,    19,   219,   220,   221,
      58,     0,     0,     0,     0,   222,     0,     0,     0,     0,
      59,   223,   224,    62,     0,     0,     0,     0,     0,    65,
      66,  -499,    20,    68,    69,     0,     0,    71,     0,     0,
      72,  -499,    74,     0,    76,     0,   226,    21,    22,    23,
      81,    82,    83,    84,   227,    86,    24,     0,   228,     0,
       0,   229,     0,     0,     0,     0,     0,    93,     0,     0,
      95,     0,    97,   230,    99,     0,   100,     0,     0,     0,
     231,   104,    26,     0,     0,     0,   106,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   232,     0,
       0,     0,   233,     0,     0,     0,     0,   234,     0,   235,
     516,     0,     0,    27,   218,    19,   219,   220,   221,    58,
       0,     0,     0,     0,   222,     0,     0,     0,     0,    59,
     223,   224,    62,     0,     0,     0,     0,     0,    65,    66,
    -499,    20,    68,    69,     0,     0,    71,     0,     0,    72,
    -499,    74,     0,    76,     0,   226,    21,    22,    23,    81,
      82,    83,    84,   227,    86,    24,     0,   228,     0,     0,
     229,     0,     0,     0,     0,     0,    93,     0,     0,    95,
       0,    97,   230,    99,     0,   100,     0,     0,     0,   231,
     104,    26,     0,     0,     0,   106,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   232,     0,     0,
       0,   233,     0,     0,     0,     0,   234,     0,   235,   726,
       0,     0,    27,   218,    19,   219,   220,   221,    58,     0,
       0,     0,     0,   222,     0,     0,     0,     0,    59,   223,
     224,    62,     0,     0,     0,     0,     0,    65,    66,  -499,
      20,    68,    69,     0,     0,    71,     0,     0,    72,  -499,
      74,     0,    76,     0,   226,    21,    22,    23,    81,    82,
      83,    84,   227,    86,    24,     0,   228,     0,     0,   229,
       0,     0,     0,     0,     0,    93,     0,     0,    95,     0,
      97,   230,    99,     0,   100,     0,     0,     0,   231,   104,
      26,     0,     0,     4,   106,     0,  -156,     0,  -156,     0,
       0,     0,     0,     0,     0,     0,   232,     0,     0,     0,
     233,     0,     0,     0,     0,   234,   292,   235,     0,  -156,
    -156,    27,     0,  -156,  -156,     0,     0,  -156,     0,     0,
       0,     0,     0,  -156,  -156,  -156,     0,  -156,     0,  -156,
    -156,  -156,     0,     6,  -156,  -156,  -156,  -156,  -156,  -156,
       0,  -156,     0,     0,     0,  -156,  -156,     0,     0,  -156,
    -156,     0,  -156,  -156,  -156,  -156,  -156,     0,  -156,  -156,
       0,  -156,     0,  -156,  -156,  -156,     0,     0,  -156,     0,
       0,     4,     0,     0,  -156,     0,  -156,     0,     0,     0,
       0,     0,     0,     0,     0,     7,     0,   293,     0,     0,
       0,     0,     0,  -156,  -325,  -156,     0,  -156,  -156,     0,
       0,  -156,  -156,     0,     0,  -156,     0,     0,     0,     0,
       0,  -156,  -156,  -156,     0,  -156,     0,  -156,  -156,  -156,
       0,     6,  -156,  -156,  -156,  -156,  -156,  -156,     0,  -156,
       0,     0,     0,  -156,  -156,     0,     0,  -156,  -156,     0,
    -156,  -156,  -156,  -156,  -156,     0,  -156,  -156,     0,  -156,
       0,  -156,  -156,  -156,     0,     0,  -156,   464,     0,     0,
       0,   218,    19,   219,   220,   221,     0,     0,     0,     0,
       0,   222,     0,     7,     0,  -325,     0,   300,   301,     0,
       0,  -156,     0,  -156,     0,     0,     0,  -499,    20,     0,
       0,     0,     0,     0,     0,     0,     0,  -499,     0,     0,
       0,     0,   302,    21,    22,    23,     0,     0,     0,     0,
     303,     0,    24,     0,   304,     0,     0,   229,     0,     0,
       0,     0,     0,     0,     0,     0,   466,     0,     0,    25,
     218,    19,   219,   220,   221,     0,   305,     0,    26,     0,
     222,     0,     0,     0,     0,     0,   300,   301,     0,     0,
       0,     0,     0,     0,   232,     0,  -499,    20,   233,     0,
       0,     0,     0,   234,     0,   235,  -499,     0,     0,    27,
       0,   302,    21,    22,    23,     0,     0,     0,     0,   303,
       0,    24,     0,   304,     0,     0,   229,     0,     0,     0,
       0,     0,     0,     0,     0,   468,     0,     0,    25,   218,
      19,   219,   220,   221,     0,   305,     0,    26,     0,   222,
       0,     0,     0,     0,     0,   300,   301,     0,     0,     0,
       0,     0,     0,   232,     0,  -499,    20,   233,     0,     0,
       0,     0,   234,     0,   235,  -499,     0,     0,    27,     0,
     302,    21,    22,    23,     0,     0,     0,     0,   303,     0,
      24,     0,   304,     0,     0,   229,     0,     0,     0,     0,
       0,     0,     0,     0,   470,     0,     0,    25,   218,    19,
     219,   220,   221,     0,   305,     0,    26,     0,   222,     0,
       0,     0,     0,     0,   300,   301,     0,     0,     0,     0,
       0,     0,   232,     0,  -499,    20,   233,     0,     0,     0,
       0,   234,     0,   235,  -499,     0,     0,    27,     0,   302,
      21,    22,    23,     0,     0,     0,     0,   303,     0,    24,
       0,   304,     0,     0,   229,     0,     0,     0,     0,     0,
       0,     0,     0,   472,     0,     0,    25,   218,    19,   219,
     220,   221,     0,   305,     0,    26,     0,   222,     0,     0,
       0,     0,     0,   300,   301,     0,     0,     0,     0,     0,
       0,   232,     0,  -499,    20,   233,     0,     0,     0,     0,
     234,     0,   235,  -499,     0,     0,    27,     0,   302,    21,
      22,    23,     0,     0,     0,     0,   303,     0,    24,     0,
     304,     0,     0,   229,     0,     0,     0,     0,     0,     0,
       0,     0,   474,     0,     0,    25,   218,    19,   219,   220,
     221,     0,   305,     0,    26,     0,   222,     0,     0,     0,
       0,     0,   300,   301,     0,     0,     0,     0,     0,     0,
     232,     0,  -499,    20,   233,     0,     0,     0,     0,   234,
       0,   235,  -499,     0,     0,    27,     0,   302,    21,    22,
      23,     0,     0,     0,     0,   303,     0,    24,     0,   304,
       0,     0,   229,     0,     0,     0,     0,     0,     0,     0,
       0,   476,     0,     0,    25,   218,    19,   219,   220,   221,
       0,   305,     0,    26,     0,   222,     0,     0,     0,     0,
       0,   300,   301,     0,     0,     0,     0,     0,     0,   232,
       0,  -499,    20,   233,     0,     0,     0,     0,   234,     0,
     235,  -499,     0,     0,    27,     0,   302,    21,    22,    23,
       0,     0,     0,     0,   303,     0,    24,     0,   304,     0,
       0,   229,     0,     0,     0,     0,     0,     0,     0,     0,
     478,     0,     0,    25,   218,    19,   219,   220,   221,     0,
     305,     0,    26,     0,   222,     0,     0,     0,     0,     0,
     300,   301,     0,     0,     0,     0,     0,     0,   232,     0,
    -499,    20,   233,     0,     0,     0,     0,   234,     0,   235,
    -499,     0,     0,    27,     0,   302,    21,    22,    23,     0,
       0,     0,     0,   303,     0,    24,     0,   304,     0,     0,
     229,     0,     0,     0,     0,     0,     0,     0,     0,   481,
       0,     0,    25,   218,    19,   219,   220,   221,     0,   305,
       0,    26,     0,   222,     0,     0,     0,     0,     0,   300,
     301,     0,     0,     0,     0,     0,     0,   232,     0,  -499,
      20,   233,     0,     0,     0,     0,   234,     0,   235,  -499,
       0,     0,    27,     0,   302,    21,    22,    23,     0,     0,
       0,     0,   303,     0,    24,     0,   304,     0,     0,   229,
       0,     0,     0,     0,     0,     0,     0,     0,   483,     0,
       0,    25,   218,    19,   219,   220,   221,     0,   305,     0,
      26,     0,   222,     0,     0,     0,     0,     0,   300,   301,
       0,     0,     0,     0,     0,     0,   232,     0,  -499,    20,
     233,     0,     0,     0,     0,   234,     0,   235,  -499,     0,
       0,    27,     0,   302,    21,    22,    23,     0,     0,     0,
       0,   303,     0,    24,     0,   304,     0,     0,   229,     0,
       0,     0,     0,     0,     0,     0,     0,   485,     0,     0,
      25,   218,    19,   219,   220,   221,     0,   305,     0,    26,
       0,   222,     0,     0,     0,     0,     0,   300,   301,     0,
       0,     0,     0,     0,     0,   232,     0,  -499,    20,   233,
       0,     0,     0,     0,   234,     0,   235,  -499,     0,     0,
      27,     0,   302,    21,    22,    23,     0,     0,     0,     0,
     303,     0,    24,     0,   304,     0,     0,   229,     0,     0,
       0,     0,     0,     0,     0,     0,   487,     0,     0,    25,
     218,    19,   219,   220,   221,     0,   305,     0,    26,     0,
     222,     0,     0,     0,     0,     0,   300,   301,     0,     0,
       0,     0,     0,     0,   232,     0,  -499,    20,   233,     0,
       0,     0,     0,   234,     0,   235,  -499,     0,     0,    27,
       0,   302,    21,    22,    23,     0,     0,     0,     0,   303,
       0,    24,     0,   304,     0,     0,   229,     0,     0,     0,
       0,     0,     0,     0,     0,   489,     0,     0,    25,   218,
      19,   219,   220,   221,     0,   305,     0,    26,     0,   222,
       0,     0,     0,     0,     0,   300,   301,     0,     0,     0,
       0,     0,     0,   232,     0,  -499,    20,   233,     0,     0,
       0,     0,   234,     0,   235,  -499,     0,     0,    27,     0,
     302,    21,    22,    23,     0,     0,     0,     0,   303,     0,
      24,     0,   304,     0,     0,   229,     0,     0,     0,     0,
       0,     0,     0,     0,   491,     0,     0,    25,   218,    19,
     219,   220,   221,     0,   305,     0,    26,     0,   222,     0,
       0,     0,     0,     0,   300,   301,     0,     0,     0,     0,
       0,     0,   232,     0,  -499,    20,   233,     0,     0,     0,
       0,   234,     0,   235,  -499,     0,     0,    27,     0,   302,
      21,    22,    23,     0,     0,     0,     0,   303,     0,    24,
       0,   304,     0,     0,   229,     0,     0,     0,     0,     0,
       0,     0,     0,   493,     0,     0,    25,   218,    19,   219,
     220,   221,     0,   305,     0,    26,     0,   222,     0,     0,
       0,     0,     0,   300,   301,     0,     0,     0,     0,     0,
       0,   232,     0,  -499,    20,   233,     0,     0,     0,     0,
     234,     0,   235,  -499,     0,     0,    27,     0,   302,    21,
      22,    23,     0,     0,     0,     0,   303,     0,    24,     0,
     304,     0,     0,   229,     0,     0,     0,     0,     0,     0,
       0,     0,   495,     0,     0,    25,   218,    19,   219,   220,
     221,     0,   305,     0,    26,     0,   222,     0,     0,     0,
       0,     0,   300,   301,     0,     0,     0,     0,     0,     0,
     232,     0,  -499,    20,   233,     0,     0,     0,     0,   234,
       0,   235,  -499,     0,     0,    27,     0,   302,    21,    22,
      23,     0,     0,     0,     0,   303,     0,    24,     0,   304,
       0,     0,   229,     0,     0,     0,     0,     0,     0,     0,
       0,   497,     0,     0,    25,   218,    19,   219,   220,   221,
       0,   305,     0,    26,     0,   222,     0,     0,     0,     0,
       0,   300,   301,     0,     0,     0,     0,     0,     0,   232,
       0,  -499,    20,   233,     0,     0,     0,     0,   234,     0,
     235,  -499,     0,     0,    27,     0,   302,    21,    22,    23,
       0,     0,     0,     0,   303,     0,    24,     0,   304,     0,
       0,   229,     0,     0,     0,     0,     0,     0,     0,     0,
     499,     0,     0,    25,   218,    19,   219,   220,   221,     0,
     305,     0,    26,     0,   222,     0,     0,     0,     0,     0,
     300,   301,     0,     0,     0,     0,     0,     0,   232,     0,
    -499,    20,   233,     0,   132,   133,     0,   234,     0,   235,
    -499,     0,   134,    27,     0,   302,    21,    22,    23,     0,
     135,     0,   136,   303,     0,    24,     0,   304,     0,     0,
     229,     0,     0,     0,   137,     0,   138,     0,     0,   278,
     139,   140,    25,     0,    19,   141,     0,     0,   142,   305,
       0,    26,     0,     0,   143,     0,     0,     0,     0,     0,
     144,     0,     0,     0,   599,   132,   133,   232,     0,     0,
      20,   233,     0,   134,     0,     0,   234,     0,   235,     0,
       0,   135,    27,   136,     0,    21,    22,    23,   367,   368,
       0,     0,     0,     0,    24,   137,     0,   138,     0,   369,
       0,   139,   140,     0,     0,     0,   141,     0,   278,   142,
       0,    25,     0,    19,     0,   143,     0,     0,     0,     0,
      26,   144,     0,     0,     0,   370,     0,     0,   371,   372,
       0,     0,   373,     0,   132,   133,     0,     0,   374,    20,
       0,   375,   134,     0,     0,     0,   296,     0,   376,     0,
     135,    27,   136,   600,    21,    22,    23,     0,     0,     0,
     288,     0,     0,    24,   137,    19,   138,     0,     0,  -600,
     139,   140,     0,  -600,     0,   141,     0,     0,   142,     0,
      25,     0,     0,     0,   143,     0,   132,   133,     0,    26,
     144,    20,     0,     0,   134,     0,     0,     0,     0,     0,
       0,     0,   135,     0,   136,     0,    21,    22,    23,    18,
       0,     0,     0,     0,    19,    24,   137,     0,   138,     0,
      27,     0,   139,   140,     0,     0,     0,   141,     0,     0,
     142,     0,    25,  -649,  -649,     0,   143,     0,     0,     0,
      20,    26,   144,     0,  -649,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    21,    22,    23,     0,     0,
       0,     0,     0,     0,    24,     0,     0,     0,     0,     0,
    -649,     0,    27,  -649,  -649,     0,     0,  -649,     0,     0,
       0,    25,     0,  -649,     0,     0,  -649,     0,     0,     0,
      26,  -540,     0,  -649,     0,     0,  -540,  -540,  -649,  -540,
    -540,  -540,  -540,     0,  -540,  -540,  -540,  -540,     0,     0,
       0,     0,  -540,  -540,  -540,     0,     0,     0,     0,     0,
       0,    27,     0,     0,  -540,     0,  -540,  -540,   343,   344,
     345,   346,     0,   347,   348,   349,   350,     0,     0,     0,
       0,   343,   344,   345,   346,     0,   347,   348,     0,     0,
    -540,     0,     0,  -540,  -540,     0,     0,  -540,     0,   343,
     344,   345,   346,  -540,   347,   348,  -540,     0,     0,     0,
       0,     0,     0,  -540,     0,  -540,  -540,     0,  -540,  -540,
    -540,  -540,  -540,  -540,  -540,  -540,  -540,  -540,  -540,  -540,
       0,  -540,  -540,  -540,  -540,  -540,  -540,  -540,  -540,   364,
       0,   115,     0,     0,   365,   366,     0,     0,   351,   352,
     353,   354,   355,   356,   357,   358,   359,   360,   361,     0,
       0,   367,   368,   353,   354,   355,   356,   357,   358,   359,
     360,   361,   369,     0,     0,     0,     0,     0,     0,     0,
     352,   353,   354,   355,   356,   357,   358,   359,   360,   361,
       0,     0,     0,     0,     0,     0,     0,     0,   370,     0,
       0,   371,   372,     0,     0,   373,     0,     0,     0,     0,
       0,   374,     0,     0,   375,     0,     0,     0,     0,     0,
       0,   376,     0,   377,   378,     0,   379,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   218,    19,   219,   220,
     221,    58,     0,   234,     0,   235,   222,     0,     0,   380,
       0,    59,   223,   224,    62,   510,     0,     0,   132,   133,
      65,    66,     0,    20,    68,    69,   134,     0,    71,  -566,
    -566,    72,     0,    74,   135,    76,   136,   226,    21,    22,
      23,    81,    82,    83,    84,   227,    86,    24,   137,   228,
     138,     0,   229,     0,   139,   140,     0,     0,    93,   141,
       0,    95,   142,    97,   230,    99,     0,   100,   143,     0,
       0,   231,   104,    26,   144,     0,     0,   106,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   511,     0,   232,
       0,     0,     0,   233,     0,     0,     0,     0,   234,     0,
     235,     0,     0,     0,    27,   218,    19,   219,   220,   221,
      58,     0,     0,     0,     0,   222,     0,     0,     0,     0,
      59,   223,   224,    62,   510,     0,     0,   132,   133,    65,
      66,     0,    20,    68,    69,   134,     0,    71,     0,     0,
      72,     0,    74,   135,    76,   136,   226,    21,    22,    23,
      81,    82,    83,    84,   227,    86,    24,   137,   228,   138,
       0,   229,     0,   139,   140,     0,     0,    93,   141,     0,
      95,   142,    97,   230,    99,     0,   100,   143,     0,     0,
     231,   104,    26,   144,     0,     0,   106,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   511,     0,   232,     0,
       0,     0,   233,     0,     0,     0,     0,   234,     0,   235,
    -566,     0,     0,    27,   218,    19,   219,   220,   221,    58,
       0,     0,     0,     0,   222,     0,     0,     0,     0,    59,
     223,   224,    62,     0,     0,     0,   132,   133,    65,    66,
    -499,    20,    68,    69,   134,     0,    71,     0,     0,    72,
    -499,    74,   135,    76,   136,   226,    21,    22,    23,    81,
      82,    83,    84,   227,    86,    24,   137,   228,   138,     0,
     229,     0,   139,   140,     0,     0,    93,   141,     0,    95,
     142,    97,   230,    99,     0,   100,   143,     0,     0,   231,
     104,    26,   144,     0,     0,   106,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   232,     0,     0,
       0,   233,     0,     0,     0,     0,   234,     0,   235,     0,
       0,     0,    27,   218,    19,   219,   220,   221,    58,     0,
       0,     0,     0,   222,     0,     0,     0,     0,    59,   223,
     224,    62,   675,     0,     0,   132,   133,    65,    66,     0,
      20,    68,    69,   134,     0,    71,     0,     0,    72,     0,
      74,   135,    76,   136,   226,    21,    22,    23,    81,    82,
      83,    84,   227,    86,    24,   137,   228,   138,     0,   229,
       0,   139,   140,     0,     0,    93,   141,     0,    95,   142,
      97,   230,    99,     0,   100,   143,     0,     0,   231,   104,
      26,   144,     0,     0,   106,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   232,   218,    19,   219,
     233,     0,    58,     0,     0,   234,     0,   235,     0,     0,
       0,    27,    59,   223,   224,    62,     0,     0,     0,   132,
     133,    65,    66,     0,    20,    68,    69,   134,     0,    71,
       0,     0,    72,     0,    74,   135,    76,   136,   226,    21,
      22,    23,    81,    82,    83,    84,   227,    86,    24,   137,
     228,   138,     0,   229,     0,   139,   140,     0,     0,    93,
     141,     0,    95,   142,    97,   230,    99,     0,   100,   143,
       0,     0,   231,   104,    26,   144,     0,     0,   106,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   218,    19,   219,   220,   221,    58,     0,   234,
       0,   235,   222,     0,     0,    27,     0,    59,   223,   224,
      62,     0,     0,     0,     0,     0,    65,    66,  -499,    20,
      68,    69,     0,     0,    71,     0,     0,    72,  -499,    74,
       0,    76,     0,   226,    21,    22,    23,    81,    82,    83,
      84,   227,    86,    24,     0,   228,     0,     0,   229,     0,
       0,     0,     0,     0,    93,     0,     0,    95,     0,    97,
     230,    99,     0,   100,     0,     0,     0,   231,   104,    26,
       0,     0,     0,   106,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   232,     0,     0,     0,   233,
       0,     0,     0,     0,   234,     0,   235,     0,     0,   434,
      27,   218,    19,   219,   220,   221,    58,     0,     0,     0,
       0,   222,     0,     0,     0,     0,    59,   223,   224,    62,
       0,     0,     0,     0,     0,    65,    66,     0,    20,    68,
      69,     0,     0,    71,     0,     0,    72,     0,    74,     0,
      76,     0,   226,    21,    22,    23,    81,    82,    83,    84,
     227,    86,    24,     0,   228,     0,     0,   229,     0,     0,
       0,     0,     0,    93,     0,     0,    95,     0,    97,   230,
      99,     0,   100,     0,     0,     0,   231,   104,    26,     0,
       0,     0,   106,   218,    19,   219,   220,   221,     0,     0,
       0,     0,     0,   222,   232,     0,     0,     0,   233,   300,
     301,     0,     0,   234,     0,   235,   218,    19,   219,    27,
      20,     0,     0,     0,   343,   344,   345,   346,     0,   347,
     348,     0,   300,   301,   302,    21,    22,    23,     0,     0,
       0,     0,   303,    20,    24,     0,   304,     0,     0,   229,
       0,     0,     0,     0,     0,     0,     0,   302,    21,    22,
      23,    25,     0,     0,     0,   303,     0,    24,   305,   304,
      26,     0,   229,     0,     0,     0,     0,     0,    19,     0,
       0,     0,     0,     0,    25,     0,   232,     0,     0,     0,
     233,   305,     0,    26,     0,   234,     0,   235,     0,   132,
     133,    27,     0,     0,    20,     0,     0,   134,   355,   356,
     357,   358,   359,   360,   361,   135,     0,   136,   234,    21,
      22,    23,     0,     0,    27,     0,     0,     0,    24,   137,
      19,   138,     0,     0,     0,   139,   140,     0,     0,     0,
     141,     0,     0,   142,     0,    25,     0,     0,     0,   143,
       0,   132,   133,     0,    26,   144,    20,     0,     0,   134,
       0,     0,     0,     0,     0,     0,     0,   135,     0,   136,
       0,    21,    22,    23,     0,     0,     0,     0,   396,     0,
      24,   137,    19,   138,     0,    27,     0,   139,   140,     0,
       0,     0,   141,     0,     0,   142,     0,    25,     0,     0,
       0,   143,     0,   132,   152,     0,    26,   144,    20,     0,
       0,   153,     0,     0,     0,     0,     0,     0,     0,   135,
       0,   136,     0,    21,    22,    23,     0,     0,     0,     0,
       0,     0,    24,   137,     0,   138,     0,    27,     0,   139,
     140,     0,     0,   522,   141,     0,     0,   142,     0,    25,
       0,     0,    58,   143,     0,     0,     0,     0,    26,   144,
       0,     0,    59,    60,    61,    62,  -336,     0,     0,    63,
      64,    65,    66,    67,     0,    68,    69,    70,     0,    71,
       0,     0,    72,    73,    74,    75,    76,    77,    78,    27,
     208,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      89,    90,   599,     0,     0,    91,    92,     0,     0,    93,
      94,     0,    95,    96,    97,    98,    99,     0,   100,   101,
       0,   102,   103,   104,     0,   105,   367,   368,   106,   343,
     344,   345,   346,     0,   347,   348,   349,   369,     0,     0,
     367,   368,     0,     0,     0,     0,     0,  -336,  -336,     0,
       0,   369,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   370,     0,     0,   371,   372,     0,     0,
     373,     0,     0,     0,     0,     0,   374,   370,     0,   375,
     371,   372,     0,     0,   373,     0,   376,     0,     0,     0,
     374,   600,     0,   375,     0,     0,     0,     0,     0,     0,
     376,     0,     0,     0,     0,   384,     0,     0,     0,     0,
     352,   353,   354,   355,   356,   357,   358,   359,   360,   361,
     603,     0,     0,   604,     0,     0,     0,     0,     0,   605,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   606,
     607,   608,   609,     0,     0,     0,   610,   611,   612,   613,
     614,     0,   615,   616,   617,     0,   618,     0,     0,   619,
     620,   621,   622,   623,   624,   625,   626,   627,   628,   629,
     630,   631,   632,   633,   634,   635,   636,   637,   638,     0,
       0,     0,   639,   640,     0,     0,   641,   642,     0,   643,
     644,   645,   646,   647,     0,   648,   649,     0,   650,   651,
     652,   267,   653,   654,     0,   655,   268,     0,     0,     0,
      58,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      59,    60,    61,    62,     0,     0,     0,    63,    64,    65,
      66,    67,     0,    68,    69,    70,     0,    71,     0,     0,
      72,    73,    74,    75,    76,    77,    78,     0,   269,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
       0,     0,     0,    91,    92,     0,     0,    93,    94,   117,
      95,    96,    97,    98,    99,     0,   100,   101,    58,   102,
     103,   104,     0,   105,     0,     0,   106,     0,    59,    60,
      61,    62,     0,     0,     0,    63,    64,    65,    66,    67,
       0,    68,    69,    70,     0,    71,     0,     0,    72,    73,
      74,    75,    76,    77,    78,     0,   118,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,     0,     0,
       0,    91,    92,     0,     0,    93,    94,   122,    95,    96,
      97,    98,    99,     0,   100,   101,    58,   102,   103,   104,
       0,   105,     0,     0,   106,     0,    59,    60,    61,    62,
       0,     0,     0,    63,    64,    65,    66,    67,     0,    68,
      69,    70,     0,    71,     0,     0,    72,    73,    74,    75,
      76,    77,    78,     0,   123,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,     0,     0,     0,    91,
      92,     0,     0,    93,    94,   163,    95,    96,    97,    98,
      99,     0,   100,   101,    58,   102,   103,   104,     0,   105,
       0,     0,   106,     0,    59,    60,    61,    62,     0,     0,
       0,    63,    64,    65,    66,    67,     0,    68,    69,    70,
       0,    71,     0,     0,    72,    73,    74,    75,    76,    77,
      78,     0,   164,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,     0,     0,     0,    91,    92,     0,
       0,    93,    94,   259,    95,    96,    97,    98,    99,     0,
     100,   101,    58,   102,   103,   104,     0,   105,     0,     0,
     106,     0,    59,    60,    61,    62,     0,     0,     0,    63,
      64,    65,    66,    67,     0,    68,    69,    70,     0,    71,
       0,     0,    72,    73,    74,    75,    76,    77,    78,     0,
     123,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      89,    90,     0,     0,     0,    91,    92,     0,     0,    93,
      94,   879,    95,    96,    97,    98,    99,     0,   100,   101,
      58,   102,   103,   104,     0,   105,     0,     0,   106,     0,
      59,    60,    61,    62,     0,     0,     0,    63,    64,    65,
      66,    67,     0,    68,    69,    70,     0,    71,     0,     0,
      72,    73,    74,    75,    76,    77,    78,     0,   880,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
       0,     0,     0,    91,    92,     0,     0,    93,    94,   930,
      95,    96,    97,    98,    99,     0,   100,   101,    58,   102,
     103,   104,     0,   105,     0,     0,   106,     0,    59,    60,
      61,    62,     0,     0,     0,    63,    64,    65,    66,    67,
       0,    68,    69,    70,     0,    71,     0,     0,    72,    73,
      74,    75,    76,    77,    78,     0,   880,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,     0,     0,
       0,    91,    92,     0,     0,    93,    94,     0,    95,    96,
      97,    98,    99,     0,   100,   101,    58,   102,   103,   104,
       0,   105,     0,     0,   106,     0,    59,    60,    61,    62,
       0,     0,     0,    63,    64,    65,    66,    67,     0,    68,
      69,    70,     0,    71,     0,     0,    72,    73,    74,    75,
      76,    77,    78,     0,   208,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,     0,     0,     0,    91,
      92,     0,     0,    93,    94,     0,    95,    96,    97,    98,
      99,     0,   100,   101,    58,   102,   103,   104,     0,   105,
       0,     0,   106,     0,    59,    60,    61,    62,   209,     0,
       0,    63,    64,    65,    66,    67,     0,    68,    69,    70,
       0,    71,   529,   530,    72,    73,    74,    75,    76,    77,
      78,     0,     0,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,     0,     0,     0,    91,    92,     0,
       0,    93,    94,     0,    95,    96,    97,    98,    99,     0,
     100,   101,    58,   102,   103,   104,     0,   105,     0,     0,
     106,     0,    59,    60,    61,    62,     0,     0,     0,    63,
      64,    65,    66,    67,     0,    68,    69,    70,     0,    71,
       0,     0,    72,    73,    74,    75,    76,    77,    78,     0,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      89,    90,     0,     0,     0,    91,    92,     0,     0,    93,
      94,     0,    95,    96,    97,    98,    99,     0,   100,   101,
      58,   102,   103,   104,     0,   105,     0,     0,   106,     0,
      59,    60,    61,    62,     0,     0,     0,    63,    64,    65,
      66,    67,     0,    68,    69,    70,     0,    71,     0,     0,
      72,    73,    74,    75,    76,    77,    78,     0,   159,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
       0,     0,     0,    91,    92,     0,     0,    93,    94,     0,
      95,    96,    97,    98,    99,     0,   100,   101,    58,   102,
     103,   104,     0,   105,     0,     0,   106,     0,    59,    60,
      61,    62,     0,     0,     0,    63,    64,    65,    66,    67,
       0,    68,    69,    70,     0,    71,     0,     0,    72,    73,
      74,    75,    76,    77,    78,     0,   161,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,     0,     0,
       0,    91,    92,     0,     0,    93,    94,     0,    95,    96,
      97,    98,    99,     0,   100,   101,    58,   102,   103,   104,
       0,   105,     0,     0,   106,     0,    59,    60,    61,    62,
       0,     0,     0,    63,    64,    65,    66,    67,     0,    68,
      69,    70,     0,    71,     0,     0,    72,    73,    74,    75,
      76,    77,    78,     0,   176,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,     0,     0,     0,    91,
      92,     0,     0,    93,    94,     0,    95,    96,    97,    98,
      99,     0,   100,   101,    58,   102,   103,   104,     0,   105,
       0,     0,   106,     0,    59,    60,    61,    62,     0,     0,
       0,    63,    64,    65,    66,    67,     0,    68,    69,    70,
       0,    71,     0,     0,    72,    73,    74,    75,    76,    77,
      78,     0,   414,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,     0,     0,     0,    91,    92,     0,
       0,    93,    94,     0,    95,    96,    97,    98,    99,     0,
     100,   101,    58,   102,   103,   104,     0,   105,     0,     0,
     106,     0,    59,    60,    61,    62,     0,     0,     0,    63,
      64,    65,    66,    67,     0,    68,    69,    70,     0,    71,
       0,     0,    72,    73,    74,    75,    76,    77,    78,     0,
     430,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      89,    90,     0,     0,     0,    91,    92,     0,     0,    93,
      94,     0,    95,    96,    97,    98,    99,     0,   100,   101,
      58,   102,   103,   104,     0,   105,     0,     0,   106,     0,
      59,    60,    61,    62,     0,     0,     0,    63,    64,    65,
      66,    67,     0,    68,    69,    70,     0,    71,     0,     0,
      72,    73,    74,    75,    76,    77,    78,     0,   560,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
       0,     0,     0,    91,    92,     0,     0,    93,    94,     0,
      95,    96,    97,    98,    99,     0,   100,   101,    58,   102,
     103,   104,     0,   105,     0,     0,   106,     0,    59,    60,
      61,    62,     0,     0,     0,    63,    64,    65,    66,    67,
       0,    68,    69,    70,     0,    71,     0,     0,    72,    73,
      74,    75,    76,    77,    78,     0,   706,    80,    81,    82,
      83,    84,    85,    86,    87,    88,    89,    90,     0,     0,
       0,    91,    92,     0,     0,    93,    94,     0,    95,    96,
      97,    98,    99,     0,   100,   101,    58,   102,   103,   104,
       0,   105,     0,     0,   106,     0,    59,    60,    61,    62,
       0,     0,     0,    63,    64,    65,    66,    67,     0,    68,
      69,    70,     0,    71,     0,     0,    72,    73,    74,    75,
      76,    77,    78,     0,   713,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,     0,     0,     0,    91,
      92,     0,     0,    93,    94,     0,    95,    96,    97,    98,
      99,     0,   100,   101,    58,   102,   103,   104,     0,   105,
       0,     0,   106,     0,    59,    60,    61,    62,     0,     0,
       0,    63,    64,    65,    66,    67,     0,    68,    69,    70,
       0,    71,     0,     0,    72,    73,    74,    75,    76,    77,
      78,     0,   208,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,     0,     0,     0,    91,    92,     0,
       0,    93,    94,     0,    95,    96,    97,    98,    99,     0,
     100,   101,    58,   102,   103,   104,     0,   105,     0,     0,
     106,     0,    59,    60,    61,    62,     0,     0,     0,    63,
      64,    65,    66,    67,     0,    68,    69,    70,     0,    71,
       0,     0,    72,    73,    74,    75,    76,    77,    78,     0,
     828,    80,    81,    82,    83,    84,    85,    86,    87,    88,
      89,    90,     0,     0,     0,    91,    92,     0,     0,    93,
      94,     0,    95,    96,    97,    98,    99,     0,   100,   101,
       0,   102,   103,   104,     0,   105,  -646,  -646,   106,   465,
     467,   469,   471,   473,   475,   477,   479,  -646,   482,   484,
     486,   488,   490,   492,   494,   496,   498,   500,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  -646,     0,     0,  -646,  -646,     0,     0,
    -646,     0,     0,     0,     0,     0,  -646,     0,     0,  -646,
       0,     0,     0,     0,     0,     0,  -646,     0,     0,     0,
       0,  -646
};

static const yytype_int16 yycheck[] =
{
       6,    35,   128,   151,   236,   237,   257,    20,   216,     2,
     515,   351,    20,   461,     1,   172,   209,    30,   175,   332,
     783,    34,    30,    38,   503,    40,    34,   280,    32,     1,
     598,   520,    38,    32,    40,     1,    33,   560,     1,   858,
       7,   860,   295,    24,     1,     1,   809,     1,    24,     1,
     869,   220,   221,    60,     1,     1,     6,     0,   226,   193,
       1,    24,     1,     1,    32,   787,   761,    24,   237,   888,
      24,     1,     1,   722,    92,     1,     1,   309,    24,   213,
     249,     1,    32,    24,   806,   780,   236,     1,     6,   768,
      32,     1,   110,   103,   773,   327,   106,    32,   111,   112,
     332,   108,   115,   111,   112,   104,    56,   115,     1,   113,
      97,   220,   221,   222,   127,   128,     6,   766,    90,   106,
      38,   108,    40,   232,   233,   131,   107,   103,   237,   238,
     239,    98,   145,   446,   302,   107,   955,   145,   307,   308,
     103,   107,   311,   906,   712,   313,   399,   966,   111,   106,
     106,   108,   108,   150,   111,   107,   306,   111,   663,   978,
     107,   174,   108,   332,   111,   111,   174,   336,   107,   107,
     111,   184,    38,   111,    40,   190,   184,   107,   107,   194,
      90,   107,   107,    97,   190,   438,   106,    24,   194,   204,
     713,   188,   106,    92,   209,   229,   449,   107,   204,   214,
     679,   452,    48,   209,    24,   104,    24,    97,   214,   417,
     103,   104,   463,   131,   446,   423,     6,   103,   327,   212,
      24,    24,   237,   332,   237,    38,    39,   113,    48,   461,
      32,   237,    38,    39,   343,   344,   345,   346,   347,   348,
     349,   350,   351,   352,   353,   354,   355,   356,   357,   358,
     359,   360,   361,   742,   743,   778,    38,   736,    40,   256,
     453,    24,   602,    24,    48,   280,    56,   520,   105,   836,
      24,   286,   190,   840,   280,   193,   194,   446,   326,   276,
     286,   287,   451,   103,   297,   103,   204,   105,     3,   297,
     108,   209,   461,     8,     9,   213,   214,    60,   104,   103,
     103,   105,   105,    32,   108,   108,   319,   110,     6,   315,
      32,   319,   327,   103,   327,   757,   107,   332,    92,   332,
       3,   327,    90,    84,   190,    90,   332,   894,   194,   771,
     364,    38,    39,   381,   108,   840,   107,   446,   204,   107,
     103,   895,   105,   377,   378,   108,   380,    31,   214,   103,
     222,   105,   461,   920,   108,    90,   274,    41,    56,     4,
     232,   233,   280,    24,     1,   919,   238,   239,   286,   287,
       7,   810,    87,    88,   387,    92,   382,   944,   393,   387,
     107,   948,   936,   950,   951,    92,    31,   393,   827,    24,
     895,   108,   107,   390,   109,   429,    41,   412,   113,   107,
     967,    38,    39,    92,    87,    88,   412,    52,   190,   113,
       1,   424,   194,   107,   280,     6,   424,   107,    24,   108,
     286,   315,   204,    92,   107,   103,   109,   209,   106,   682,
     113,   446,   214,   446,    79,   107,    16,    17,   453,   108,
     446,    32,   103,   104,   105,    24,   461,   453,   461,    24,
     103,    90,    89,   106,     4,   461,    47,    48,    49,    24,
      92,    98,    92,    24,   103,    56,   111,   106,   103,   222,
     105,    24,    92,   108,   725,   393,   108,   111,   108,   232,
     233,   107,    73,   236,   237,   238,   239,   103,   382,   103,
     106,    82,    24,   602,   412,    97,   249,   503,   280,   105,
     107,    24,   108,   169,   286,   511,   172,   760,    24,   175,
      97,    98,    99,   100,   101,   963,   964,    97,    98,    99,
     100,   101,   113,   107,   103,    90,   105,   393,   103,   108,
     105,   544,   689,   741,   982,   453,   544,    90,   103,   687,
     105,   103,   103,   556,   105,    24,   412,   108,   556,    32,
     103,   898,   105,   306,   307,   308,    24,    90,   311,   716,
     107,   106,   719,   108,    11,    12,    13,    14,   108,    16,
      17,   103,   108,   105,   327,     7,   108,   924,   108,   332,
     103,   108,   105,   336,    99,   100,   101,   103,    48,   105,
     343,   344,   345,   346,   347,   348,   349,   350,   351,   352,
     353,   354,   355,   356,   357,   358,   359,   360,   361,   503,
     104,   393,   106,   106,   104,   962,   106,   511,    38,    39,
     788,   968,   969,   110,   103,   107,   105,   789,   790,   976,
     412,   742,   743,     6,   108,   103,   106,   105,   985,   807,
      12,    13,   810,   990,    16,    17,   312,    94,    95,    96,
      97,    98,    99,   100,   101,   321,   322,   108,   108,   827,
     326,   327,    92,   108,    24,   680,   792,   106,   106,   110,
     105,   453,   108,   679,   680,   106,   110,   104,    38,    39,
     695,    48,    48,   698,   108,   110,    90,   110,   106,   695,
     705,   104,   698,   446,     7,   106,   108,   107,   451,   705,
     106,    90,   110,   737,   111,   108,   874,   108,   461,   108,
     110,    90,    90,   379,    90,   381,   382,   383,   384,   385,
     107,    48,   110,    95,    96,    97,    98,    99,   100,   101,
     736,   963,   964,   108,   108,    90,   749,   107,   753,   110,
     108,   749,   757,   103,   104,   105,   107,   753,   107,   107,
     982,   757,   909,    90,   747,   912,   771,    90,   915,   104,
      90,   107,   680,   107,   107,   771,   107,   780,   434,   107,
      40,     1,   780,   287,   789,   790,     6,   695,   103,   792,
     698,   174,   874,   789,   790,   679,   143,   705,   680,   455,
     138,   804,   417,   914,   963,   964,   804,   718,   872,   841,
     248,   749,    32,   809,   248,   145,   964,   982,   984,   843,
     576,   669,   954,   982,   680,   957,   958,    47,    48,    49,
     593,   313,   835,   965,    -1,    -1,    56,   835,    -1,   695,
     836,    -1,   698,    -1,   840,   753,    -1,   503,    -1,   757,
      -1,   847,   736,    73,    -1,    -1,   988,    -1,    -1,   602,
      42,    -1,    82,   771,   963,   964,   890,   891,    -1,    -1,
      -1,    53,    54,    55,    -1,   899,    -1,   901,   902,    -1,
      -1,   789,   790,   982,    -1,    67,   542,    -1,    70,    -1,
      72,    -1,    74,   113,    76,   551,    -1,   753,   894,    81,
      -1,    -1,   898,    -1,    86,    -1,    -1,    -1,   680,    -1,
     906,   914,    -1,    -1,    -1,    -1,   914,    -1,    -1,    -1,
     576,    -1,    -1,   695,   920,   809,   698,    -1,   924,    -1,
      -1,    -1,    -1,   705,   590,    -1,    -1,   593,    -1,   847,
      -1,    -1,    -1,    -1,   600,   601,    -1,    -1,   944,    -1,
      -1,    -1,   948,   949,   950,   951,    -1,    -1,   963,   964,
     963,   964,    -1,    -1,    -1,    -1,   962,   963,   964,     3,
       6,   967,   968,   969,     8,     9,    -1,   982,    -1,   982,
     976,   753,    -1,    -1,    -1,   757,   982,    -1,   984,   985,
      -1,    25,    26,    -1,   990,    -1,    32,    -1,    -1,   771,
      -1,    -1,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    47,    48,    49,   898,    -1,    -1,   789,   790,    -1,
      56,    -1,   906,    -1,    -1,    -1,    -1,    -1,    62,    -1,
      -1,    65,    66,   689,    -1,    69,    -1,    73,    -1,    -1,
     924,    75,    -1,    -1,    78,   701,    82,    -1,    -1,    -1,
      -1,    85,    -1,    87,    88,    -1,    90,    -1,    -1,    -1,
     716,    -1,    -1,   719,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   106,   107,    -1,   109,   110,   113,   962,   113,
      -1,    -1,    -1,    -1,   968,   969,    -1,    -1,    -1,     0,
       1,    -1,   976,     4,    -1,     6,    -1,    -1,    -1,    -1,
      -1,   985,    -1,    -1,    -1,    -1,   990,    -1,    -1,   765,
      -1,   767,    -1,    24,    -1,    -1,    27,    28,    -1,    -1,
      31,    32,    -1,    -1,    35,    -1,    -1,    -1,    -1,    -1,
      41,    42,    43,    -1,    45,    -1,    47,    48,    49,    -1,
      51,    52,    53,    54,    55,    56,    57,    -1,    59,    -1,
      -1,    -1,    63,    64,    -1,    -1,    67,    68,     1,    70,
      71,    72,    73,    74,    -1,    76,    77,    -1,    79,    -1,
      81,    82,    83,    -1,    -1,    86,    -1,    -1,    -1,    -1,
      -1,    24,    25,    26,    -1,    -1,    -1,    -1,    -1,    -1,
      25,    26,   103,    36,    -1,    -1,    -1,    -1,    -1,    -1,
     111,    36,   113,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    62,
     963,   964,    65,    66,    -1,    -1,    69,    62,    -1,    -1,
      65,    66,    75,    -1,    69,    78,    -1,    -1,    -1,   982,
      75,    -1,    85,    78,    -1,    -1,    -1,    90,    -1,    -1,
      85,    -1,    -1,   909,    -1,    90,   912,    -1,    -1,   915,
     103,    -1,   105,   106,   107,   108,    -1,   110,   111,   104,
      -1,     1,    -1,    -1,    -1,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,   945,
      20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
      30,    31,    32,    33,    34,    35,    36,    37,    -1,    -1,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      -1,    61,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    -1,
      80,    81,    82,    83,    -1,    85,    86,    -1,    -1,    -1,
      90,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,
      -1,    -1,   102,   103,    -1,    -1,    -1,   107,    -1,   109,
       1,    -1,    -1,   113,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    -1,    25,    26,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    -1,    80,
      81,    82,    83,    -1,    85,    86,    -1,    -1,    -1,    90,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,
      -1,   102,    -1,    -1,    -1,    -1,   107,    -1,   109,    -1,
       1,    -1,   113,     4,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    24,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    -1,    37,    -1,    -1,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
      61,    -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,
      71,    72,    73,    74,    -1,    76,    77,    -1,    -1,    80,
      81,    82,    83,    84,    -1,    86,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,
      -1,   102,   103,    -1,   105,    -1,   107,    -1,   109,     1,
     111,    -1,   113,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,
      22,    23,    24,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    -1,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    -1,    61,
      -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,    71,
      72,    73,    74,    -1,    76,    77,    -1,    -1,    80,    81,
      82,    83,    -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    96,    -1,    98,    99,    -1,    -1,
     102,    -1,    -1,    -1,    -1,   107,    -1,   109,    -1,     1,
      -1,   113,     4,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    -1,    37,    -1,    -1,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    -1,    61,
      -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,    71,
      72,    73,    74,    -1,    76,    77,    -1,    -1,    80,    81,
      82,    83,    84,    -1,    86,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,
     102,   103,    -1,    -1,    -1,   107,    -1,   109,     1,   111,
      -1,   113,     5,     6,     7,     8,     9,    10,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,
      23,    24,    -1,    -1,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    -1,    37,    -1,    -1,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    -1,    61,    -1,
      63,    64,    -1,    -1,    67,    68,    -1,    70,    71,    72,
      73,    74,    -1,    76,    77,    -1,    -1,    80,    81,    82,
      83,    -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,   102,
     103,   104,   105,    -1,   107,    -1,   109,     1,    -1,    -1,
     113,     5,     6,     7,     8,     9,    10,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,
      24,    -1,    -1,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    -1,    37,    -1,    -1,    40,    41,    42,    43,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    -1,    61,    -1,    63,
      64,    -1,    -1,    67,    68,    -1,    70,    71,    72,    73,
      74,    -1,    76,    77,    -1,    -1,    80,    81,    82,    83,
      -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,   102,    -1,
      -1,   105,    -1,   107,   108,   109,     1,    -1,    -1,   113,
       5,     6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,
      15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,    24,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    -1,    37,    -1,    -1,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    -1,    61,    -1,    63,    64,
      -1,    -1,    67,    68,    -1,    70,    71,    72,    73,    74,
      -1,    76,    77,    -1,    -1,    80,    81,    82,    83,    -1,
      -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    98,    -1,    -1,    -1,   102,   103,    -1,
      -1,    -1,   107,    -1,   109,     1,    -1,    -1,   113,     5,
       6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,
      -1,    -1,    -1,    -1,    20,    21,    22,    23,    24,    -1,
      -1,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      -1,    37,    -1,    -1,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    -1,    61,    -1,    63,    64,    -1,
      -1,    67,    68,    -1,    70,    71,    72,    73,    74,    -1,
      76,    77,    -1,    -1,    80,    81,    82,    83,    -1,    -1,
      86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    98,    -1,    -1,    -1,   102,   103,    -1,    -1,
      -1,   107,    -1,   109,     1,    -1,    -1,   113,     5,     6,
       7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    -1,
      37,    -1,    -1,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    -1,    61,    -1,    63,    64,    -1,    -1,
      67,    68,    -1,    70,    71,    72,    73,    74,    -1,    76,
      77,    -1,    -1,    80,    81,    82,    83,    -1,    -1,    86,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    98,    -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,
     107,    -1,   109,     1,   111,    -1,   113,     5,     6,     7,
       8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,
      -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,
      28,    29,    30,    31,    32,    33,    34,    35,    -1,    37,
      -1,    -1,    40,    41,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    -1,    61,    -1,    63,    64,    -1,    -1,    67,
      68,    -1,    70,    71,    72,    73,    74,    -1,    76,    77,
      -1,    -1,    80,    81,    82,    83,    -1,    -1,    86,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      98,    -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,   107,
      -1,   109,     1,    -1,    -1,   113,     5,     6,     7,     8,
       9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,
      -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    -1,    37,    -1,
      -1,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    -1,    61,    -1,    63,    64,    -1,    -1,    67,    68,
      -1,    70,    71,    72,    73,    74,    -1,    76,    77,    -1,
      -1,    80,    81,    82,    83,    -1,    -1,    86,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    98,
       5,     6,     7,   102,    -1,    10,    -1,    -1,   107,    -1,
     109,    -1,    -1,    -1,   113,    20,    21,    22,    23,    24,
      -1,    -1,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    -1,    37,    -1,    -1,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    -1,    61,    -1,    63,    64,
      -1,    -1,    67,    68,    -1,    70,    71,    72,    73,    74,
      -1,    76,    77,    -1,    -1,    80,    81,    82,    83,    -1,
      -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
       1,    -1,    -1,    -1,     5,     6,     7,    -1,    -1,    10,
     105,    -1,   107,   108,   109,    -1,    -1,    -1,   113,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    -1,    37,    -1,    -1,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
      61,    -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,
      71,    72,    73,    74,    -1,    76,    77,    -1,    -1,    80,
      81,    82,    83,    -1,    -1,    86,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     1,    -1,    -1,    -1,     5,     6,
       7,    -1,   103,    10,    -1,    -1,   107,    -1,   109,    -1,
      -1,    -1,   113,    20,    21,    22,    23,    -1,    -1,    -1,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    -1,
      37,    -1,    -1,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    -1,    61,    -1,    63,    64,    -1,    -1,
      67,    68,    -1,    70,    71,    72,    73,    74,    -1,    76,
      77,    -1,    -1,    80,    81,    82,    83,    -1,    -1,    86,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     1,
      -1,    -1,    -1,     5,     6,     7,     8,     9,    10,    -1,
     107,    -1,   109,    15,    -1,    -1,   113,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,
      32,    33,    34,    -1,    -1,    37,    -1,    -1,    40,    41,
      42,    -1,    44,    -1,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    -1,    58,    -1,    60,    61,
      -1,    -1,    -1,    -1,    -1,    67,    -1,    -1,    70,    -1,
      72,    73,    74,    -1,    76,    -1,    -1,    -1,    80,    81,
      82,    -1,    -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,
     102,    -1,    -1,    -1,    -1,   107,   108,   109,     1,    -1,
     112,   113,     5,     6,     7,     8,     9,    10,    -1,    -1,
      -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,
      23,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,    32,
      33,    34,    -1,    -1,    37,    -1,    -1,    40,    41,    42,
      -1,    44,    -1,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    -1,    58,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    -1,    67,    -1,    -1,    70,    -1,    72,
      73,    74,    -1,    76,    -1,    -1,    -1,    80,    81,    82,
      -1,    -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,   102,
      -1,    -1,    -1,    -1,   107,   108,   109,     1,    -1,   112,
     113,     5,     6,     7,     8,     9,    10,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,
      -1,    -1,    -1,    -1,    -1,    29,    30,    31,    32,    33,
      34,    -1,    -1,    37,    -1,    -1,    40,    41,    42,    -1,
      44,    -1,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    -1,    67,    -1,    -1,    70,    -1,    72,    73,
      74,    -1,    76,    -1,    -1,    -1,    80,    81,    82,    -1,
      -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,   102,    -1,
      -1,    -1,    -1,   107,   108,   109,   110,     1,    -1,   113,
      -1,     5,     6,     7,     8,     9,    10,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,
      24,    -1,    -1,    -1,    -1,    29,    30,    31,    32,    33,
      34,    -1,    -1,    37,    -1,    -1,    40,    41,    42,    -1,
      44,    -1,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    -1,    67,    -1,    -1,    70,    -1,    72,    73,
      74,    -1,    76,    -1,    -1,    -1,    80,    81,    82,    -1,
      -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,   102,    -1,
      -1,    -1,    -1,   107,    -1,   109,     1,    -1,    -1,   113,
       5,     6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,
      15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,    -1,
      -1,    -1,    -1,    -1,    29,    30,    31,    32,    33,    34,
      -1,    -1,    37,    -1,    -1,    40,    41,    42,    -1,    44,
      -1,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    -1,    67,    -1,    -1,    70,    -1,    72,    73,    74,
      -1,    76,    -1,    -1,    -1,    80,    81,    82,    -1,    -1,
      -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    98,    -1,    -1,    -1,   102,    -1,    -1,
      -1,    -1,   107,    -1,   109,     1,   111,    -1,   113,     5,
       6,     7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,
      -1,    -1,    -1,    -1,    20,    21,    22,    23,    24,    -1,
      -1,    -1,    -1,    29,    30,    31,    32,    33,    34,    -1,
      -1,    37,    -1,    -1,    40,    41,    42,    -1,    44,    -1,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    -1,    58,    -1,    -1,    61,    -1,    -1,    -1,    -1,
      -1,    67,    -1,    -1,    70,    -1,    72,    73,    74,    -1,
      76,    -1,    -1,    -1,    80,    81,    82,    -1,    -1,    -1,
      86,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    98,    -1,    -1,    -1,   102,    -1,    -1,    -1,
      -1,   107,    -1,   109,     1,    -1,    -1,   113,     5,     6,
       7,     8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,
      -1,    -1,    -1,    20,    21,    22,    23,    24,    -1,    -1,
      -1,    -1,    29,    30,    31,    32,    33,    34,    -1,    -1,
      37,    -1,    -1,    40,    41,    42,    -1,    44,    -1,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      -1,    58,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,
      67,    -1,    -1,    70,    -1,    72,    73,    74,    -1,    76,
      -1,    -1,    -1,    80,    81,    82,    -1,    -1,    -1,    86,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    98,    -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,
     107,    -1,   109,     1,    -1,    -1,   113,     5,     6,     7,
       8,     9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,
      -1,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    -1,
      -1,    29,    30,    31,    32,    33,    34,    -1,    -1,    37,
      -1,    -1,    40,    41,    42,    -1,    44,    -1,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    -1,
      58,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,    67,
      -1,    -1,    70,    -1,    72,    73,    74,    -1,    76,    -1,
      -1,    -1,    80,    81,    82,    -1,    -1,    -1,    86,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      98,    -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,   107,
      -1,   109,     1,    -1,    -1,   113,     5,     6,     7,     8,
       9,    10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,
      -1,    20,    21,    22,    23,    -1,    -1,    -1,    -1,    -1,
      29,    30,    31,    32,    33,    34,    -1,    -1,    37,    -1,
      -1,    40,    41,    42,    -1,    44,    -1,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    -1,    58,
      -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,    67,    -1,
      -1,    70,    -1,    72,    73,    74,    -1,    76,    -1,    -1,
      -1,    80,    81,    82,    -1,    -1,    -1,    86,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,
      -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,   107,    -1,
     109,     1,    -1,    -1,   113,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    -1,    -1,    -1,    -1,    -1,    29,
      30,    31,    32,    33,    34,    -1,    -1,    37,    -1,    -1,
      40,    41,    42,    -1,    44,    -1,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    -1,    58,    -1,
      -1,    61,    -1,    -1,    -1,    -1,    -1,    67,    -1,    -1,
      70,    -1,    72,    73,    74,    -1,    76,    -1,    -1,    -1,
      80,    81,    82,    -1,    -1,    -1,    86,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,
      -1,    -1,   102,    -1,    -1,    -1,    -1,   107,    -1,   109,
       1,    -1,    -1,   113,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    -1,    -1,    -1,    -1,    -1,    29,    30,
      31,    32,    33,    34,    -1,    -1,    37,    -1,    -1,    40,
      41,    42,    -1,    44,    -1,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    -1,    58,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    -1,    67,    -1,    -1,    70,
      -1,    72,    73,    74,    -1,    76,    -1,    -1,    -1,    80,
      81,    82,    -1,    -1,    -1,    86,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,
      -1,   102,    -1,    -1,    -1,    -1,   107,    -1,   109,     1,
      -1,    -1,   113,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,
      32,    33,    34,    -1,    -1,    37,    -1,    -1,    40,    41,
      42,    -1,    44,    -1,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    -1,    58,    -1,    -1,    61,
      -1,    -1,    -1,    -1,    -1,    67,    -1,    -1,    70,    -1,
      72,    73,    74,    -1,    76,    -1,    -1,    -1,    80,    81,
      82,    -1,    -1,     1,    86,    -1,     4,    -1,     6,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,
     102,    -1,    -1,    -1,    -1,   107,    24,   109,    -1,    27,
      28,   113,    -1,    31,    32,    -1,    -1,    35,    -1,    -1,
      -1,    -1,    -1,    41,    42,    43,    -1,    45,    -1,    47,
      48,    49,    -1,    51,    52,    53,    54,    55,    56,    57,
      -1,    59,    -1,    -1,    -1,    63,    64,    -1,    -1,    67,
      68,    -1,    70,    71,    72,    73,    74,    -1,    76,    77,
      -1,    79,    -1,    81,    82,    83,    -1,    -1,    86,    -1,
      -1,     1,    -1,    -1,     4,    -1,     6,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   103,    -1,   105,    -1,    -1,
      -1,    -1,    -1,   111,    24,   113,    -1,    27,    28,    -1,
      -1,    31,    32,    -1,    -1,    35,    -1,    -1,    -1,    -1,
      -1,    41,    42,    43,    -1,    45,    -1,    47,    48,    49,
      -1,    51,    52,    53,    54,    55,    56,    57,    -1,    59,
      -1,    -1,    -1,    63,    64,    -1,    -1,    67,    68,    -1,
      70,    71,    72,    73,    74,    -1,    76,    77,    -1,    79,
      -1,    81,    82,    83,    -1,    -1,    86,     1,    -1,    -1,
      -1,     5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,    15,    -1,   103,    -1,   105,    -1,    21,    22,    -1,
      -1,   111,    -1,   113,    -1,    -1,    -1,    31,    32,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    41,    -1,    -1,
      -1,    -1,    46,    47,    48,    49,    -1,    -1,    -1,    -1,
      54,    -1,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    73,
       5,     6,     7,     8,     9,    -1,    80,    -1,    82,    -1,
      15,    -1,    -1,    -1,    -1,    -1,    21,    22,    -1,    -1,
      -1,    -1,    -1,    -1,    98,    -1,    31,    32,   102,    -1,
      -1,    -1,    -1,   107,    -1,   109,    41,    -1,    -1,   113,
      -1,    46,    47,    48,    49,    -1,    -1,    -1,    -1,    54,
      -1,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    73,     5,
       6,     7,     8,     9,    -1,    80,    -1,    82,    -1,    15,
      -1,    -1,    -1,    -1,    -1,    21,    22,    -1,    -1,    -1,
      -1,    -1,    -1,    98,    -1,    31,    32,   102,    -1,    -1,
      -1,    -1,   107,    -1,   109,    41,    -1,    -1,   113,    -1,
      46,    47,    48,    49,    -1,    -1,    -1,    -1,    54,    -1,
      56,    -1,    58,    -1,    -1,    61,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     1,    -1,    -1,    73,     5,     6,
       7,     8,     9,    -1,    80,    -1,    82,    -1,    15,    -1,
      -1,    -1,    -1,    -1,    21,    22,    -1,    -1,    -1,    -1,
      -1,    -1,    98,    -1,    31,    32,   102,    -1,    -1,    -1,
      -1,   107,    -1,   109,    41,    -1,    -1,   113,    -1,    46,
      47,    48,    49,    -1,    -1,    -1,    -1,    54,    -1,    56,
      -1,    58,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     1,    -1,    -1,    73,     5,     6,     7,
       8,     9,    -1,    80,    -1,    82,    -1,    15,    -1,    -1,
      -1,    -1,    -1,    21,    22,    -1,    -1,    -1,    -1,    -1,
      -1,    98,    -1,    31,    32,   102,    -1,    -1,    -1,    -1,
     107,    -1,   109,    41,    -1,    -1,   113,    -1,    46,    47,
      48,    49,    -1,    -1,    -1,    -1,    54,    -1,    56,    -1,
      58,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     1,    -1,    -1,    73,     5,     6,     7,     8,
       9,    -1,    80,    -1,    82,    -1,    15,    -1,    -1,    -1,
      -1,    -1,    21,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      98,    -1,    31,    32,   102,    -1,    -1,    -1,    -1,   107,
      -1,   109,    41,    -1,    -1,   113,    -1,    46,    47,    48,
      49,    -1,    -1,    -1,    -1,    54,    -1,    56,    -1,    58,
      -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     1,    -1,    -1,    73,     5,     6,     7,     8,     9,
      -1,    80,    -1,    82,    -1,    15,    -1,    -1,    -1,    -1,
      -1,    21,    22,    -1,    -1,    -1,    -1,    -1,    -1,    98,
      -1,    31,    32,   102,    -1,    -1,    -1,    -1,   107,    -1,
     109,    41,    -1,    -1,   113,    -1,    46,    47,    48,    49,
      -1,    -1,    -1,    -1,    54,    -1,    56,    -1,    58,    -1,
      -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
       1,    -1,    -1,    73,     5,     6,     7,     8,     9,    -1,
      80,    -1,    82,    -1,    15,    -1,    -1,    -1,    -1,    -1,
      21,    22,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,
      31,    32,   102,    -1,    -1,    -1,    -1,   107,    -1,   109,
      41,    -1,    -1,   113,    -1,    46,    47,    48,    49,    -1,
      -1,    -1,    -1,    54,    -1,    56,    -1,    58,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     1,
      -1,    -1,    73,     5,     6,     7,     8,     9,    -1,    80,
      -1,    82,    -1,    15,    -1,    -1,    -1,    -1,    -1,    21,
      22,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    31,
      32,   102,    -1,    -1,    -1,    -1,   107,    -1,   109,    41,
      -1,    -1,   113,    -1,    46,    47,    48,    49,    -1,    -1,
      -1,    -1,    54,    -1,    56,    -1,    58,    -1,    -1,    61,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,
      -1,    73,     5,     6,     7,     8,     9,    -1,    80,    -1,
      82,    -1,    15,    -1,    -1,    -1,    -1,    -1,    21,    22,
      -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    31,    32,
     102,    -1,    -1,    -1,    -1,   107,    -1,   109,    41,    -1,
      -1,   113,    -1,    46,    47,    48,    49,    -1,    -1,    -1,
      -1,    54,    -1,    56,    -1,    58,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,
      73,     5,     6,     7,     8,     9,    -1,    80,    -1,    82,
      -1,    15,    -1,    -1,    -1,    -1,    -1,    21,    22,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    -1,    31,    32,   102,
      -1,    -1,    -1,    -1,   107,    -1,   109,    41,    -1,    -1,
     113,    -1,    46,    47,    48,    49,    -1,    -1,    -1,    -1,
      54,    -1,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    73,
       5,     6,     7,     8,     9,    -1,    80,    -1,    82,    -1,
      15,    -1,    -1,    -1,    -1,    -1,    21,    22,    -1,    -1,
      -1,    -1,    -1,    -1,    98,    -1,    31,    32,   102,    -1,
      -1,    -1,    -1,   107,    -1,   109,    41,    -1,    -1,   113,
      -1,    46,    47,    48,    49,    -1,    -1,    -1,    -1,    54,
      -1,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     1,    -1,    -1,    73,     5,
       6,     7,     8,     9,    -1,    80,    -1,    82,    -1,    15,
      -1,    -1,    -1,    -1,    -1,    21,    22,    -1,    -1,    -1,
      -1,    -1,    -1,    98,    -1,    31,    32,   102,    -1,    -1,
      -1,    -1,   107,    -1,   109,    41,    -1,    -1,   113,    -1,
      46,    47,    48,    49,    -1,    -1,    -1,    -1,    54,    -1,
      56,    -1,    58,    -1,    -1,    61,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     1,    -1,    -1,    73,     5,     6,
       7,     8,     9,    -1,    80,    -1,    82,    -1,    15,    -1,
      -1,    -1,    -1,    -1,    21,    22,    -1,    -1,    -1,    -1,
      -1,    -1,    98,    -1,    31,    32,   102,    -1,    -1,    -1,
      -1,   107,    -1,   109,    41,    -1,    -1,   113,    -1,    46,
      47,    48,    49,    -1,    -1,    -1,    -1,    54,    -1,    56,
      -1,    58,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,     1,    -1,    -1,    73,     5,     6,     7,
       8,     9,    -1,    80,    -1,    82,    -1,    15,    -1,    -1,
      -1,    -1,    -1,    21,    22,    -1,    -1,    -1,    -1,    -1,
      -1,    98,    -1,    31,    32,   102,    -1,    -1,    -1,    -1,
     107,    -1,   109,    41,    -1,    -1,   113,    -1,    46,    47,
      48,    49,    -1,    -1,    -1,    -1,    54,    -1,    56,    -1,
      58,    -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     1,    -1,    -1,    73,     5,     6,     7,     8,
       9,    -1,    80,    -1,    82,    -1,    15,    -1,    -1,    -1,
      -1,    -1,    21,    22,    -1,    -1,    -1,    -1,    -1,    -1,
      98,    -1,    31,    32,   102,    -1,    -1,    -1,    -1,   107,
      -1,   109,    41,    -1,    -1,   113,    -1,    46,    47,    48,
      49,    -1,    -1,    -1,    -1,    54,    -1,    56,    -1,    58,
      -1,    -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,     1,    -1,    -1,    73,     5,     6,     7,     8,     9,
      -1,    80,    -1,    82,    -1,    15,    -1,    -1,    -1,    -1,
      -1,    21,    22,    -1,    -1,    -1,    -1,    -1,    -1,    98,
      -1,    31,    32,   102,    -1,    -1,    -1,    -1,   107,    -1,
     109,    41,    -1,    -1,   113,    -1,    46,    47,    48,    49,
      -1,    -1,    -1,    -1,    54,    -1,    56,    -1,    58,    -1,
      -1,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
       1,    -1,    -1,    73,     5,     6,     7,     8,     9,    -1,
      80,    -1,    82,    -1,    15,    -1,    -1,    -1,    -1,    -1,
      21,    22,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,
      31,    32,   102,    -1,    27,    28,    -1,   107,    -1,   109,
      41,    -1,    35,   113,    -1,    46,    47,    48,    49,    -1,
      43,    -1,    45,    54,    -1,    56,    -1,    58,    -1,    -1,
      61,    -1,    -1,    -1,    57,    -1,    59,    -1,    -1,     1,
      63,    64,    73,    -1,     6,    68,    -1,    -1,    71,    80,
      -1,    82,    -1,    -1,    77,    -1,    -1,    -1,    -1,    -1,
      83,    -1,    -1,    -1,     1,    27,    28,    98,    -1,    -1,
      32,   102,    -1,    35,    -1,    -1,   107,    -1,   109,    -1,
      -1,    43,   113,    45,    -1,    47,    48,    49,    25,    26,
      -1,    -1,    -1,    -1,    56,    57,    -1,    59,    -1,    36,
      -1,    63,    64,    -1,    -1,    -1,    68,    -1,     1,    71,
      -1,    73,    -1,     6,    -1,    77,    -1,    -1,    -1,    -1,
      82,    83,    -1,    -1,    -1,    62,    -1,    -1,    65,    66,
      -1,    -1,    69,    -1,    27,    28,    -1,    -1,    75,    32,
      -1,    78,    35,    -1,    -1,    -1,   108,    -1,    85,    -1,
      43,   113,    45,    90,    47,    48,    49,    -1,    -1,    -1,
       1,    -1,    -1,    56,    57,     6,    59,    -1,    -1,   106,
      63,    64,    -1,   110,    -1,    68,    -1,    -1,    71,    -1,
      73,    -1,    -1,    -1,    77,    -1,    27,    28,    -1,    82,
      83,    32,    -1,    -1,    35,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    43,    -1,    45,    -1,    47,    48,    49,     1,
      -1,    -1,    -1,    -1,     6,    56,    57,    -1,    59,    -1,
     113,    -1,    63,    64,    -1,    -1,    -1,    68,    -1,    -1,
      71,    -1,    73,    25,    26,    -1,    77,    -1,    -1,    -1,
      32,    82,    83,    -1,    36,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    47,    48,    49,    -1,    -1,
      -1,    -1,    -1,    -1,    56,    -1,    -1,    -1,    -1,    -1,
      62,    -1,   113,    65,    66,    -1,    -1,    69,    -1,    -1,
      -1,    73,    -1,    75,    -1,    -1,    78,    -1,    -1,    -1,
      82,     3,    -1,    85,    -1,    -1,     8,     9,    90,    11,
      12,    13,    14,    -1,    16,    17,    18,    19,    -1,    -1,
      -1,    -1,    24,    25,    26,    -1,    -1,    -1,    -1,    -1,
      -1,   113,    -1,    -1,    36,    -1,    38,    39,    11,    12,
      13,    14,    -1,    16,    17,    18,    19,    -1,    -1,    -1,
      -1,    11,    12,    13,    14,    -1,    16,    17,    -1,    -1,
      62,    -1,    -1,    65,    66,    -1,    -1,    69,    -1,    11,
      12,    13,    14,    75,    16,    17,    78,    -1,    -1,    -1,
      -1,    -1,    -1,    85,    -1,    87,    88,    -1,    90,    91,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
      -1,   103,   104,   105,   106,   107,   108,   109,   110,     3,
      -1,   113,    -1,    -1,     8,     9,    -1,    -1,    91,    92,
      93,    94,    95,    96,    97,    98,    99,   100,   101,    -1,
      -1,    25,    26,    93,    94,    95,    96,    97,    98,    99,
     100,   101,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    62,    -1,
      -1,    65,    66,    -1,    -1,    69,    -1,    -1,    -1,    -1,
      -1,    75,    -1,    -1,    78,    -1,    -1,    -1,    -1,    -1,
      -1,    85,    -1,    87,    88,    -1,    90,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     5,     6,     7,     8,
       9,    10,    -1,   107,    -1,   109,    15,    -1,    -1,   113,
      -1,    20,    21,    22,    23,    24,    -1,    -1,    27,    28,
      29,    30,    -1,    32,    33,    34,    35,    -1,    37,    38,
      39,    40,    -1,    42,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    -1,    61,    -1,    63,    64,    -1,    -1,    67,    68,
      -1,    70,    71,    72,    73,    74,    -1,    76,    77,    -1,
      -1,    80,    81,    82,    83,    -1,    -1,    86,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    96,    -1,    98,
      -1,    -1,    -1,   102,    -1,    -1,    -1,    -1,   107,    -1,
     109,    -1,    -1,    -1,   113,     5,     6,     7,     8,     9,
      10,    -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    24,    -1,    -1,    27,    28,    29,
      30,    -1,    32,    33,    34,    35,    -1,    37,    -1,    -1,
      40,    -1,    42,    43,    44,    45,    46,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      -1,    61,    -1,    63,    64,    -1,    -1,    67,    68,    -1,
      70,    71,    72,    73,    74,    -1,    76,    77,    -1,    -1,
      80,    81,    82,    83,    -1,    -1,    86,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    96,    -1,    98,    -1,
      -1,    -1,   102,    -1,    -1,    -1,    -1,   107,    -1,   109,
     110,    -1,    -1,   113,     5,     6,     7,     8,     9,    10,
      -1,    -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    32,    33,    34,    35,    -1,    37,    -1,    -1,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
      61,    -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,
      71,    72,    73,    74,    -1,    76,    77,    -1,    -1,    80,
      81,    82,    83,    -1,    -1,    86,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,
      -1,   102,    -1,    -1,    -1,    -1,   107,    -1,   109,    -1,
      -1,    -1,   113,     5,     6,     7,     8,     9,    10,    -1,
      -1,    -1,    -1,    15,    -1,    -1,    -1,    -1,    20,    21,
      22,    23,    24,    -1,    -1,    27,    28,    29,    30,    -1,
      32,    33,    34,    35,    -1,    37,    -1,    -1,    40,    -1,
      42,    43,    44,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    -1,    61,
      -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,    71,
      72,    73,    74,    -1,    76,    77,    -1,    -1,    80,    81,
      82,    83,    -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    98,     5,     6,     7,
     102,    -1,    10,    -1,    -1,   107,    -1,   109,    -1,    -1,
      -1,   113,    20,    21,    22,    23,    -1,    -1,    -1,    27,
      28,    29,    30,    -1,    32,    33,    34,    35,    -1,    37,
      -1,    -1,    40,    -1,    42,    43,    44,    45,    46,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    -1,    61,    -1,    63,    64,    -1,    -1,    67,
      68,    -1,    70,    71,    72,    73,    74,    -1,    76,    77,
      -1,    -1,    80,    81,    82,    83,    -1,    -1,    86,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,     5,     6,     7,     8,     9,    10,    -1,   107,
      -1,   109,    15,    -1,    -1,   113,    -1,    20,    21,    22,
      23,    -1,    -1,    -1,    -1,    -1,    29,    30,    31,    32,
      33,    34,    -1,    -1,    37,    -1,    -1,    40,    41,    42,
      -1,    44,    -1,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    -1,    58,    -1,    -1,    61,    -1,
      -1,    -1,    -1,    -1,    67,    -1,    -1,    70,    -1,    72,
      73,    74,    -1,    76,    -1,    -1,    -1,    80,    81,    82,
      -1,    -1,    -1,    86,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    98,    -1,    -1,    -1,   102,
      -1,    -1,    -1,    -1,   107,    -1,   109,    -1,    -1,   112,
     113,     5,     6,     7,     8,     9,    10,    -1,    -1,    -1,
      -1,    15,    -1,    -1,    -1,    -1,    20,    21,    22,    23,
      -1,    -1,    -1,    -1,    -1,    29,    30,    -1,    32,    33,
      34,    -1,    -1,    37,    -1,    -1,    40,    -1,    42,    -1,
      44,    -1,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    -1,    58,    -1,    -1,    61,    -1,    -1,
      -1,    -1,    -1,    67,    -1,    -1,    70,    -1,    72,    73,
      74,    -1,    76,    -1,    -1,    -1,    80,    81,    82,    -1,
      -1,    -1,    86,     5,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,    15,    98,    -1,    -1,    -1,   102,    21,
      22,    -1,    -1,   107,    -1,   109,     5,     6,     7,   113,
      32,    -1,    -1,    -1,    11,    12,    13,    14,    -1,    16,
      17,    -1,    21,    22,    46,    47,    48,    49,    -1,    -1,
      -1,    -1,    54,    32,    56,    -1,    58,    -1,    -1,    61,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    46,    47,    48,
      49,    73,    -1,    -1,    -1,    54,    -1,    56,    80,    58,
      82,    -1,    61,    -1,    -1,    -1,    -1,    -1,     6,    -1,
      -1,    -1,    -1,    -1,    73,    -1,    98,    -1,    -1,    -1,
     102,    80,    -1,    82,    -1,   107,    -1,   109,    -1,    27,
      28,   113,    -1,    -1,    32,    -1,    -1,    35,    95,    96,
      97,    98,    99,   100,   101,    43,    -1,    45,   107,    47,
      48,    49,    -1,    -1,   113,    -1,    -1,    -1,    56,    57,
       6,    59,    -1,    -1,    -1,    63,    64,    -1,    -1,    -1,
      68,    -1,    -1,    71,    -1,    73,    -1,    -1,    -1,    77,
      -1,    27,    28,    -1,    82,    83,    32,    -1,    -1,    35,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    43,    -1,    45,
      -1,    47,    48,    49,    -1,    -1,    -1,    -1,   106,    -1,
      56,    57,     6,    59,    -1,   113,    -1,    63,    64,    -1,
      -1,    -1,    68,    -1,    -1,    71,    -1,    73,    -1,    -1,
      -1,    77,    -1,    27,    28,    -1,    82,    83,    32,    -1,
      -1,    35,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    43,
      -1,    45,    -1,    47,    48,    49,    -1,    -1,    -1,    -1,
      -1,    -1,    56,    57,    -1,    59,    -1,   113,    -1,    63,
      64,    -1,    -1,     1,    68,    -1,    -1,    71,    -1,    73,
      -1,    -1,    10,    77,    -1,    -1,    -1,    -1,    82,    83,
      -1,    -1,    20,    21,    22,    23,    24,    -1,    -1,    27,
      28,    29,    30,    31,    -1,    33,    34,    35,    -1,    37,
      -1,    -1,    40,    41,    42,    43,    44,    45,    46,   113,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,     1,    -1,    -1,    63,    64,    -1,    -1,    67,
      68,    -1,    70,    71,    72,    73,    74,    -1,    76,    77,
      -1,    79,    80,    81,    -1,    83,    25,    26,    86,    11,
      12,    13,    14,    -1,    16,    17,    18,    36,    -1,    -1,
      25,    26,    -1,    -1,    -1,    -1,    -1,   105,   106,    -1,
      -1,    36,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    62,    -1,    -1,    65,    66,    -1,    -1,
      69,    -1,    -1,    -1,    -1,    -1,    75,    62,    -1,    78,
      65,    66,    -1,    -1,    69,    -1,    85,    -1,    -1,    -1,
      75,    90,    -1,    78,    -1,    -1,    -1,    -1,    -1,    -1,
      85,    -1,    -1,    -1,    -1,    90,    -1,    -1,    -1,    -1,
      92,    93,    94,    95,    96,    97,    98,    99,   100,   101,
       1,    -1,    -1,     4,    -1,    -1,    -1,    -1,    -1,    10,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    20,
      21,    22,    23,    -1,    -1,    -1,    27,    28,    29,    30,
      31,    -1,    33,    34,    35,    -1,    37,    -1,    -1,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    -1,
      -1,    -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,
      71,    72,    73,    74,    -1,    76,    77,    -1,    79,    80,
      81,     1,    83,    84,    -1,    86,     6,    -1,    -1,    -1,
      10,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    -1,    -1,    -1,    27,    28,    29,
      30,    31,    -1,    33,    34,    35,    -1,    37,    -1,    -1,
      40,    41,    42,    43,    44,    45,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      -1,    -1,    -1,    63,    64,    -1,    -1,    67,    68,     1,
      70,    71,    72,    73,    74,    -1,    76,    77,    10,    79,
      80,    81,    -1,    83,    -1,    -1,    86,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      -1,    33,    34,    35,    -1,    37,    -1,    -1,    40,    41,
      42,    43,    44,    45,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    -1,    -1,
      -1,    63,    64,    -1,    -1,    67,    68,     1,    70,    71,
      72,    73,    74,    -1,    76,    77,    10,    79,    80,    81,
      -1,    83,    -1,    -1,    86,    -1,    20,    21,    22,    23,
      -1,    -1,    -1,    27,    28,    29,    30,    31,    -1,    33,
      34,    35,    -1,    37,    -1,    -1,    40,    41,    42,    43,
      44,    45,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    -1,    -1,    -1,    63,
      64,    -1,    -1,    67,    68,     1,    70,    71,    72,    73,
      74,    -1,    76,    77,    10,    79,    80,    81,    -1,    83,
      -1,    -1,    86,    -1,    20,    21,    22,    23,    -1,    -1,
      -1,    27,    28,    29,    30,    31,    -1,    33,    34,    35,
      -1,    37,    -1,    -1,    40,    41,    42,    43,    44,    45,
      46,    -1,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    -1,    -1,    -1,    63,    64,    -1,
      -1,    67,    68,     1,    70,    71,    72,    73,    74,    -1,
      76,    77,    10,    79,    80,    81,    -1,    83,    -1,    -1,
      86,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,
      28,    29,    30,    31,    -1,    33,    34,    35,    -1,    37,
      -1,    -1,    40,    41,    42,    43,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    -1,    -1,    -1,    63,    64,    -1,    -1,    67,
      68,     1,    70,    71,    72,    73,    74,    -1,    76,    77,
      10,    79,    80,    81,    -1,    83,    -1,    -1,    86,    -1,
      20,    21,    22,    23,    -1,    -1,    -1,    27,    28,    29,
      30,    31,    -1,    33,    34,    35,    -1,    37,    -1,    -1,
      40,    41,    42,    43,    44,    45,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      -1,    -1,    -1,    63,    64,    -1,    -1,    67,    68,     1,
      70,    71,    72,    73,    74,    -1,    76,    77,    10,    79,
      80,    81,    -1,    83,    -1,    -1,    86,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      -1,    33,    34,    35,    -1,    37,    -1,    -1,    40,    41,
      42,    43,    44,    45,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    -1,    -1,
      -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,    71,
      72,    73,    74,    -1,    76,    77,    10,    79,    80,    81,
      -1,    83,    -1,    -1,    86,    -1,    20,    21,    22,    23,
      -1,    -1,    -1,    27,    28,    29,    30,    31,    -1,    33,
      34,    35,    -1,    37,    -1,    -1,    40,    41,    42,    43,
      44,    45,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    -1,    -1,    -1,    63,
      64,    -1,    -1,    67,    68,    -1,    70,    71,    72,    73,
      74,    -1,    76,    77,    10,    79,    80,    81,    -1,    83,
      -1,    -1,    86,    -1,    20,    21,    22,    23,    92,    -1,
      -1,    27,    28,    29,    30,    31,    -1,    33,    34,    35,
      -1,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    -1,    -1,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    -1,    -1,    -1,    63,    64,    -1,
      -1,    67,    68,    -1,    70,    71,    72,    73,    74,    -1,
      76,    77,    10,    79,    80,    81,    -1,    83,    -1,    -1,
      86,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,
      28,    29,    30,    31,    -1,    33,    34,    35,    -1,    37,
      -1,    -1,    40,    41,    42,    43,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    -1,    -1,    -1,    63,    64,    -1,    -1,    67,
      68,    -1,    70,    71,    72,    73,    74,    -1,    76,    77,
      10,    79,    80,    81,    -1,    83,    -1,    -1,    86,    -1,
      20,    21,    22,    23,    -1,    -1,    -1,    27,    28,    29,
      30,    31,    -1,    33,    34,    35,    -1,    37,    -1,    -1,
      40,    41,    42,    43,    44,    45,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      -1,    -1,    -1,    63,    64,    -1,    -1,    67,    68,    -1,
      70,    71,    72,    73,    74,    -1,    76,    77,    10,    79,
      80,    81,    -1,    83,    -1,    -1,    86,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      -1,    33,    34,    35,    -1,    37,    -1,    -1,    40,    41,
      42,    43,    44,    45,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    -1,    -1,
      -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,    71,
      72,    73,    74,    -1,    76,    77,    10,    79,    80,    81,
      -1,    83,    -1,    -1,    86,    -1,    20,    21,    22,    23,
      -1,    -1,    -1,    27,    28,    29,    30,    31,    -1,    33,
      34,    35,    -1,    37,    -1,    -1,    40,    41,    42,    43,
      44,    45,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    -1,    -1,    -1,    63,
      64,    -1,    -1,    67,    68,    -1,    70,    71,    72,    73,
      74,    -1,    76,    77,    10,    79,    80,    81,    -1,    83,
      -1,    -1,    86,    -1,    20,    21,    22,    23,    -1,    -1,
      -1,    27,    28,    29,    30,    31,    -1,    33,    34,    35,
      -1,    37,    -1,    -1,    40,    41,    42,    43,    44,    45,
      46,    -1,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    -1,    -1,    -1,    63,    64,    -1,
      -1,    67,    68,    -1,    70,    71,    72,    73,    74,    -1,
      76,    77,    10,    79,    80,    81,    -1,    83,    -1,    -1,
      86,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,
      28,    29,    30,    31,    -1,    33,    34,    35,    -1,    37,
      -1,    -1,    40,    41,    42,    43,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    -1,    -1,    -1,    63,    64,    -1,    -1,    67,
      68,    -1,    70,    71,    72,    73,    74,    -1,    76,    77,
      10,    79,    80,    81,    -1,    83,    -1,    -1,    86,    -1,
      20,    21,    22,    23,    -1,    -1,    -1,    27,    28,    29,
      30,    31,    -1,    33,    34,    35,    -1,    37,    -1,    -1,
      40,    41,    42,    43,    44,    45,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      -1,    -1,    -1,    63,    64,    -1,    -1,    67,    68,    -1,
      70,    71,    72,    73,    74,    -1,    76,    77,    10,    79,
      80,    81,    -1,    83,    -1,    -1,    86,    -1,    20,    21,
      22,    23,    -1,    -1,    -1,    27,    28,    29,    30,    31,
      -1,    33,    34,    35,    -1,    37,    -1,    -1,    40,    41,
      42,    43,    44,    45,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    -1,    -1,
      -1,    63,    64,    -1,    -1,    67,    68,    -1,    70,    71,
      72,    73,    74,    -1,    76,    77,    10,    79,    80,    81,
      -1,    83,    -1,    -1,    86,    -1,    20,    21,    22,    23,
      -1,    -1,    -1,    27,    28,    29,    30,    31,    -1,    33,
      34,    35,    -1,    37,    -1,    -1,    40,    41,    42,    43,
      44,    45,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    -1,    -1,    -1,    63,
      64,    -1,    -1,    67,    68,    -1,    70,    71,    72,    73,
      74,    -1,    76,    77,    10,    79,    80,    81,    -1,    83,
      -1,    -1,    86,    -1,    20,    21,    22,    23,    -1,    -1,
      -1,    27,    28,    29,    30,    31,    -1,    33,    34,    35,
      -1,    37,    -1,    -1,    40,    41,    42,    43,    44,    45,
      46,    -1,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    -1,    -1,    -1,    63,    64,    -1,
      -1,    67,    68,    -1,    70,    71,    72,    73,    74,    -1,
      76,    77,    10,    79,    80,    81,    -1,    83,    -1,    -1,
      86,    -1,    20,    21,    22,    23,    -1,    -1,    -1,    27,
      28,    29,    30,    31,    -1,    33,    34,    35,    -1,    37,
      -1,    -1,    40,    41,    42,    43,    44,    45,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      58,    59,    -1,    -1,    -1,    63,    64,    -1,    -1,    67,
      68,    -1,    70,    71,    72,    73,    74,    -1,    76,    77,
      -1,    79,    80,    81,    -1,    83,    25,    26,    86,   343,
     344,   345,   346,   347,   348,   349,   350,    36,   352,   353,
     354,   355,   356,   357,   358,   359,   360,   361,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    62,    -1,    -1,    65,    66,    -1,    -1,
      69,    -1,    -1,    -1,    -1,    -1,    75,    -1,    -1,    78,
      -1,    -1,    -1,    -1,    -1,    -1,    85,    -1,    -1,    -1,
      -1,    90
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,   115,   116,     0,     1,    24,    51,   103,   123,   124,
     127,   138,   155,   156,   245,    24,   103,   105,     1,     6,
      32,    47,    48,    49,    56,    73,    82,   113,   298,   299,
     300,   301,   312,   313,     4,    31,    41,    52,    79,   111,
     158,   233,   241,    42,    53,    54,    55,    67,    70,    72,
      74,    76,    81,    86,   149,    24,   103,   105,    10,    20,
      21,    22,    23,    27,    28,    29,    30,    31,    33,    34,
      35,    37,    40,    41,    42,    43,    44,    45,    46,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    58,
      59,    63,    64,    67,    68,    70,    71,    72,    73,    74,
      76,    77,    79,    80,    81,    83,    86,   316,   317,    32,
     113,    32,    32,    48,   103,   113,    32,     1,    48,   316,
     103,   312,     1,    48,   125,   126,   316,   195,   242,     1,
     121,   122,    27,    28,    35,    43,    45,    57,    59,    63,
      64,    68,    71,    77,    83,   166,   168,   169,   170,   298,
     313,   142,    28,    35,   129,   157,   163,   166,    48,    48,
     316,    48,   316,     1,    48,   316,    32,    32,    24,    90,
     103,   105,    90,   103,   106,    90,    48,   144,   316,   144,
      24,   103,   105,     1,   104,   118,   119,   298,   313,   314,
     107,   185,     1,   107,   107,   107,   179,   107,   174,   185,
     107,   186,   176,   177,   107,   178,   174,   175,    48,    92,
     236,   316,   116,   107,   107,     4,   137,     1,     5,     7,
       8,     9,    15,    21,    22,    24,    46,    54,    58,    61,
      73,    80,    98,   102,   107,   109,   130,   134,   160,   161,
     220,   252,   280,   281,   289,   290,   291,   294,   295,   296,
     297,   298,   303,   304,   306,   308,   313,   317,   252,     1,
     125,   252,   234,   111,    24,   103,   105,     1,     6,    48,
     117,   315,   316,   103,    97,   166,   313,   314,     1,   166,
     180,     1,     7,    89,    98,   172,   187,   107,     1,   166,
     168,   103,    24,   105,   133,   314,   108,   159,   190,   191,
      21,    22,    46,    54,    58,    80,   130,   296,   296,   134,
     290,   296,   107,   307,     1,   107,   111,   196,   305,    32,
     195,   195,   107,   290,   290,     1,   111,   134,   167,   169,
     278,   280,   134,   162,   167,   170,   296,   298,   309,   310,
     317,   290,   290,    11,    12,    13,    14,    16,    17,    18,
      19,    91,    92,    93,    94,    95,    96,    97,    98,    99,
     100,   101,   233,   241,     3,     8,     9,    25,    26,    36,
      62,    65,    66,    69,    75,    78,    85,    87,    88,    90,
     113,   130,   134,   282,    90,   282,   235,   243,     6,    97,
     313,   108,     1,   106,   108,   108,   106,   166,   182,   183,
     283,   108,   108,     7,    38,    39,   173,   166,   119,   120,
     108,   108,   106,   283,    48,   316,   103,   106,   167,     1,
     280,   305,     1,   164,   165,   167,   170,   277,   278,   197,
      48,   316,   219,     1,   112,   279,   280,   284,   285,     1,
     280,    24,   103,   105,   108,   284,   134,   280,   286,   287,
     288,   296,   317,    92,   108,   106,   108,   167,   310,    48,
     110,   106,   311,   110,     1,   289,     1,   289,     1,   289,
       1,   289,     1,   289,     1,   289,     1,   289,     1,   289,
     281,     1,   289,     1,   289,     1,   289,     1,   289,     1,
     289,     1,   289,     1,   289,     1,   289,     1,   289,     1,
     289,   195,   195,   195,     1,   280,   195,     1,   284,     1,
      24,    96,    99,   277,   280,   302,     1,   280,   280,   280,
     107,   230,     1,   236,   238,   240,     6,   108,   166,    38,
      39,   143,   106,   283,     7,    98,   171,   104,   108,   108,
      90,   136,    90,   141,   159,   191,    24,   103,   105,   108,
       1,   106,    24,   103,   105,   108,   159,   193,   203,   225,
      48,   194,   204,   223,   316,   108,   195,   218,    24,    60,
     103,   105,   108,   280,    60,   108,   106,   283,    24,   103,
     105,   108,   108,   105,   132,   310,    24,   103,   104,   105,
     271,   110,   135,   106,   283,   168,   280,   110,   309,     1,
      90,   282,   104,     1,     4,    10,    20,    21,    22,    23,
      27,    28,    29,    30,    31,    33,    34,    35,    37,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    63,
      64,    67,    68,    70,    71,    72,    73,    74,    76,    77,
      79,    80,    81,    83,    84,    86,   150,   151,   152,   153,
     154,    48,   280,   302,    48,    24,   103,   105,   108,   108,
      24,   103,   105,   108,   110,    24,   277,   110,   110,   173,
     155,   227,   228,   229,   283,     1,    24,   111,   231,    90,
     237,   106,   244,   108,   104,   184,     7,   108,   188,     1,
      24,   192,     1,   107,   280,   107,    48,   316,    24,   103,
     105,   108,   280,    48,   316,   106,    90,   218,   106,    90,
     198,     1,   221,   279,   108,   110,     1,   280,   108,     1,
     288,   311,   280,   280,   281,   110,   173,   111,   292,   292,
     302,   129,   104,   106,   283,   108,   131,   116,   252,   239,
      24,   105,   200,   181,   166,   166,   280,   139,   145,   147,
     148,   166,   283,     1,   311,    90,   218,    90,   202,   252,
       1,   107,   146,   202,   252,   199,   146,   302,   195,   110,
     159,   227,   227,   232,   238,   166,   189,   147,   108,   104,
     106,   283,   143,    24,   103,   105,   108,   108,     1,    24,
     280,     1,   146,   280,   159,   193,   147,   224,   193,   208,
     222,   110,   218,   143,   316,   200,   108,   108,   131,     1,
      24,   103,   128,   196,   145,   145,   144,   226,    48,   131,
       1,    24,   196,   201,     1,     4,    10,    20,    23,    29,
      30,    33,    34,    37,    44,    48,    50,    51,    84,   103,
     124,   196,   200,   207,   209,   210,   211,   212,   215,   216,
     217,   246,   255,   258,   260,   263,   267,   270,   272,   274,
     277,   201,   293,    48,   140,   201,    24,   103,   105,     1,
      48,   205,   206,   316,     1,    24,   103,   259,   276,   277,
     268,   256,    48,   214,   173,   276,   214,   104,   195,   261,
     213,   247,   264,   259,   259,   259,   208,   128,    24,    90,
     103,   105,    90,   103,   106,    90,   259,   195,   195,   276,
     173,   271,   211,   195,   104,   195,   195,   200,   252,   252,
       1,   205,   252,   269,   257,   271,   275,   276,    24,    84,
     262,   211,   248,   265,   107,   107,   271,    24,   107,   107,
     107,   107,   276,   280,   276,   273,   276,   276,   276,    24,
     105,   108,   249,   103,   106,   254,   249,   259,   249,   249,
     211,     1,   251,   253,   309,   251,   249,   259,   266,   276,
     211,   211,   103,   211,   259,    40,   250,   253,   273,   211,
     249,   211
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   114,   115,   115,   116,   116,   116,   117,   117,   118,
     118,   118,   118,   119,   119,   120,   122,   121,   123,   123,
     123,   123,   123,   123,   123,   124,   124,   124,   124,   124,
     125,   125,   125,   126,   126,   127,   127,   127,   127,   128,
     128,   128,   128,   129,   130,   131,   131,   132,   132,   133,
     133,   134,   135,   135,   136,   137,   137,   139,   140,   138,
     138,   141,   138,   138,   138,   138,   138,   138,   138,   138,
     138,   138,   138,   142,   138,   143,   143,   143,   144,   144,
     144,   145,   146,   147,   147,   148,   148,   148,   149,   149,
     149,   149,   149,   149,   149,   149,   149,   149,   149,   150,
     150,   150,   150,   150,   150,   150,   150,   150,   150,   150,
     151,   151,   151,   151,   151,   151,   151,   151,   151,   151,
     151,   151,   151,   151,   151,   151,   152,   152,   152,   152,
     152,   152,   152,   152,   152,   152,   152,   152,   152,   152,
     152,   152,   152,   152,   152,   152,   152,   152,   152,   153,
     153,   153,   154,   154,   154,   155,   156,   156,   157,   157,
     157,   158,   158,   159,   160,   161,   162,   162,   163,   164,
     165,   166,   166,   167,   167,   168,   168,   169,   169,   169,
     169,   169,   169,   169,   169,   169,   169,   169,   169,   169,
     169,   169,   169,   170,   171,   171,   171,   172,   172,   172,
     173,   173,   174,   174,   174,   174,   175,   176,   177,   176,
     178,   178,   178,   180,   181,   179,   179,   182,   182,   183,
     184,   183,   185,   185,   187,   188,   189,   186,   186,   190,
     190,   191,   191,   192,   191,   191,   191,   191,   193,   193,
     193,   193,   193,   193,   194,   194,   194,   194,   195,   197,
     198,   199,   196,   200,   200,   201,   201,   201,   202,   203,
     203,   204,   204,   205,   205,   205,   206,   206,   207,   207,
     207,   207,   208,   208,   209,   210,   210,   210,   210,   210,
     210,   210,   210,   210,   210,   210,   210,   211,   211,   211,
     211,   211,   211,   211,   211,   211,   213,   212,   214,   214,
     215,   216,   216,   217,   218,   219,   221,   222,   220,   220,
     224,   223,   223,   226,   225,   225,   227,   227,   228,   228,
     228,   229,   229,   230,   230,   232,   231,   231,   231,   234,
     235,   233,   236,   236,   237,   237,   238,   238,   239,   240,
     240,   240,   242,   243,   244,   241,   245,   247,   248,   246,
     249,   249,   249,   250,   250,   251,   251,   252,   252,   252,
     253,   253,   254,   254,   256,   257,   255,   258,   258,   258,
     259,   259,   261,   262,   260,   264,   265,   263,   266,   266,
     268,   269,   267,   270,   270,   270,   271,   271,   271,   271,
     272,   272,   273,   273,   274,   275,   275,   276,   276,   277,
     277,   277,   277,   277,   278,   278,   279,   279,   280,   280,
     280,   280,   280,   280,   280,   280,   280,   280,   281,   281,
     282,   282,   282,   282,   282,   282,   282,   282,   282,   282,
     283,   283,   284,   284,   285,   285,   286,   286,   287,   287,
     287,   288,   288,   289,   289,   289,   289,   289,   289,   289,
     289,   289,   289,   289,   289,   289,   289,   289,   289,   289,
     289,   289,   289,   289,   289,   289,   289,   289,   289,   289,
     289,   289,   289,   289,   289,   289,   289,   289,   289,   289,
     290,   290,   290,   290,   290,   290,   290,   290,   291,   291,
     291,   292,   293,   292,   294,   294,   294,   294,   294,   295,
     296,   296,   296,   296,   296,   296,   296,   296,   296,   296,
     296,   296,   296,   296,   296,   296,   296,   296,   296,   296,
     296,   296,   296,   296,   296,   296,   296,   296,   296,   296,
     296,   296,   296,   296,   296,   296,   296,   296,   296,   296,
     297,   297,   297,   298,   298,   298,   298,   299,   299,   300,
     300,   300,   300,   301,   301,   301,   301,   301,   301,   301,
     301,   301,   301,   301,   301,   301,   302,   302,   302,   302,
     302,   303,   304,   304,   304,   304,   304,   305,   305,   305,
     305,   305,   305,   305,   307,   306,   308,   308,   308,   308,
     308,   308,   308,   308,   308,   308,   308,   308,   308,   309,
     309,   309,   309,   310,   311,   311,   312,   312,   313,   313,
     314,   314,   315,   315,   315,   316,   316,   316,   316,   316,
     316,   316,   316,   316,   316,   316,   316,   316,   316,   316,
     316,   316,   316,   316,   317,   317,   317,   317,   317,   317,
     317,   317,   317,   317,   317,   317,   317,   317,   317,   317,
     317,   317,   317,   317,   317,   317,   317,   317,   317,   317,
     317,   317,   317,   317
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     2,     2,     0,     1,     1,     2,
       2,     2,     0,     1,     1,     1,     0,     2,     5,     5,
       5,     5,     4,     4,     4,     3,     3,     3,     3,     3,
       3,     3,     3,     1,     3,     4,     4,     4,     4,     1,
       1,     1,     1,     1,     1,     1,     0,     1,     0,     1,
       1,     1,     1,     0,     0,     0,     1,     0,     0,    13,
       8,     0,    11,     6,     1,     1,     1,     2,     2,     1,
       2,     2,     2,     0,     5,     1,     1,     0,     1,     1,
       0,     3,     3,     1,     2,     1,     3,     3,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     0,     2,     5,     3,
       1,     0,     2,     0,     3,     3,     1,     1,     1,     1,
       1,     3,     1,     3,     1,     1,     1,     1,     1,     1,
       2,     2,     2,     2,     2,     2,     2,     2,     6,     5,
       2,     4,     4,     1,     0,     1,     2,     0,     1,     2,
       1,     1,     0,     3,     5,     3,     1,     0,     0,     4,
       0,     3,     3,     0,     0,     8,     0,     1,     2,     1,
       0,     4,     3,     0,     0,     0,     0,     8,     0,     1,
       3,     2,     2,     0,     5,     4,     4,     4,     2,     2,
       4,     4,     4,     4,     1,     1,     3,     3,     0,     0,
       0,     0,     7,     1,     1,     1,     1,     1,     0,     1,
       4,     1,     4,     3,     3,     3,     1,     3,     3,     3,
       3,     3,     0,     2,     2,     1,     1,     1,     1,     1,
       1,     2,     2,     2,     2,     2,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     0,     4,     1,     0,
       2,     2,     1,     2,     0,     0,     0,     0,     8,     5,
       0,     5,     3,     0,     6,     4,     5,     4,     1,     3,
       3,     1,     2,     0,     3,     0,     4,     1,     1,     0,
       0,     7,     1,     1,     0,     2,     0,     2,     0,     1,
       4,     1,     0,     0,     0,     8,     5,     0,     0,     9,
       1,     1,     1,     0,     2,     1,     1,     1,     1,     1,
       0,     1,     2,     4,     0,     0,     9,     8,     5,     4,
       1,     1,     0,     0,    12,     0,     0,     8,     0,     1,
       0,     0,     8,     3,     5,     4,     1,     1,     1,     1,
       2,     3,     0,     1,     1,     0,     1,     1,     1,     1,
       2,     2,     2,     2,     1,     3,     1,     2,     1,     3,
       3,     3,     5,     3,     3,     3,     5,     4,     1,     5,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       0,     1,     0,     2,     1,     3,     0,     2,     1,     3,
       3,     3,     3,     1,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       1,     2,     2,     2,     2,     2,     2,     2,     1,     2,
       2,     0,     0,     6,     5,     5,     4,     4,     4,     0,
       1,     1,     1,     1,     1,     1,     1,     1,     2,     2,
       1,     1,     4,     4,     6,     5,     7,     4,     4,     4,
       4,     4,     3,     5,     5,     4,     4,     3,     3,     3,
       3,     4,     4,     4,     4,     4,     4,     4,     4,     4,
       1,     3,     3,     1,     3,     3,     3,     1,     1,     2,
       2,     3,     3,     1,     2,     3,     1,     3,     3,     3,
       3,     2,     2,     2,     2,     2,     0,     1,     2,     1,
       2,     2,     4,     4,     4,     4,     4,     3,     3,     3,
       3,     3,     1,     1,     0,     3,     7,     7,     7,     7,
       7,     5,     5,     5,     5,     4,     4,     4,     4,     1,
       3,     2,     1,     2,     0,     3,     1,     1,     1,     2,
       1,     3,     1,     2,     3,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
/* The lookahead symbol.  */
int yychar;


/* The semantic value of the lookahead symbol.  */
/* Default value used for initialization, for pacifying older GCCs
   or non-GCC compilers.  */
YY_INITIAL_VALUE (static YYSTYPE yyval_default;)
YYSTYPE yylval YY_INITIAL_VALUE (= yyval_default);

    /* Number of syntax errors so far.  */
    int yynerrs;

    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex (&yylval);
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 385 "language.yacc" /* yacc.c:1646  */
    { YYACCEPT; }
#line 3810 "y.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 386 "language.yacc" /* yacc.c:1646  */
    { YYACCEPT; }
#line 3816 "y.tab.c" /* yacc.c:1646  */
    break;

  case 9:
#line 399 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); }
#line 3822 "y.tab.c" /* yacc.c:1646  */
    break;

  case 10:
#line 400 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 3828 "y.tab.c" /* yacc.c:1646  */
    break;

  case 11:
#line 401 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 3834 "y.tab.c" /* yacc.c:1646  */
    break;

  case 12:
#line 402 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 3840 "y.tab.c" /* yacc.c:1646  */
    break;

  case 13:
#line 409 "language.yacc" /* yacc.c:1646  */
    {
    STACK_LEVEL_START(0);

    ref_push_string((yyvsp[0].n)->u.sval.u.string);
    if (call_handle_inherit((yyvsp[0].n)->u.sval.u.string)) {
      STACK_LEVEL_CHECK(2);
      (yyval.n)=mksvaluenode(Pike_sp-1);
      pop_stack();
    }
    else
      (yyval.n)=mknewintnode(0);
    STACK_LEVEL_CHECK(1);
    if((yyval.n)->name) free_string((yyval.n)->name);
#ifdef PIKE_DEBUG
    if (TYPEOF(Pike_sp[-1]) != T_STRING) {
      Pike_fatal("Compiler lost track of program name.\n");
    }
#endif /* PIKE_DEBUG */
    /* FIXME: Why not use $1->u.sval.u.string here? */
    add_ref( (yyval.n)->name=Pike_sp[-1].u.string );
    free_node((yyvsp[0].n));

    STACK_LEVEL_DONE(1);
  }
#line 3869 "y.tab.c" /* yacc.c:1646  */
    break;

  case 14:
#line 434 "language.yacc" /* yacc.c:1646  */
    {
    STACK_LEVEL_START(0);

    if(Pike_compiler->last_identifier)
    {
      ref_push_string(Pike_compiler->last_identifier);
    }else{
      push_empty_string();
    }
    (yyval.n)=(yyvsp[0].n);

    STACK_LEVEL_DONE(1);
  }
#line 3887 "y.tab.c" /* yacc.c:1646  */
    break;

  case 15:
#line 451 "language.yacc" /* yacc.c:1646  */
    {
    STACK_LEVEL_START(0);

    resolv_program((yyvsp[0].n));
    free_node((yyvsp[0].n));

    STACK_LEVEL_DONE(1);
  }
#line 3900 "y.tab.c" /* yacc.c:1646  */
    break;

  case 16:
#line 462 "language.yacc" /* yacc.c:1646  */
    {
    SET_FORCE_RESOLVE((yyval.number));
  }
#line 3908 "y.tab.c" /* yacc.c:1646  */
    break;

  case 17:
#line 466 "language.yacc" /* yacc.c:1646  */
    {
    UNSET_FORCE_RESOLVE((yyvsp[-1].number));
    (yyval.n) = (yyvsp[0].n);
  }
#line 3917 "y.tab.c" /* yacc.c:1646  */
    break;

  case 18:
#line 473 "language.yacc" /* yacc.c:1646  */
    {
    if (((yyvsp[-4].number) & ID_EXTERN) && (Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared inherit.");
    }
    if((yyvsp[-2].n))
    {
      struct pike_string *s=Pike_sp[-1].u.string;
      if((yyvsp[-1].n)) s=(yyvsp[-1].n)->u.sval.u.string;
      compiler_do_inherit((yyvsp[-2].n),(yyvsp[-4].number),s);
    }
    if((yyvsp[-1].n)) free_node((yyvsp[-1].n));
    pop_stack();
    if ((yyvsp[-2].n)) free_node((yyvsp[-2].n));
  }
#line 3936 "y.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 488 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[-2].n)) free_node((yyvsp[-2].n));
    pop_stack();
    yyerrok;
  }
#line 3946 "y.tab.c" /* yacc.c:1646  */
    break;

  case 20:
#line 494 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[-2].n)) free_node((yyvsp[-2].n));
    pop_stack();
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
#line 3957 "y.tab.c" /* yacc.c:1646  */
    break;

  case 21:
#line 501 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[-2].n)) free_node((yyvsp[-2].n));
    pop_stack();
    yyerror("Missing ';'.");
  }
#line 3967 "y.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 506 "language.yacc" /* yacc.c:1646  */
    { yyerrok; }
#line 3973 "y.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 508 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
#line 3982 "y.tab.c" /* yacc.c:1646  */
    break;

  case 24:
#line 512 "language.yacc" /* yacc.c:1646  */
    { yyerror("Missing ';'."); }
#line 3988 "y.tab.c" /* yacc.c:1646  */
    break;

  case 25:
#line 516 "language.yacc" /* yacc.c:1646  */
    {
    resolv_constant((yyvsp[-1].n));
    free_node((yyvsp[-1].n));
    use_module(Pike_sp-1);
    pop_stack();
  }
#line 3999 "y.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 523 "language.yacc" /* yacc.c:1646  */
    {
    if (call_handle_import((yyvsp[-1].n)->u.sval.u.string)) {
      use_module(Pike_sp-1);
      pop_stack();
    }
    free_node((yyvsp[-1].n));
  }
#line 4011 "y.tab.c" /* yacc.c:1646  */
    break;

  case 27:
#line 530 "language.yacc" /* yacc.c:1646  */
    { yyerrok; }
#line 4017 "y.tab.c" /* yacc.c:1646  */
    break;

  case 28:
#line 532 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
#line 4026 "y.tab.c" /* yacc.c:1646  */
    break;

  case 29:
#line 536 "language.yacc" /* yacc.c:1646  */
    { yyerror("Missing ';'."); }
#line 4032 "y.tab.c" /* yacc.c:1646  */
    break;

  case 30:
#line 540 "language.yacc" /* yacc.c:1646  */
    {
    /* This can be made more lenient in the future */

    /* Ugly hack to make sure that $3 is optimized */
    {
      int tmp=Pike_compiler->compiler_pass;
      (yyvsp[0].n)=mknode(F_COMMA_EXPR,(yyvsp[0].n),0);
      Pike_compiler->compiler_pass=tmp;
    }

    if (!TEST_COMPAT(7, 6) && (Pike_compiler->current_modifiers & ID_EXTERN)) {
      int depth = 0;
      struct program_state *state = Pike_compiler;
      node *n = (yyvsp[0].n);
      while (((n->token == F_COMMA_EXPR) || (n->token == F_ARG_LIST)) &&
	     ((!CAR(n)) ^ (!CDR(n)))) {
	if (CAR(n)) n = CAR(n);
	else n = CDR(n);
      }
      if (n->token == F_EXTERNAL) {
	while (state && (state->new_program->id != n->u.integer.a)) {
	  depth++;
	  state = state->previous;
	}
      }
      if (depth && state) {
	/* Alias for a symbol in a surrounding scope. */
	int id = really_low_reference_inherited_identifier(state, 0,
							   n->u.integer.b);
	define_alias((yyvsp[-2].n)->u.sval.u.string, n->type,
		     Pike_compiler->current_modifiers & ~ID_EXTERN,
		     depth, id);
      } else if (Pike_compiler->compiler_pass == 1) {
	yyerror("Invalid extern declared constant.");
	add_constant((yyvsp[-2].n)->u.sval.u.string, &svalue_undefined,
		     Pike_compiler->current_modifiers & ~ID_EXTERN);
      }
    } else {
      if (TEST_COMPAT(7, 6) &&
	  (Pike_compiler->current_modifiers & ID_EXTERN) &&
	  (Pike_compiler->compiler_pass == 1)) {
	yywarning("Extern declared constant.");
      }
      if(!is_const((yyvsp[0].n))) {
	if (Pike_compiler->compiler_pass == 2) {
	  yyerror("Constant definition is not constant.");
	}
	add_constant((yyvsp[-2].n)->u.sval.u.string, 0,
		     Pike_compiler->current_modifiers & ~ID_EXTERN);
      } else {
	if(!Pike_compiler->num_parse_error)
	{
	  ptrdiff_t tmp=eval_low((yyvsp[0].n),1);
	  if(tmp < 1)
	  {
	    yyerror("Error in constant definition.");
	    push_undefined();
	  }else{
	    pop_n_elems(DO_NOT_WARN((INT32)(tmp - 1)));
	  }
	} else {
	  push_undefined();
	}
	add_constant((yyvsp[-2].n)->u.sval.u.string, Pike_sp-1,
		     Pike_compiler->current_modifiers & ~ID_EXTERN);
	pop_stack();
      }
    }
  const_def_ok:
    if((yyvsp[0].n)) free_node((yyvsp[0].n));
    free_node((yyvsp[-2].n));
  }
#line 4109 "y.tab.c" /* yacc.c:1646  */
    break;

  case 31:
#line 612 "language.yacc" /* yacc.c:1646  */
    { if ((yyvsp[0].n)) free_node((yyvsp[0].n)); }
#line 4115 "y.tab.c" /* yacc.c:1646  */
    break;

  case 32:
#line 613 "language.yacc" /* yacc.c:1646  */
    { if ((yyvsp[0].n)) free_node((yyvsp[0].n)); }
#line 4121 "y.tab.c" /* yacc.c:1646  */
    break;

  case 35:
#line 620 "language.yacc" /* yacc.c:1646  */
    {}
#line 4127 "y.tab.c" /* yacc.c:1646  */
    break;

  case 36:
#line 621 "language.yacc" /* yacc.c:1646  */
    { yyerrok; }
#line 4133 "y.tab.c" /* yacc.c:1646  */
    break;

  case 37:
#line 623 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
#line 4142 "y.tab.c" /* yacc.c:1646  */
    break;

  case 38:
#line 627 "language.yacc" /* yacc.c:1646  */
    { yyerror("Missing ';'."); }
#line 4148 "y.tab.c" /* yacc.c:1646  */
    break;

  case 39:
#line 631 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mknode(F_COMMA_EXPR,(yyvsp[0].n),mknode(F_RETURN,mkintnode(0),0));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[0].n));
  }
#line 4157 "y.tab.c" /* yacc.c:1646  */
    break;

  case 40:
#line 635 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = NULL; }
#line 4163 "y.tab.c" /* yacc.c:1646  */
    break;

  case 41:
#line 636 "language.yacc" /* yacc.c:1646  */
    { yyerror("Expected ';'."); (yyval.n) = NULL; }
#line 4169 "y.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 637 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = NULL; }
#line 4175 "y.tab.c" /* yacc.c:1646  */
    break;

  case 43:
#line 642 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
    check_type_string((yyvsp[0].n)->u.sval.u.type);
#endif /* PIKE_DEBUG */
    if(Pike_compiler->compiler_frame->current_type)
      free_type(Pike_compiler->compiler_frame->current_type);
    copy_pike_type(Pike_compiler->compiler_frame->current_type,
		   (yyvsp[0].n)->u.sval.u.type);
    free_node((yyvsp[0].n));
  }
#line 4190 "y.tab.c" /* yacc.c:1646  */
    break;

  case 44:
#line 655 "language.yacc" /* yacc.c:1646  */
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
#line 4199 "y.tab.c" /* yacc.c:1646  */
    break;

  case 45:
#line 662 "language.yacc" /* yacc.c:1646  */
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
#line 4208 "y.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 667 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ')'.");
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
#line 4218 "y.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 676 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing '}'.");
  }
#line 4226 "y.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 683 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing '}'.");
  }
#line 4234 "y.tab.c" /* yacc.c:1646  */
    break;

  case 51:
#line 689 "language.yacc" /* yacc.c:1646  */
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
#line 4243 "y.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 697 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ']'.");
  }
#line 4251 "y.tab.c" /* yacc.c:1646  */
    break;

  case 54:
#line 703 "language.yacc" /* yacc.c:1646  */
    {
    push_compiler_frame(SCOPE_LOCAL);

    if(!Pike_compiler->compiler_frame->previous ||
       !Pike_compiler->compiler_frame->previous->current_type)
    {
      yyerror("Internal compiler error (push_compiler_frame0).");
      copy_pike_type(Pike_compiler->compiler_frame->current_type,
		mixed_type_string);
    }else{
      copy_pike_type(Pike_compiler->compiler_frame->current_type,
		Pike_compiler->compiler_frame->previous->current_type);
    }

    (yyval.ptr) = Pike_compiler->compiler_frame;
  }
#line 4272 "y.tab.c" /* yacc.c:1646  */
    break;

  case 55:
#line 722 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number) = OPT_EXTERNAL_DEPEND|OPT_SIDE_EFFECT;
  }
#line 4280 "y.tab.c" /* yacc.c:1646  */
    break;

  case 56:
#line 726 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number) = 0;
  }
#line 4288 "y.tab.c" /* yacc.c:1646  */
    break;

  case 57:
#line 734 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number) = 0;
    /* Check for the (very special) case of create and create_args. */
    if (Pike_compiler->num_create_args) {
      struct pike_string *create_string = NULL;
      int e;
      MAKE_CONST_STRING(create_string, "create");
      if ((yyvsp[-2].n)->u.sval.u.string == create_string) {
	if (TEST_COMPAT(7, 6)) {
	  yywarning("Having both an implicit and an explicit create() "
		    "was not supported in Pike 7.6 and before.");
	}
	/* Prepend the create arguments. */
	if (Pike_compiler->num_create_args < 0) {
	  Pike_compiler->varargs = 1;
	  for (e = 0; e < -Pike_compiler->num_create_args; e++) {
	    struct identifier *id =
	      Pike_compiler->new_program->identifiers + e;
	    add_ref(id->type);
	    add_local_name(empty_pike_string, id->type, 0);
	    /* Note: add_local_name() above will return e. */
	    Pike_compiler->compiler_frame->variable[e].flags |=
	      LOCAL_VAR_IS_USED;
	  }
	} else {
	  for (e = 0; e < Pike_compiler->num_create_args; e++) {
	    struct identifier *id =
	      Pike_compiler->new_program->identifiers + e;
	    add_ref(id->type);
	    add_local_name(empty_pike_string, id->type, 0);
	    /* Note: add_local_name() above will return e. */
	    Pike_compiler->compiler_frame->variable[e].flags |=
	      LOCAL_VAR_IS_USED;
	  }
	}
	(yyval.number) = e;
      }
    }
  }
#line 4332 "y.tab.c" /* yacc.c:1646  */
    break;

  case 58:
#line 774 "language.yacc" /* yacc.c:1646  */
    {
    int e;

    /* Adjust opt_flags in case we've got an optional_constant. */
    Pike_compiler->compiler_frame->opt_flags = (yyvsp[-7].number);

    /* construct the function type */
    push_finished_type(Pike_compiler->compiler_frame->current_type);

    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    Pike_compiler->compiler_frame->current_return_type = compiler_pop_type();

    push_finished_type(Pike_compiler->compiler_frame->current_return_type);

    e = (yyvsp[-2].number) + (yyvsp[-1].number) - 1;
    if(Pike_compiler->varargs &&
       (!(yyvsp[-2].number) || (Pike_compiler->num_create_args >= 0)))
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    push_type(T_MANY);
    for(; e>=0; e--)
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      push_type(T_FUNCTION);
    }

    if (Pike_compiler->current_attributes) {
      node *n = Pike_compiler->current_attributes;
      while (n) {
	push_type_attribute(CDR(n)->u.sval.u.string);
	n = CAR(n);
      }
    }

    {
      struct pike_type *s=compiler_pop_type();
      int i = isidentifier((yyvsp[-5].n)->u.sval.u.string);

      if (Pike_compiler->compiler_pass != 1) {
	if (i < 0) {
	  my_yyerror("Identifier %S lost after first pass.",
		     (yyvsp[-5].n)->u.sval.u.string);
	}
      }

      (yyval.n) = mktypenode(s);
      free_type(s);
    }


/*    if(Pike_compiler->compiler_pass==1) */
    {
      /* FIXME:
       * set current_function_number for local functions as well
       */
      Pike_compiler->compiler_frame->current_function_number=
	define_function((yyvsp[-5].n)->u.sval.u.string,
			(yyval.n)->u.sval.u.type,
			(yyvsp[-10].number) & (~ID_EXTERN),
			IDENTIFIER_PIKE_FUNCTION |
			(Pike_compiler->varargs?IDENTIFIER_VARARGS:0),
			0,
			(yyvsp[-7].number));

      Pike_compiler->varargs=0;
    }
  }
#line 4410 "y.tab.c" /* yacc.c:1646  */
    break;

  case 59:
#line 848 "language.yacc" /* yacc.c:1646  */
    {
    int e;
    if((yyvsp[0].n))
    {
      int f;
      node *check_args = NULL;
      struct compilation *c = THIS_COMPILATION;
      struct pike_string *save_file = c->lex.current_file;
      int save_line  = c->lex.current_line;
      int num_required_args = 0;
      struct identifier *i;
      c->lex.current_file = (yyvsp[-7].n)->current_file;
      c->lex.current_line = (yyvsp[-7].n)->line_number;

      if (((yyvsp[-12].number) & ID_EXTERN) && (Pike_compiler->compiler_pass == 1)) {
	yywarning("Extern declared function definition.");
      }

      for(e=0; e<(yyvsp[-4].number)+(yyvsp[-3].number); e++)
      {
	if((e >= (yyvsp[-4].number)) &&
	   (!Pike_compiler->compiler_frame->variable[e].name ||
	    !Pike_compiler->compiler_frame->variable[e].name->len))
	{
	  my_yyerror("Missing name for argument %d.", e - (yyvsp[-4].number));
	} else {
	  if (Pike_compiler->compiler_pass == 2) {
	      /* FIXME: Should probably use some other flag. */
	      if ((runtime_options & RUNTIME_CHECK_TYPES) &&
		  (Pike_compiler->compiler_frame->variable[e].type !=
		   mixed_type_string)) {
		node *local_node;

		/* fprintf(stderr, "Creating soft cast node for local #%d\n", e);*/

		local_node = mkcastnode(mixed_type_string, mklocalnode(e, 0));

		/* NOTE: The cast to mixed above is needed to avoid generating
		 *       compilation errors, as well as avoiding optimizations
		 *       in mksoftcastnode().
		 */
		check_args =
		  mknode(F_COMMA_EXPR, check_args,
			 mksoftcastnode(Pike_compiler->compiler_frame->variable[e].type,
					local_node));
	      }
	  }
	}
      }

      if ((yyvsp[-4].number)) {
	/* Hook in the initializers for the create arguments. */
	for (e = (yyvsp[-4].number); e--;) {
	  (yyvsp[0].n) = mknode(F_COMMA_EXPR,
		       mknode(F_POP_VALUE,
			      mknode(F_ASSIGN, mklocalnode(e, 0),
				     mkidentifiernode(e)), NULL),
		       (yyvsp[0].n));
	}
      }

      {
	int l = (yyvsp[0].n)->line_number;
	struct pike_string *f = (yyvsp[0].n)->current_file;
	if (check_args) {
	  /* Prepend the arg checking code. */
	  (yyvsp[0].n) = mknode(F_COMMA_EXPR, mknode(F_POP_VALUE, check_args, NULL), (yyvsp[0].n));
	}
	c->lex.current_line = l;
	c->lex.current_file = f;
      }

      f=dooptcode((yyvsp[-7].n)->u.sval.u.string, (yyvsp[0].n), (yyvsp[-1].n)->u.sval.u.type, (yyvsp[-12].number));

      i = ID_FROM_INT(Pike_compiler->new_program, f);
      i->opt_flags = Pike_compiler->compiler_frame->opt_flags;

#ifdef PIKE_DEBUG
      if(Pike_interpreter.recoveries &&
	 ((Pike_sp - Pike_interpreter.evaluator_stack) <
	  Pike_interpreter.recoveries->stack_pointer))
	Pike_fatal("Stack error (underflow)\n");

      if((Pike_compiler->compiler_pass == 1) &&
	 (f != Pike_compiler->compiler_frame->current_function_number)) {
	fprintf(stderr, "define_function()/do_opt_code() failed for symbol %s\n",
		(yyvsp[-7].n)->u.sval.u.string->str);
	dump_program_desc(Pike_compiler->new_program);
	Pike_fatal("define_function screwed up! %d != %d\n",
	      f, Pike_compiler->compiler_frame->current_function_number);
      }
#endif

      c->lex.current_line = save_line;
      c->lex.current_file = save_file;
    } else {
      /* Prototype; don't warn about unused arguments. */
      for (e = Pike_compiler->compiler_frame->current_number_of_locals; e--;) {
	Pike_compiler->compiler_frame->variable[e].flags |= LOCAL_VAR_IS_USED;
      }
    }
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-6].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-6].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
    free_node((yyvsp[-7].n));
    free_node((yyvsp[-2].n));
    free_node((yyvsp[-1].n));
  }
#line 4529 "y.tab.c" /* yacc.c:1646  */
    break;

  case 60:
#line 965 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-1].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-1].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
    free_node((yyvsp[-2].n));
  }
#line 4546 "y.tab.c" /* yacc.c:1646  */
    break;

  case 61:
#line 978 "language.yacc" /* yacc.c:1646  */
    {
    compiler_discard_type();
  }
#line 4554 "y.tab.c" /* yacc.c:1646  */
    break;

  case 62:
#line 982 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[0].n)) free_node((yyvsp[0].n));
  }
#line 4562 "y.tab.c" /* yacc.c:1646  */
    break;

  case 64:
#line 986 "language.yacc" /* yacc.c:1646  */
    {}
#line 4568 "y.tab.c" /* yacc.c:1646  */
    break;

  case 65:
#line 987 "language.yacc" /* yacc.c:1646  */
    {}
#line 4574 "y.tab.c" /* yacc.c:1646  */
    break;

  case 66:
#line 988 "language.yacc" /* yacc.c:1646  */
    {}
#line 4580 "y.tab.c" /* yacc.c:1646  */
    break;

  case 67:
#line 989 "language.yacc" /* yacc.c:1646  */
    { free_node((yyvsp[0].n)); }
#line 4586 "y.tab.c" /* yacc.c:1646  */
    break;

  case 68:
#line 990 "language.yacc" /* yacc.c:1646  */
    { free_node((yyvsp[0].n)); }
#line 4592 "y.tab.c" /* yacc.c:1646  */
    break;

  case 69:
#line 991 "language.yacc" /* yacc.c:1646  */
    {}
#line 4598 "y.tab.c" /* yacc.c:1646  */
    break;

  case 70:
#line 993 "language.yacc" /* yacc.c:1646  */
    {
    reset_type_stack();
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file");
  }
#line 4608 "y.tab.c" /* yacc.c:1646  */
    break;

  case 71:
#line 999 "language.yacc" /* yacc.c:1646  */
    {
    reset_type_stack();
    yyerrok;
/*     if(Pike_compiler->num_parse_error>5) YYACCEPT; */
  }
#line 4618 "y.tab.c" /* yacc.c:1646  */
    break;

  case 72:
#line 1005 "language.yacc" /* yacc.c:1646  */
    {
    reset_type_stack();
    yyerror("Missing ';'.");
   /* yychar = '}';	*/ /* Put the '}' back on the input stream */
  }
#line 4628 "y.tab.c" /* yacc.c:1646  */
    break;

  case 73:
#line 1012 "language.yacc" /* yacc.c:1646  */
    {
      (yyval.number)=THIS_COMPILATION->lex.pragmas;
      THIS_COMPILATION->lex.pragmas|=(yyvsp[-1].number);
    }
#line 4637 "y.tab.c" /* yacc.c:1646  */
    break;

  case 74:
#line 1018 "language.yacc" /* yacc.c:1646  */
    {
      THIS_COMPILATION->lex.pragmas=(yyvsp[-2].number);
    }
#line 4645 "y.tab.c" /* yacc.c:1646  */
    break;

  case 75:
#line 1023 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=1; }
#line 4651 "y.tab.c" /* yacc.c:1646  */
    break;

  case 76:
#line 1025 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Range indicator ('..') where elipsis ('...') expected.");
    (yyval.number)=1;
  }
#line 4660 "y.tab.c" /* yacc.c:1646  */
    break;

  case 77:
#line 1029 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=0; }
#line 4666 "y.tab.c" /* yacc.c:1646  */
    break;

  case 79:
#line 1033 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 4672 "y.tab.c" /* yacc.c:1646  */
    break;

  case 80:
#line 1034 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 4678 "y.tab.c" /* yacc.c:1646  */
    break;

  case 81:
#line 1038 "language.yacc" /* yacc.c:1646  */
    {
    int i;
    if(Pike_compiler->varargs) yyerror("Can't define more arguments after ...");

    if((yyvsp[-1].number))
    {
      push_type(T_ARRAY);
      Pike_compiler->varargs=1;
    }

    if(!(yyvsp[0].n))
    {
      (yyvsp[0].n)=mkstrnode(empty_pike_string);
    }

    if((yyvsp[0].n)->u.sval.u.string->len &&
       islocal((yyvsp[0].n)->u.sval.u.string) >= 0)
      my_yyerror("Variable %S appears twice in argument list.",
		 (yyvsp[0].n)->u.sval.u.string);

    i = add_local_name((yyvsp[0].n)->u.sval.u.string, compiler_pop_type(),0);
    if (i >= 0) {
      /* Don't warn about unused arguments. */
      Pike_compiler->compiler_frame->variable[i].flags |= LOCAL_VAR_IS_USED;
    }
    free_node((yyvsp[0].n));
  }
#line 4710 "y.tab.c" /* yacc.c:1646  */
    break;

  case 82:
#line 1068 "language.yacc" /* yacc.c:1646  */
    {
    free_node((yyvsp[0].n));
    (yyval.number)=(yyvsp[-1].number);
  }
#line 4719 "y.tab.c" /* yacc.c:1646  */
    break;

  case 83:
#line 1074 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=0; }
#line 4725 "y.tab.c" /* yacc.c:1646  */
    break;

  case 85:
#line 1078 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = 1; }
#line 4731 "y.tab.c" /* yacc.c:1646  */
    break;

  case 86:
#line 1079 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = (yyvsp[-2].number) + 1; }
#line 4737 "y.tab.c" /* yacc.c:1646  */
    break;

  case 87:
#line 1081 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Unexpected ':' in argument list.");
    (yyval.number) = (yyvsp[-2].number) + 1;
  }
#line 4746 "y.tab.c" /* yacc.c:1646  */
    break;

  case 88:
#line 1089 "language.yacc" /* yacc.c:1646  */
    {
      (yyval.number) = ID_FINAL | ID_INLINE;
      if( !(THIS_COMPILATION->lex.pragmas & ID_NO_DEPRECATION_WARNINGS) &&
          !TEST_COMPAT(7, 6) && Pike_compiler->compiler_pass==1 )
        yywarning("Keyword nomask is deprecated in favour of 'final'.");
    }
#line 4757 "y.tab.c" /* yacc.c:1646  */
    break;

  case 89:
#line 1095 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_FINAL | ID_INLINE; }
#line 4763 "y.tab.c" /* yacc.c:1646  */
    break;

  case 90:
#line 1096 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number) = ID_PROTECTED;
    if( !(THIS_COMPILATION->lex.pragmas & ID_NO_DEPRECATION_WARNINGS) &&
        !TEST_COMPAT(7, 8) && Pike_compiler->compiler_pass==1 )
      yywarning("Keyword static is deprecated in favour of 'protected'.");
    }
#line 4774 "y.tab.c" /* yacc.c:1646  */
    break;

  case 91:
#line 1102 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_EXTERN; }
#line 4780 "y.tab.c" /* yacc.c:1646  */
    break;

  case 92:
#line 1103 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_OPTIONAL; }
#line 4786 "y.tab.c" /* yacc.c:1646  */
    break;

  case 93:
#line 1104 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_PRIVATE | ID_PROTECTED; }
#line 4792 "y.tab.c" /* yacc.c:1646  */
    break;

  case 94:
#line 1105 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_INLINE; }
#line 4798 "y.tab.c" /* yacc.c:1646  */
    break;

  case 95:
#line 1106 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_PUBLIC; }
#line 4804 "y.tab.c" /* yacc.c:1646  */
    break;

  case 96:
#line 1107 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_PROTECTED; }
#line 4810 "y.tab.c" /* yacc.c:1646  */
    break;

  case 97:
#line 1108 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_INLINE; }
#line 4816 "y.tab.c" /* yacc.c:1646  */
    break;

  case 98:
#line 1109 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = ID_VARIANT; }
#line 4822 "y.tab.c" /* yacc.c:1646  */
    break;

  case 99:
#line 1113 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "nomask"; }
#line 4828 "y.tab.c" /* yacc.c:1646  */
    break;

  case 100:
#line 1114 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "final"; }
#line 4834 "y.tab.c" /* yacc.c:1646  */
    break;

  case 101:
#line 1115 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "static"; }
#line 4840 "y.tab.c" /* yacc.c:1646  */
    break;

  case 102:
#line 1116 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "extern"; }
#line 4846 "y.tab.c" /* yacc.c:1646  */
    break;

  case 103:
#line 1117 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "private"; }
#line 4852 "y.tab.c" /* yacc.c:1646  */
    break;

  case 104:
#line 1118 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "local"; }
#line 4858 "y.tab.c" /* yacc.c:1646  */
    break;

  case 105:
#line 1119 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "public"; }
#line 4864 "y.tab.c" /* yacc.c:1646  */
    break;

  case 106:
#line 1120 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "protected"; }
#line 4870 "y.tab.c" /* yacc.c:1646  */
    break;

  case 107:
#line 1121 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "inline"; }
#line 4876 "y.tab.c" /* yacc.c:1646  */
    break;

  case 108:
#line 1122 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "optional"; }
#line 4882 "y.tab.c" /* yacc.c:1646  */
    break;

  case 109:
#line 1123 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "variant"; }
#line 4888 "y.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 1127 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "void"; }
#line 4894 "y.tab.c" /* yacc.c:1646  */
    break;

  case 111:
#line 1128 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "mixed"; }
#line 4900 "y.tab.c" /* yacc.c:1646  */
    break;

  case 112:
#line 1129 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "array"; }
#line 4906 "y.tab.c" /* yacc.c:1646  */
    break;

  case 113:
#line 1130 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "__attribute__"; }
#line 4912 "y.tab.c" /* yacc.c:1646  */
    break;

  case 114:
#line 1131 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "__deprecated__"; }
#line 4918 "y.tab.c" /* yacc.c:1646  */
    break;

  case 115:
#line 1132 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "mapping"; }
#line 4924 "y.tab.c" /* yacc.c:1646  */
    break;

  case 116:
#line 1133 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "multiset"; }
#line 4930 "y.tab.c" /* yacc.c:1646  */
    break;

  case 117:
#line 1134 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "object"; }
#line 4936 "y.tab.c" /* yacc.c:1646  */
    break;

  case 118:
#line 1135 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "function"; }
#line 4942 "y.tab.c" /* yacc.c:1646  */
    break;

  case 119:
#line 1136 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "__func__"; }
#line 4948 "y.tab.c" /* yacc.c:1646  */
    break;

  case 120:
#line 1137 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "program"; }
#line 4954 "y.tab.c" /* yacc.c:1646  */
    break;

  case 121:
#line 1138 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "string"; }
#line 4960 "y.tab.c" /* yacc.c:1646  */
    break;

  case 122:
#line 1139 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "float"; }
#line 4966 "y.tab.c" /* yacc.c:1646  */
    break;

  case 123:
#line 1140 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "int"; }
#line 4972 "y.tab.c" /* yacc.c:1646  */
    break;

  case 124:
#line 1141 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "enum"; }
#line 4978 "y.tab.c" /* yacc.c:1646  */
    break;

  case 125:
#line 1142 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "typedef"; }
#line 4984 "y.tab.c" /* yacc.c:1646  */
    break;

  case 126:
#line 1146 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "if"; }
#line 4990 "y.tab.c" /* yacc.c:1646  */
    break;

  case 127:
#line 1147 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "do"; }
#line 4996 "y.tab.c" /* yacc.c:1646  */
    break;

  case 128:
#line 1148 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "for"; }
#line 5002 "y.tab.c" /* yacc.c:1646  */
    break;

  case 129:
#line 1149 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "while"; }
#line 5008 "y.tab.c" /* yacc.c:1646  */
    break;

  case 130:
#line 1150 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "else"; }
#line 5014 "y.tab.c" /* yacc.c:1646  */
    break;

  case 131:
#line 1151 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "foreach"; }
#line 5020 "y.tab.c" /* yacc.c:1646  */
    break;

  case 132:
#line 1152 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "catch"; }
#line 5026 "y.tab.c" /* yacc.c:1646  */
    break;

  case 133:
#line 1153 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "gauge"; }
#line 5032 "y.tab.c" /* yacc.c:1646  */
    break;

  case 134:
#line 1154 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "class"; }
#line 5038 "y.tab.c" /* yacc.c:1646  */
    break;

  case 135:
#line 1155 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "break"; }
#line 5044 "y.tab.c" /* yacc.c:1646  */
    break;

  case 136:
#line 1156 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "case"; }
#line 5050 "y.tab.c" /* yacc.c:1646  */
    break;

  case 137:
#line 1157 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "constant"; }
#line 5056 "y.tab.c" /* yacc.c:1646  */
    break;

  case 138:
#line 1158 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "continue"; }
#line 5062 "y.tab.c" /* yacc.c:1646  */
    break;

  case 139:
#line 1159 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "default"; }
#line 5068 "y.tab.c" /* yacc.c:1646  */
    break;

  case 140:
#line 1160 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "import"; }
#line 5074 "y.tab.c" /* yacc.c:1646  */
    break;

  case 141:
#line 1161 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "inherit"; }
#line 5080 "y.tab.c" /* yacc.c:1646  */
    break;

  case 142:
#line 1162 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "lambda"; }
#line 5086 "y.tab.c" /* yacc.c:1646  */
    break;

  case 143:
#line 1163 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "predef"; }
#line 5092 "y.tab.c" /* yacc.c:1646  */
    break;

  case 144:
#line 1164 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "return"; }
#line 5098 "y.tab.c" /* yacc.c:1646  */
    break;

  case 145:
#line 1165 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "sscanf"; }
#line 5104 "y.tab.c" /* yacc.c:1646  */
    break;

  case 146:
#line 1166 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "switch"; }
#line 5110 "y.tab.c" /* yacc.c:1646  */
    break;

  case 147:
#line 1167 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "typeof"; }
#line 5116 "y.tab.c" /* yacc.c:1646  */
    break;

  case 148:
#line 1168 "language.yacc" /* yacc.c:1646  */
    { (yyval.str) = "global"; }
#line 5122 "y.tab.c" /* yacc.c:1646  */
    break;

  case 154:
#line 1175 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *tmp=make_shared_string((yyvsp[0].str));
    (yyval.n)=mkstrnode(tmp);
    free_string(tmp);
  }
#line 5132 "y.tab.c" /* yacc.c:1646  */
    break;

  case 155:
#line 1183 "language.yacc" /* yacc.c:1646  */
    {
   (yyval.number)=Pike_compiler->current_modifiers=(yyvsp[0].number) |
     (THIS_COMPILATION->lex.pragmas & ID_MODIFIER_MASK);
 }
#line 5141 "y.tab.c" /* yacc.c:1646  */
    break;

  case 156:
#line 1189 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = 0; }
#line 5147 "y.tab.c" /* yacc.c:1646  */
    break;

  case 157:
#line 1190 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = (yyvsp[-1].number) | (yyvsp[0].number); }
#line 5153 "y.tab.c" /* yacc.c:1646  */
    break;

  case 158:
#line 1194 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = (yyvsp[-2].n);
  }
#line 5161 "y.tab.c" /* yacc.c:1646  */
    break;

  case 159:
#line 1198 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *deprecated_string;
    MAKE_CONST_STRING(deprecated_string, "deprecated");
    (yyval.n) = mkstrnode(deprecated_string);
  }
#line 5171 "y.tab.c" /* yacc.c:1646  */
    break;

  case 160:
#line 1204 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *deprecated_string;
    MAKE_CONST_STRING(deprecated_string, "deprecated");
    (yyval.n) = mkstrnode(deprecated_string);
  }
#line 5181 "y.tab.c" /* yacc.c:1646  */
    break;

  case 161:
#line 1212 "language.yacc" /* yacc.c:1646  */
    {
    if (Pike_compiler->current_attributes) {
      free_node(Pike_compiler->current_attributes);
    }
    if ((Pike_compiler->current_attributes =
	 THIS_COMPILATION->lex.attributes)) {
      add_ref(Pike_compiler->current_attributes);
    }
  }
#line 5195 "y.tab.c" /* yacc.c:1646  */
    break;

  case 162:
#line 1222 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[0].n)) {
      Pike_compiler->current_attributes =
	mknode(F_ARG_LIST, Pike_compiler->current_attributes, (yyvsp[0].n));
    }
  }
#line 5206 "y.tab.c" /* yacc.c:1646  */
    break;

  case 163:
#line 1230 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=0; }
#line 5212 "y.tab.c" /* yacc.c:1646  */
    break;

  case 164:
#line 1234 "language.yacc" /* yacc.c:1646  */
    {
      struct pike_type *s = compiler_pop_type();
      (yyval.n) = mktypenode(s);
      free_type(s);
      COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
      free_node ((yyvsp[-2].n));
    }
#line 5224 "y.tab.c" /* yacc.c:1646  */
    break;

  case 165:
#line 1244 "language.yacc" /* yacc.c:1646  */
    {
      struct pike_type *s = compiler_pop_type();
      (yyval.n) = mktypenode(s);
      free_type(s);
      COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
      free_node ((yyvsp[-2].n));
    }
#line 5236 "y.tab.c" /* yacc.c:1646  */
    break;

  case 168:
#line 1256 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *s = compiler_pop_type();
    (yyval.n) = mktypenode(s);
#ifdef PIKE_DEBUG
    if ((yyval.n)->u.sval.u.type != s) {
      Pike_fatal("mktypenode(%p) created node with %p\n", s, (yyval.n)->u.sval.u.type);
    }
#endif /* PIKE_DEBUG */
    free_type(s);
  }
#line 5251 "y.tab.c" /* yacc.c:1646  */
    break;

  case 169:
#line 1269 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *s = compiler_pop_type();
    (yyval.n) = mktypenode(s);
#ifdef PIKE_DEBUG
    if ((yyval.n)->u.sval.u.type != s) {
      Pike_fatal("mktypenode(%p) created node with %p\n", s, (yyval.n)->u.sval.u.type);
    }
#endif /* PIKE_DEBUG */
    free_type(s);
  }
#line 5266 "y.tab.c" /* yacc.c:1646  */
    break;

  case 170:
#line 1282 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *s = compiler_pop_type();
    (yyval.n) = mktypenode(s);
#ifdef PIKE_DEBUG
    if ((yyval.n)->u.sval.u.type != s) {
      Pike_fatal("mktypenode(%p) created node with %p\n", s, (yyval.n)->u.sval.u.type);
    }
#endif /* PIKE_DEBUG */
    free_type(s);
  }
#line 5281 "y.tab.c" /* yacc.c:1646  */
    break;

  case 171:
#line 1294 "language.yacc" /* yacc.c:1646  */
    { push_type(T_OR); }
#line 5287 "y.tab.c" /* yacc.c:1646  */
    break;

  case 173:
#line 1298 "language.yacc" /* yacc.c:1646  */
    { push_type(T_OR); }
#line 5293 "y.tab.c" /* yacc.c:1646  */
    break;

  case 177:
#line 1305 "language.yacc" /* yacc.c:1646  */
    { push_type(T_FLOAT); }
#line 5299 "y.tab.c" /* yacc.c:1646  */
    break;

  case 178:
#line 1306 "language.yacc" /* yacc.c:1646  */
    { push_type(T_VOID); }
#line 5305 "y.tab.c" /* yacc.c:1646  */
    break;

  case 179:
#line 1307 "language.yacc" /* yacc.c:1646  */
    { push_type(T_MIXED); }
#line 5311 "y.tab.c" /* yacc.c:1646  */
    break;

  case 180:
#line 1308 "language.yacc" /* yacc.c:1646  */
    {}
#line 5317 "y.tab.c" /* yacc.c:1646  */
    break;

  case 181:
#line 1309 "language.yacc" /* yacc.c:1646  */
    {}
#line 5323 "y.tab.c" /* yacc.c:1646  */
    break;

  case 182:
#line 1310 "language.yacc" /* yacc.c:1646  */
    {}
#line 5329 "y.tab.c" /* yacc.c:1646  */
    break;

  case 183:
#line 1311 "language.yacc" /* yacc.c:1646  */
    {}
#line 5335 "y.tab.c" /* yacc.c:1646  */
    break;

  case 184:
#line 1312 "language.yacc" /* yacc.c:1646  */
    {}
#line 5341 "y.tab.c" /* yacc.c:1646  */
    break;

  case 185:
#line 1313 "language.yacc" /* yacc.c:1646  */
    { push_type(T_PROGRAM); }
#line 5347 "y.tab.c" /* yacc.c:1646  */
    break;

  case 186:
#line 1314 "language.yacc" /* yacc.c:1646  */
    { push_type(T_ARRAY); }
#line 5353 "y.tab.c" /* yacc.c:1646  */
    break;

  case 187:
#line 1315 "language.yacc" /* yacc.c:1646  */
    { push_type(T_MULTISET); }
#line 5359 "y.tab.c" /* yacc.c:1646  */
    break;

  case 188:
#line 1317 "language.yacc" /* yacc.c:1646  */
    {
    push_type_attribute((yyvsp[-3].n)->u.sval.u.string);
    free_node((yyvsp[-3].n));
  }
#line 5368 "y.tab.c" /* yacc.c:1646  */
    break;

  case 189:
#line 1322 "language.yacc" /* yacc.c:1646  */
    {
    push_type(T_MIXED);
    push_type_attribute((yyvsp[-2].n)->u.sval.u.string);
    free_node((yyvsp[-2].n));
  }
#line 5378 "y.tab.c" /* yacc.c:1646  */
    break;

  case 190:
#line 1328 "language.yacc" /* yacc.c:1646  */
    {
    push_type(T_MIXED);
  }
#line 5386 "y.tab.c" /* yacc.c:1646  */
    break;

  case 191:
#line 1332 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *deprecated_string;
    MAKE_CONST_STRING(deprecated_string, "deprecated");
    push_type_attribute(deprecated_string);
  }
#line 5396 "y.tab.c" /* yacc.c:1646  */
    break;

  case 192:
#line 1338 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *deprecated_string;
    MAKE_CONST_STRING(deprecated_string, "deprecated");
    push_type(T_MIXED);
    push_type_attribute(deprecated_string);
  }
#line 5407 "y.tab.c" /* yacc.c:1646  */
    break;

  case 193:
#line 1347 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[0].n)) {
      fix_type_field((yyvsp[0].n));

      if (!pike_types_le((yyvsp[0].n)->type, typeable_type_string) &&
	  (THIS_COMPILATION->lex.pragmas & ID_STRICT_TYPES)) {
	yytype_report(REPORT_WARNING,
		      (yyvsp[0].n)->current_file, (yyvsp[0].n)->line_number, typeable_type_string,
		      (yyvsp[0].n)->current_file, (yyvsp[0].n)->line_number, (yyvsp[0].n)->type,
		      0, "Invalid type.");
      }
    }

    resolv_constant((yyvsp[0].n));

    if (TYPEOF(Pike_sp[-1]) == T_TYPE) {
      /* "typedef" */
      push_finished_type(Pike_sp[-1].u.type);
    } else {
      /* object type */
      struct program *p = NULL;

      if (TYPEOF(Pike_sp[-1]) == T_OBJECT) {
	if(!(p = Pike_sp[-1].u.object->prog))
	{
	  pop_stack();
	  push_int(0);
	  yyerror("Destructed object used as program identifier.");
	}else{
	  int f = FIND_LFUN(p->inherits[SUBTYPEOF(Pike_sp[-1])].prog,
			    LFUN_CALL);
	  if(f!=-1)
	  {
	    SET_SVAL_SUBTYPE(Pike_sp[-1],
			     f + p->inherits[SUBTYPEOF(Pike_sp[-1])].
			     identifier_level);
	    SET_SVAL_TYPE(Pike_sp[-1], T_FUNCTION);
	  }else{
	    extern void f_object_program(INT32);
	    if (Pike_compiler->compiler_pass == 2)
	      yywarning("Using object as program identifier.");
	    f_object_program(1);
	  }
	}
      }

      switch(TYPEOF(Pike_sp[-1])) {
	case T_FUNCTION:
	if((p = program_from_function(Pike_sp-1))) {
	  push_object_type(0, p?(p->id):0);
	  break;
	} else {
	  /* Attempt to get the return type for the function. */
	  struct pike_type *a, *b;
	  a = get_type_of_svalue(Pike_sp-1);
	  /* Note: check_splice_call() below eats a reference from a.
	   * Note: CALL_INHIBIT_WARNINGS is needed since we don't
	   *       provide a function name (and we don't want
	   *       warnings here anyway).
	   */
	  a = check_splice_call(NULL, a, 0, mixed_type_string, NULL,
				CALL_INHIBIT_WARNINGS);
	  if (a) {
	    b = new_get_return_type(a, 0);
	    free_type(a);
	    if (b) {
	      push_finished_type(b);
	      free_type(b);
	      break;
	    }
	  }
	}
	/* FALL_THROUGH */

      default:
	if (Pike_compiler->compiler_pass!=1)
	  my_yyerror("Illegal program identifier: %O.", Pike_sp-1);
	pop_stack();
	push_int(0);
	push_object_type(0, 0);
	break;

      case T_PROGRAM:
	p = Pike_sp[-1].u.program;
	push_object_type(0, p?(p->id):0);
	break;
      }
    }
    /* Attempt to name the type. */
    if (Pike_compiler->last_identifier) {
      push_type_name(Pike_compiler->last_identifier);
    }
    pop_stack();
    free_node((yyvsp[0].n));
  }
#line 5507 "y.tab.c" /* yacc.c:1646  */
    break;

  case 194:
#line 1445 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mkintnode(MAX_INT_TYPE);
  }
#line 5515 "y.tab.c" /* yacc.c:1646  */
    break;

  case 196:
#line 1450 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
    if (((yyvsp[0].n)->token != F_CONSTANT) || (TYPEOF((yyvsp[0].n)->u.sval) != T_INT)) {
      Pike_fatal("Unexpected number in negative int-range.\n");
    }
#endif /* PIKE_DEBUG */
    (yyval.n) = mkintnode(-((yyvsp[0].n)->u.sval.u.integer));
    free_node((yyvsp[0].n));
  }
#line 5529 "y.tab.c" /* yacc.c:1646  */
    break;

  case 197:
#line 1462 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mkintnode(MIN_INT_TYPE);
  }
#line 5537 "y.tab.c" /* yacc.c:1646  */
    break;

  case 199:
#line 1467 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
    if (((yyvsp[0].n)->token != F_CONSTANT) || (TYPEOF((yyvsp[0].n)->u.sval) != T_INT)) {
      Pike_fatal("Unexpected number in negative int-range.\n");
    }
#endif /* PIKE_DEBUG */
    (yyval.n) = mkintnode(-((yyvsp[0].n)->u.sval.u.integer));
    free_node((yyvsp[0].n));
  }
#line 5551 "y.tab.c" /* yacc.c:1646  */
    break;

  case 201:
#line 1480 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Elipsis ('...') where range indicator ('..') expected.");
  }
#line 5559 "y.tab.c" /* yacc.c:1646  */
    break;

  case 202:
#line 1486 "language.yacc" /* yacc.c:1646  */
    {
    push_int_type(MIN_INT_TYPE, MAX_INT_TYPE);
  }
#line 5567 "y.tab.c" /* yacc.c:1646  */
    break;

  case 203:
#line 1490 "language.yacc" /* yacc.c:1646  */
    {
      push_int_type( 0, (1<<(yyvsp[-1].n)->u.sval.u.integer)-1 );
      free_node( (yyvsp[-1].n) );
  }
#line 5576 "y.tab.c" /* yacc.c:1646  */
    break;

  case 204:
#line 1495 "language.yacc" /* yacc.c:1646  */
    {
    INT_TYPE min = MIN_INT_TYPE;
    INT_TYPE max = MAX_INT_TYPE;

    /* FIXME: Check that $4 is >= $2. */
    if((yyvsp[-1].n)->token == F_CONSTANT) {
      if (TYPEOF((yyvsp[-1].n)->u.sval) == T_INT) {
	max = (yyvsp[-1].n)->u.sval.u.integer;
      } else if (is_bignum_object_in_svalue(&(yyvsp[-1].n)->u.sval)) {
	push_int(0);
	if (is_lt(&(yyvsp[-1].n)->u.sval, Pike_sp-1)) {
	  max = MIN_INT_TYPE;
	}
	pop_stack();
      }
    }

    if((yyvsp[-3].n)->token == F_CONSTANT) {
      if (TYPEOF((yyvsp[-3].n)->u.sval) == T_INT) {
	min = (yyvsp[-3].n)->u.sval.u.integer;
      } else if (is_bignum_object_in_svalue(&(yyvsp[-3].n)->u.sval)) {
	push_int(0);
	if (is_lt(Pike_sp-1, &(yyvsp[-3].n)->u.sval)) {
	  min = MAX_INT_TYPE;
	}
	pop_stack();
      }
    }

    push_int_type(min, max);

    free_node((yyvsp[-3].n));
    free_node((yyvsp[-1].n));
  }
#line 5615 "y.tab.c" /* yacc.c:1646  */
    break;

  case 205:
#line 1530 "language.yacc" /* yacc.c:1646  */
    {
    push_int_type(MIN_INT32, MAX_INT32);
    yyerror("Expected integer range.");
  }
#line 5624 "y.tab.c" /* yacc.c:1646  */
    break;

  case 206:
#line 1537 "language.yacc" /* yacc.c:1646  */
    {
    push_type(T_STRING);
  }
#line 5632 "y.tab.c" /* yacc.c:1646  */
    break;

  case 207:
#line 1542 "language.yacc" /* yacc.c:1646  */
    { push_object_type(0, 0); }
#line 5638 "y.tab.c" /* yacc.c:1646  */
    break;

  case 208:
#line 1543 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
      (yyval.ptr) = Pike_sp;
#endif /* PIKE_DEBUG */
    }
#line 5648 "y.tab.c" /* yacc.c:1646  */
    break;

  case 209:
#line 1549 "language.yacc" /* yacc.c:1646  */
    {
    /* NOTE: On entry, there are two items on the stack:
     *   Pike_sp-2:	Name of the program reference (string).
     *   Pike_sp-1:	The resolved program (program|function|zero).
     */
    struct program *p=program_from_svalue(Pike_sp-1);

#ifdef PIKE_DEBUG
    if ((yyvsp[-3].ptr) != (Pike_sp - 2)) {
      Pike_fatal("Unexpected stack depth: %p != %p\n",
		 (yyvsp[-3].n), Pike_sp-2);
    }
#endif /* PIKE_DEBUG */

    if(!p) {
      if (Pike_compiler->compiler_pass!=1) {
	my_yyerror("Not a valid program specifier: %S", Pike_sp[-2].u.string);
      }
    }
    push_object_type(0, p?(p->id):0);
    /* Attempt to name the type. */
    if (TYPEOF(Pike_sp[-2]) == T_STRING) {
      push_type_name(Pike_sp[-2].u.string);
    }
    pop_n_elems(2);
  }
#line 5679 "y.tab.c" /* yacc.c:1646  */
    break;

  case 210:
#line 1577 "language.yacc" /* yacc.c:1646  */
    { push_object_type(0, 0); }
#line 5685 "y.tab.c" /* yacc.c:1646  */
    break;

  case 212:
#line 1580 "language.yacc" /* yacc.c:1646  */
    {
    push_object_type(0, 0);
    yyerror("Invalid program subtype.");
  }
#line 5694 "y.tab.c" /* yacc.c:1646  */
    break;

  case 213:
#line 1587 "language.yacc" /* yacc.c:1646  */
    {
    type_stack_mark();
  }
#line 5702 "y.tab.c" /* yacc.c:1646  */
    break;

  case 214:
#line 1591 "language.yacc" /* yacc.c:1646  */
    {
    /* Add the many type if there is none. */
    if ((yyvsp[-1].number))
    {
      if (!(yyvsp[-2].number)) {
	/* function_type_list ends with a comma, or is empty.
	 * FIXME: Should this be a syntax error or not?
	 */
	if (Pike_compiler->compiler_pass == 1) {
	  yyerror("Missing type before ... .");
	}
	push_type(T_MIXED);
      }
    }else{
      push_type(T_VOID);
    }
  }
#line 5724 "y.tab.c" /* yacc.c:1646  */
    break;

  case 215:
#line 1609 "language.yacc" /* yacc.c:1646  */
    {
    push_reverse_type(T_MANY);
    Pike_compiler->pike_type_mark_stackp--;
    while (*Pike_compiler->pike_type_mark_stackp+1 <
	   Pike_compiler->type_stackp) {
      push_reverse_type(T_FUNCTION);
    }
  }
#line 5737 "y.tab.c" /* yacc.c:1646  */
    break;

  case 216:
#line 1618 "language.yacc" /* yacc.c:1646  */
    {
   push_type(T_MIXED);
   push_type(T_VOID);
   push_type(T_OR);

   push_type(T_ZERO);
   push_type(T_VOID);
   push_type(T_OR);

   push_type(T_MANY);
  }
#line 5753 "y.tab.c" /* yacc.c:1646  */
    break;

  case 217:
#line 1631 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=0; }
#line 5759 "y.tab.c" /* yacc.c:1646  */
    break;

  case 218:
#line 1632 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=!(yyvsp[0].number); }
#line 5765 "y.tab.c" /* yacc.c:1646  */
    break;

  case 219:
#line 1635 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=1; }
#line 5771 "y.tab.c" /* yacc.c:1646  */
    break;

  case 220:
#line 1637 "language.yacc" /* yacc.c:1646  */
    {
  }
#line 5778 "y.tab.c" /* yacc.c:1646  */
    break;

  case 223:
#line 1643 "language.yacc" /* yacc.c:1646  */
    { push_type(T_MIXED); }
#line 5784 "y.tab.c" /* yacc.c:1646  */
    break;

  case 224:
#line 1647 "language.yacc" /* yacc.c:1646  */
    {
  }
#line 5791 "y.tab.c" /* yacc.c:1646  */
    break;

  case 225:
#line 1650 "language.yacc" /* yacc.c:1646  */
    {
  }
#line 5798 "y.tab.c" /* yacc.c:1646  */
    break;

  case 226:
#line 1653 "language.yacc" /* yacc.c:1646  */
    {
    push_reverse_type(T_MAPPING);
  }
#line 5806 "y.tab.c" /* yacc.c:1646  */
    break;

  case 228:
#line 1658 "language.yacc" /* yacc.c:1646  */
    {
    push_type(T_MIXED);
    push_type(T_MIXED);
    push_type(T_MAPPING);
  }
#line 5816 "y.tab.c" /* yacc.c:1646  */
    break;

  case 231:
#line 1671 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *type;
    node *n;
    push_finished_type(Pike_compiler->compiler_frame->current_type);
    n = Pike_compiler->current_attributes;
    while(n) {
      push_type_attribute(CDR(n)->u.sval.u.string);
      n = CAR(n);
    }
    type=compiler_pop_type();
    define_variable((yyvsp[0].n)->u.sval.u.string, type,
		    Pike_compiler->current_modifiers);
    free_type(type);
    free_node((yyvsp[0].n));
  }
#line 5836 "y.tab.c" /* yacc.c:1646  */
    break;

  case 232:
#line 1686 "language.yacc" /* yacc.c:1646  */
    {}
#line 5842 "y.tab.c" /* yacc.c:1646  */
    break;

  case 233:
#line 1688 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *type;
    node *n;
    push_finished_type(Pike_compiler->compiler_frame->current_type);
    n = Pike_compiler->current_attributes;
    while(n) {
      push_type_attribute(CDR(n)->u.sval.u.string);
      n = CAR(n);
    }
    type=compiler_pop_type();
    if ((Pike_compiler->current_modifiers & ID_EXTERN) &&
	(Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared variable has initializer.");
    }
    (yyval.number)=define_variable((yyvsp[-1].n)->u.sval.u.string, type,
			       Pike_compiler->current_modifiers & (~ID_EXTERN));
    free_type(type);
  }
#line 5865 "y.tab.c" /* yacc.c:1646  */
    break;

  case 234:
#line 1707 "language.yacc" /* yacc.c:1646  */
    {
    if ((Pike_compiler->compiler_pass == 2) &&
	!TEST_COMPAT(7, 8) && ((yyvsp[0].n)) && ((yyvsp[0].n)->token == F_CONSTANT) &&
	!Pike_compiler->num_parse_error) {
      /* Check if it is zero, in which case we can throw it away.
       *
       * NB: The compat test is due to that this changes the semantics
       *     of calling __INIT() by hand.
       */
      if ((TYPEOF((yyvsp[0].n)->u.sval) == PIKE_T_INT) && !SUBTYPEOF((yyvsp[0].n)->u.sval) &&
	  !(yyvsp[0].n)->u.sval.u.integer &&
	  !IDENTIFIER_IS_ALIAS(ID_FROM_INT(Pike_compiler->new_program,
					   (yyvsp[-1].number))->identifier_flags)) {
	/* NB: Inherited variables get converted into aliases by
	 *     define_variable, and we need to support clearing
	 *     of inherited variables.
	 */
#ifdef PIKE_DEBUG
	if (l_flag > 5) {
	  fprintf(stderr,
		  "Ignoring initialization to zero for variable %s.\n",
		  (yyvsp[-3].n)->u.sval.u.string->str);
	}
#endif /* PIKE_DEBUG */
	free_node((yyvsp[0].n));
	(yyvsp[0].n) = NULL;
      }
    }
    if ((yyvsp[0].n)) {
      Pike_compiler->init_node=mknode(F_COMMA_EXPR,Pike_compiler->init_node,
		       mkcastnode(void_type_string,
				  mknode(F_ASSIGN,(yyvsp[0].n),
					 mkidentifiernode((yyvsp[-1].number)))));
    }
    free_node((yyvsp[-3].n));
  }
#line 5906 "y.tab.c" /* yacc.c:1646  */
    break;

  case 235:
#line 1744 "language.yacc" /* yacc.c:1646  */
    {
    free_node((yyvsp[-2].n));
  }
#line 5914 "y.tab.c" /* yacc.c:1646  */
    break;

  case 236:
#line 1748 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Unexpected end of file in variable definition.");
    free_node((yyvsp[-2].n));
  }
#line 5923 "y.tab.c" /* yacc.c:1646  */
    break;

  case 237:
#line 1753 "language.yacc" /* yacc.c:1646  */
    {
    free_node((yyvsp[0].n));
  }
#line 5931 "y.tab.c" /* yacc.c:1646  */
    break;

  case 238:
#line 1760 "language.yacc" /* yacc.c:1646  */
    {
    int id;
    push_finished_type((yyvsp[-2].n)->u.sval.u.type);
    id = add_local_name((yyvsp[0].n)->u.sval.u.string, compiler_pop_type(),0);
    if (id >= 0) {
      /* FIXME: Consider using mklocalnode(id, -1). */
      (yyval.n)=mknode(F_ASSIGN,mkintnode(0),mklocalnode(id,0));
    } else
      (yyval.n) = 0;
    free_node((yyvsp[0].n));
  }
#line 5947 "y.tab.c" /* yacc.c:1646  */
    break;

  case 239:
#line 1771 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 5953 "y.tab.c" /* yacc.c:1646  */
    break;

  case 240:
#line 1773 "language.yacc" /* yacc.c:1646  */
    {
    int id;
    push_finished_type((yyvsp[-4].n)->u.sval.u.type);
    id = add_local_name((yyvsp[-2].n)->u.sval.u.string, compiler_pop_type(),0);
    if (id >= 0) {
      if (!(THIS_COMPILATION->lex.pragmas & ID_STRICT_TYPES)) {
	/* Only warn about unused initialized variables in strict types mode. */
	Pike_compiler->compiler_frame->variable[id].flags |= LOCAL_VAR_IS_USED;
      }
      (yyval.n)=mknode(F_ASSIGN,(yyvsp[0].n),mklocalnode(id,0));
    } else
      (yyval.n) = 0;
    free_node((yyvsp[-2].n));
  }
#line 5972 "y.tab.c" /* yacc.c:1646  */
    break;

  case 241:
#line 1788 "language.yacc" /* yacc.c:1646  */
    {
    free_node((yyvsp[0].n));
    (yyval.n)=0;
  }
#line 5981 "y.tab.c" /* yacc.c:1646  */
    break;

  case 242:
#line 1793 "language.yacc" /* yacc.c:1646  */
    {
    free_node((yyvsp[-2].n));
    /* No yyerok here since we aren't done yet. */
    (yyval.n)=0;
  }
#line 5991 "y.tab.c" /* yacc.c:1646  */
    break;

  case 243:
#line 1799 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Unexpected end of file in local variable definition.");
    free_node((yyvsp[-2].n));
    /* No yyerok here since we aren't done yet. */
    (yyval.n)=0;
  }
#line 6002 "y.tab.c" /* yacc.c:1646  */
    break;

  case 244:
#line 1808 "language.yacc" /* yacc.c:1646  */
    {
    int id;
    add_ref((yyvsp[-1].n)->u.sval.u.type);
    id = add_local_name((yyvsp[0].n)->u.sval.u.string, (yyvsp[-1].n)->u.sval.u.type, 0);
    if (id >= 0) {
      /* FIXME: Consider using mklocalnode(id, -1). */
      (yyval.n)=mknode(F_ASSIGN,mkintnode(0),mklocalnode(id,0));
    } else
      (yyval.n) = 0;
    free_node((yyvsp[0].n));
  }
#line 6018 "y.tab.c" /* yacc.c:1646  */
    break;

  case 245:
#line 1819 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 6024 "y.tab.c" /* yacc.c:1646  */
    break;

  case 246:
#line 1821 "language.yacc" /* yacc.c:1646  */
    {
    int id;
    add_ref((yyvsp[-3].n)->u.sval.u.type);
    id = add_local_name((yyvsp[-2].n)->u.sval.u.string, (yyvsp[-3].n)->u.sval.u.type, 0);
    if (id >= 0) {
      if (!(THIS_COMPILATION->lex.pragmas & ID_STRICT_TYPES)) {
	/* Only warn about unused initialized variables in strict types mode. */
	Pike_compiler->compiler_frame->variable[id].flags |= LOCAL_VAR_IS_USED;
      }
      (yyval.n)=mknode(F_ASSIGN,(yyvsp[0].n), mklocalnode(id,0));
    } else
      (yyval.n) = 0;
    free_node((yyvsp[-2].n));
  }
#line 6043 "y.tab.c" /* yacc.c:1646  */
    break;

  case 247:
#line 1835 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); }
#line 6049 "y.tab.c" /* yacc.c:1646  */
    break;

  case 248:
#line 1839 "language.yacc" /* yacc.c:1646  */
    {
    /* Used to hold line-number info */
    (yyval.n) = mkintnode(0);
  }
#line 6058 "y.tab.c" /* yacc.c:1646  */
    break;

  case 249:
#line 1846 "language.yacc" /* yacc.c:1646  */
    {
    (yyvsp[0].number)=Pike_compiler->num_used_modules;
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
#line 6067 "y.tab.c" /* yacc.c:1646  */
    break;

  case 250:
#line 1851 "language.yacc" /* yacc.c:1646  */
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;

    if((yyval.number) == -1) /* if 'first block' */
      Pike_compiler->compiler_frame->last_block_level=0; /* all variables */
    else
      Pike_compiler->compiler_frame->last_block_level=(yyvsp[-1].number);
  }
#line 6081 "y.tab.c" /* yacc.c:1646  */
    break;

  case 251:
#line 1860 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.ptr) = Pike_compiler;
  }
#line 6089 "y.tab.c" /* yacc.c:1646  */
    break;

  case 252:
#line 1864 "language.yacc" /* yacc.c:1646  */
    {
    /* Recover compilation context on syntax errors. */
    while (Pike_compiler != (yyvsp[-2].ptr)) {
      struct program *p;
      /* fprintf(stderr, "Compiler context out of sync. Attempting to recover...\n"); */
      if(Pike_compiler->compiler_pass == 1)
	p = end_first_pass(0);
      else
	p=end_first_pass(1);

      if (p) free_program(p);
    }

    unuse_modules(Pike_compiler->num_used_modules - (yyvsp[-6].number));
    (yyvsp[-1].n) = pop_local_variables((yyvsp[-5].number), (yyvsp[-1].n));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-3].number);
    if ((yyvsp[-1].n)) COPY_LINE_NUMBER_INFO((yyvsp[-1].n), (yyvsp[-4].n));
    free_node ((yyvsp[-4].n));
    (yyval.n)=(yyvsp[-1].n);
  }
#line 6114 "y.tab.c" /* yacc.c:1646  */
    break;

  case 254:
#line 1889 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing '}'.");
    if ((yyvsp[-1].n)) {
      low_yyreport(REPORT_ERROR, (yyvsp[-1].n)->current_file, (yyvsp[-1].n)->line_number,
		   parser_system_string, 0, "Opening '{' was here.");
    }
    yyerror("Unexpected end of file.");
  }
#line 6127 "y.tab.c" /* yacc.c:1646  */
    break;

  case 256:
#line 1900 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 6133 "y.tab.c" /* yacc.c:1646  */
    break;

  case 257:
#line 1901 "language.yacc" /* yacc.c:1646  */
    { yyerror("Unexpected end of file."); (yyval.n)=0; }
#line 6139 "y.tab.c" /* yacc.c:1646  */
    break;

  case 258:
#line 1906 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = (yyvsp[(-2) - (0)].n);
  }
#line 6147 "y.tab.c" /* yacc.c:1646  */
    break;

  case 260:
#line 1914 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[-3].n)), (yyvsp[0].n)); }
#line 6153 "y.tab.c" /* yacc.c:1646  */
    break;

  case 262:
#line 1920 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[-3].n)), (yyvsp[0].n)); }
#line 6159 "y.tab.c" /* yacc.c:1646  */
    break;

  case 263:
#line 1925 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *type;

    /* Ugly hack to make sure that $3 is optimized */
    {
      int tmp=Pike_compiler->compiler_pass;
      (yyvsp[0].n)=mknode(F_COMMA_EXPR,(yyvsp[0].n),0);
      optimize_node((yyvsp[0].n));
      Pike_compiler->compiler_pass=tmp;
      type=(yyvsp[0].n)->u.node.a->type;
    }

    if(!is_const((yyvsp[0].n)))
    {
      if(Pike_compiler->compiler_pass==2)
	yyerror("Constant definition is not constant.");
    }else{
      ptrdiff_t tmp=eval_low((yyvsp[0].n),1);
      if(tmp < 1)
      {
	yyerror("Error in constant definition.");
      }else{
	pop_n_elems(DO_NOT_WARN((INT32)(tmp - 1)));
	if((yyvsp[0].n)) free_node((yyvsp[0].n));
	(yyvsp[0].n)=mksvaluenode(Pike_sp-1);
	type=(yyvsp[0].n)->type;
	pop_stack();
      }
    }
    if(!type) type = mixed_type_string;
    add_ref(type);
    low_add_local_name(Pike_compiler->compiler_frame, /*->previous,*/
		       (yyvsp[-2].n)->u.sval.u.string,
		       type, (yyvsp[0].n));
    /* Note: Intentionally not marked as used. */
    free_node((yyvsp[-2].n));
  }
#line 6201 "y.tab.c" /* yacc.c:1646  */
    break;

  case 264:
#line 1962 "language.yacc" /* yacc.c:1646  */
    { if ((yyvsp[0].n)) free_node((yyvsp[0].n)); }
#line 6207 "y.tab.c" /* yacc.c:1646  */
    break;

  case 265:
#line 1963 "language.yacc" /* yacc.c:1646  */
    { if ((yyvsp[0].n)) free_node((yyvsp[0].n)); }
#line 6213 "y.tab.c" /* yacc.c:1646  */
    break;

  case 269:
#line 1971 "language.yacc" /* yacc.c:1646  */
    { yyerrok; }
#line 6219 "y.tab.c" /* yacc.c:1646  */
    break;

  case 270:
#line 1973 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
#line 6228 "y.tab.c" /* yacc.c:1646  */
    break;

  case 271:
#line 1977 "language.yacc" /* yacc.c:1646  */
    { yyerror("Missing ';'."); }
#line 6234 "y.tab.c" /* yacc.c:1646  */
    break;

  case 272:
#line 1981 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 6240 "y.tab.c" /* yacc.c:1646  */
    break;

  case 273:
#line 1983 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mknode(F_COMMA_EXPR, (yyvsp[-1].n), mkcastnode(void_type_string, (yyvsp[0].n)));
  }
#line 6248 "y.tab.c" /* yacc.c:1646  */
    break;

  case 276:
#line 1991 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 6254 "y.tab.c" /* yacc.c:1646  */
    break;

  case 279:
#line 1994 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 6260 "y.tab.c" /* yacc.c:1646  */
    break;

  case 283:
#line 1998 "language.yacc" /* yacc.c:1646  */
    { reset_type_stack(); (yyval.n)=0; yyerrok; }
#line 6266 "y.tab.c" /* yacc.c:1646  */
    break;

  case 284:
#line 2000 "language.yacc" /* yacc.c:1646  */
    {
    reset_type_stack();
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
    (yyval.n)=0;
  }
#line 6277 "y.tab.c" /* yacc.c:1646  */
    break;

  case 285:
#line 2007 "language.yacc" /* yacc.c:1646  */
    {
    reset_type_stack();
    yyerror("Missing ';'.");
/*    yychar = '}'; */	/* Put the '}' back on the input stream. */
    (yyval.n)=0;
  }
#line 6288 "y.tab.c" /* yacc.c:1646  */
    break;

  case 286:
#line 2013 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 6294 "y.tab.c" /* yacc.c:1646  */
    break;

  case 287:
#line 2017 "language.yacc" /* yacc.c:1646  */
    {
    Pike_compiler->compiler_frame->opt_flags &= ~OPT_CUSTOM_LABELS;
  }
#line 6302 "y.tab.c" /* yacc.c:1646  */
    break;

  case 296:
#line 2031 "language.yacc" /* yacc.c:1646  */
    {
    Pike_compiler->compiler_frame->opt_flags &= ~OPT_CUSTOM_LABELS;
  }
#line 6310 "y.tab.c" /* yacc.c:1646  */
    break;

  case 297:
#line 2035 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mknode(Pike_compiler->compiler_frame->opt_flags & OPT_CUSTOM_LABELS ?
		F_CUSTOM_STMT_LABEL : F_NORMAL_STMT_LABEL,
		(yyvsp[-3].n), (yyvsp[0].n));

    /* FIXME: This won't be correct if the node happens to be shared.
     * That's an issue to be solved with shared nodes in general,
     * though. */
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-3].n));
  }
#line 6325 "y.tab.c" /* yacc.c:1646  */
    break;

  case 299:
#line 2048 "language.yacc" /* yacc.c:1646  */
    {(yyval.n) = 0;}
#line 6331 "y.tab.c" /* yacc.c:1646  */
    break;

  case 300:
#line 2051 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_BREAK,(yyvsp[0].n),0); }
#line 6337 "y.tab.c" /* yacc.c:1646  */
    break;

  case 301:
#line 2052 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_DEFAULT,0,0); }
#line 6343 "y.tab.c" /* yacc.c:1646  */
    break;

  case 302:
#line 2054 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_DEFAULT,0,0); yyerror("Expected ':' after default.");
  }
#line 6351 "y.tab.c" /* yacc.c:1646  */
    break;

  case 303:
#line 2059 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_CONTINUE,(yyvsp[0].n),0); }
#line 6357 "y.tab.c" /* yacc.c:1646  */
    break;

  case 304:
#line 2062 "language.yacc" /* yacc.c:1646  */
    {
    push_compiler_frame(SCOPE_LOCAL);

    (yyval.ptr) = Pike_compiler->compiler_frame;
  }
#line 6367 "y.tab.c" /* yacc.c:1646  */
    break;

  case 305:
#line 2070 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *name;
    (yyval.n)=mkstrnode(name = get_new_name(NULL));
    free_string(name);
  }
#line 6377 "y.tab.c" /* yacc.c:1646  */
    break;

  case 306:
#line 2078 "language.yacc" /* yacc.c:1646  */
    {
    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);
    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    copy_pike_type(Pike_compiler->compiler_frame->current_return_type,
		   any_type_string);
  }
#line 6389 "y.tab.c" /* yacc.c:1646  */
    break;

  case 307:
#line 2086 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *name = (yyvsp[-3].n)->u.sval.u.string;
    struct pike_type *type;
    int e;

    (yyval.number) = Pike_compiler->varargs;
    Pike_compiler->varargs = 0;

    if (Pike_compiler->compiler_pass == 1) {
      /* Define a tentative prototype for the lambda. */
      push_finished_type(mixed_type_string);
      e=(yyvsp[0].number)-1;
      if((yyval.number))
      {
	push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
	e--;
	pop_type_stack(T_ARRAY);
      }else{
	push_type(T_VOID);
      }
      Pike_compiler->varargs=0;
      push_type(T_MANY);
      for(; e>=0; e--) {
	push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
	push_type(T_FUNCTION);
      }
      type=compiler_pop_type();
      Pike_compiler->compiler_frame->current_function_number =
	define_function(name, type,
			ID_PROTECTED | ID_PRIVATE | ID_INLINE | ID_USED,
			IDENTIFIER_PIKE_FUNCTION, NULL,
			(unsigned INT16)
			(Pike_compiler->compiler_frame->opt_flags));
      free_type(type);
    } else {
      /* In pass 2 we just reuse the type from pass 1. */
      Pike_compiler->compiler_frame->current_function_number =
	isidentifier(name);
    }
  }
#line 6434 "y.tab.c" /* yacc.c:1646  */
    break;

  case 308:
#line 2127 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *type;
    int f,e;
    struct pike_string *name;
    struct compilation *c = THIS_COMPILATION;
    struct pike_string *save_file = c->lex.current_file;
    int save_line = c->lex.current_line;
    c->lex.current_file = (yyvsp[-6].n)->current_file;
    c->lex.current_line = (yyvsp[-6].n)->line_number;

    debug_malloc_touch((yyvsp[0].n));
    (yyvsp[0].n)=mknode(F_COMMA_EXPR,(yyvsp[0].n),mknode(F_RETURN,mkintnode(0),0));
    if (Pike_compiler->compiler_pass == 2) {
      /* Doing this in pass 1 might induce too strict checks on types
       * in cases where we got placeholders. */
      type=find_return_type((yyvsp[0].n));
      if (type) {
	push_finished_type(type);
	free_type(type);
      } else {
	yywarning("Failed to determine return type for lambda.");
	push_type(T_ZERO);
      }
    } else {
      /* Tentative return type. */
      push_type(T_MIXED);
    }

    e=(yyvsp[-2].number)-1;
    if((yyvsp[-1].number))
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    Pike_compiler->varargs=0;
    push_type(T_MANY);
    for(; e>=0; e--) {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      push_type(T_FUNCTION);
    }

    type=compiler_pop_type();

    name = (yyvsp[-5].n)->u.sval.u.string;

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: LAMBDA: %s 0x%08lx 0x%08lx\n%d:   type: ",
	    Pike_compiler->compiler_pass, name->str,
	    (long)Pike_compiler->new_program->id,
	    Pike_compiler->local_class_counter-1,
	    Pike_compiler->compiler_pass);
    simple_describe_type(type);
    fprintf(stderr, "\n");
#endif /* LAMBDA_DEBUG */

    f=dooptcode(name,
		(yyvsp[0].n),
		type,
		ID_PROTECTED | ID_PRIVATE | ID_INLINE | ID_USED);

#ifdef PIKE_DEBUG
    if (f != Pike_compiler->compiler_frame->current_function_number) {
      Pike_fatal("Lost track of lambda %s.\n", name->str);
    }
#endif /* PIKE_DEBUG */

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d:   lexical_scope: 0x%08x\n",
	    Pike_compiler->compiler_pass,
	    Pike_compiler->compiler_frame->lexical_scope);
#endif /* LAMBDA_DEBUG */

    if(Pike_compiler->compiler_frame->lexical_scope & SCOPE_SCOPED) {
      (yyval.n) = mktrampolinenode(f, Pike_compiler->compiler_frame->previous);
    } else {
      (yyval.n) = mkidentifiernode(f);
    }
    free_type(type);
    c->lex.current_line = save_line;
    c->lex.current_file = save_file;
    free_node((yyvsp[-5].n));
    free_node ((yyvsp[-6].n));
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-4].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-4].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
  }
#line 6534 "y.tab.c" /* yacc.c:1646  */
    break;

  case 309:
#line 2223 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-1].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-1].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
    (yyval.n) = mkintnode(0);
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-3].n));
    free_node((yyvsp[-2].n));
    free_node((yyvsp[-3].n));
  }
#line 6554 "y.tab.c" /* yacc.c:1646  */
    break;

  case 310:
#line 2241 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *name;
    struct pike_type *type;
    int id,e;
    node *n;
    struct identifier *i=0;

    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);
    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    copy_pike_type(Pike_compiler->compiler_frame->current_return_type,
		   (yyvsp[-3].n)->u.sval.u.type);


    /***/
    push_finished_type(Pike_compiler->compiler_frame->current_return_type);

    e=(yyvsp[0].number)-1;
    if(Pike_compiler->varargs)
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    push_type(T_MANY);
    for(; e>=0; e--) {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
    push_type(T_FUNCTION);
    }

    type=compiler_pop_type();
    /***/

    name = get_new_name((yyvsp[-2].n)->u.sval.u.string);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: LAMBDA: %s 0x%08lx 0x%08lx\n",
	    Pike_compiler->compiler_pass, name->str,
	    (long)Pike_compiler->new_program->id,
	    Pike_compiler->local_class_counter-1);
#endif /* LAMBDA_DEBUG */

    if(Pike_compiler->compiler_pass > 1)
    {
      id=isidentifier(name);
    }else{
      id=define_function(name,
			 type,
			 ID_PROTECTED | ID_PRIVATE | ID_INLINE | ID_USED,
			 IDENTIFIER_PIKE_FUNCTION |
			 (Pike_compiler->varargs?IDENTIFIER_VARARGS:0),
			 0,
			 OPT_SIDE_EFFECT|OPT_EXTERNAL_DEPEND);
    }
    Pike_compiler->varargs=0;
    Pike_compiler->compiler_frame->current_function_number=id;

    n=0;
    if(Pike_compiler->compiler_pass > 1 &&
       (i=ID_FROM_INT(Pike_compiler->new_program, id)))
    {
      if(i->identifier_flags & IDENTIFIER_SCOPED)
	n = mktrampolinenode(id, Pike_compiler->compiler_frame->previous);
      else
	n = mkidentifiernode(id);
    }

    low_add_local_name(Pike_compiler->compiler_frame->previous,
		       (yyvsp[-2].n)->u.sval.u.string, type, n);

    (yyval.number)=id;
    free_string(name);
  }
#line 6634 "y.tab.c" /* yacc.c:1646  */
    break;

  case 311:
#line 2317 "language.yacc" /* yacc.c:1646  */
    {
    int localid;
    struct identifier *i=ID_FROM_INT(Pike_compiler->new_program, (yyvsp[-1].number));
    struct compilation *c = THIS_COMPILATION;
    struct pike_string *save_file = c->lex.current_file;
    int save_line = c->lex.current_line;
    c->lex.current_file = (yyvsp[-4].n)->current_file;
    c->lex.current_line = (yyvsp[-4].n)->line_number;

    (yyvsp[0].n)=mknode(F_COMMA_EXPR,(yyvsp[0].n),mknode(F_RETURN,mkintnode(0),0));

    debug_malloc_touch((yyvsp[0].n));
    dooptcode(i->name,
	      (yyvsp[0].n),
	      i->type,
	      ID_PROTECTED | ID_PRIVATE | ID_INLINE);

    i->opt_flags = Pike_compiler->compiler_frame->opt_flags;

    c->lex.current_line = save_line;
    c->lex.current_file = save_file;
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-3].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-3].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
    free_node((yyvsp[-4].n));

    /* WARNING: If the local function adds more variables we are screwed */
    /* WARNING2: if add_local_name stops adding local variables at the end,
     *           this has to be fixed.
     */

    localid=Pike_compiler->compiler_frame->current_number_of_locals-1;
    if(Pike_compiler->compiler_frame->variable[localid].def)
    {
      (yyval.n)=copy_node(Pike_compiler->compiler_frame->variable[localid].def);
    }else{
      if(Pike_compiler->compiler_frame->lexical_scope &
	 (SCOPE_SCOPE_USED | SCOPE_SCOPED))
      {
	(yyval.n) = mktrampolinenode((yyvsp[-1].number),Pike_compiler->compiler_frame);
      }else{
	(yyval.n) = mkidentifiernode((yyvsp[-1].number));
      }
    }
  }
#line 6690 "y.tab.c" /* yacc.c:1646  */
    break;

  case 312:
#line 2369 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-1].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-1].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
    (yyval.n)=mkintnode(0);
  }
#line 6707 "y.tab.c" /* yacc.c:1646  */
    break;

  case 313:
#line 2384 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *name;
    struct pike_type *type;
    int id,e;
    node *n;
    struct identifier *i=0;

    /***/
    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);

    push_finished_type((yyvsp[-4].n)->u.sval.u.type);

    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    Pike_compiler->compiler_frame->current_return_type=compiler_pop_type();

    /***/
    push_finished_type(Pike_compiler->compiler_frame->current_return_type);

    e=(yyvsp[0].number)-1;
    if(Pike_compiler->varargs)
    {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      e--;
      pop_type_stack(T_ARRAY);
    }else{
      push_type(T_VOID);
    }
    push_type(T_MANY);
    for(; e>=0; e--) {
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
      push_type(T_FUNCTION);
    }

    type=compiler_pop_type();
    /***/

    name = get_new_name((yyvsp[-2].n)->u.sval.u.string);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: LAMBDA: %s 0x%08lx 0x%08lx\n",
	    Pike_compiler->compiler_pass, name->str,
	    (long)Pike_compiler->new_program->id,
	    Pike_compiler->local_class_counter-1);
#endif /* LAMBDA_DEBUG */

    if(Pike_compiler->compiler_pass > 1)
    {
      id=isidentifier(name);
    }else{
      id=define_function(name,
			 type,
			 ID_PROTECTED | ID_PRIVATE | ID_INLINE | ID_USED,
			 IDENTIFIER_PIKE_FUNCTION|
			 (Pike_compiler->varargs?IDENTIFIER_VARARGS:0),
			 0,
			 OPT_SIDE_EFFECT|OPT_EXTERNAL_DEPEND);
    }
    Pike_compiler->varargs=0;
    Pike_compiler->compiler_frame->current_function_number=id;

    n=0;
    if(Pike_compiler->compiler_pass > 1 &&
       (i=ID_FROM_INT(Pike_compiler->new_program, id)))
    {
      if(i->identifier_flags & IDENTIFIER_SCOPED)
	n = mktrampolinenode(id, Pike_compiler->compiler_frame->previous);
      else
	n = mkidentifiernode(id);
    }

    low_add_local_name(Pike_compiler->compiler_frame->previous,
		       (yyvsp[-2].n)->u.sval.u.string, type, n);
    (yyval.number)=id;
    free_string(name);
  }
#line 6788 "y.tab.c" /* yacc.c:1646  */
    break;

  case 314:
#line 2461 "language.yacc" /* yacc.c:1646  */
    {
    int localid;
    struct identifier *i=ID_FROM_INT(Pike_compiler->new_program, (yyvsp[-1].number));
    struct compilation *c = THIS_COMPILATION;
    struct pike_string *save_file = c->lex.current_file;
    int save_line = c->lex.current_line;
    c->lex.current_file = (yyvsp[-4].n)->current_file;
    c->lex.current_line = (yyvsp[-4].n)->line_number;

    debug_malloc_touch((yyvsp[0].n));
    (yyvsp[0].n)=mknode(F_COMMA_EXPR,(yyvsp[0].n),mknode(F_RETURN,mkintnode(0),0));


    debug_malloc_touch((yyvsp[0].n));
    dooptcode(i->name,
	      (yyvsp[0].n),
	      i->type,
	      ID_PROTECTED | ID_PRIVATE | ID_INLINE);

    i->opt_flags = Pike_compiler->compiler_frame->opt_flags;

    c->lex.current_line = save_line;
    c->lex.current_file = save_file;
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-3].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-3].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
    free_node((yyvsp[-4].n));

    /* WARNING: If the local function adds more variables we are screwed */
    /* WARNING2: if add_local_name stops adding local variables at the end,
     *           this has to be fixed.
     */

    localid=Pike_compiler->compiler_frame->current_number_of_locals-1;
    if(Pike_compiler->compiler_frame->variable[localid].def)
    {
      (yyval.n)=copy_node(Pike_compiler->compiler_frame->variable[localid].def);
    }else{
      if(Pike_compiler->compiler_frame->lexical_scope &
	 (SCOPE_SCOPE_USED | SCOPE_SCOPED))
      {
        (yyval.n) = mktrampolinenode((yyvsp[-1].number),Pike_compiler->compiler_frame);
      }else{
        (yyval.n) = mkidentifiernode((yyvsp[-1].number));
      }
    }
  }
#line 6846 "y.tab.c" /* yacc.c:1646  */
    break;

  case 315:
#line 2515 "language.yacc" /* yacc.c:1646  */
    {
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-1].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-1].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
    free_node((yyvsp[-2].n));
    (yyval.n)=mkintnode(0);
  }
#line 6864 "y.tab.c" /* yacc.c:1646  */
    break;

  case 316:
#line 2531 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *type;
    int ref_no;

    if (Pike_compiler->num_create_args < 0) {
      yyerror("Can't define more variables after ...");
    }

    push_finished_type(Pike_compiler->compiler_frame->current_type);
    if ((yyvsp[-1].number)) {
      push_type(T_ARRAY);
    }
    type=compiler_pop_type();

    /* Add the identifier globally.
     * Note: Since these are the first identifiers (and references)
     *       to be added to the program, they will be numbered in
     *       sequence starting at 0 (zero). This means that the
     *       counter num_create_args is sufficient extra information
     *       to be able to keep track of them.
     */
    ref_no = define_variable((yyvsp[0].n)->u.sval.u.string, type,
			     Pike_compiler->current_modifiers);
    free_type(type);

    if (Pike_compiler->num_create_args != ref_no) {
      my_yyerror("Multiple definitions of create variable %S (%d != %d).",
		 (yyvsp[0].n)->u.sval.u.string,
		 Pike_compiler->num_create_args, ref_no);
    }
    if ((yyvsp[-1].number)) {
      /* Encode varargs marker as negative number of args. */
      Pike_compiler->num_create_args = -(ref_no + 1);
    } else {
      Pike_compiler->num_create_args = ref_no + 1;
    }

    /* free_type(type); */
    free_node((yyvsp[0].n));
    (yyval.number)=0;
  }
#line 6910 "y.tab.c" /* yacc.c:1646  */
    break;

  case 317:
#line 2572 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=0; }
#line 6916 "y.tab.c" /* yacc.c:1646  */
    break;

  case 318:
#line 2575 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = 1; }
#line 6922 "y.tab.c" /* yacc.c:1646  */
    break;

  case 319:
#line 2576 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = (yyvsp[-2].number) + 1; }
#line 6928 "y.tab.c" /* yacc.c:1646  */
    break;

  case 320:
#line 2578 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Unexpected ':' in create argument list.");
    (yyval.number) = (yyvsp[-2].number) + 1;
  }
#line 6937 "y.tab.c" /* yacc.c:1646  */
    break;

  case 321:
#line 2584 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=0; }
#line 6943 "y.tab.c" /* yacc.c:1646  */
    break;

  case 323:
#line 2588 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = 0; }
#line 6949 "y.tab.c" /* yacc.c:1646  */
    break;

  case 324:
#line 2590 "language.yacc" /* yacc.c:1646  */
    {
    /* NOTE: One more than the number of arguments, so that we
<     *       can detect the case of no parenthesis below. */
    (yyval.number) = (yyvsp[-1].number) + 1;
    free_node((yyvsp[0].n));
  }
#line 6960 "y.tab.c" /* yacc.c:1646  */
    break;

  case 325:
#line 2598 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = NULL; }
#line 6966 "y.tab.c" /* yacc.c:1646  */
    break;

  case 327:
#line 2599 "language.yacc" /* yacc.c:1646  */
    { yyerrok; }
#line 6972 "y.tab.c" /* yacc.c:1646  */
    break;

  case 328:
#line 2601 "language.yacc" /* yacc.c:1646  */
    {
		  yyerror("End of file where program definition expected.");
		}
#line 6980 "y.tab.c" /* yacc.c:1646  */
    break;

  case 329:
#line 2608 "language.yacc" /* yacc.c:1646  */
    {
    if(!(yyvsp[0].n))
    {
      struct pike_string *s;
      char buffer[42];
      sprintf(buffer,"__class_%ld_%ld_line_%d",
	      (long)Pike_compiler->new_program->id,
	      (long)Pike_compiler->local_class_counter++,
	      (int) (yyvsp[-1].n)->line_number);
      s=make_shared_string(buffer);
      (yyvsp[0].n)=mkstrnode(s);
      free_string(s);
      (yyvsp[-3].number)|=ID_PROTECTED | ID_PRIVATE | ID_INLINE;
    }
    /* fprintf(stderr, "LANGUAGE.YACC: CLASS start\n"); */
    if(Pike_compiler->compiler_pass==1)
    {
      if ((yyvsp[-3].number) & ID_EXTERN) {
	yywarning("Extern declared class definition.");
      }
      low_start_new_program(0, 1, (yyvsp[0].n)->u.sval.u.string,
			    (yyvsp[-3].number),
			    &(yyval.number));

      /* fprintf(stderr, "Pass 1: Program %s has id %d\n",
	 $4->u.sval.u.string->str, Pike_compiler->new_program->id); */

      store_linenumber((yyvsp[-1].n)->line_number, (yyvsp[-1].n)->current_file);
      debug_malloc_name(Pike_compiler->new_program,
			(yyvsp[-1].n)->current_file->str,
			(yyvsp[-1].n)->line_number);
    }else{
      int i;
      struct identifier *id;
      int tmp=Pike_compiler->compiler_pass;
      i=isidentifier((yyvsp[0].n)->u.sval.u.string);
      if(i<0)
      {
	/* Seriously broken... */
	yyerror("Pass 2: program not defined!");
	low_start_new_program(0, 2, 0,
			      (yyvsp[-3].number),
			      &(yyval.number));
      }else{
	id=ID_FROM_INT(Pike_compiler->new_program, i);
	if(IDENTIFIER_IS_CONSTANT(id->identifier_flags))
	{
	  struct svalue *s;
	  if ((id->func.const_info.offset >= 0) &&
	      (TYPEOF(*(s = &PROG_FROM_INT(Pike_compiler->new_program,i)->
			constants[id->func.const_info.offset].sval)) ==
	       T_PROGRAM))
	  {
	    low_start_new_program(s->u.program, 2,
				  (yyvsp[0].n)->u.sval.u.string,
				  (yyvsp[-3].number),
				  &(yyval.number));

	    /* fprintf(stderr, "Pass 2: Program %s has id %d\n",
	       $4->u.sval.u.string->str, Pike_compiler->new_program->id); */

	  }else{
	    yyerror("Pass 2: constant redefined!");
	    low_start_new_program(0, 2, 0,
				  (yyvsp[-3].number),
				  &(yyval.number));
	  }
	}else{
	  yyerror("Pass 2: class constant no longer constant!");
	  low_start_new_program(0, 2, 0,
				(yyvsp[-3].number),
				&(yyval.number));
	}
      }
      Pike_compiler->compiler_pass=tmp;
    }
  }
#line 7062 "y.tab.c" /* yacc.c:1646  */
    break;

  case 330:
#line 2685 "language.yacc" /* yacc.c:1646  */
    {
    /* Clear scoped modifiers. */
    (yyval.number) = THIS_COMPILATION->lex.pragmas;
    THIS_COMPILATION->lex.pragmas &= ~ID_MODIFIER_MASK;
  }
#line 7072 "y.tab.c" /* yacc.c:1646  */
    break;

  case 331:
#line 2691 "language.yacc" /* yacc.c:1646  */
    {
    struct program *p;

    /* Check if we have create arguments but no locally defined create(). */
    if ((yyvsp[-1].number)) {
      struct pike_string *create_string = NULL;
      struct reference *ref = NULL;
      struct identifier *id = NULL;
      int ref_id;
      MAKE_CONST_STRING(create_string, "create");
      if (((ref_id = isidentifier(create_string)) < 0) ||
	  (ref = PTR_FROM_INT(Pike_compiler->new_program, ref_id))->inherit_offset ||
	  ((id = ID_FROM_PTR(Pike_compiler->new_program, ref))->func.offset == -1)) {
	int e;
	struct pike_type *type = NULL;
	int nargs = Pike_compiler->num_create_args;

	push_compiler_frame(SCOPE_LOCAL);

	/* Init: Prepend the create arguments. */
	if (Pike_compiler->num_create_args < 0) {
	  for (e = 0; e < -Pike_compiler->num_create_args; e++) {
	    id = Pike_compiler->new_program->identifiers + e;
	    add_ref(id->type);
	    add_local_name(id->name, id->type, 0);
	    /* Note: add_local_name() above will return e. */
	    Pike_compiler->compiler_frame->variable[e].flags |=
	      LOCAL_VAR_IS_USED;
	  }
	} else {
	  for (e = 0; e < Pike_compiler->num_create_args; e++) {
	    id = Pike_compiler->new_program->identifiers + e;
	    add_ref(id->type);
	    add_local_name(id->name, id->type, 0);
	    /* Note: add_local_name() above will return e. */
	    Pike_compiler->compiler_frame->variable[e].flags |=
	      LOCAL_VAR_IS_USED;
	  }
	}

	/* First: Deduce the type for the create() function. */
	push_type(T_VOID); /* Return type. */

	if ((e = nargs) < 0) {
	  /* Varargs */
	  e = nargs = -nargs;
	  push_finished_type(Pike_compiler->compiler_frame->variable[--e].type);
	  pop_type_stack(T_ARRAY); /* Pop one level of array. */
	} else {
	  /* Not varargs. */
	  push_type(T_VOID);
	}
	push_type(T_MANY);
	while(e--) {
	  push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
	  push_type(T_FUNCTION);
	}

	type = compiler_pop_type();

	/* Second: Declare the function. */

	Pike_compiler->compiler_frame->current_function_number=
	  define_function(create_string, type,
			  ID_INLINE | ID_PROTECTED,
			  IDENTIFIER_PIKE_FUNCTION |
			  (Pike_compiler->num_create_args < 0?IDENTIFIER_VARARGS:0),
			  0,
			  OPT_SIDE_EFFECT);

	if (Pike_compiler->compiler_pass == 2) {
	  node *create_code = NULL;
	  int f;

	  /* Third: Generate the initialization code.
	   *
	   * global_arg = [type]local_arg;
	   * [,..]
	   */

	  for(e=0; e<nargs; e++)
	  {
	    if(!Pike_compiler->compiler_frame->variable[e].name ||
	       !Pike_compiler->compiler_frame->variable[e].name->len)
	    {
	      my_yyerror("Missing name for argument %d.",e);
	    } else {
	      node *local_node = mklocalnode(e, 0);

	      /* FIXME: Should probably use some other flag. */
	      if ((runtime_options & RUNTIME_CHECK_TYPES) &&
		  (Pike_compiler->compiler_pass == 2) &&
		  (Pike_compiler->compiler_frame->variable[e].type !=
		   mixed_type_string)) {
		/* fprintf(stderr, "Creating soft cast node for local #%d\n", e);*/

		local_node = mkcastnode(mixed_type_string, local_node);

		/* NOTE: The cast to mixed above is needed to avoid generating
		 *       compilation errors, as well as avoiding optimizations
		 *       in mksoftcastnode().
		 */
		local_node = mksoftcastnode(Pike_compiler->compiler_frame->
					    variable[e].type, local_node);
	      }
	      create_code =
		mknode(F_COMMA_EXPR, create_code,
		       mknode(F_ASSIGN, local_node,
			      mkidentifiernode(e)));
	    }
	  }

	  /* Fourth: Add a return 0; at the end. */

	  create_code = mknode(F_COMMA_EXPR,
			       mknode(F_POP_VALUE, create_code, NULL),
			       mknode(F_RETURN, mkintnode(0), NULL));

	  /* Fifth: Define the function. */

	  f=dooptcode(create_string, create_code, type, ID_PROTECTED);

#ifdef PIKE_DEBUG
	  if(Pike_interpreter.recoveries &&
	     Pike_sp-Pike_interpreter.evaluator_stack < Pike_interpreter.recoveries->stack_pointer)
	    Pike_fatal("Stack error (underflow)\n");

	  if(Pike_compiler->compiler_pass == 1 &&
	     f!=Pike_compiler->compiler_frame->current_function_number)
	    Pike_fatal("define_function screwed up! %d != %d\n",
		       f, Pike_compiler->compiler_frame->current_function_number);
#endif
	}

	/* Done. */

	free_type(type);
	pop_compiler_frame();
      }
    }

    if(Pike_compiler->compiler_pass == 1)
      p=end_first_pass(0);
    else
      p=end_first_pass(1);

    /* fprintf(stderr, "LANGUAGE.YACC: CLASS end\n"); */

    if(p) {
      /* Update the type for the program constant,
       * since we might have a lfun::create(). */
      struct identifier *i;
      struct svalue sv;
      SET_SVAL(sv, T_PROGRAM, 0, program, p);
      i = ID_FROM_INT(Pike_compiler->new_program, (yyvsp[-3].number));
      free_type(i->type);
      i->type = get_type_of_svalue(&sv);
      free_program(p);
    } else if (!Pike_compiler->num_parse_error) {
      /* Make sure code in this class is aware that something went wrong. */
      Pike_compiler->num_parse_error = 1;
    }

    (yyval.n)=mkidentifiernode((yyvsp[-3].number));

    free_node((yyvsp[-5].n));
    free_node((yyvsp[-4].n));
    check_tree((yyval.n),0);
    THIS_COMPILATION->lex.pragmas = (yyvsp[-2].number);
  }
#line 7247 "y.tab.c" /* yacc.c:1646  */
    break;

  case 333:
#line 2864 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = 0; }
#line 7253 "y.tab.c" /* yacc.c:1646  */
    break;

  case 334:
#line 2867 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = 0; }
#line 7259 "y.tab.c" /* yacc.c:1646  */
    break;

  case 335:
#line 2868 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = (yyvsp[0].n); }
#line 7265 "y.tab.c" /* yacc.c:1646  */
    break;

  case 337:
#line 2874 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[-1].n)) {
      if ((yyvsp[0].n)) {
	/* Explicit enum value. */

	/* This can be made more lenient in the future */

	/* Ugly hack to make sure that $2 is optimized */
	{
	  int tmp=Pike_compiler->compiler_pass;
	  (yyvsp[0].n)=mknode(F_COMMA_EXPR,(yyvsp[0].n),0);
	  Pike_compiler->compiler_pass=tmp;
	}

	if(!is_const((yyvsp[0].n)))
	{
	  if(Pike_compiler->compiler_pass==2)
	    yyerror("Enum definition is not constant.");
	  push_int(0);
	} else {
	  if(!Pike_compiler->num_parse_error)
	  {
	    ptrdiff_t tmp=eval_low((yyvsp[0].n),1);
	    if(tmp < 1)
	    {
	      yyerror("Error in enum definition.");
	      push_int(0);
	    }else{
	      pop_n_elems(DO_NOT_WARN((INT32)(tmp - 1)));
	    }
	  } else {
	    push_int(0);
	  }
	}
	free_node((yyvsp[0].n));
	free_node((yyvsp[-2].n));
	(yyvsp[-2].n) = mkconstantsvaluenode(Pike_sp-1);
      } else {
	/* Implicit enum value. */
	(yyvsp[-2].n) = safe_inc_enum((yyvsp[-2].n));
	push_svalue(&(yyvsp[-2].n)->u.sval);
      }
      add_constant((yyvsp[-1].n)->u.sval.u.string, Pike_sp-1,
		   (Pike_compiler->current_modifiers & ~ID_EXTERN) | ID_INLINE);
      /* Update the type. */
      {
	struct pike_type *current = pop_unfinished_type();
	struct pike_type *new = get_type_of_svalue(Pike_sp-1);
	struct pike_type *res = or_pike_types(new, current, 3);
	free_type(current);
	free_type(new);
	type_stack_mark();
	push_finished_type(res);
	free_type(res);
      }
      pop_stack();
      free_node((yyvsp[-1].n));
    } else if ((yyvsp[0].n)) {
      free_node((yyvsp[0].n));
    }
  }
#line 7331 "y.tab.c" /* yacc.c:1646  */
    break;

  case 338:
#line 2939 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = (yyvsp[(-2) - (0)].n);
  }
#line 7339 "y.tab.c" /* yacc.c:1646  */
    break;

  case 340:
#line 2946 "language.yacc" /* yacc.c:1646  */
    { (yyvsp[-4].n) = (yyvsp[-1].n); }
#line 7345 "y.tab.c" /* yacc.c:1646  */
    break;

  case 342:
#line 2952 "language.yacc" /* yacc.c:1646  */
    {
    if ((Pike_compiler->current_modifiers & ID_EXTERN) &&
	(Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared enum.");
    }

    type_stack_mark();
    push_type(T_ZERO);	/* Joined type so far. */
  }
#line 7359 "y.tab.c" /* yacc.c:1646  */
    break;

  case 343:
#line 2962 "language.yacc" /* yacc.c:1646  */
    {
    push_int(-1);	/* Previous value. */
    (yyval.n) = mkconstantsvaluenode(Pike_sp-1);
    pop_stack();
  }
#line 7369 "y.tab.c" /* yacc.c:1646  */
    break;

  case 344:
#line 2967 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = NULL; }
#line 7375 "y.tab.c" /* yacc.c:1646  */
    break;

  case 345:
#line 2968 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *t = pop_unfinished_type();
    free_node((yyvsp[-3].n));
    if ((yyvsp[-5].n)) {
      ref_push_type_value(t);
      add_constant((yyvsp[-5].n)->u.sval.u.string, Pike_sp-1,
		   (Pike_compiler->current_modifiers & ~ID_EXTERN) | ID_INLINE);
      pop_stack();
      free_node((yyvsp[-5].n));
    }
    (yyval.n) = mktypenode(t);
    free_type(t);
  }
#line 7393 "y.tab.c" /* yacc.c:1646  */
    break;

  case 346:
#line 2984 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *t = compiler_pop_type();

    if ((Pike_compiler->current_modifiers & ID_EXTERN) &&
	(Pike_compiler->compiler_pass == 1)) {
      yywarning("Extern declared typedef.");
    }

    if ((yyvsp[-1].n)) {
      ref_push_type_value(t);
      add_constant((yyvsp[-1].n)->u.sval.u.string, Pike_sp-1,
		   (Pike_compiler->current_modifiers & ~ID_EXTERN) | ID_INLINE);
      pop_stack();
      free_node((yyvsp[-1].n));
    }
    free_type(t);
  }
#line 7415 "y.tab.c" /* yacc.c:1646  */
    break;

  case 347:
#line 3004 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
#line 7423 "y.tab.c" /* yacc.c:1646  */
    break;

  case 348:
#line 3008 "language.yacc" /* yacc.c:1646  */
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-1].number);
  }
#line 7433 "y.tab.c" /* yacc.c:1646  */
    break;

  case 349:
#line 3014 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mknode('?', (yyvsp[-3].n),
		mknode(':',
		       mkcastnode(void_type_string, (yyvsp[-1].n)),
		       mkcastnode(void_type_string, (yyvsp[0].n))));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-6].n));
    (yyval.n) = mkcastnode(void_type_string, (yyval.n));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-6].n));
    free_node ((yyvsp[-6].n));
    (yyval.n) = pop_local_variables((yyvsp[-7].number), (yyval.n));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-5].number);
  }
#line 7450 "y.tab.c" /* yacc.c:1646  */
    break;

  case 351:
#line 3029 "language.yacc" /* yacc.c:1646  */
    { yyerror("Missing ')'."); }
#line 7456 "y.tab.c" /* yacc.c:1646  */
    break;

  case 352:
#line 3031 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
#line 7465 "y.tab.c" /* yacc.c:1646  */
    break;

  case 353:
#line 3037 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7471 "y.tab.c" /* yacc.c:1646  */
    break;

  case 354:
#line 3038 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); }
#line 7477 "y.tab.c" /* yacc.c:1646  */
    break;

  case 355:
#line 3042 "language.yacc" /* yacc.c:1646  */
    {
    if (!(THIS_COMPILATION->lex.pragmas & ID_STRICT_TYPES) && (yyvsp[0].n)) {
      if ((yyvsp[0].n)->token == F_ARRAY_LVALUE) {
	mark_lvalues_as_used(CAR((yyvsp[0].n)));
      } else if (((yyvsp[0].n)->token == F_LOCAL) && !((yyvsp[0].n)->u.integer.b)) {
	Pike_compiler->compiler_frame->variable[(yyvsp[0].n)->u.integer.a].flags |=
	  LOCAL_VAR_IS_USED;
      }
    }
  }
#line 7492 "y.tab.c" /* yacc.c:1646  */
    break;

  case 356:
#line 3052 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7498 "y.tab.c" /* yacc.c:1646  */
    break;

  case 358:
#line 3056 "language.yacc" /* yacc.c:1646  */
    { yyerror("Unexpected end of file."); (yyval.n)=0; }
#line 7504 "y.tab.c" /* yacc.c:1646  */
    break;

  case 359:
#line 3057 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7510 "y.tab.c" /* yacc.c:1646  */
    break;

  case 360:
#line 3061 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7516 "y.tab.c" /* yacc.c:1646  */
    break;

  case 362:
#line 3065 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); }
#line 7522 "y.tab.c" /* yacc.c:1646  */
    break;

  case 363:
#line 3067 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(':',(yyvsp[-2].n),(yyvsp[0].n)); }
#line 7528 "y.tab.c" /* yacc.c:1646  */
    break;

  case 364:
#line 3071 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
#line 7536 "y.tab.c" /* yacc.c:1646  */
    break;

  case 365:
#line 3075 "language.yacc" /* yacc.c:1646  */
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-1].number);
  }
#line 7546 "y.tab.c" /* yacc.c:1646  */
    break;

  case 366:
#line 3081 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[-2].n)) {
      (yyval.n)=mknode(F_FOREACH,
		mknode(F_VAL_LVAL,(yyvsp[-3].n),(yyvsp[-2].n)),
		(yyvsp[0].n));
    } else {
      /* Error in lvalue */
      (yyval.n)=mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[-3].n)), (yyvsp[0].n));
    }
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-6].n));
    free_node ((yyvsp[-6].n));
    (yyval.n) = pop_local_variables((yyvsp[-7].number), (yyval.n));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-5].number);
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
#line 7566 "y.tab.c" /* yacc.c:1646  */
    break;

  case 367:
#line 3100 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_DO,(yyvsp[-5].n),(yyvsp[-2].n));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-6].n));
    free_node ((yyvsp[-6].n));
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
#line 7577 "y.tab.c" /* yacc.c:1646  */
    break;

  case 368:
#line 3107 "language.yacc" /* yacc.c:1646  */
    {
    free_node ((yyvsp[-3].n));
    (yyval.n)=0;
    yyerror("Missing '(' in do-while loop.");
    yyerror("Unexpected end of file.");
  }
#line 7588 "y.tab.c" /* yacc.c:1646  */
    break;

  case 369:
#line 3114 "language.yacc" /* yacc.c:1646  */
    {
    free_node ((yyvsp[-2].n));
    (yyval.n)=0;
    yyerror("Missing 'while' in do-while loop.");
    yyerror("Unexpected end of file.");
  }
#line 7599 "y.tab.c" /* yacc.c:1646  */
    break;

  case 371:
#line 3124 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ';'.");
    yyerror("Unexpected end of file.");
  }
#line 7608 "y.tab.c" /* yacc.c:1646  */
    break;

  case 372:
#line 3131 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
#line 7616 "y.tab.c" /* yacc.c:1646  */
    break;

  case 373:
#line 3135 "language.yacc" /* yacc.c:1646  */
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-1].number);
  }
#line 7626 "y.tab.c" /* yacc.c:1646  */
    break;

  case 374:
#line 3142 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[-6].n)),
	      mknode(F_FOR,(yyvsp[-4].n),mknode(':',(yyvsp[0].n),(yyvsp[-2].n))));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-9].n));
    free_node ((yyvsp[-9].n));
    (yyval.n) = pop_local_variables((yyvsp[-10].number), (yyval.n));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-8].number);
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
#line 7640 "y.tab.c" /* yacc.c:1646  */
    break;

  case 375:
#line 3155 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
#line 7648 "y.tab.c" /* yacc.c:1646  */
    break;

  case 376:
#line 3159 "language.yacc" /* yacc.c:1646  */
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-1].number);
  }
#line 7658 "y.tab.c" /* yacc.c:1646  */
    break;

  case 377:
#line 3165 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_FOR,(yyvsp[-2].n),mknode(':',(yyvsp[0].n),NULL));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-5].n));
    free_node ((yyvsp[-5].n));
    (yyval.n) = pop_local_variables((yyvsp[-6].number), (yyval.n));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-4].number);
    Pike_compiler->compiler_frame->opt_flags |= OPT_CUSTOM_LABELS;
  }
#line 7671 "y.tab.c" /* yacc.c:1646  */
    break;

  case 378:
#line 3175 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkintnode(1); }
#line 7677 "y.tab.c" /* yacc.c:1646  */
    break;

  case 380:
#line 3180 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
#line 7685 "y.tab.c" /* yacc.c:1646  */
    break;

  case 381:
#line 3184 "language.yacc" /* yacc.c:1646  */
    {
    /* Trick to store more than one number on compiler stack - Hubbe */
    (yyval.number)=Pike_compiler->compiler_frame->last_block_level;
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-1].number);
  }
#line 7695 "y.tab.c" /* yacc.c:1646  */
    break;

  case 382:
#line 3190 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_SWITCH,(yyvsp[-2].n),(yyvsp[0].n));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-5].n));
    free_node ((yyvsp[-5].n));
    (yyval.n) = pop_local_variables((yyvsp[-6].number), (yyval.n));
    Pike_compiler->compiler_frame->last_block_level=(yyvsp[-4].number);
  }
#line 7707 "y.tab.c" /* yacc.c:1646  */
    break;

  case 383:
#line 3200 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_CASE,(yyvsp[-1].n),0);
  }
#line 7715 "y.tab.c" /* yacc.c:1646  */
    break;

  case 384:
#line 3204 "language.yacc" /* yacc.c:1646  */
    {
     (yyval.n)=mknode(F_CASE_RANGE,(yyvsp[-3].n),(yyvsp[-1].n));
  }
#line 7723 "y.tab.c" /* yacc.c:1646  */
    break;

  case 385:
#line 3208 "language.yacc" /* yacc.c:1646  */
    {
     (yyval.n)=mknode(F_CASE_RANGE,0,(yyvsp[-1].n));
  }
#line 7731 "y.tab.c" /* yacc.c:1646  */
    break;

  case 387:
#line 3215 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ':'.");
  }
#line 7739 "y.tab.c" /* yacc.c:1646  */
    break;

  case 388:
#line 3219 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ':'.");
  }
#line 7747 "y.tab.c" /* yacc.c:1646  */
    break;

  case 389:
#line 3223 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ':'.");
    yyerror("Unexpected end of file.");
  }
#line 7756 "y.tab.c" /* yacc.c:1646  */
    break;

  case 390:
#line 3230 "language.yacc" /* yacc.c:1646  */
    {
    if(!match_types(Pike_compiler->compiler_frame->current_return_type,
		    void_type_string))
    {
      yytype_error("Must return a value for a non-void function.",
		   Pike_compiler->compiler_frame->current_return_type,
		   void_type_string, 0);
    }
    (yyval.n)=mknode(F_RETURN,mkintnode(0),0);
  }
#line 7771 "y.tab.c" /* yacc.c:1646  */
    break;

  case 391:
#line 3241 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_RETURN,(yyvsp[-1].n),0);
  }
#line 7779 "y.tab.c" /* yacc.c:1646  */
    break;

  case 392:
#line 3246 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7785 "y.tab.c" /* yacc.c:1646  */
    break;

  case 393:
#line 3247 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkcastnode(void_type_string, (yyvsp[0].n));  }
#line 7791 "y.tab.c" /* yacc.c:1646  */
    break;

  case 394:
#line 3250 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkcastnode(void_type_string, (yyvsp[0].n));  }
#line 7797 "y.tab.c" /* yacc.c:1646  */
    break;

  case 395:
#line 3252 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7803 "y.tab.c" /* yacc.c:1646  */
    break;

  case 398:
#line 3257 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7809 "y.tab.c" /* yacc.c:1646  */
    break;

  case 400:
#line 3261 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); free_node((yyvsp[-1].n)); }
#line 7815 "y.tab.c" /* yacc.c:1646  */
    break;

  case 401:
#line 3262 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); free_node((yyvsp[-1].n)); }
#line 7821 "y.tab.c" /* yacc.c:1646  */
    break;

  case 402:
#line 3263 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); free_node((yyvsp[-1].n)); }
#line 7827 "y.tab.c" /* yacc.c:1646  */
    break;

  case 403:
#line 3264 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); free_node((yyvsp[-1].n)); }
#line 7833 "y.tab.c" /* yacc.c:1646  */
    break;

  case 405:
#line 3270 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mknode(F_COMMA_EXPR, mkcastnode(void_type_string, (yyvsp[-2].n)), (yyvsp[0].n));
  }
#line 7841 "y.tab.c" /* yacc.c:1646  */
    break;

  case 407:
#line 3276 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_PUSH_ARRAY,(yyvsp[0].n),0); }
#line 7847 "y.tab.c" /* yacc.c:1646  */
    break;

  case 409:
#line 3279 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_ASSIGN,(yyvsp[0].n),(yyvsp[-2].n)); }
#line 7853 "y.tab.c" /* yacc.c:1646  */
    break;

  case 410:
#line 3280 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); reset_type_stack(); yyerrok; }
#line 7859 "y.tab.c" /* yacc.c:1646  */
    break;

  case 411:
#line 3281 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); }
#line 7865 "y.tab.c" /* yacc.c:1646  */
    break;

  case 412:
#line 3283 "language.yacc" /* yacc.c:1646  */
    {
    if (!(THIS_COMPILATION->lex.pragmas & ID_STRICT_TYPES)) {
      mark_lvalues_as_used((yyvsp[-3].n));
    }
    (yyval.n)=mknode(F_ASSIGN,(yyvsp[0].n),mknode(F_ARRAY_LVALUE,(yyvsp[-3].n),0));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-4].n));
    free_node ((yyvsp[-4].n));
  }
#line 7878 "y.tab.c" /* yacc.c:1646  */
    break;

  case 413:
#line 3291 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode((yyvsp[-1].number),(yyvsp[-2].n),(yyvsp[0].n)); }
#line 7884 "y.tab.c" /* yacc.c:1646  */
    break;

  case 414:
#line 3292 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); reset_type_stack(); yyerrok; }
#line 7890 "y.tab.c" /* yacc.c:1646  */
    break;

  case 415:
#line 3293 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[0].n); }
#line 7896 "y.tab.c" /* yacc.c:1646  */
    break;

  case 416:
#line 3295 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode((yyvsp[-1].number),mknode(F_ARRAY_LVALUE,(yyvsp[-3].n),0),(yyvsp[0].n));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-4].n));
    free_node ((yyvsp[-4].n));
  }
#line 7906 "y.tab.c" /* yacc.c:1646  */
    break;

  case 417:
#line 3301 "language.yacc" /* yacc.c:1646  */
    {
      (yyval.n)=(yyvsp[-2].n); free_node ((yyvsp[-3].n)); reset_type_stack(); yyerrok;
    }
#line 7914 "y.tab.c" /* yacc.c:1646  */
    break;

  case 419:
#line 3308 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode('?',(yyvsp[-4].n),mknode(':',(yyvsp[-2].n),(yyvsp[0].n))); }
#line 7920 "y.tab.c" /* yacc.c:1646  */
    break;

  case 420:
#line 3311 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_AND_EQ; }
#line 7926 "y.tab.c" /* yacc.c:1646  */
    break;

  case 421:
#line 3312 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_OR_EQ; }
#line 7932 "y.tab.c" /* yacc.c:1646  */
    break;

  case 422:
#line 3313 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_XOR_EQ; }
#line 7938 "y.tab.c" /* yacc.c:1646  */
    break;

  case 423:
#line 3314 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_LSH_EQ; }
#line 7944 "y.tab.c" /* yacc.c:1646  */
    break;

  case 424:
#line 3315 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_RSH_EQ; }
#line 7950 "y.tab.c" /* yacc.c:1646  */
    break;

  case 425:
#line 3316 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_ADD_EQ; }
#line 7956 "y.tab.c" /* yacc.c:1646  */
    break;

  case 426:
#line 3317 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_SUB_EQ; }
#line 7962 "y.tab.c" /* yacc.c:1646  */
    break;

  case 427:
#line 3318 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_MULT_EQ; }
#line 7968 "y.tab.c" /* yacc.c:1646  */
    break;

  case 428:
#line 3319 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_MOD_EQ; }
#line 7974 "y.tab.c" /* yacc.c:1646  */
    break;

  case 429:
#line 3320 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=F_DIV_EQ; }
#line 7980 "y.tab.c" /* yacc.c:1646  */
    break;

  case 430:
#line 3323 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=0; }
#line 7986 "y.tab.c" /* yacc.c:1646  */
    break;

  case 431:
#line 3323 "language.yacc" /* yacc.c:1646  */
    { (yyval.number)=1; }
#line 7992 "y.tab.c" /* yacc.c:1646  */
    break;

  case 432:
#line 3325 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 7998 "y.tab.c" /* yacc.c:1646  */
    break;

  case 435:
#line 3331 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_ARG_LIST,(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8004 "y.tab.c" /* yacc.c:1646  */
    break;

  case 436:
#line 3334 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 8010 "y.tab.c" /* yacc.c:1646  */
    break;

  case 439:
#line 3340 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[0].n)) {
      (yyval.n)=mknode(F_ARG_LIST,(yyvsp[-2].n),(yyvsp[0].n));
    } else {
      /* Error in assoc_pair */
      (yyval.n)=(yyvsp[-2].n);
    }
  }
#line 8023 "y.tab.c" /* yacc.c:1646  */
    break;

  case 441:
#line 3352 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_ARG_LIST,(yyvsp[-2].n),(yyvsp[0].n));
  }
#line 8031 "y.tab.c" /* yacc.c:1646  */
    break;

  case 442:
#line 3355 "language.yacc" /* yacc.c:1646  */
    { free_node((yyvsp[-2].n)); (yyval.n)=0; }
#line 8037 "y.tab.c" /* yacc.c:1646  */
    break;

  case 444:
#line 3359 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_LOR,(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8043 "y.tab.c" /* yacc.c:1646  */
    break;

  case 445:
#line 3360 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_LAND,(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8049 "y.tab.c" /* yacc.c:1646  */
    break;

  case 446:
#line 3361 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`|",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8055 "y.tab.c" /* yacc.c:1646  */
    break;

  case 447:
#line 3362 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`^",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8061 "y.tab.c" /* yacc.c:1646  */
    break;

  case 448:
#line 3363 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`&",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8067 "y.tab.c" /* yacc.c:1646  */
    break;

  case 449:
#line 3364 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`==",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8073 "y.tab.c" /* yacc.c:1646  */
    break;

  case 450:
#line 3365 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`!=",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8079 "y.tab.c" /* yacc.c:1646  */
    break;

  case 451:
#line 3366 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`>",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8085 "y.tab.c" /* yacc.c:1646  */
    break;

  case 452:
#line 3367 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`>=",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8091 "y.tab.c" /* yacc.c:1646  */
    break;

  case 453:
#line 3368 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`<",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8097 "y.tab.c" /* yacc.c:1646  */
    break;

  case 454:
#line 3369 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`<=",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8103 "y.tab.c" /* yacc.c:1646  */
    break;

  case 455:
#line 3370 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`<<",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8109 "y.tab.c" /* yacc.c:1646  */
    break;

  case 456:
#line 3371 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`>>",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8115 "y.tab.c" /* yacc.c:1646  */
    break;

  case 457:
#line 3372 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`+",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8121 "y.tab.c" /* yacc.c:1646  */
    break;

  case 458:
#line 3373 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`-",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8127 "y.tab.c" /* yacc.c:1646  */
    break;

  case 459:
#line 3374 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`*",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8133 "y.tab.c" /* yacc.c:1646  */
    break;

  case 460:
#line 3375 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`%",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8139 "y.tab.c" /* yacc.c:1646  */
    break;

  case 461:
#line 3376 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`/",(yyvsp[-2].n),(yyvsp[0].n)); }
#line 8145 "y.tab.c" /* yacc.c:1646  */
    break;

  case 481:
#line 3399 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mkcastnode((yyvsp[-1].n)->u.sval.u.type, (yyvsp[0].n));
    free_node((yyvsp[-1].n));
  }
#line 8154 "y.tab.c" /* yacc.c:1646  */
    break;

  case 482:
#line 3404 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mksoftcastnode((yyvsp[-1].n)->u.sval.u.type, (yyvsp[0].n));
    free_node((yyvsp[-1].n));
  }
#line 8163 "y.tab.c" /* yacc.c:1646  */
    break;

  case 483:
#line 3408 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_INC,(yyvsp[0].n),0); }
#line 8169 "y.tab.c" /* yacc.c:1646  */
    break;

  case 484:
#line 3409 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_DEC,(yyvsp[0].n),0); }
#line 8175 "y.tab.c" /* yacc.c:1646  */
    break;

  case 485:
#line 3410 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`!",(yyvsp[0].n),0); }
#line 8181 "y.tab.c" /* yacc.c:1646  */
    break;

  case 486:
#line 3411 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`~",(yyvsp[0].n),0); }
#line 8187 "y.tab.c" /* yacc.c:1646  */
    break;

  case 487:
#line 3412 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkopernode("`-",(yyvsp[0].n),0); }
#line 8193 "y.tab.c" /* yacc.c:1646  */
    break;

  case 489:
#line 3416 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_POST_INC,(yyvsp[-1].n),0); }
#line 8199 "y.tab.c" /* yacc.c:1646  */
    break;

  case 490:
#line 3417 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknode(F_POST_DEC,(yyvsp[-1].n),0); }
#line 8205 "y.tab.c" /* yacc.c:1646  */
    break;

  case 491:
#line 3439 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 8211 "y.tab.c" /* yacc.c:1646  */
    break;

  case 492:
#line 3443 "language.yacc" /* yacc.c:1646  */
    {
    debug_malloc_touch(Pike_compiler->compiler_frame->current_return_type);
    if(Pike_compiler->compiler_frame->current_return_type)
      free_type(Pike_compiler->compiler_frame->current_return_type);
    copy_pike_type(Pike_compiler->compiler_frame->current_return_type,
		   any_type_string);

    /* block code */
    (yyvsp[-2].number)=Pike_compiler->num_used_modules;
    (yyval.number)=Pike_compiler->compiler_frame->current_number_of_locals;
  }
#line 8227 "y.tab.c" /* yacc.c:1646  */
    break;

  case 493:
#line 3455 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *type;
    int f/*, e */;
    struct pike_string *name;
    struct compilation *c = THIS_COMPILATION;
    struct pike_string *save_file = c->lex.current_file;
    int save_line = c->lex.current_line;
    c->lex.current_file = (yyvsp[-4].n)->current_file;
    c->lex.current_line = (yyvsp[-4].n)->line_number;

    /* block code */
    unuse_modules(Pike_compiler->num_used_modules - (yyvsp[-5].number));
    (yyvsp[-1].n) = pop_local_variables((yyvsp[-2].number), (yyvsp[-1].n));

    debug_malloc_touch((yyvsp[-1].n));
    (yyvsp[-1].n)=mknode(F_COMMA_EXPR,(yyvsp[-1].n),mknode(F_RETURN,mkintnode(0),0));
    if (Pike_compiler->compiler_pass == 2) {
      /* Doing this in pass 1 might induce too strict checks on types
       * in cases where we got placeholders. */
      type=find_return_type((yyvsp[-1].n));
      if (type) {
	push_finished_type(type);
	free_type(type);
      } else {
	yywarning("Failed to determine return type for implicit lambda.");
	push_type(T_ZERO);
      }
    } else {
      /* Tentative return type. */
      push_type(T_MIXED);
    }

    push_type(T_VOID);
    push_type(T_MANY);
/*
    e=$5-1;
    for(; e>=0; e--)
      push_finished_type(Pike_compiler->compiler_frame->variable[e].type);
*/

    type=compiler_pop_type();

    name = get_new_name(NULL);

#ifdef LAMBDA_DEBUG
    fprintf(stderr, "%d: IMPLICIT LAMBDA: %s 0x%08lx 0x%08lx\n",
	    Pike_compiler->compiler_pass, name->str,
	    (long)Pike_compiler->new_program->id,
	    Pike_compiler->local_class_counter-1);
#endif /* LAMBDA_DEBUG */

    f=dooptcode(name,
		(yyvsp[-1].n),
		type,
		ID_PROTECTED | ID_PRIVATE | ID_INLINE | ID_USED);

    if(Pike_compiler->compiler_frame->lexical_scope & SCOPE_SCOPED) {
      (yyval.n) = mktrampolinenode(f,Pike_compiler->compiler_frame->previous);
    } else {
      (yyval.n) = mkidentifiernode(f);
    }

    c->lex.current_line = save_line;
    c->lex.current_file = save_file;
    free_node ((yyvsp[-4].n));
    free_string(name);
    free_type(type);
#ifdef PIKE_DEBUG
    if (Pike_compiler->compiler_frame != (yyvsp[-3].ptr)) {
      Pike_fatal("Lost track of compiler_frame!\n"
		 "  Got: %p (Expected: %p) Previous: %p\n",
		 Pike_compiler->compiler_frame, (yyvsp[-3].ptr),
		 Pike_compiler->compiler_frame->previous);
    }
#endif
    pop_compiler_frame();
  }
#line 8309 "y.tab.c" /* yacc.c:1646  */
    break;

  case 494:
#line 3536 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mkapplynode((yyvsp[-4].n), mknode(F_ARG_LIST, (yyvsp[-2].n), (yyvsp[0].n)));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-3].n));
    free_node ((yyvsp[-3].n));
  }
#line 8319 "y.tab.c" /* yacc.c:1646  */
    break;

  case 495:
#line 3542 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mkapplynode((yyvsp[-4].n), (yyvsp[0].n));
    free_node ((yyvsp[-3].n));
    yyerrok;
  }
#line 8329 "y.tab.c" /* yacc.c:1646  */
    break;

  case 496:
#line 3548 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
    (yyval.n)=mkapplynode((yyvsp[-3].n), NULL);
    free_node ((yyvsp[-2].n));
  }
#line 8340 "y.tab.c" /* yacc.c:1646  */
    break;

  case 497:
#line 3555 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ')'.");
    (yyval.n)=mkapplynode((yyvsp[-3].n), NULL);
    free_node ((yyvsp[-2].n));
  }
#line 8350 "y.tab.c" /* yacc.c:1646  */
    break;

  case 498:
#line 3561 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing ')'.");
    (yyval.n)=mkapplynode((yyvsp[-3].n), NULL);
    free_node ((yyvsp[-2].n));
  }
#line 8360 "y.tab.c" /* yacc.c:1646  */
    break;

  case 499:
#line 3569 "language.yacc" /* yacc.c:1646  */
    {
    if (TEST_COMPAT(7, 6)) {
      (yyval.number) = Pike_compiler->current_modifiers =
	(THIS_COMPILATION->lex.pragmas & ID_MODIFIER_MASK);
    } else {
      (yyval.number) = Pike_compiler->current_modifiers = ID_PROTECTED|ID_INLINE|ID_PRIVATE |
	(THIS_COMPILATION->lex.pragmas & ID_MODIFIER_MASK);
    }
  }
#line 8374 "y.tab.c" /* yacc.c:1646  */
    break;

  case 502:
#line 3582 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mkfloatnode((FLOAT_TYPE)(yyvsp[0].fnum)); }
#line 8380 "y.tab.c" /* yacc.c:1646  */
    break;

  case 508:
#line 3588 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = (yyvsp[0].n); }
#line 8386 "y.tab.c" /* yacc.c:1646  */
    break;

  case 509:
#line 3589 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = (yyvsp[0].n); }
#line 8392 "y.tab.c" /* yacc.c:1646  */
    break;

  case 512:
#line 3593 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_AUTO_MAP_MARKER, (yyvsp[-3].n), 0);
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
    free_node ((yyvsp[-2].n));
  }
#line 8402 "y.tab.c" /* yacc.c:1646  */
    break;

  case 513:
#line 3599 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_INDEX,(yyvsp[-3].n),(yyvsp[-1].n));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
    free_node ((yyvsp[-2].n));
  }
#line 8412 "y.tab.c" /* yacc.c:1646  */
    break;

  case 514:
#line 3606 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_RANGE,(yyvsp[-5].n),mknode(':',(yyvsp[-3].n),(yyvsp[-1].n)));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-4].n));
    free_node ((yyvsp[-4].n));
  }
#line 8422 "y.tab.c" /* yacc.c:1646  */
    break;

  case 515:
#line 3612 "language.yacc" /* yacc.c:1646  */
    {
    /* A[?X] to ((tmp=A) && tmp[X]) */
    if( (yyvsp[-4].n) && ((yyvsp[-4].n)->token == F_LOCAL) )
    {
      (yyval.n)=mknode(F_LAND, copy_node((yyvsp[-4].n)), mknode(F_INDEX,  (yyvsp[-4].n), (yyvsp[-1].n)));
    }
    else
    {
      fix_type_field( (yyvsp[-4].n) );
      if( (yyvsp[-4].n) && (yyvsp[-4].n)->type )
      {
        int temporary;
        (yyvsp[-4].n)->type->refs++;

        temporary = add_local_name(empty_pike_string, (yyvsp[-4].n)->type, 0);
        Pike_compiler->compiler_frame->variable[temporary].flags |= LOCAL_VAR_IS_USED;
        (yyval.n)=mknode(F_LAND,
                  mknode(F_ASSIGN, (yyvsp[-4].n), mklocalnode(temporary,0)),
                  mknode(F_INDEX,  mklocalnode(temporary,0), (yyvsp[-1].n)));
      }
      else
      {
        (yyval.n)=mknode(F_INDEX, (yyvsp[-4].n),(yyvsp[-1].n));
        yyerror("Indexing unexpected value.");
      }
    }
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
    free_node ((yyvsp[-2].n));
  }
#line 8456 "y.tab.c" /* yacc.c:1646  */
    break;

  case 516:
#line 3643 "language.yacc" /* yacc.c:1646  */
    {
    /* A[?X..Y] to ((tmp=A) && tmp[X..Y]) */
    node *range = mknode(':',(yyvsp[-3].n),(yyvsp[-1].n));
    if( (yyvsp[-6].n) && ((yyvsp[-6].n)->token == F_LOCAL ) )
    {
      (yyval.n) = mknode( F_LAND, copy_node((yyvsp[-6].n)), mknode(F_RANGE, (yyvsp[-6].n), range) );
    }
    else
    {
      fix_type_field( (yyvsp[-6].n) );
      if( (yyvsp[-6].n) && (yyvsp[-6].n)->type )
      {
        int temporary;
        (yyvsp[-6].n)->type->refs++;

        temporary = add_local_name(empty_pike_string, (yyvsp[-6].n)->type, 0);
        Pike_compiler->compiler_frame->variable[temporary].flags |= LOCAL_VAR_IS_USED;
        (yyval.n)=mknode(F_LAND,
                  mknode(F_ASSIGN, (yyvsp[-6].n), mklocalnode(temporary,0) ),
                  mknode(F_RANGE,  mklocalnode(temporary,0), range) );
      }
      else
      {
        (yyval.n) = mknode( F_LAND, (yyvsp[-6].n), mknode(F_RANGE,(yyvsp[-6].n),range) );
        yyerror("Indexing unexpected value.");
      }
    }
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-4].n));
    free_node ((yyvsp[-4].n));
  }
#line 8491 "y.tab.c" /* yacc.c:1646  */
    break;

  case 517:
#line 3674 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=(yyvsp[-3].n);
    free_node ((yyvsp[-2].n));
    yyerrok;
  }
#line 8501 "y.tab.c" /* yacc.c:1646  */
    break;

  case 518:
#line 3680 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=(yyvsp[-3].n); yyerror("Missing ']'.");
    yyerror("Unexpected end of file.");
    free_node ((yyvsp[-2].n));
  }
#line 8511 "y.tab.c" /* yacc.c:1646  */
    break;

  case 519:
#line 3686 "language.yacc" /* yacc.c:1646  */
    {(yyval.n)=(yyvsp[-3].n); yyerror("Missing ']'."); free_node ((yyvsp[-2].n));}
#line 8517 "y.tab.c" /* yacc.c:1646  */
    break;

  case 520:
#line 3688 "language.yacc" /* yacc.c:1646  */
    {(yyval.n)=(yyvsp[-3].n); yyerror("Missing ']'."); free_node ((yyvsp[-2].n));}
#line 8523 "y.tab.c" /* yacc.c:1646  */
    break;

  case 521:
#line 3690 "language.yacc" /* yacc.c:1646  */
    {(yyval.n)=(yyvsp[-3].n); yyerror("Missing ']'."); free_node ((yyvsp[-2].n));}
#line 8529 "y.tab.c" /* yacc.c:1646  */
    break;

  case 522:
#line 3692 "language.yacc" /* yacc.c:1646  */
    {
      (yyval.n)=(yyvsp[-1].n);
      if ((yyval.n)) {
	COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
      }
      free_node ((yyvsp[-2].n));
    }
#line 8541 "y.tab.c" /* yacc.c:1646  */
    break;

  case 523:
#line 3700 "language.yacc" /* yacc.c:1646  */
    {
      /* FIXME: May eat lots of stack; cf Standards.FIPS10_4.divisions */
      (yyval.n)=mkefuncallnode("aggregate",(yyvsp[-2].n));
      COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-4].n));
      free_node ((yyvsp[-4].n));
    }
#line 8552 "y.tab.c" /* yacc.c:1646  */
    break;

  case 524:
#line 3709 "language.yacc" /* yacc.c:1646  */
    {
      /* FIXME: May eat lots of stack; cf Standards.FIPS10_4.divisions */
      (yyval.n)=mkefuncallnode("aggregate_mapping",(yyvsp[-2].n));
      COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-4].n));
      free_node ((yyvsp[-4].n));
      free_node ((yyvsp[-3].n));
    }
#line 8564 "y.tab.c" /* yacc.c:1646  */
    break;

  case 525:
#line 3717 "language.yacc" /* yacc.c:1646  */
    {
      /* FIXME: May eat lots of stack; cf Standards.FIPS10_4.divisions */
      (yyval.n)=mkefuncallnode("aggregate_multiset",(yyvsp[-1].n));
      COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
      free_node ((yyvsp[-2].n));
    }
#line 8575 "y.tab.c" /* yacc.c:1646  */
    break;

  case 526:
#line 3724 "language.yacc" /* yacc.c:1646  */
    {
      yyerror("Missing '>'.");
      (yyval.n)=mkefuncallnode("aggregate_multiset",(yyvsp[-1].n));
      COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
      free_node ((yyvsp[-2].n));
    }
#line 8586 "y.tab.c" /* yacc.c:1646  */
    break;

  case 527:
#line 3730 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); yyerrok; }
#line 8592 "y.tab.c" /* yacc.c:1646  */
    break;

  case 528:
#line 3732 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=(yyvsp[-2].n); yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
#line 8601 "y.tab.c" /* yacc.c:1646  */
    break;

  case 529:
#line 3736 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); yyerror("Missing ')'."); }
#line 8607 "y.tab.c" /* yacc.c:1646  */
    break;

  case 530:
#line 3737 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); yyerror("Missing ')'."); }
#line 8613 "y.tab.c" /* yacc.c:1646  */
    break;

  case 531:
#line 3738 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); yyerrok; }
#line 8619 "y.tab.c" /* yacc.c:1646  */
    break;

  case 532:
#line 3739 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Missing '>'.");
    (yyval.n)=(yyvsp[-2].n); yyerrok;
  }
#line 8628 "y.tab.c" /* yacc.c:1646  */
    break;

  case 533:
#line 3744 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=(yyvsp[-2].n); yyerror("Missing '>)'.");
    yyerror("Unexpected end of file.");
  }
#line 8637 "y.tab.c" /* yacc.c:1646  */
    break;

  case 534:
#line 3748 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); yyerror("Missing '>)'."); }
#line 8643 "y.tab.c" /* yacc.c:1646  */
    break;

  case 535:
#line 3749 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-2].n); yyerror("Missing '>)'."); }
#line 8649 "y.tab.c" /* yacc.c:1646  */
    break;

  case 536:
#line 3751 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_ARROW,(yyvsp[-3].n),(yyvsp[0].n));
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-1].n));
    free_node ((yyvsp[-1].n));
  }
#line 8659 "y.tab.c" /* yacc.c:1646  */
    break;

  case 537:
#line 3757 "language.yacc" /* yacc.c:1646  */
    {
    /* A?->B to ((tmp=A) && tmp->B) */
    int temporary;
    if( (yyvsp[-3].n) && ((yyvsp[-3].n)->token == F_LOCAL) )
    {
      (yyval.n)=mknode(F_LAND, copy_node((yyvsp[-3].n)), mknode(F_ARROW, (yyvsp[-3].n), (yyvsp[0].n)));
    }
    else
    {
      fix_type_field( (yyvsp[-3].n) );
      if( (yyvsp[-3].n) && (yyvsp[-3].n)->type )
      {
        (yyvsp[-3].n)->type->refs++;

        temporary = add_local_name(empty_pike_string, (yyvsp[-3].n)->type, 0);
        Pike_compiler->compiler_frame->variable[temporary].flags |= LOCAL_VAR_IS_USED;
        (yyval.n)=mknode(F_LAND,
                  mknode(F_ASSIGN, (yyvsp[-3].n), mklocalnode(temporary,0)),
                  mknode(F_ARROW,  mklocalnode(temporary,0), (yyvsp[0].n)));
      }
      else
      {
        (yyval.n)=mknode(F_ARROW, (yyvsp[-3].n),(yyvsp[0].n));
        yyerror("Indexing unexpected value.");
      }
    }
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-1].n));
    free_node ((yyvsp[-1].n));
  }
#line 8693 "y.tab.c" /* yacc.c:1646  */
    break;

  case 538:
#line 3787 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=index_node((yyvsp[-3].n),".",(yyvsp[0].n)->u.sval.u.string);
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-1].n));
    free_node ((yyvsp[-3].n));
    free_node ((yyvsp[-1].n));
    free_node ((yyvsp[0].n));
  }
#line 8705 "y.tab.c" /* yacc.c:1646  */
    break;

  case 539:
#line 3794 "language.yacc" /* yacc.c:1646  */
    {(yyval.n)=(yyvsp[-3].n); free_node ((yyvsp[-1].n));}
#line 8711 "y.tab.c" /* yacc.c:1646  */
    break;

  case 541:
#line 3799 "language.yacc" /* yacc.c:1646  */
    {
    int i;

    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);

    if (((i = find_shared_string_identifier(Pike_compiler->last_identifier,
					    Pike_compiler->new_program)) >= 0) ||
	((i = really_low_find_shared_string_identifier(Pike_compiler->last_identifier,
						       Pike_compiler->new_program,
						       SEE_PROTECTED|
						       SEE_PRIVATE)) >= 0)) {
      struct reference *ref = Pike_compiler->new_program->identifier_references + i;
      if (IDENTIFIER_IS_VARIABLE (
	    ID_FROM_PTR (Pike_compiler->new_program, ref)->identifier_flags)) {
	/* Allowing local:: on variables would lead to pathological
	 * behavior: If a non-local variable in a class is referenced
	 * both with and without local::, both references would
	 * address the same variable in all cases except where an
	 * inheriting program overrides it (c.f. [bug 1252]).
	 *
	 * Furthermore, that's not how it works currently; if this
	 * error is removed then local:: will do nothing on variables
	 * except forcing a lookup in the closest surrounding class
	 * scope. */
	yyerror ("Cannot make local references to variables.");
	(yyval.n) = 0;
      }
      else {
	if (!(ref->id_flags & ID_LOCAL)) {
	  /* We need to generate a new reference. */
	  int d;
	  struct reference funp = *ref;
	  funp.id_flags = (funp.id_flags & ~ID_INHERITED) | ID_INLINE|ID_HIDDEN;
	  i = -1;
	  for(d = 0; d < (int)Pike_compiler->new_program->num_identifier_references; d++) {
	    struct reference *refp;
	    refp = Pike_compiler->new_program->identifier_references + d;

	    if (!(refp->id_flags & ID_LOCAL)) continue;

	    if((refp->inherit_offset == funp.inherit_offset) &&
	       (refp->identifier_offset == funp.identifier_offset)) {
	      i = d;
	      break;
	    }
	  }
	  if (i < 0) {
	    add_to_identifier_references(funp);
	    i = Pike_compiler->new_program->num_identifier_references - 1;
	  }
	}
	(yyval.n) = mkidentifiernode(i);
      }
    } else {
      if (Pike_compiler->compiler_pass == 2) {
	my_yyerror("%S not defined in local scope.",
		   Pike_compiler->last_identifier);
	(yyval.n) = 0;
      } else {
	(yyval.n) = mknode(F_UNDEFINED, 0, 0);
      }
    }

    free_node((yyvsp[0].n));
  }
#line 8782 "y.tab.c" /* yacc.c:1646  */
    break;

  case 542:
#line 3866 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
  }
#line 8790 "y.tab.c" /* yacc.c:1646  */
    break;

  case 544:
#line 3873 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=index_node((yyvsp[-2].n), Pike_compiler->last_identifier?Pike_compiler->last_identifier->str:NULL,
		  (yyvsp[0].n)->u.sval.u.string);
    free_node((yyvsp[-2].n));
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);
    free_node((yyvsp[0].n));
  }
#line 8803 "y.tab.c" /* yacc.c:1646  */
    break;

  case 545:
#line 3881 "language.yacc" /* yacc.c:1646  */
    {}
#line 8809 "y.tab.c" /* yacc.c:1646  */
    break;

  case 546:
#line 3882 "language.yacc" /* yacc.c:1646  */
    {}
#line 8815 "y.tab.c" /* yacc.c:1646  */
    break;

  case 549:
#line 3896 "language.yacc" /* yacc.c:1646  */
    {
    struct compilation *c = THIS_COMPILATION;
    struct program_state *state = Pike_compiler;
    int depth;
    int e = -1;

    inherit_state = NULL;
    inherit_depth = 0;

    /* NB: The heuristics here are a bit strange
     *     (all to make it as backward compatible as possible).
     *
     *     The priority order is as follows:
     *
     *     1: Direct inherits in the current class.
     *
     *     2: The name of the current class.
     *
     *     3: 1 & 2 recursively for surrounding parent classes.
     *
     *     4: Indirect inherits in the current class.
     *
     *     5: 4 recursively for surrounding parent classes.
     *
     *     6: this_program.
     *
     * Note that a deep inherit in the current class trumphs
     * a not so deep inherit in a parent class (but not a
     * direct inherit in a parent class). To select the deep
     * inherit in the parent class in this case, prefix it
     * with the name of the parent class.
     */
    for (depth = 0;; depth++, state = state->previous) {
      int inh = find_inherit(state->new_program, (yyvsp[-1].n)->u.sval.u.string);
      if (inh &&
	  (!inherit_state ||
	   (state->new_program->inherits[inh].inherit_level == 1))) {
	/* Found, and we've either not found anything earlier,
	 * or this is a direct inherit (and the previous
	 * wasn't since we didn't break out of the loop).
	 */
	e = inh;
	inherit_state = state;
	inherit_depth = depth;
	if (state->new_program->inherits[inh].inherit_level == 1) {
	  /* Name of direct inherit ==> Done. */
	  break;
	}
      }
      /* The top-level class does not have a name, so break here. */
      if (depth == c->compilation_depth) break;
      if (ID_FROM_INT (state->previous->new_program,
		       state->parent_identifier)->name ==
	  (yyvsp[-1].n)->u.sval.u.string) {
	/* Name of surrounding class ==> Done. */
	e = 0;
	inherit_state = state;
	inherit_depth = depth;
	break;
      }
    }
    if (e == -1) {
      inherit_state = state;
      inherit_depth = depth;
      if ((yyvsp[-1].n)->u.sval.u.string == this_program_string || (yyvsp[-1].n)->u.sval.u.string == this_string) {
        inherit_state = Pike_compiler;
        inherit_depth = 0;
        e = 0;
      }
      else
        my_yyerror("No inherit or surrounding class %S.",
                   (yyvsp[-1].n)->u.sval.u.string);
    }
    free_node((yyvsp[-1].n));
    (yyval.number) = e;
  }
#line 8896 "y.tab.c" /* yacc.c:1646  */
    break;

  case 550:
#line 3973 "language.yacc" /* yacc.c:1646  */
    {
    struct compilation *c = THIS_COMPILATION;
    inherit_state = Pike_compiler;
    for (inherit_depth = 0; inherit_depth < c->compilation_depth;
	 inherit_depth++, inherit_state = inherit_state->previous) {}
    (yyval.number) = -1;
  }
#line 8908 "y.tab.c" /* yacc.c:1646  */
    break;

  case 551:
#line 3981 "language.yacc" /* yacc.c:1646  */
    {
    int e = 0;
    if ((yyvsp[-2].number) < 0) {
      (yyvsp[-2].number) = 0;
    }
#if 0
    /* FIXME: The inherit modifiers aren't kept. */
    if (!(inherit_state->new_program->inherits[(yyvsp[-2].number)].flags & ID_PRIVATE)) {
#endif /* 0 */
      e = find_inherit(inherit_state->new_program->inherits[(yyvsp[-2].number)].prog,
		       (yyvsp[-1].n)->u.sval.u.string);
#if 0
    }
#endif /* 0 */
    if (!e) {
      if (inherit_state->new_program->inherits[(yyvsp[-2].number)].name) {
	my_yyerror("No such inherit %S::%S.",
		   inherit_state->new_program->inherits[(yyvsp[-2].number)].name,
		   (yyvsp[-1].n)->u.sval.u.string);
      } else {
	my_yyerror("No such inherit %S.", (yyvsp[-1].n)->u.sval.u.string);
      }
      (yyval.number) = -1;
    } else {
      /* We know stuff about the inherit structure... */
      (yyval.number) = e + (yyvsp[-2].number);
    }
    free_node((yyvsp[-1].n));
  }
#line 8942 "y.tab.c" /* yacc.c:1646  */
    break;

  case 552:
#line 4010 "language.yacc" /* yacc.c:1646  */
    { (yyval.number) = -1; }
#line 8948 "y.tab.c" /* yacc.c:1646  */
    break;

  case 553:
#line 4014 "language.yacc" /* yacc.c:1646  */
    {
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);

    if(((yyval.n)=lexical_islocal(Pike_compiler->last_identifier)))
    {
      /* done, nothing to do here */
    }else if(!((yyval.n)=find_module_identifier(Pike_compiler->last_identifier,1)) &&
	     !((yyval.n) = program_magic_identifier (Pike_compiler, 0, -1,
					      Pike_compiler->last_identifier, 0))) {
      if((Pike_compiler->flags & COMPILATION_FORCE_RESOLVE) ||
	 (Pike_compiler->compiler_pass==2)) {
	my_yyerror("Undefined identifier %S.",
		   Pike_compiler->last_identifier);
	/* FIXME: Add this identifier as a constant in the current program to
	 *        avoid multiple reporting of the same identifier.
	 * NOTE: This should then only be done in the second pass.
	 */	
	(yyval.n)=0;
      }else{
	(yyval.n)=mknode(F_UNDEFINED,0,0);
      }
    }
    free_node((yyvsp[0].n));
  }
#line 8978 "y.tab.c" /* yacc.c:1646  */
    break;

  case 554:
#line 4040 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *dot;
    MAKE_CONST_STRING(dot, ".");
    if (call_handle_import(dot)) {
      node *tmp=mkconstantsvaluenode(Pike_sp-1);
      pop_stack();
      (yyval.n)=index_node(tmp, ".", (yyvsp[0].n)->u.sval.u.string);
      free_node(tmp);
    }
    else
      (yyval.n)=mknewintnode(0);
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);
    free_node((yyvsp[0].n));
  }
#line 8998 "y.tab.c" /* yacc.c:1646  */
    break;

  case 555:
#line 4056 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = resolve_identifier ((yyvsp[0].n)->u.sval.u.string);
    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);
    free_node ((yyvsp[0].n));
  }
#line 9009 "y.tab.c" /* yacc.c:1646  */
    break;

  case 556:
#line 4063 "language.yacc" /* yacc.c:1646  */
    {
    ref_push_string((yyvsp[0].n)->u.sval.u.string);
    low_yyreport(REPORT_ERROR, NULL, 0, parser_system_string,
		 1, "Unknown reserved symbol %s.");
    free_node((yyvsp[0].n));
    (yyval.n) = 0;
  }
#line 9021 "y.tab.c" /* yacc.c:1646  */
    break;

  case 557:
#line 4071 "language.yacc" /* yacc.c:1646  */
    {
    struct compilation *c = THIS_COMPILATION;
    node *tmp2;

    if(Pike_compiler->last_identifier)
      free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);

    tmp2 = mkconstantsvaluenode(&c->default_module);
    (yyval.n) = index_node(tmp2, "predef", (yyvsp[0].n)->u.sval.u.string);
    if(!(yyval.n)->name)
      add_ref( (yyval.n)->name=(yyvsp[0].n)->u.sval.u.string );
    free_node(tmp2);
    free_node((yyvsp[0].n));
  }
#line 9041 "y.tab.c" /* yacc.c:1646  */
    break;

  case 558:
#line 4087 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
  }
#line 9049 "y.tab.c" /* yacc.c:1646  */
    break;

  case 559:
#line 4091 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = find_versioned_identifier((yyvsp[0].n)->u.sval.u.string,
				   (yyvsp[-2].n)->u.integer.a, (yyvsp[-2].n)->u.integer.b);
    free_node((yyvsp[-2].n));
    free_node((yyvsp[0].n));
  }
#line 9060 "y.tab.c" /* yacc.c:1646  */
    break;

  case 560:
#line 4098 "language.yacc" /* yacc.c:1646  */
    {
    free_node((yyvsp[-2].n));
    (yyval.n)=0;
  }
#line 9069 "y.tab.c" /* yacc.c:1646  */
    break;

  case 561:
#line 4103 "language.yacc" /* yacc.c:1646  */
    {
    int id;

    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);

    if ((yyvsp[-1].number) > 0)
      id = low_reference_inherited_identifier(inherit_state,
					      (yyvsp[-1].number),
					      Pike_compiler->last_identifier,
					      SEE_PROTECTED);
    else
      id = really_low_find_shared_string_identifier(Pike_compiler->last_identifier,
						    inherit_state->new_program,
						    SEE_PROTECTED|SEE_PRIVATE);

    if (id != -1) {
      if (inherit_depth > 0) {
	(yyval.n) = mkexternalnode(inherit_state->new_program, id);
      } else {
	(yyval.n) = mkidentifiernode(id);
      }
    } else if (((yyval.n) = program_magic_identifier (inherit_state, inherit_depth, (yyvsp[-1].number),
					       Pike_compiler->last_identifier, 1))) {
      /* All done. */
    }
    else {
      if ((Pike_compiler->flags & COMPILATION_FORCE_RESOLVE) ||
	  (Pike_compiler->compiler_pass == 2)) {
	if (((yyvsp[-1].number) >= 0) && inherit_state->new_program->inherits[(yyvsp[-1].number)].name) {
	  my_yyerror("Undefined identifier %S::%S.",
		     inherit_state->new_program->inherits[(yyvsp[-1].number)].name,
		     Pike_compiler->last_identifier);
	} else {
	  my_yyerror("Undefined identifier %S.",
		     Pike_compiler->last_identifier);
	}
	(yyval.n)=0;
      }
      else
	(yyval.n)=mknode(F_UNDEFINED,0,0);
    }

    free_node((yyvsp[0].n));
  }
#line 9119 "y.tab.c" /* yacc.c:1646  */
    break;

  case 562:
#line 4148 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 9125 "y.tab.c" /* yacc.c:1646  */
    break;

  case 563:
#line 4149 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; }
#line 9131 "y.tab.c" /* yacc.c:1646  */
    break;

  case 564:
#line 4151 "language.yacc" /* yacc.c:1646  */
    {
    int e,i;

    if(Pike_compiler->last_identifier) free_string(Pike_compiler->last_identifier);
    copy_shared_string(Pike_compiler->last_identifier, (yyvsp[0].n)->u.sval.u.string);

    (yyval.n)=0;
    for(e=1;e<(int)Pike_compiler->new_program->num_inherits;e++)
    {
      if(Pike_compiler->new_program->inherits[e].inherit_level!=1) continue;
      i=low_reference_inherited_identifier(0,e,(yyvsp[0].n)->u.sval.u.string,SEE_PROTECTED);
      if(i==-1) continue;
      if((yyval.n))
      {
	(yyval.n)=mknode(F_ARG_LIST,(yyval.n),mkidentifiernode(i));
      }else{
	(yyval.n)=mkidentifiernode(i);
      }
    }
    if(!(yyval.n))
    {
      if (!((yyval.n) = program_magic_identifier (Pike_compiler, 0, -1,
					   (yyvsp[0].n)->u.sval.u.string, 1)))
      {
	if (Pike_compiler->compiler_pass == 2) {
          my_yyerror("Undefined identifier ::%S.", (yyvsp[0].n)->u.sval.u.string);
	}
	(yyval.n)=mkintnode(0);
      }
    }else{
      if((yyval.n)->token==F_ARG_LIST) (yyval.n)=mkefuncallnode("aggregate",(yyval.n));
    }
    free_node((yyvsp[0].n));
  }
#line 9170 "y.tab.c" /* yacc.c:1646  */
    break;

  case 565:
#line 4186 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
  }
#line 9178 "y.tab.c" /* yacc.c:1646  */
    break;

  case 566:
#line 4193 "language.yacc" /* yacc.c:1646  */
    {(yyval.n) = mknode (F_RANGE_OPEN, NULL, NULL);}
#line 9184 "y.tab.c" /* yacc.c:1646  */
    break;

  case 567:
#line 4195 "language.yacc" /* yacc.c:1646  */
    {(yyval.n) = mknode (F_RANGE_FROM_BEG, (yyvsp[0].n), NULL);}
#line 9190 "y.tab.c" /* yacc.c:1646  */
    break;

  case 568:
#line 4197 "language.yacc" /* yacc.c:1646  */
    {(yyval.n) = mknode (F_RANGE_FROM_END, (yyvsp[0].n), NULL);}
#line 9196 "y.tab.c" /* yacc.c:1646  */
    break;

  case 569:
#line 4199 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Unexpected end of file.");
    (yyval.n) = mknode (F_RANGE_OPEN, NULL, NULL);
  }
#line 9205 "y.tab.c" /* yacc.c:1646  */
    break;

  case 570:
#line 4204 "language.yacc" /* yacc.c:1646  */
    {
    yyerror("Unexpected end of file.");
    (yyval.n) = mknode (F_RANGE_OPEN, NULL, NULL);
  }
#line 9214 "y.tab.c" /* yacc.c:1646  */
    break;

  case 571:
#line 4211 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mkopernode("`/",
		  mkopernode("`-",
			     mkopernode("`-",
					mkefuncallnode("gethrvtime",
						       mkintnode(1)),
					mknode(F_COMMA_EXPR,
					       mknode(F_POP_VALUE, (yyvsp[0].n), NULL),
					       mkefuncallnode("gethrvtime",
							      mkintnode(1)))),
			     NULL),
		  mkfloatnode((FLOAT_TYPE)1e9));
  }
#line 9232 "y.tab.c" /* yacc.c:1646  */
    break;

  case 572:
#line 4226 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_type *t;
    node *tmp;

    /* FIXME: Why build the node at all? */
    /* Because the optimizer cannot optimize the root node of the
     * tree properly -Hubbe
     */
    tmp=mknode(F_COMMA_EXPR, (yyvsp[-1].n), 0);
    optimize_node(tmp);

    t=(tmp && CAR(tmp) && CAR(tmp)->type ? CAR(tmp)->type : mixed_type_string);
    (yyval.n) = mktypenode(t);
    free_node(tmp);
  }
#line 9252 "y.tab.c" /* yacc.c:1646  */
    break;

  case 573:
#line 4241 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerrok; }
#line 9258 "y.tab.c" /* yacc.c:1646  */
    break;

  case 574:
#line 4242 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerror("Missing ')'."); }
#line 9264 "y.tab.c" /* yacc.c:1646  */
    break;

  case 575:
#line 4244 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0; yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
#line 9273 "y.tab.c" /* yacc.c:1646  */
    break;

  case 576:
#line 4248 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerror("Missing ')'."); }
#line 9279 "y.tab.c" /* yacc.c:1646  */
    break;

  case 577:
#line 4251 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=(yyvsp[-1].n); }
#line 9285 "y.tab.c" /* yacc.c:1646  */
    break;

  case 578:
#line 4252 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerrok; }
#line 9291 "y.tab.c" /* yacc.c:1646  */
    break;

  case 579:
#line 4254 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0; yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
#line 9300 "y.tab.c" /* yacc.c:1646  */
    break;

  case 580:
#line 4258 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerror("Missing ')'."); }
#line 9306 "y.tab.c" /* yacc.c:1646  */
    break;

  case 581:
#line 4259 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerror("Missing ')'."); }
#line 9312 "y.tab.c" /* yacc.c:1646  */
    break;

  case 583:
#line 4261 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerror("Bad expression for catch."); }
#line 9318 "y.tab.c" /* yacc.c:1646  */
    break;

  case 584:
#line 4265 "language.yacc" /* yacc.c:1646  */
    {
       Pike_compiler->catch_level++;
     }
#line 9326 "y.tab.c" /* yacc.c:1646  */
    break;

  case 585:
#line 4269 "language.yacc" /* yacc.c:1646  */
    {
       (yyval.n)=mknode(F_CATCH,(yyvsp[0].n),NULL);
       Pike_compiler->catch_level--;
     }
#line 9335 "y.tab.c" /* yacc.c:1646  */
    break;

  case 586:
#line 4276 "language.yacc" /* yacc.c:1646  */
    {
    if ((yyvsp[-1].n) && !(THIS_COMPILATION->lex.pragmas & ID_STRICT_TYPES)) {
      mark_lvalues_as_used((yyvsp[-1].n));
    }
    (yyval.n)=mknode(F_SSCANF,mknode(':', mkintnode(TEST_COMPAT(7, 6)? SSCANF_FLAG_76_COMPAT : 0), mknode(F_ARG_LIST,(yyvsp[-4].n),(yyvsp[-2].n))),(yyvsp[-1].n));
  }
#line 9346 "y.tab.c" /* yacc.c:1646  */
    break;

  case 587:
#line 4283 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-4].n));
    free_node((yyvsp[-2].n));
    yyerrok;
  }
#line 9357 "y.tab.c" /* yacc.c:1646  */
    break;

  case 588:
#line 4290 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-4].n));
    free_node((yyvsp[-2].n));
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
#line 9369 "y.tab.c" /* yacc.c:1646  */
    break;

  case 589:
#line 4298 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-4].n));
    free_node((yyvsp[-2].n));
    yyerror("Missing ')'.");
  }
#line 9380 "y.tab.c" /* yacc.c:1646  */
    break;

  case 590:
#line 4305 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-4].n));
    free_node((yyvsp[-2].n));
    yyerror("Missing ')'.");
  }
#line 9391 "y.tab.c" /* yacc.c:1646  */
    break;

  case 591:
#line 4312 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-2].n));
    yyerrok;
  }
#line 9401 "y.tab.c" /* yacc.c:1646  */
    break;

  case 592:
#line 4318 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-2].n));
    yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
#line 9412 "y.tab.c" /* yacc.c:1646  */
    break;

  case 593:
#line 4325 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-2].n));
    yyerror("Missing ')'.");
  }
#line 9422 "y.tab.c" /* yacc.c:1646  */
    break;

  case 594:
#line 4331 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0;
    free_node((yyvsp[-2].n));
    yyerror("Missing ')'.");
  }
#line 9432 "y.tab.c" /* yacc.c:1646  */
    break;

  case 595:
#line 4336 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerrok; }
#line 9438 "y.tab.c" /* yacc.c:1646  */
    break;

  case 596:
#line 4338 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=0; yyerror("Missing ')'.");
    yyerror("Unexpected end of file.");
  }
#line 9447 "y.tab.c" /* yacc.c:1646  */
    break;

  case 597:
#line 4342 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerror("Missing ')'."); }
#line 9453 "y.tab.c" /* yacc.c:1646  */
    break;

  case 598:
#line 4343 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=0; yyerror("Missing ')'."); }
#line 9459 "y.tab.c" /* yacc.c:1646  */
    break;

  case 600:
#line 4348 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_ARRAY_LVALUE, (yyvsp[-1].n),0);
    COPY_LINE_NUMBER_INFO((yyval.n), (yyvsp[-2].n));
    free_node((yyvsp[-2].n));
  }
#line 9469 "y.tab.c" /* yacc.c:1646  */
    break;

  case 601:
#line 4354 "language.yacc" /* yacc.c:1646  */
    {
    int id = add_local_name((yyvsp[0].n)->u.sval.u.string,compiler_pop_type(),0);
    /* Note: Variable intentionally not marked as used. */
    if (id >= 0)
      (yyval.n)=mklocalnode(id,-1);
    else
      (yyval.n) = 0;
    free_node((yyvsp[0].n));
  }
#line 9483 "y.tab.c" /* yacc.c:1646  */
    break;

  case 602:
#line 4365 "language.yacc" /* yacc.c:1646  */
    { (yyval.n)=mknewintnode(0); }
#line 9489 "y.tab.c" /* yacc.c:1646  */
    break;

  case 603:
#line 4369 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n)=mknode(F_LVALUE_LIST,(yyvsp[-1].n),(yyvsp[0].n));
  }
#line 9497 "y.tab.c" /* yacc.c:1646  */
    break;

  case 604:
#line 4374 "language.yacc" /* yacc.c:1646  */
    { (yyval.n) = 0; }
#line 9503 "y.tab.c" /* yacc.c:1646  */
    break;

  case 605:
#line 4376 "language.yacc" /* yacc.c:1646  */
    {
    (yyval.n) = mknode(F_LVALUE_LIST,(yyvsp[-1].n),(yyvsp[0].n));
  }
#line 9511 "y.tab.c" /* yacc.c:1646  */
    break;

  case 607:
#line 4383 "language.yacc" /* yacc.c:1646  */
    {
    struct compiler_frame *f = Pike_compiler->compiler_frame;
    if (!f || (f->current_function_number < 0)) {
      (yyval.n) = mkstrnode(lfun_strings[LFUN___INIT]);
    } else {
      struct identifier *id =
	ID_FROM_INT(Pike_compiler->new_program, f->current_function_number);
      if (!id->name->size_shift) {
	int len;
	if ((len = strlen(id->name->str)) == id->name->len) {
	  /* Most common case. */
	  (yyval.n) = mkstrnode(id->name);
	} else {
	  struct pike_string *str =
	    make_shared_binary_string(id->name->str, len);
	  (yyval.n) = mkstrnode(str);
	  free_string(str);
	}
      } else {
	struct pike_string *str;
	struct array *split;
	MAKE_CONST_STRING(str, "\0");
	split = explode(id->name, str);
	(yyval.n) = mkstrnode(split->item->u.string);
	free_array(split);
      }
    }
  }
#line 9544 "y.tab.c" /* yacc.c:1646  */
    break;

  case 609:
#line 4415 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *a,*b;
    copy_shared_string(a,(yyvsp[-1].n)->u.sval.u.string);
    copy_shared_string(b,(yyvsp[0].n)->u.sval.u.string);
    free_node((yyvsp[-1].n));
    free_node((yyvsp[0].n));
    a=add_and_free_shared_strings(a,b);
    (yyval.n)=mkstrnode(a);
    free_string(a);
  }
#line 9559 "y.tab.c" /* yacc.c:1646  */
    break;

  case 611:
#line 4429 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *a,*b;
    copy_shared_string(a,(yyvsp[-2].n)->u.sval.u.string);
    copy_shared_string(b,(yyvsp[0].n)->u.sval.u.string);
    free_node((yyvsp[-2].n));
    free_node((yyvsp[0].n));
    a=add_and_free_shared_strings(a,b);
    (yyval.n)=mkstrnode(a);
    free_string(a);
  }
#line 9574 "y.tab.c" /* yacc.c:1646  */
    break;

  case 613:
#line 4444 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *a,*b;
    copy_shared_string(a,(yyvsp[-1].n)->u.sval.u.string);
    copy_shared_string(b,(yyvsp[0].n)->u.sval.u.string);
    free_node((yyvsp[-1].n));
    free_node((yyvsp[0].n));
    a=add_and_free_shared_strings(a,b);
    (yyval.n)=mkstrnode(a);
    free_string(a);
  }
#line 9589 "y.tab.c" /* yacc.c:1646  */
    break;

  case 614:
#line 4455 "language.yacc" /* yacc.c:1646  */
    {
    struct pike_string *a,*b;
    copy_shared_string(a,(yyvsp[-2].n)->u.sval.u.string);
    copy_shared_string(b,(yyvsp[0].n)->u.sval.u.string);
    free_node((yyvsp[-2].n));
    free_node((yyvsp[0].n));
    a=add_and_free_shared_strings(a,b);
    (yyval.n)=mkstrnode(a);
    free_string(a);
  }
#line 9604 "y.tab.c" /* yacc.c:1646  */
    break;

  case 616:
#line 4475 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("array"); }
#line 9610 "y.tab.c" /* yacc.c:1646  */
    break;

  case 617:
#line 4477 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("__attribute__"); }
#line 9616 "y.tab.c" /* yacc.c:1646  */
    break;

  case 618:
#line 4479 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("class"); }
#line 9622 "y.tab.c" /* yacc.c:1646  */
    break;

  case 619:
#line 4481 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("__deprecated__"); }
#line 9628 "y.tab.c" /* yacc.c:1646  */
    break;

  case 620:
#line 4483 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("enum"); }
#line 9634 "y.tab.c" /* yacc.c:1646  */
    break;

  case 621:
#line 4485 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("float");}
#line 9640 "y.tab.c" /* yacc.c:1646  */
    break;

  case 622:
#line 4487 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("function");}
#line 9646 "y.tab.c" /* yacc.c:1646  */
    break;

  case 623:
#line 4489 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("__FUNCTION__");}
#line 9652 "y.tab.c" /* yacc.c:1646  */
    break;

  case 624:
#line 4491 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("int"); }
#line 9658 "y.tab.c" /* yacc.c:1646  */
    break;

  case 625:
#line 4493 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("mapping"); }
#line 9664 "y.tab.c" /* yacc.c:1646  */
    break;

  case 626:
#line 4495 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("mixed"); }
#line 9670 "y.tab.c" /* yacc.c:1646  */
    break;

  case 627:
#line 4497 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("multiset"); }
#line 9676 "y.tab.c" /* yacc.c:1646  */
    break;

  case 628:
#line 4499 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("object"); }
#line 9682 "y.tab.c" /* yacc.c:1646  */
    break;

  case 629:
#line 4501 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("program"); }
#line 9688 "y.tab.c" /* yacc.c:1646  */
    break;

  case 630:
#line 4503 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("string"); }
#line 9694 "y.tab.c" /* yacc.c:1646  */
    break;

  case 631:
#line 4505 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("typedef"); }
#line 9700 "y.tab.c" /* yacc.c:1646  */
    break;

  case 632:
#line 4507 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("void"); }
#line 9706 "y.tab.c" /* yacc.c:1646  */
    break;

  case 633:
#line 4509 "language.yacc" /* yacc.c:1646  */
    {
    ref_push_string((yyvsp[0].n)->u.sval.u.string);
    low_yyreport(REPORT_ERROR, NULL, 0, parser_system_string,
		 1, "Unknown reserved symbol %s.");
    free_node((yyvsp[0].n));
  }
#line 9717 "y.tab.c" /* yacc.c:1646  */
    break;

  case 634:
#line 4519 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("inline"); }
#line 9723 "y.tab.c" /* yacc.c:1646  */
    break;

  case 635:
#line 4521 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("local"); }
#line 9729 "y.tab.c" /* yacc.c:1646  */
    break;

  case 636:
#line 4523 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("nomask"); }
#line 9735 "y.tab.c" /* yacc.c:1646  */
    break;

  case 637:
#line 4525 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("predef"); }
#line 9741 "y.tab.c" /* yacc.c:1646  */
    break;

  case 638:
#line 4527 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("private"); }
#line 9747 "y.tab.c" /* yacc.c:1646  */
    break;

  case 639:
#line 4529 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("protected"); }
#line 9753 "y.tab.c" /* yacc.c:1646  */
    break;

  case 640:
#line 4531 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("public"); }
#line 9759 "y.tab.c" /* yacc.c:1646  */
    break;

  case 641:
#line 4533 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("optional"); }
#line 9765 "y.tab.c" /* yacc.c:1646  */
    break;

  case 642:
#line 4535 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("variant"); }
#line 9771 "y.tab.c" /* yacc.c:1646  */
    break;

  case 643:
#line 4537 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("static"); }
#line 9777 "y.tab.c" /* yacc.c:1646  */
    break;

  case 644:
#line 4539 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("extern"); }
#line 9783 "y.tab.c" /* yacc.c:1646  */
    break;

  case 645:
#line 4541 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("final");}
#line 9789 "y.tab.c" /* yacc.c:1646  */
    break;

  case 646:
#line 4543 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("do"); }
#line 9795 "y.tab.c" /* yacc.c:1646  */
    break;

  case 647:
#line 4545 "language.yacc" /* yacc.c:1646  */
    { yyerror("else without if."); }
#line 9801 "y.tab.c" /* yacc.c:1646  */
    break;

  case 648:
#line 4547 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("return"); }
#line 9807 "y.tab.c" /* yacc.c:1646  */
    break;

  case 649:
#line 4549 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("import"); }
#line 9813 "y.tab.c" /* yacc.c:1646  */
    break;

  case 650:
#line 4551 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("inherit"); }
#line 9819 "y.tab.c" /* yacc.c:1646  */
    break;

  case 651:
#line 4553 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("catch"); }
#line 9825 "y.tab.c" /* yacc.c:1646  */
    break;

  case 652:
#line 4555 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("gauge"); }
#line 9831 "y.tab.c" /* yacc.c:1646  */
    break;

  case 653:
#line 4557 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("lambda"); }
#line 9837 "y.tab.c" /* yacc.c:1646  */
    break;

  case 654:
#line 4559 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("sscanf"); }
#line 9843 "y.tab.c" /* yacc.c:1646  */
    break;

  case 655:
#line 4561 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("switch"); }
#line 9849 "y.tab.c" /* yacc.c:1646  */
    break;

  case 656:
#line 4563 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("typeof"); }
#line 9855 "y.tab.c" /* yacc.c:1646  */
    break;

  case 657:
#line 4565 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("break"); }
#line 9861 "y.tab.c" /* yacc.c:1646  */
    break;

  case 658:
#line 4567 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("case"); }
#line 9867 "y.tab.c" /* yacc.c:1646  */
    break;

  case 659:
#line 4569 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("continue"); }
#line 9873 "y.tab.c" /* yacc.c:1646  */
    break;

  case 660:
#line 4571 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("default"); }
#line 9879 "y.tab.c" /* yacc.c:1646  */
    break;

  case 661:
#line 4573 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("for"); }
#line 9885 "y.tab.c" /* yacc.c:1646  */
    break;

  case 662:
#line 4575 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("foreach"); }
#line 9891 "y.tab.c" /* yacc.c:1646  */
    break;

  case 663:
#line 4577 "language.yacc" /* yacc.c:1646  */
    { yyerror_reserved("if"); }
#line 9897 "y.tab.c" /* yacc.c:1646  */
    break;


#line 9901 "y.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 4590 "language.yacc" /* yacc.c:1906  */


static void yyerror_reserved(const char *keyword)
{
  my_yyerror("%s is a reserved word.", keyword);
}

static struct pike_string *get_new_name(struct pike_string *prefix)
{
  char buf[40];
  /* Generate a name for a global symbol... */
  sprintf(buf,"__lambda_%ld_%ld_line_%d",
	  (long)Pike_compiler->new_program->id,
	  (long)(Pike_compiler->local_class_counter++ & 0xffffffff), /* OSF/1 cc bug. */
	  (int) THIS_COMPILATION->lex.current_line);
  if (prefix) {
    struct string_builder sb;
    init_string_builder_alloc(&sb, prefix->len + strlen(buf) + 1,
			      prefix->size_shift);
    string_builder_shared_strcat(&sb, prefix);
    string_builder_putchar(&sb, 0);
    string_builder_strcat(&sb, buf);
    return finish_string_builder(&sb);
  }
  return make_shared_string(buf);
}


static int low_islocal(struct compiler_frame *f,
		       struct pike_string *str)
{
  int e;
  for(e=f->current_number_of_locals-1;e>=0;e--)
    if(f->variable[e].name==str) {
      f->variable[e].flags |= LOCAL_VAR_IS_USED;
      return e;
    }
  return -1;
}


/* Add a local variable to the current function in frame.
 * NOTE: Steals the references to type and def, but not to str.
 */
int low_add_local_name(struct compiler_frame *frame,
		       struct pike_string *str,
		       struct pike_type *type,
		       node *def)
{

  if (str->len) {
    int tmp=low_islocal(frame,str);
    if(tmp>=0 && tmp >= frame->last_block_level)
    {
      my_yyerror("Duplicate local variable %S, "
		 "previous declaration on line %d\n",
		 str, frame->variable[tmp].line);
    }

    if(type == void_type_string)
    {
      my_yyerror("Local variable %S is void.\n", str);
    }
  }

  debug_malloc_touch(def);
  debug_malloc_touch(type);
  debug_malloc_touch(str);
  /* NOTE: The number of locals can be 0..255 (not 256), due to
   *       the use of READ_INCR_BYTE() in apply_low.h.
   */
  if (frame->current_number_of_locals == MAX_LOCAL-1)
  {
    my_yyerror("Too many local variables: no space for local variable %S.",
	       str);
    free_type(type);
    if (def) free_node(def);
    return -1;
  } else {
    int var = frame->current_number_of_locals;

#ifdef PIKE_DEBUG
    check_type_string(type);
#endif /* PIKE_DEBUG */
    if (pike_types_le(type, void_type_string)) {
      if (Pike_compiler->compiler_pass != 1) {
	yywarning("Declaring local variable %S with type void "
		  "(converted to type zero).", str);
      }
      free_type(type);
      copy_pike_type(type, zero_type_string);
    }
    frame->variable[var].type = type;
    frame->variable[var].name = str;
    reference_shared_string(str);
    frame->variable[var].def = def;

    frame->variable[var].line = THIS_COMPILATION->lex.current_line;
    copy_shared_string(frame->variable[var].file,
		       THIS_COMPILATION->lex.current_file);

    if (pike_types_le(void_type_string, type)) {
      /* Don't warn about unused voidable variables. */
      frame->variable[var].flags = LOCAL_VAR_IS_USED;
    } else {
      frame->variable[var].flags = 0;
    }

    frame->current_number_of_locals++;
    if(frame->current_number_of_locals > frame->max_number_of_locals)
    {
      frame->max_number_of_locals = frame->current_number_of_locals;
    }

    return var;
  }
}


/* argument must be a shared string */
/* Note that this function eats a reference to 'type' */
/* If def is nonzero, it also eats a ref to def */
int add_local_name(struct pike_string *str,
		   struct pike_type *type,
		   node *def)
{
  return low_add_local_name(Pike_compiler->compiler_frame,
			    str,
			    type,
			    def);
}

/* Mark local variables declared in a multi-assign or sscanf expression
 * as used. */
static void mark_lvalues_as_used(node *n)
{
  while (n && n->token == F_LVALUE_LIST) {
    if (!CAR(n)) {
      /* Can happen if a variable hasn't been declared. */
    } else if (CAR(n)->token == F_ARRAY_LVALUE) {
      mark_lvalues_as_used(CAAR(n));
    } else if ((CAR(n)->token == F_LOCAL) && !(CAR(n)->u.integer.b)) {
      Pike_compiler->compiler_frame->variable[CAR(n)->u.integer.a].flags |=
	LOCAL_VAR_IS_USED;
    }
    n = CDR(n);
  }
}

#if 0
/* Note that this function eats a reference to each of
 * 'type' and 'initializer', but not to 'name'.
 * Note also that 'initializer' may be NULL.
 */
static node *add_protected_variable(struct pike_string *name,
				    struct pike_type *type,
				    int depth,
				    node *initializer)
{
  struct compiler_frame *f = Pike_compiler->compiler_frame;
  int i;
  int id;
  node *n = NULL;

  if (initializer) {
    /* FIXME: We need to pop levels off local and external variables here. */
  }

  for(i = depth; f && i; i--) {
    f->lexical_scope |= SCOPE_SCOPED;
    f = f->previous;
  }
  if (!f) {
    int parent_depth = i;
    struct program_state *p = Pike_compiler;
    struct pike_string *tmp_name;
    while (i--) {
      if (!p->previous) {
	my_yyerror("Too many levels of protected (%d, max:%d).",
		   depth, depth - (i+1));
	parent_depth -= i+1;
	break;
      }
      p->new_program->flags |= PROGRAM_USES_PARENT;
      p = p->previous;
    }
    
    tmp_name = get_new_name(name);
    id = define_parent_variable(p, tmp_name, type,
				ID_PROTECTED|ID_PRIVATE|ID_INLINE);
    free_string(tmp_name);
    if (id >= 0) {
      if (def) {
	p->init_node =
	  mknode(F_COMMA_EXPR, Pike_compiler->init_node,
		 mkcastnode(void_type_string,
			    mknode(F_ASSIGN, initializer,
				   mkidentifiernode(id))));
	initializer = NULL;
      }
      n = mkexternalnode(id, parent_depth);
    }
  } else if (depth) {
    f->lexical_scope|=SCOPE_SCOPE_USED;
    tmp_name = get_new_name(name);
    id = low_add_local_name(f, tmp_name, type, NULL);
    free_string(tmp_name);
    if(f->min_number_of_locals < id+1)
      f->min_number_of_locals = id+1;
    if (initializer) {
      /* FIXME! */
      yyerror("Initializers not yet supported for protected variables with function scope.");
    }
    n = mklocalnode(id, depth);
  }
  id = add_local_name(name, type, n);
  if (id >= 0) {
    if (initializer) {
      return mknode(F_ASSIGN, initializer, mklocalnode(id,0));
    }
    return mklocalnode(id, 0);
  }
  if (initializer) {
    free_node(initializer);
  }
  return NULL;
}
#endif /* 0 */

int islocal(struct pike_string *str)
{
  return low_islocal(Pike_compiler->compiler_frame, str);
}

/* argument must be a shared string */
static node *lexical_islocal(struct pike_string *str)
{
  int e,depth=0;
  struct compiler_frame *f=Pike_compiler->compiler_frame;
  
  while(1)
  {
    for(e=f->current_number_of_locals-1;e>=0;e--)
    {
      if(f->variable[e].name==str)
      {
	struct compiler_frame *q=Pike_compiler->compiler_frame;

	f->variable[e].flags |= LOCAL_VAR_IS_USED;

	while(q!=f) 
	{
	  q->lexical_scope|=SCOPE_SCOPED;
	  q=q->previous;
	}

	if(depth) {
	  q->lexical_scope|=SCOPE_SCOPE_USED;

	  if(q->min_number_of_locals < e+1)
	    q->min_number_of_locals = e+1;
	}

	if(f->variable[e].def) {
	  /*fprintf(stderr, "Found prior definition of \"%s\"\n", str->str); */
	  return copy_node(f->variable[e].def);
	}

	return mklocalnode(e,depth);
      }
    }
    if(!(f->lexical_scope & SCOPE_LOCAL)) return 0;
    depth++;
    f=f->previous;
  }
}

static node *safe_inc_enum(node *n)
{
  JMP_BUF recovery;
  STACK_LEVEL_START(0);

  if (SETJMP(recovery)) {
    handle_compile_exception ("Bad implicit enum value (failed to add 1).");
    push_int(0);
  } else {
    if (n->token != F_CONSTANT) Pike_fatal("Bad node to safe_inc_enum().\n");
    push_svalue(&n->u.sval);
    push_int(1);
    f_add(2);
  }
  UNSETJMP(recovery);
  STACK_LEVEL_DONE(1);
  free_node(n);
  n = mkconstantsvaluenode(Pike_sp-1);
  pop_stack();
  return n;
}

static node *find_versioned_identifier(struct pike_string *identifier,
				       int major, int minor)
{
  struct compilation *c = THIS_COMPILATION;
  int old_major = Pike_compiler->compat_major;
  int old_minor = Pike_compiler->compat_minor;
  struct svalue *efun = NULL;
  node *res = NULL;

  change_compiler_compatibility(major, minor);

  if(Pike_compiler->last_identifier)
    free_string(Pike_compiler->last_identifier);
  copy_shared_string(Pike_compiler->last_identifier, identifier);

  /* Check predef:: first, and then the modules. */

  if (TYPEOF(c->default_module) == T_MAPPING) {
    if ((efun = low_mapping_string_lookup(c->default_module.u.mapping,
					  identifier)))
      res = mkconstantsvaluenode(efun);
  }
  else if (TYPEOF(c->default_module) != T_INT) {
    JMP_BUF tmp;
    if (SETJMP (tmp)) {
      handle_compile_exception ("Couldn't index %d.%d "
				"default module with \"%S\".",
				major, minor, identifier);
    } else {
      push_svalue(&c->default_module);
      ref_push_string(identifier);
      f_index (2);
      if (!IS_UNDEFINED(Pike_sp - 1))
	res = mkconstantsvaluenode(Pike_sp - 1);
      pop_stack();
    }
    UNSETJMP(tmp);
  }

  if (!res && !(res = resolve_identifier(identifier))) {
    if((Pike_compiler->flags & COMPILATION_FORCE_RESOLVE) ||
       (Pike_compiler->compiler_pass==2)) {
      my_yyerror("Undefined identifier %d.%d::%S.",
		 major, minor, identifier);
    }else{
      res = mknode(F_UNDEFINED, 0, 0);
    }
  }

  change_compiler_compatibility(old_major, old_minor);

  return res;
}

static int call_handle_import(struct pike_string *s)
{
  struct compilation *c = THIS_COMPILATION;
  int args;

  ref_push_string(s);
  ref_push_string(c->lex.current_file);
  if (c->handler && c->handler->prog) {
    ref_push_object(c->handler);
    args = 3;
  }
  else args = 2;

  if (safe_apply_handler("handle_import", c->handler, c->compat_handler,
			 args, BIT_MAPPING|BIT_OBJECT|BIT_PROGRAM|BIT_ZERO))
    if (TYPEOF(Pike_sp[-1]) != T_INT)
      return 1;
    else {
      pop_stack();
      my_yyerror("Couldn't find module to import: %S", s);
    }
  else
    handle_compile_exception ("Error finding module to import");

  return 0;
}

void cleanup_compiler(void)
{
}
