/* whitefish main includefile */

#if defined(__i486__) || defined(__i386__)
#define HANDLES_UNALIGNED_READ
#endif
