
void init_blobs_program();
void exit_blobs_program();
