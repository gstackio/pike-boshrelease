/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 6f8170355c74f8e6beebbb1269b9a7c440b1187b $
*/

#ifndef PIPE_MACHINE_H
#define PIPE_MACHINE_H

@TOP@
@BOTTOM@

#endif
