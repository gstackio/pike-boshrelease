/*
|| This file is part of Pike. For copyright information see COPYRIGHT.
|| Pike is distributed under GPL, LGPL and MPL. See the file COPYING
|| for more information.
|| $Id: 16dcd92ea6f7173971c00e1d2b901a01c96ac2dc $
*/

#ifndef COMMONLOG_MACHINE_H
#define COMMONLOG_MACHINE_H

@TOP@
@BOTTOM@

#endif /* COMMONLOG_MACHINE_H */
