/*
 * $Id: 1789230fa5c7cd9f1d9b680f103d6db51415a4be $
 */

void pike_init_CircularList_module(void);
void pike_exit_CircularList_module(void);

