#if __VERSION__ > 7.6
#warning opengl.h is deprecated.
#endif
import GL;
import GLU;
#if constant(GLUT.GLUT_WINDOW_X)
import GLUT;
#endif
