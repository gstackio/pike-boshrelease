#if __VERSION__ > 7.6
#warning getopt.h is deprecated.
#endif
import Getopt;
